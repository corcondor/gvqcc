'''V58 measured prefix compiler and exact affine-line transition between
mutually exclusive prefix leaves. Integrates direct/toggle phase hybrid.'''
from v58_hybrid import *
from functools import lru_cache
from compile_affine import mcx,Op
@lru_cache(None)
def dp(n,c,Q,clear):
 if n<=1:return 0,('dirty',)
 if n==2:return (0,('erase',)) if clear else (1,('dirty',))
 # n+1 <= Q. Only the explicitly supplied c clean scratch slots
 # are assumed clean. Dirty multi-control fallback restores all others.
 best=(sum(o.raw==49 for o in mcx(list(range(n)),n,Q)),('dirty',))
 if not c:return best
 for k in range(2,n):
  a=dp(k,c-1,Q,False)[0];b=dp(n-k+1,c-1,Q,clear)[0];z=dp(k,c-1,Q,True)[0]
  if a+b+z<best[0]:best=(a+b+z,('split',k))
 return best

class Routed(Hybrid):
 def __init__(self,Q,scale,S,mode,route_policy):super().__init__(Q,scale,S,mode);self.route_policy=route_policy
 def andxor(self,cs,t,free,clear=False):
  n=len(cs);cost,op=dp(n,len(free),self.Q,clear)
  if op[0]=='erase':self.erase(t,cs);return
  if op[0]=='dirty':self.ops+=mcx(cs,t,self.Q);return
  k=op[1];d=free[0];rem=free[1:];self.andxor(cs[:k],d,rem);self.andxor(cs[k:]+[d],t,rem,clear);self.andxor(cs[:k],d,rem,True)
 def prefixcost(self,d):
  return dp(d,self.Q-W-1,self.Q,False)[0]+dp(d,self.Q-W-1,self.Q,True)[0] if d else 0
 def prefix(self,d,p,t,clear=False):
  cs=list(range(W-d,W));neg=[q for q in cs if not(p>>(q-W+d)&1)];free=[q for q in range(W,self.Q)if q!=t]
  for q in neg:self.op(17,q)
  self.andxor(cs,t,free,clear)
  for q in neg[::-1]:self.op(17,q)
 def transition(self,d,p,q,t):
  assert p!=q;cs=list(range(W-d,W));delta=p^q;j=next(bits(delta));z=cs[j];ops=[]
  for k in bits(delta):
   if k!=j:ops.append(Op(33,(z,cs[k])))
  self.ops+=ops;v=p^((delta^(1<<j)) if (p>>j)&1 else 0);neg=[cs[k]for k in range(d)if k!=j and not(v>>k&1)];ctr=[cs[k]for k in range(d)if k!=j];free=[u for u in range(W,self.Q)if u!=t]
  for u in neg:self.op(17,u)
  self.andxor(ctr,t,free)
  for u in neg[::-1]:self.op(17,u)
  self.ops+=ops[::-1];self.stats['prefix_transitions']+=1
 def routed(self,root,scale):
  levels=defaultdict(list)
  def visit(z):
   if z.data is not None:levels[z.d].append(z)
   else:
    for c in z.ch.values():visit(c)
  visit(root);f=self.flags[0];free=self.flags[1:]
  for d,L in sorted(levels.items()):
   # minimum cost on equal-depth affine transitions: choose nearest Hamming neighbor for CX tie-break.
   cur=min(L,key=lambda z:z.p);L.remove(cur);self.prefix(d,cur.p,f);self.leaf_basis(cur,f,free)
   while L:
    nxt=min(L,key=lambda z:((z.p^cur.p).bit_count(),z.p));L.remove(nxt);self.transition(d,cur.p,nxt.p,f);self.leaf_basis(nxt,f,free);cur=nxt
   self.prefix(d,cur.p,f,True)

def run(Q,mode,policy,S):
 t=time.time();P=json.load(open('coset_plan_0_adaptive.json'));scale=MOD//P['scale'];groups,*_=data(P);a=dict(json.load(open('reciprocal_assignment.json'))['assignment']);rep=defaultdict(list)
 for j,(bi,s,V,H,v,o) in enumerate(groups):
  u=a[j];assert choices(u,V,H,o[u])==o;rep[bi].append((u,V,H,o[u]))
 e=Routed(Q,scale,S,mode,policy);root=Trie(0,0)
 for i,b in enumerate(P['blocks']):
  d=W-b['k'];p=b['start']>>b['k'];z=root
  for j in range(d):
   bit=p>>(d-j-1)&1
   if bit not in z.ch:z.ch[bit]=Trie(z.d+1,z.p*2+bit)
   z=z.ch[bit]
  z.data=rep[i]
 if policy=='route':e.routed(root,scale)
 else:e.split(root,scale)
 e.sweep(None,list(e.plain.items()),0,0,[],[]);ref=NativeKMB.read('reference_header.kmb');stem=f'v58_prefix_{mode}_{policy}_Q{Q}';p=Path(stem+'.kmb');write_hmr(ref,p,e.ops,e.angles,Q,True);c=Counter(o.raw for o in e.ops)
 r=dict(width=Q,mode=mode,policy=policy,ops=len(e.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],**e.stats,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t);r['proxy']=Q*(r['ccx']+COST*r['generic']);Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles],ledger=e.ledger),separators=(',',':')));print(r,flush=True);return stem
if __name__=='__main__':
 mode=sys.argv[1];S=set(json.load(open('v58_selection_'+mode+'.json'))['frequencies'])
 for Q in map(int,sys.argv[2:]):
  for policy in ('tree','route'):run(Q,mode,policy,S)
