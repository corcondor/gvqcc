"""Joint lattice projection on signed Walsh cosets; independent full-domain replay required."""
import numpy as np,json,sys,time,collections,copy,math
from pathlib import Path
from scipy.linalg import lstsq
P=json.load(open('parent.plan.json'));S=P['scale'];N=P['legal'];eps=P['epsilon']
def fwht(a):
 a=a.copy();k=1
 while k<len(a):
  b=a.reshape(-1,2*k);u=b[:,:k].copy();v=b[:,k:].copy();b[:,:k]=u+v;b[:,k:]=u-v;k*=2
 return a
def spectrum(cos):
 cols=[];fs=set()
 for s,V,H,a in cos:
  z={s:1}
  for v,h in zip(V,H):z.update({x^v:y*h for x,y in list(z.items())})
  cols.append(z);fs.update(z)
 fs=sorted(fs);I={f:i for i,f in enumerate(fs)};A=np.zeros((len(fs),len(cols)),np.int8)
 for j,c in enumerate(cols):
  for f,v in c.items():A[I[f],j]=v
 return np.array(fs),A,np.array([1<<len(c[1]) for c in cos],np.int64)
def pack(b,aa):
 cos=[];coeff=collections.Counter()
 for (s,V,H,_),a in zip(b['cosets'],aa):
  a=int(a)
  if not a:continue
  assert a%(1<<len(V))==0
  cos.append([s,V,H,a]);v={s:a//(1<<len(V))}
  for u,h in zip(V,H):v.update({k^u:z*h for k,z in list(v.items())})
  coeff.update(v)
 return dict(b,cosets=cos,coeff={str(s):v for s,v in coeff.items() if v})
def run_block(b,minmargin):
 k=b['k'];L=1<<k;st=b['start'];valid=min(L,N-st+1);n=len(b['cosets']);I,A,den=spectrum(b['cosets']);A64=A.astype(np.int64);x=np.arange(st,st+L,dtype=np.float64);target=S/np.sqrt(x);tol=eps/np.sqrt(x)
 old=np.array([c[-1] for c in b['cosets']],dtype=np.int64)
 def test(a):
  u=np.zeros(L,np.int64);u[I]=A64@(a//den);r=fwht(u);e=r[:valid]-target[:valid];return float(np.min(tol[:valid]-np.abs(e)))
 m0=test(old);floor=min(m0,max(minmargin,0.08*float(tol[:valid].min())))
 if L<8:return b,dict(start=st,old=n,new=n,margin=m0,step=0)
 F=fwht(target)/L;B=A.astype(np.float64)/den;v=lstsq(B,F[I],lapack_driver='gelsy')[0]
 best=old;bestm=m0;bestgrid=0;tested=0
 for power in range(int(np.floor(np.log2(tol[:valid].min())))-1,1,-1):
  step=1<<power
  if step<4:continue
  for center in (v,old.astype(float),.5*(v+old)):
   a=np.rint(center/step).astype(np.int64)*step;tested+=1;m=test(a)
   if m>=floor:
    merit=(np.count_nonzero(a),-step,-m)
    if merit<(np.count_nonzero(best),-bestgrid,-bestm):best=a;bestm=m;bestgrid=step
  if bestgrid and power<bestgrid.bit_length()-4:break
 new=pack(b,best);return new,dict(start=st,k=k,old=n,new=len(new['cosets']),old_margin=m0,margin=bestm,step=bestgrid,tested=tested)
def main():
 t=time.time();out=copy.deepcopy(P);stats=[];m=float(sys.argv[1]) if len(sys.argv)>1 else 270000
 for i,b in enumerate(P['blocks']):
  q,r=run_block(b,m);stats.append(r);out['blocks'][i]=q;print(i,r,flush=True)
 out['cosets']=sum(len(b['cosets']) for b in out['blocks']);out['lattice_stats']=stats;out['lattice_seconds']=time.time()-t
 Path('lattice.plan.json').write_text(json.dumps(out));print('TOTAL',P['cosets'],out['cosets'],'seconds',time.time()-t,flush=True)
if __name__=='__main__':main()
