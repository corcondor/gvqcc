"""Finite-domain nonlinear coset exchange via Chebyshev refitting + residual pricing.
New affine-subspace generators are discovered from Fourier residuals, not a
fixed dictionary. Full-domain check uses integer FWHT on every proposal;
final oracle validation is separate, exact 128-bit. No global-optimum claim.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
import sys,time,json,math,collections,itertools,copy
from pathlib import Path
import numpy as np
from scipy.optimize import linprog
from lattice import fwht,spectrum,pack,P,S,N,eps

def calc(cos,k):
 if not cos:return np.zeros(1<<k,np.int64)
 I,A,den=spectrum(cos);z=np.zeros(1<<k,np.int64);z[I]=A.astype(np.int64)@(np.array([a[-1] for a in cos],np.int64)//den);return fwht(z)

def features(cos,ix,par):
 out=[]
 for s,V,H,a in cos:
  v=(1-2*par[ix&s])
  for u,h in zip(V,H):v=v*((1-2*par[ix&u])==h)
  out.append(v)
 return np.stack(out,axis=1).astype(np.float64)

def fit(cos,b,target,tol,valid,par,reserve,rng,passes=5):
 # exact old integer baseline, optimize only small deltas normalized by local tolerance
 k=b['k'];L=1<<k;base=calc(cos,k);err=base[:valid]-target[:valid];T=float(np.min(tol[:valid]));old=np.array([c[-1] for c in cos],np.int64);den=np.array([1<<len(c[1]) for c in cos],np.int64)
 n=len(cos);samples=np.unique(np.r_[np.linspace(0,valid-1,min(valid,max(128,3*n)),dtype=int),rng.choice(valid,min(valid,2*n),replace=False),np.argpartition(tol[:valid]-np.abs(err),min(valid-1,max(32,n)))[:min(valid,max(32,n))]])
 for j in range(passes):
  M=features(cos,samples,par);e=err[samples]/T;t=tol[samples]/T
  A=np.vstack([np.c_[M,-t],np.c_[-M,-t]]);rhs=np.r_[-e,e];c=np.r_[np.zeros(n),1.]
  r=linprog(c,A_ub=A,b_ub=rhs,bounds=[(-8,8)]*n+[(0,None)],method='highs',options={'time_limit':0.7})
  if not r.success:return None,None,j
  aa=np.rint((old+r.x[:-1]*T)/den).astype(np.int64)*den;D=[[*c[:3],int(a)]for c,a in zip(cos,aa) if a]
  y=calc(D,k);m=tol[:valid]-np.abs(y[:valid]-target[:valid]);margin=float(m.min())
  if margin>=reserve:return D,margin,j+1
  if j==passes-1:return None,margin,j+1
  worst=np.argpartition(m,min(valid-1,max(32,n//2)))[:min(valid,max(32,n//2))];samples=np.unique(np.r_[samples,worst]);
 return None,None,passes

def residual_candidates(b,cos,target,par,nmax=12):
 L=1<<b['k'];r=target-calc(cos,b['k']);F=fwht(r)/L;covered=set()
 for s,V,H,a in cos:
  support={s}
  for u in V:support|={s^u for s in list(support)}
  covered|=support
 ix=np.argsort(-np.abs(F))[:max(100,nmax*8)];ix=[int(s)for s in ix if s not in covered][:4*nmax];A=[];used=set()
 # Pricing: pair similar residual magnitudes into a fresh rank-one coset, or
 # create a new singleton. Pairing spans all missing frequencies considered.
 for s in ix:
  if s in used:continue
  v=F[s];ls=[t for t in ix if t!=s and t not in used and abs(abs(F[t])-abs(v))<=.25*abs(v)]
  if ls:
   t=min(ls,key=lambda t:((s^t).bit_count(),abs(abs(F[t])-abs(v))));a=int(round((v+np.sign(v)*abs(F[t]))/2));A.append([s,[s^t],[1 if F[t]*v>0 else -1],2*a]);used.update((s,t))
  else:A.append([s,[],[],int(round(v))]);used.add(s)
  if len(A)>=nmax:break
 return A

def runblock(b,minimum,seed):
 L=1<<b['k'];st=b['start'];valid=min(L,N-st+1);n=len(b['cosets']);x=np.arange(st,st+L,dtype=np.float64);target=S/np.sqrt(x);tol=eps/np.sqrt(x);par=np.fromiter((i.bit_count()&1 for i in range(L)),np.int8,L);orig=b['cosets'];m0=float(np.min((tol-np.abs(calc(orig,b['k'])-target))[:valid]));reserve=min(m0,max(minimum,0.07*float(tol[:valid].min())));rng=np.random.default_rng(seed+st);best=orig;bm=m0;attempts=[]
 if n<24:return b,dict(start=st,n=n,new=n,margin=m0,attempts=0)
 # Geometric coarse-to-fine search. Use weighted strength (rank-2 support
 # occupies fewer rows), then synthesize new generators for residual peaks.
 for frac in (.22,.12,.06,.03,.015):
  base=best;nc=len(base);d=max(1,int(nc*frac));order=sorted(range(nc),key=lambda j:abs(base[j][-1])/(2**(.5*len(base[j][1]))));rm=set(order[:d]);surv=[c for j,c in enumerate(base)if j not in rm]
  configs=[surv]
  if d>=3:
   extra=residual_candidates(b,surv,target,par,max(1,d//3));configs.append(surv+extra)
  for ci,c in enumerate(configs):
   if len(c)>=len(best):continue
   out,m,nit=fit(c,b,target,tol,valid,par,reserve,rng,passes=4);attempts.append([d,ci,len(c),m,nit])
   if out is not None and len(out)<len(best):best=out;bm=m;break
  # Large old term count near the phase budget; 2 more exact integer exchange
  # rounds can follow when the last one succeeded.
 b2=pack(dict(b,cosets=best),[c[-1]for c in best]);return b2,dict(start=st,n=n,new=len(best),old_margin=m0,margin=bm,reserve=reserve,attempts=attempts)
def main():
 from concurrent.futures import ProcessPoolExecutor
 t=time.time();src=sys.argv[1] if len(sys.argv)>1 else 'parent.plan.json';p=json.load(open(src));minimum=float(sys.argv[2])if len(sys.argv)>2 else 269000.;out=sys.argv[3]if len(sys.argv)>3 else 'sparse.plan.json'
 with ProcessPoolExecutor(max_workers=4)as E:
  jobs=[E.submit(runblock,b,minimum,781)for b in p['blocks']]
  rr=[]
  for i,j in enumerate(jobs):
   b,r=j.result();p['blocks'][i]=b;rr.append(r);print(i,r['start'],r['n'],'->',r['new'],'margin',r['margin'],'attempts',len(r['attempts']) if isinstance(r['attempts'],list)else 0,flush=True)
 p['sparse_stats']=rr;p['cosets']=sum(len(b['cosets'])for b in p['blocks']);p['sparse_seconds']=time.time()-t;Path(out).write_text(json.dumps(p));print('TOTAL',sum(r['n']for r in rr),'->',p['cosets'],'sec',time.time()-t,flush=True)
if __name__=='__main__':main()
