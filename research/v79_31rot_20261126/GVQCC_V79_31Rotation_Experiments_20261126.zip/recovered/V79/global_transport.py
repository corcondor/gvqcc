"""Strict-width whole-oracle basis-subspace transport (research only)."""
import json,random,collections,functools,sys,hashlib,time
from pathlib import Path
from conditional_basis_prefix import Basis,Trie,leaf_groups,pivot_basis,reduce,batches
from emit_coset import MOD,W,bits,NativeKMB,choices
from emit_coset_hmr import write_hmr
from reciprocal import data

def independent(vs):
 p={};out=[]
 for v in vs:
  u=v
  while u and u.bit_length()-1 in p:u^=p[u.bit_length()-1]
  if u:p[u.bit_length()-1]=u;out.append(v)
 return out

def intersection(A,B):
 piv={}
 for v in A:
  u=v
  while u and u.bit_length()-1 in piv:u^=piv[u.bit_length()-1][0]
  assert u;piv[u.bit_length()-1]=(u,0)
 out=[]
 for j,v in enumerate(B):
  u=v;c=1<<j
  while u and u.bit_length()-1 in piv:
   z,k=piv[u.bit_length()-1];u^=z;c^=k
  if u:piv[u.bit_length()-1]=(u,c)
  else:
   z=0
   for k in bits(c):z^=B[k]
   assert z;out.append(z)
 assert len(out)==len(A)+len(B)-len(independent(A+B))
 return out

def rankcost(A,B):return len(independent(A+B))-len(A)

def basis_xors(A,B):
 assert len(A)==len(B);T=pivot_basis(A);M=[]
 for v in B:
  r,c=reduce(v,T);assert r==0;M.append(c)
 ops=[];n=len(A)
 for i in range(n):
  if not M[i]>>i&1:
   j=next(j for j in range(i+1,n)if M[j]>>i&1)
   for a,b in [(j,i),(i,j),(j,i)]:M[b]^=M[a];ops.append((a,b))
  for j in range(n):
   if j!=i and M[j]>>i&1:M[j]^=M[i];ops.append((i,j))
 assert M==[1<<i for i in range(n)]
 ops=ops[::-1];c=A[:]
 for a,b in ops:c[b]^=c[a]
 assert c==B
 return ops

def plan_rank_cost(plan):
 A=[];cost=0
 for B,_ in plan:cost+=rankcost(A,B);A=B
 return cost

def order_plan(plan,seed):
 rng=random.Random(seed);rem=list(range(len(plan)));A=[];out=[]
 while rem:
  j=min(rem,key=lambda i:(rankcost(A,plan[i][0]),-len(plan[i][1]),i if not seed else rng.random()))
  out.append(plan[j]);A=plan[j][0];rem.remove(j)
 best=plan_rank_cost(out)
 for _ in range(12):
  if len(out)<2:break
  i,j=rng.sample(range(len(out)),2);t=out[:];t[i],t[j]=t[j],t[i];v=plan_rank_cost(t)
  if v<best:out=t;best=v
 return out

def groups_policy(cosets,scale,policy,seed):
 if not policy:return leaf_groups(cosets,scale)
 rng=random.Random(seed);base=[];sub=collections.defaultdict(lambda:collections.defaultdict(list));score=collections.Counter();chosen=collections.Counter()
 for s,V,H,a in cosets:
  if len(V)==1:score[V[0],H[0]]+=4
  elif len(V)==2:
   for v,h in list(zip(V,H))+[(V[0]^V[1],H[0]*H[1])]:score[v,h]+=1
 items=sorted(cosets,key=lambda r:(len(r[1]),-abs(r[3])))
 if policy>=3:rng.shuffle(items);items.sort(key=lambda r:len(r[1]))
 for s,V,H,a in items:
  a*=scale
  if not V:base.append((s,a));continue
  if len(V)==1:
   x=(V[0],H[0]);sub[x][None].append((s,a));chosen[x]+=1;continue
  opts=list(zip(V,H))+[(V[0]^P2(V),H[0]*H[1])]
  def merit(t):return (score[t]+(policy+1)*bool(t in chosen)+2*bool((t[0],-t[1])in chosen),-t[0].bit_count(),rng.random())
  u=max(opts,key=merit);v=min((t for t in opts if t!=u),key=lambda t:(-score[t],t[0].bit_count(),t[0]));chosen[u]+=1;sub[u][v].append((s,a))
 return base,sub

def P2(V):return V[1]

class Transport(Basis):
 def __init__(self,Q,scale,search=1):super().__init__(Q,scale);self.search=search;self.transported=0;self.basis_changes=0
 def plan(self,z,cap):
  key=(id(z),cap)
  if key in self.plan_cache:return self.plan_cache[key]
  best=None
  for pol in range(self.search+1):
   base,sub=groups_policy(z.data,self.scale,pol,z.p+37*pol);keys=sorted(sub);n=len(keys)
   second=sum(sum(s is not None for s in Z)for Z in sub.values());opts=[(n,None)]
   if cap and keys:
    for keep in sorted({0,min(2,cap-1),max(0,cap//2),max(0,cap-2)}):
     for seed in range(2):
      _,p=batches(keys,cap,seed,keep);p=order_plan(p,seed);opts.append((plan_rank_cost(p),p))
   def proxy(x):
    if x[1] is None:return (x[0],n,0)
    return (x[0],sum(v.bit_count() for B,_ in x[1]for v in B),len(x[1]))
   cost,p=min(opts,key=proxy);k=(cost+second,proxy((cost,p)),pol)
   if best is None or k<best[0]:best=(k,((cost,p),base,sub))
  self.plan_cache[key]=best[1];return best[1]
 @functools.lru_cache(None)
 def walkcost(self,z,cap):
  if z.data is not None:
   if z.d==0:return 10**8
   (c,_),_,sub=self.plan(z,cap);return c+sum(sum(s is not None for s in Z)for Z in sub.values())
  if cap<1:return 10**8
  return (1 if z.d else 0)+sum(self.walkcost(c,cap-1)for c in z.ch.values())
 def leaf_basis(self,z,f,free):
  (cost,plan),base,sub=self.plan(z,len(free));d,p=z.d,z.p;assert f is not None
  self.sweep(f,base,d,p,[],[])
  def second(v,h,Z):
   self.sweep(self.c1,Z.get(None,[]),d,p,[v],[h])
   for s,co in sorted((s,c)for s,c in Z.items()if s is not None):
    u,j=s;self.condition(self.c1,u,j,self.c2);self.stats['second_condition']+=1
    self.sweep(self.c2,co,d,p,[v,u],[h,j]);self.condition(self.c1,u,j,self.c2,True)
  if plan is None:
   for (v,h),Z in sorted(sub.items()):
    self.condition(f,v,h,self.c1);self.stats['first_condition']+=1;second(v,h,Z);self.condition(f,v,h,self.c1,True)
   self.ledger.append([d,p,len(free),len(sub),len(sub),0]);return
  A=[];wires=[];actual=0
  for B,K in plan:
   I=intersection(A,B);self.transported+=len(I)-len(set(A)&set(B));self.basis_changes+=bool(A and I and I!=A[:len(I)])
   if A:
    X=independent(I+A);assert len(X)==len(A)
    for a,b in basis_xors(A,X):self.op(33,wires[a],wires[b])
    for v,t in zip(X[len(I):],wires[len(I):]):self.condition(f,v,-1,t,True)
    wires=wires[:len(I)]
   A=independent(I+B);assert len(A)==len(B)
   for v in A[len(I):]:
    t=next(t for t in free if t not in wires);self.condition(f,v,-1,t);wires.append(t);actual+=1
   T=pivot_basis(A)
   for v,h,_ in K:
    r,c=reduce(v,T);assert r==0
    ctr=[wires[j]for j in bits(c)]+([f]if h==1 else [])
    for t in ctr:self.op(33,t,self.c1)
    second(v,h,sub[v,h]);self.stats['basis_served']+=1
    for t in ctr[::-1]:self.op(33,t,self.c1)
  for v,t in zip(A,wires):self.condition(f,v,-1,t,True)
  assert actual==cost;self.stats['basis_products']+=actual;self.ledger.append([d,p,len(free),len(sub),actual,len(plan)])

def run(Ppath,apath,Q,search=1,stem=None):
 Z=json.load(open(Ppath));scale=MOD//Z['scale'];rep=collections.defaultdict(list);A=dict(json.load(open(apath))['assignment'])
 for j,(bi,s,V,H,v,o) in enumerate(data(Z)[0]):
  u=A[j];assert choices(u,V,H,o[u])==o;rep[bi].append((u,V,H,o[u]))
 e=Transport(Q,scale,search);root=Trie(0,0);t=time.time()
 for i,b in enumerate(Z['blocks']):
  d=W-b['k'];p=b['start']>>b['k'];z=root
  for j in range(d):
   bit=p>>(d-j-1)&1
   if bit not in z.ch:z.ch[bit]=Trie(z.d+1,z.p*2+bit)
   z=z.ch[bit]
  assert z.data is None and not z.ch;z.data=rep[i]
 print('cost plan',e.splitcost(root),flush=True);e.split(root,scale);e.sweep(None,list(e.plain.items()),0,0,[],[])
 stem=stem or f'v64_Q{Q}_s{search}_{Path(Ppath).stem}';p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,e.ops,e.angles,Q,True);c=collections.Counter(o.raw for o in e.ops)
 r=dict(width=Q,ops=len(e.ops),ccx=c[49],cx=c[33],x=c[17],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],cosets=Z['cosets'],transported=e.transported,basis_changes=e.basis_changes,**e.stats,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t)
 Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles],ledger=e.ledger),separators=(',',':')));print(stem,r,flush=True);return stem
if __name__=='__main__':run(sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),sys.argv[5]if len(sys.argv)>5 else None)
