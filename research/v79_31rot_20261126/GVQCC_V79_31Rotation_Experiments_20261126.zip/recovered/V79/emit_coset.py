"""V55 signed affine-frequency contraction: 25Q full phase oracle.
Shared prefix/constraint flags, coset representative selection, and one
central unconditional parity compensation. No HMR and no 37Q parent.
"""
import json,sys,time,hashlib
from pathlib import Path
from collections import defaultdict,Counter
from compile_affine import Op,NativeKMB,bits,mcx,write
W=22;MOD=1<<128

def route(ms,p):
 ms=set(ms);cur=1<<p;out=[]
 if len(ms)<=400:
  while ms:
   nxt=min(ms,key=lambda x:((x^cur).bit_count(),x));out.append(nxt);ms.remove(nxt);cur=nxt
 else:
  def igray(x):
   a=x
   while x:x>>=1;a^=x
   return a
  out=sorted(ms,key=lambda x:igray(x^(1<<p)))
 return out

def choices(s,V,H,a):
 out={s:a}
 for d,h in zip(V,H):out.update({x^d:y*h for x,y in list(out.items())})
 return out

def select_reps(P):
 groups=[];forced=set();lookup=defaultdict(set);rep={}
 for bi,b in enumerate(P['blocks']):
  for s,V,H,a in b['cosets']:
   opt=choices(s,V,H,a);j=len(groups);groups.append((bi,s,V,H,a,opt))
   if 0 in opt:rep[j]=(0,opt[0]);continue
   if len(opt)==1:rep[j]=(s,a);forced.add(s);continue
   for u in opt:lookup[u].add(j)
 rem={j for j in range(len(groups))if j not in rep}
 for u in sorted(forced):
  for j in lookup[u]&rem:rep[j]=(u,groups[j][-1][u]);rem.remove(j)
 while rem:
  u=max(lookup,key=lambda x:(len(lookup[x]&rem),-x.bit_count(),-x));assert lookup[u]&rem
  for j in lookup[u]&rem:rep[j]=(u,groups[j][-1][u]);rem.remove(j)
 out=defaultdict(list)
 for j,(bi,s,V,H,a,opt) in enumerate(groups):
  u,c=rep[j];out[bi].append((u,V,H,c))
 return out,len({s for s,a in rep.values()if s})

class Emitter:
 def __init__(self,Q):self.Q=Q;self.ops=[];self.angles=[];self.tags=[];self.plain=defaultdict(int);self.stats=Counter()
 def op(self,g,*w):self.ops.append(Op(g,w))
 def r(self,q,a,tag):
  a%=MOD
  if a:self.op(19,q);self.angles.append(a);self.tags.append(tag)
 def pred(self,d,p,t):
  cs=list(range(W-d,W));neg=[q for q in cs if not (p>>(q-(W-d))&1)]
  for q in neg:self.op(17,q)
  self.ops+=mcx(cs,t,self.Q)
  for q in neg[::-1]:self.op(17,q)
 def control(self,parent,mask,h,t):
  # In-place affine basis for one parity; restore input before phase.
  assert mask;ps=list(bits(mask));p=ps[-1]
  for q in ps[:-1]:self.op(33,q,p)
  if h==1:self.op(17,p) # chi=+1 iff parity=0
  self.op(49,parent,p,t)
  if h==1:self.op(17,p)
  for q in ps[-2::-1]:self.op(33,q,p)
 def sweep(self,flag,terms,d,p,V,H):
  # All terms share exactly the same flag. Aggregate identical parity masks.
  z=defaultdict(int)
  for s,a in terms:z[s]+=a
  z={s:a%MOD for s,a in z.items()if a%MOD}
  if 0 in z:
   a=z.pop(0);self.r(flag,a,('direct',0,d,p,V,H))
  groups=defaultdict(dict)
  for s,a in z.items():groups[s.bit_length()-1][s]=a
  for q,co in sorted(groups.items()):
   cur=1<<q
   if flag is not None:self.op(33,flag,q)
   for s in route(co,q):
    for j in bits(cur^s):self.op(33,j,q)
    self.r(q,co[s],('toggle' if flag is not None else 'parity',s,d,p,V,H));cur=s
    if flag is not None:self.plain[s]-=co[s]
   for j in bits(cur^(1<<q)):self.op(33,j,q)
   if flag is not None:self.op(33,flag,q)
 def block(self,d,p,cosets,scale):
  self.pred(d,p,22);base=[];sub=defaultdict(lambda:defaultdict(list))
  # Two-dimensional constraint spaces have three equivalent ordered bases.
  # Maximize shared first constraint, then share the second condition.
  scores=Counter()
  for s,V,H,a in cosets:
   for v,h in zip(V,H):scores[v,h]+=1 if len(V)==2 else 3
   if len(V)==2:scores[V[0]^V[1],H[0]*H[1]]+=1
  for s,V,H,a in cosets:
   a*=scale
   if not V:base.append((s,a));continue
   if len(V)==1:sub[V[0],H[0]][None].append((s,a));continue
   assert len(V)==2
   opts=list(zip(V,H))+[(V[0]^V[1],H[0]*H[1])]
   first=max(opts,key=lambda t:(scores[t],-t[0].bit_count(),-t[0]));second=min((t for t in opts if t!=first),key=lambda t:(-scores[t],t[0].bit_count(),t[0]))
   sub[first][second].append((s,a))
  self.sweep(22,base,d,p,[],[])
  for (v,h),z in sorted(sub.items()):
   self.control(22,v,h,23);self.stats['first_condition']+=1
   self.sweep(23,z.get(None,[]),d,p,[v],[h])
   for second,co in sorted((s,c)for s,c in z.items()if s is not None):
    u,j=second;self.control(23,u,j,24);self.stats['second_condition']+=1
    self.sweep(24,co,d,p,[v,u],[h,j]);self.control(23,u,j,24)
   self.control(22,v,h,23)
  self.pred(d,p,22)

def emit(lam,Q=25):
 t=time.time();P=json.load(open(f'coset_plan_{lam}.json'));rep,nrep=select_reps(P);scale=MOD//P['scale'];e=Emitter(Q)
 for i,b in enumerate(P['blocks']):e.block(W-b['k'],b['start']>>b['k'],rep[i],scale)
 e.sweep(None,list(e.plain.items()),0,0,[],[])
 ref=NativeKMB.read('reference_header.kmb');stem=f'v55_coset{lam}_Q{Q}';p=Path(stem+'.kmb');write(ref,p,e.ops,e.angles,Q);c=Counter(o.raw for o in e.ops);r=dict(width=Q,ops=len(e.ops),ccx=c[49],cx=c[33],x=c[17],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=0,terms_before=P['terms_before'],cosets=P['cosets'],representatives=nrep,**e.stats,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t)
 Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles]),separators=(',',':')));print('NATIVE',r,flush=True)
if __name__=='__main__':emit(int(sys.argv[1]),int(sys.argv[2])if len(sys.argv)>2 else 25)
