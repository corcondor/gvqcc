"""One physical allocator combines PR142 prefix routing and signed direct/toggle phase
with global rank-intersection transport and margin-optimised coefficients.
"""
from global_transport import Transport,Trie,NativeKMB,MOD,W,data,choices,write_hmr
from v58_prefix_route import Routed
import v58_hybrid as H
import json,collections,hashlib,sys,time
from pathlib import Path
class Unified(Routed,Transport):
 pass

def run(Q,mode,route,plan,apath,S,stem):
 Z=json.load(open(plan));scale=MOD//Z['scale'];rep=collections.defaultdict(list);A=dict(json.load(open(apath))['assignment'])
 for j,(bi,s,V,h,v,o) in enumerate(data(Z)[0]):
  u=A[j];assert choices(u,V,h,o[u])==o;rep[bi].append((u,V,h,o[u]))
 e=Unified(Q,scale,S,mode,route);root=Trie(0,0);t=time.time()
 for i,b in enumerate(Z['blocks']):
  d=W-b['k'];p=b['start']>>b['k'];z=root
  for j in range(d):
   bit=p>>(d-j-1)&1
   if bit not in z.ch:z.ch[bit]=Trie(z.d+1,z.p*2+bit)
   z=z.ch[bit]
  assert z.data is None and not z.ch;z.data=rep[i]
 if route=='route':e.routed(root,scale)
 else:e.split(root,scale)
 e.sweep(None,list(e.plain.items()),0,0,[],[]);p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,e.ops,e.angles,Q,True);c=collections.Counter(o.raw for o in e.ops)
 r=dict(width=Q,mode=mode,route=route,ops=len(e.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],transported=e.transported,basis_changes=e.basis_changes,**e.stats,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t)
 Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles],ledger=e.ledger),separators=(',',':')));print(stem,r,flush=True);return stem
if __name__=='__main__':
 q,mode,route,stem=sys.argv[1:];H.COST=8.28
 S=H.select(mode,src='margin36_c8.json')
 run(int(q),mode,route,'margin138111932.json','margin138111932_assignment.json',S,stem)
