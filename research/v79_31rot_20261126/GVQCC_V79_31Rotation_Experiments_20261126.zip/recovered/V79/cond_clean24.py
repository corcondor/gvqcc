"""Native one-clean conditionally-clean ladder (Khattar–Gidney, Quantum 9,
1752 (2025), theorem 5.1 / section 5.2) + full phase echo oracle.
Independent implementation of marked-position algorithm. All controls restored.
"""
from phase_echo24 import *
import phase_echo24 as M
from v58_prefix_route import dp

class CondClean24(Echo24):
 def andxor(self,cs,t,free,clear=False):
  n=len(cs)
  if not free or n<3 or dp(n,len(free),self.Q,clear)[0]<=2*n-4-int(clear):
   return super().andxor(cs,t,free,clear)
  q=[free[0],*cs];A=[True]+[False]*n;seq=[]
  while sum(not b for b in A)>2:
   u,x,y=next((i,*[j for j in range(i+1,n+1)if not A[j]][:2]) for i in range(n+1)[::-1] if A[i] and sum(not A[j] for j in range(i+1,n+1))>=2)
   A[u]=False;A[x]=A[y]=True;seq.append((u,x,y));self.op(49,q[x],q[y],q[u])
   if u:self.op(17,q[u])
  a,b=[q[i]for i in range(n+1)if not A[i]]
  if clear:self.erase(t,[a,b])
  else:self.op(49,a,b,t)
  for u,x,y in seq[::-1]:
   if u:self.op(17,q[u]);self.op(49,q[x],q[y],q[u])
   else:self.erase(q[u],[q[x],q[y]])
  self.stats['conditional_clean_ladders']+=1
  self.stats['conditional_clean_paid_saved']+=dp(n,len(free),self.Q,clear)[0]-(2*n-4-int(clear))

if __name__=='__main__':
 M.Echo24=CondClean24;M.run(sys.argv[1]);stem='echo24_'+sys.argv[1]
 for ext in ('.kmb','.json'):
  Path(stem+ext).rename('kg24_'+sys.argv[1]+ext)
