"""Exact nonlinear guard elimination with rank-one group expansion.
A candidate is admitted only by an exact local Walsh coefficient check.
"""
from fold_cosets import fold, norm
from collections import defaultdict
from emit_coset import choices
import json,sys,copy,random
from pathlib import Path

def fold_all(data,penalty=1.0):
    A,rank2,complement=fold(data)
    G=defaultdict(lambda:defaultdict(int));pending=[]
    for s,V,H,a in A:
        if len(V)==2:pending.append((s,V,H,a));continue
        if V:s,a=norm(s,V[0],H[0],a);key=(V[0],H[0])
        else:key=None
        G[key][s]+=a
    # Eliminate full first-guard groups via Fourier expansion. Prefer no
    # additional rotation; penalty can explore other Pareto points.
    # A guard required by residual rank-2 terms is not charged as eliminated.
    locked=set()
    for s,V,H,a in pending:
        locked.update(zip(V,H));locked.add((V[0]^V[1],H[0]*H[1]))
    count=0;terms=0
    while True:
        cands=[]
        for key,B in G.items():
            if key is None or key in locked:continue
            v,h=key;B={s:a for s,a in B.items() if a}
            if not B or any(a%2 for a in B.values()):continue
            delta=defaultdict(int)
            for s,a in B.items():delta[s]+=a//2;delta[s^v]+=h*a//2
            diff=sum(int(bool(G[None].get(s,0)+b))-int(bool(G[None].get(s,0))) for s,b in delta.items())-len(B)
            if penalty*diff<=1:cands.append((diff,-len(B),key,delta))
        if not cands:break
        diff,_,key,delta=min(cands,key=lambda x:x[:3]);del G[key];count+=1;terms+=diff
        for s,a in delta.items():G[None][s]+=a
    D=list(pending)
    for key,B in G.items():
        for s,a in B.items():
            if a:D.append([s,[] if key is None else [key[0]],[] if key is None else [key[1]],a])
    def expand(data):
        z=defaultdict(int)
        for s,V,H,a in data:
            assert a%(1<<len(V))==0
            for u,b in choices(s,V,H,a//(1<<len(V))).items():z[u]+=b
        return {u:b for u,b in z.items() if b}
    assert expand(data)==expand(D)
    return D,(rank2,complement,count,terms)
if __name__=='__main__':
    p=json.load(open(sys.argv[1]));sums=[0]*4;old=0
    for b in p['blocks']:
        old+=len(b['cosets']);b['cosets'],st=fold_all(b['cosets'],float(sys.argv[3]));sums=[a+b for a,b in zip(sums,st)]
    p['cosets']=sum(len(b['cosets'])for b in p['blocks']);p['fold79']=sums
    Path(sys.argv[2]).write_text(json.dumps(p));print('fold',old,p['cosets'],sums)
