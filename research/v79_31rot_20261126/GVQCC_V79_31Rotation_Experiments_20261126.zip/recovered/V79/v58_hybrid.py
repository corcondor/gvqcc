'''V58: exact direct/toggle hybrid on PR136's fixed signed coset plan.
Select direct frequencies globally, merge the flag constants. Borrow a
prefix input (known on flag support) at Q25, or reserve one clean wire.
No new approximation. All full emitted circuits below 37Q.'''
import sys,json,time,hashlib
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np
from scipy.optimize import milp,Bounds,LinearConstraint
from scipy.sparse import coo_matrix
from conditional_basis_prefix import Basis,Trie,select_reps,choices,data,bits,write_hmr,NativeKMB,MOD,W
COST=239.00391117857393/33

def select(mode,src='reciprocal_prefix_Q36.json'):
 T=json.load(open(src));occ=defaultdict(list);base=defaultdict(int);plain={}
 for t,a in zip(T['tags'],map(int,T['angles'])):
  kind,s,d,p,V,H=t;k=(d,p,tuple(V),tuple(H))
  if kind=='toggle':occ[s].append((k,a))
  elif kind=='direct':base[k]+=a
  elif kind=='parity':plain[s]=a
 freq=[s for s,v in sorted(occ.items())if s in plain and len(v)*(2 if mode=='dirty' else 1)<COST];G=sorted({k for s in freq for k,a in occ[s]if not base[k]%MOD});idx={k:i+len(freq)for i,k in enumerate(G)}
 rr=[];cc=[];vv=[];n=0
 for i,s in enumerate(freq):
  for k,a in occ[s]:
   if k not in idx:continue
   rr += [n,n];cc += [i,idx[k]];vv += [1.,-1.];n+=1
 c=[len(occ[s])*(2 if mode=='dirty' else 1)-COST for s in freq]+[COST]*len(G)
 con=LinearConstraint(coo_matrix((vv,(rr,cc)),shape=(n,len(c))).tocsc(),-np.inf,0.)
 sol=milp(np.array(c),integrality=np.ones(len(c)),bounds=Bounds(0,1),constraints=con,options={'time_limit':15})
 assert sol.x is not None
 S={s for i,s in enumerate(freq)if sol.x[i]>.5};rec=dict(mode=mode,eligible=len(freq),flag_groups=len(G),constraints=n,selected=len(S),direct_terms=sum(len(occ[s])for s in S),proxy_objective=float(sol.fun),solver_status=int(sol.status),gap=float(sol.mip_gap),frequencies=sorted(S))
 print('select', {k:v for k,v in rec.items()if k!='frequencies'},flush=True);Path('v58_selection_'+mode+'.json').write_text(json.dumps(rec,indent=2));return S

class Hybrid(Basis):
 def __init__(self,Q,scale,S,mode):
  super().__init__(Q,scale);self.S=S;self.mode=mode
  if mode=='clean':
   assert Q>=26;self.temp=Q-3;self.flags=list(range(W,Q-3));assert self.flags
 def sweep(self,flag,terms,d,p,V,H,*args):
  if flag is None:return super().sweep(flag,terms,d,p,V,H,*args)
  z=defaultdict(int)
  for s,a in terms:z[s]=(z[s]+a)%MOD
  take={s:a for s,a in z.items()if s in self.S and s and a};rest={s:a for s,a in z.items()if s not in take and a};rest[0]=(rest.get(0,0)+sum(take.values()))%MOD
  super().sweep(flag,list(rest.items()),d,p,V,H,*args)
  for s,a in sorted(take.items()):
   ps=list(bits(s));t=ps[-1]
   for q in ps[:-1]:self.op(33,q,t)
   if self.mode=='clean':
    u=self.temp;self.op(49,flag,t,u);self.r(u,-2*a,('product',s,d,p,V,H,str(a)));self.erase(u,[flag,t])
   else:
    # Highest input bit is fixed on every nonempty prefix. It cannot
    # occur in any local suffix character. Toggle it only when f*p=1.
    assert d>0 and t<W-d;u=W-1;b=(p>>(d-1))&1;beta=-2*a*(1-2*b)
    self.op(49,flag,t,u);self.r(u,beta,('borrow',s,d,p,V,H,str(a),u));self.op(49,flag,t,u);self.plain[1<<u]-=beta
   for q in ps[-2::-1]:self.op(33,q,t)
   self.stats['direct_frequency_terms']+=1

def run(Q,mode,S):
 t=time.time();P=json.load(open('coset_plan_0_adaptive.json'));scale=MOD//P['scale'];groups,*_=data(P);a=dict(json.load(open('reciprocal_assignment.json'))['assignment']);rep=defaultdict(list)
 for j,(bi,s,V,H,v,o)in enumerate(groups):
  u=a[j];assert choices(u,V,H,o[u])==o;rep[bi].append((u,V,H,o[u]))
 e=Hybrid(Q,scale,S,mode);root=Trie(0,0)
 for i,b in enumerate(P['blocks']):
  d=W-b['k'];p=b['start']>>b['k'];z=root
  for j in range(d):
   bit=p>>(d-j-1)&1
   if bit not in z.ch:z.ch[bit]=Trie(z.d+1,z.p*2+bit)
   z=z.ch[bit]
  assert z.data is None;z.data=rep[i]
 e.split(root,scale);e.sweep(None,list(e.plain.items()),0,0,[],[])
 ref=NativeKMB.read('reference_header.kmb');stem=f'v58_hybrid_{mode}_Q{Q}';p=Path(stem+'.kmb');write_hmr(ref,p,e.ops,e.angles,Q,True);c=Counter(o.raw for o in e.ops)
 r=dict(width=Q,mode=mode,ops=len(e.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],**e.stats,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t);r['proxy']=Q*(r['ccx']+COST*r['generic'])
 Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles],ledger=e.ledger),separators=(',',':')));print(r,flush=True);return stem
if __name__=='__main__':
 mode=sys.argv[1];S=select(mode)
 for Q in map(int,sys.argv[2:]):run(Q,mode,S)
