"""V79: width-parametric conditional-carrier basis synthesis.
The first flag is a basis member, not a separately allocated wire.
Rank-one and rank-two masks can choose a different first factor; signed
complements use a CX from the prefix. The entire resident span is
transported across batches, with exact HMR erasure of the complement.
"""
import json, sys, math, time, functools, hashlib
from pathlib import Path
from collections import defaultdict, Counter
from cond_clean24 import CondClean24
from global_transport import (independent, intersection, basis_xors,
    groups_policy, plan_rank_cost, order_plan)
from conditional_basis_prefix import batches, pivot_basis, reduce
from phase_echo24 import NativeKMB, MOD, W, Trie, write_hmr, Emitter, Op, bits
from affine_transport import cancel
from emit_coset import choices


def expand_rank(data, depth):
    """Exact partial Walsh expansion; phase not approximated."""
    D=defaultdict(int)
    for s,V,H,a in data:
        if len(V)<=depth:
            D[s,tuple(V),tuple(H)]+=a
            continue
        # eliminate last condition (both half-sized signed characters)
        assert a%2==0
        q=expand_rank([(s,V[:-1],H[:-1],a//2),
                       (s^V[-1],V[:-1],H[:-1],a//2*H[-1])],depth)
        for t,A,B,b in q:D[t,tuple(A),tuple(B)]+=b
    return [(s,list(A),list(B),a) for (s,A,B),a in sorted(D.items()) if a]


def verify_repr(old,new):
    def expand(data):
        z=defaultdict(int)
        for s,V,H,a in data:
            assert a%(1<<len(V))==0
            for u,b in choices(s,V,H,a//(1<<len(V))).items():z[u]+=b
        return {u:b for u,b in z.items() if b}
    assert expand(old)==expand(new)


class Multi(CondClean24):
    def __init__(self,Q,scale,S,policy,seed=0):
        Emitter.__init__(self,Q);self.scale=scale;self.S=S
        self.mode='dirty';self.route_policy='route';self.hmr=True
        self.flags=[22];self.c1=23;self.ledger=[];self.plan_cache={}
        self.policy=policy;self.seed=seed

    def local_sweep(self,flag,terms,d,p,V,H):
        # Use inherited hybrid direct/toggle policy and compensation.
        self.sweep(flag,terms,d,p,V,H)

    def leaf_basis(self,z,f,free):
        data=z.data;d,p=z.d,z.p
        if self.Q==23:
            # no clean secondary slot, no dirty-state measurement.
            data=expand_rank(data,0);verify_repr(z.data,data)
            self.local_sweep(f,[(s,a*self.scale) for s,V,H,a in data],d,p,[],[])
            return
        # Choose direct measured second flags or dirty echo to free an extra slot.
        # The width-24 path always needs dirty echo; wider widths choose from both.
        modes=[False,True] if self.policy=='auto' else [self.policy=='clean']
        if len(free)==1:modes=[False]
        opts=[]
        for use_clean in modes:
            cap=len(free)-int(use_clean)
            if not cap:continue
            for pol in range(3):
                base,sub=groups_policy(data,self.scale,pol,z.p+37*pol+self.seed)
                keys=sorted(sub);n=len(keys)
                if not n:
                    opts.append((0,0,0,use_clean,base,sub,[]));continue
                # all second guards in one first-factor group share the same first flag.
                # echo pays two CCX per term; measured flag pays one per nonempty group.
                cost2=sum((1 if use_clean else 2*len(co)) for Z in sub.values() for k,co in Z.items() if k is not None)
                for keep in sorted({0, min(2,cap-1),max(0,cap-2),cap//2}):
                    for sd in (0,1):
                        _,plan=batches(keys,cap,sd+self.seed,keep)
                        plan=order_plan(plan,sd+self.seed)
                        c=plan_rank_cost(plan)
                        # proxy for CNOT basis changes; strict paid count first.
                        weight=sum(v.bit_count() for B,_ in plan for v in B)
                        opts.append((c+cost2,c,weight,use_clean,base,sub,plan))
        paid,first,_,use_clean,base,sub,plan=min(opts,key=lambda a:a[:3])
        self.local_sweep(f,base,d,p,[],[])
        if not plan:return
        pool=free[:-1] if use_clean else free
        second=free[-1] if use_clean else None
        A=[];wires=[];actual=0
        for B,K in plan:
            I=intersection(A,B)
            if A:
                X=independent(I+A)
                for a,b in basis_xors(A,X):self.op(33,wires[a],wires[b])
                for v,t in zip(X[len(I):],wires[len(I):]):self.condition(f,v,-1,t,True)
                wires=wires[:len(I)]
            A=independent(I+B)
            for v in A[len(I):]:
                t=next(t for t in pool if t not in wires)
                self.condition(f,v,-1,t);wires.append(t);actual+=1
            T=pivot_basis(A)
            # Materialize a required flag in-place by changing the basis,
            # then return to the same resident frame; no extra flag slot.
            for v,h,_ in K:
                r,c=reduce(v,T);assert not r
                js=list(bits(c));pivot=js[-1];t=wires[pivot]
                for j in js[:-1]:self.op(33,wires[j],t)
                if h==1:self.op(33,f,t)
                Z=sub[v,h]
                self.local_sweep(t,Z.get(None,[]),d,p,[v],[h])
                for k,co in sorted((s,c) for s,c in Z.items() if s is not None):
                    u,j=k
                    if use_clean:
                        self.condition(t,u,j,second)
                        self.local_sweep(second,co,d,p,[v,u],[h,j])
                        self.condition(t,u,j,second,True)
                    else:
                        self.c1=t
                        self.second_echo(v,h,u,j,co,d,p)
                if h==1:self.op(33,f,t)
                for j in js[-2::-1]:self.op(33,wires[j],t)
        for v,t in zip(A,wires):self.condition(f,v,-1,t,True)
        assert first==actual
        self.stats['resident_basis_products']+=actual
        self.stats['estimated_leaf_paid']+=paid
        self.stats['leaf_first_groups']+=len(sub)
        self.stats['leaf_cache_batches']+=len(plan)


def compile_plan(path,Q,stem,policy='auto',seed=0,mode='dirty'):
    P=json.load(open(path));G=defaultdict(lambda:defaultdict(int));start=time.time()
    for b in P['blocks']:
        k=b['k'];p=b['start']>>k
        for s,V,H,a in b['cosets']:G[k,p][s,tuple(zip(V,H))]+=a
    for k in range(W):
        for p in sorted(p for kk,p in list(G) if kk==k and p%2==0):
            X=G[k,p];Y=G.get((k,p+1),{});parent=G[k+1,p//2]
            for key in list(set(X)&set(Y)):
                if X[key] and X[key]==Y[key]:parent[key]+=X[key];del X[key];del Y[key]
    nodes=defaultdict(list)
    for (k,p),terms in G.items():
        z=Trie(W-k,p);z.data=[(s,[v for v,h in vh],[h for v,h in vh],a) for (s,vh),a in sorted(terms.items()) if a]
        if z.data:nodes[z.d].append(z)
    S=set(json.load(open('v58_selection_dirty.json'))['frequencies']) if mode=='dirty' else set()
    e=Multi(Q,MOD//P['scale'],S,policy,seed);f=22;free=list(range(23,Q))
    for d,L in sorted(nodes.items()):
        assert d>0
        cur=min(L,key=lambda z:z.p);L.remove(cur);e.prefix(d,cur.p,f);e.leaf_basis(cur,f,free)
        while L:
            nxt=min(L,key=lambda z:((z.p^cur.p).bit_count(),z.p));L.remove(nxt);e.transition(d,cur.p,nxt.p,f);e.leaf_basis(nxt,f,free);cur=nxt
        e.prefix(d,cur.p,f,True)
    e.local_sweep(None,list(e.plain.items()),0,0,[],[])
    best,_=cancel(e.ops)
    p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,best,e.angles,Q,True)
    K=NativeKMB.read(p);c=Counter(o.raw for o in K.ops)
    r=dict(width=Q,ops=len(K.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-start,**e.stats)
    Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x) for x in e.angles]),separators=(',',':')))
    print(stem,r,flush=True)

if __name__=='__main__':
    Q=int(sys.argv[1]);compile_plan(sys.argv[2],Q,sys.argv[3],sys.argv[4] if len(sys.argv)>4 else 'auto',int(sys.argv[5]) if len(sys.argv)>5 else 0,sys.argv[6] if len(sys.argv)>6 else 'dirty')
