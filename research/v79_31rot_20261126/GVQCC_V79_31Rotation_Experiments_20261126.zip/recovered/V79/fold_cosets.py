"""Exact within-chart change of rank-two predicates into rank-one/base terms.
Select representatives jointly so existing coefficients absorb new generators.
"""
from collections import defaultdict
from phase_echo24 import *
from pathlib import Path
import random

def norm(s,v,h,a):
 if s^v < s:return s^v,a*h
 return s,a

def fold(data,seed=0):
 rng=random.Random(seed);G=defaultdict(lambda:defaultdict(int));D=[]
 for s,V,H,a in data:
  if len(V)==2:D.append((s,V,H,a));continue
  if V:s,a=norm(s,V[0],H[0],a);key=(V[0],H[0])
  else:key=None
  G[key][s]+=a
 changed=0;pending=D[:];rng.shuffle(pending)
 while True:
  nxt=[];c=0
  for s,V,H,a in pending:
   if a%2:nxt.append((s,V,H,a));continue
   opts=list(zip(V,H))+[(V[0]^V[1],H[0]*H[1])];cand=[]
   for v,h in opts:
    for u,j in opts:
     if v==u:continue
     s1,a1=norm(s,v,h,a//2);s2,a2=norm(s^u,v,h,j*a//2);assert s1!=s2
     q=G[v,h];diff=sum(int(bool(q.get(t,0)+b))-int(bool(q.get(t,0)))for t,b in [(s1,a1),(s2,a2)])
     cand.append((diff,not any(q.values()),s1.bit_count()+s2.bit_count(),v,h,s1,a1,s2,a2))
   b=min(cand)
   if b[0]<=1 and not b[1]:
    _,_,_,v,h,s1,a1,s2,a2=b;G[v,h][s1]+=a1;G[v,h][s2]+=a2;c+=1
   else:nxt.append((s,V,H,a))
  pending=nxt;changed+=c
  if not c:break
 # Collapse complement equal/opposite coefficients, even if one term cancels.
 c=0
 for v in sorted(set(k[0]for k in G if k is not None)):
  A,B=G[v,1],G[v,-1]
  for s in set(A)&set(B):
   a,b=A[s],B[s]
   if a and a==b:G[None][s]+=a;A[s]=B[s]=0;c+=1
   elif a and a==-b:G[None][s^v]+=a;A[s]=B[s]=0;c+=1
 out=pending[:]
 # Keep representation closest to existing frequencies to reduce compensation.
 old=defaultdict(list)
 for s,V,H,a in data:
  if len(V)==1:
   t,_=norm(s,V[0],H[0],a);old[(V[0],H[0],t)].append(s)
 for key,q in G.items():
  for s,a in q.items():
   if not a:continue
   if key is None:out.append((s,[],[],a));continue
   v,h=key;z=old.get((v,h,s),[])
   if z and z[0]!=s:s^=v;a*=h
   out.append((s,[v],[h],a))
 # exact local Walsh certificate (not only term count)
 def expand(D):
  q=defaultdict(int)
  for s,V,H,a in D:
   assert a%(1<<len(V))==0
   for t,c in choices(s,V,H,a//(1<<len(V))).items():q[t]+=c
  return {s:a for s,a in q.items()if a}
 assert expand(data)==expand(out)
 return out,changed,c

def runfold(mode,seed):
 P=json.load(open('parent.plan.json'));G=defaultdict(lambda:defaultdict(int));t=time.time()
 for b in P['blocks']:
  k=b['k'];p=b['start']>>k
  for s,V,H,a in b['cosets']:G[k,p][(s,tuple(zip(V,H)))]+=a
 for k in range(W):
  for p in sorted(p for kk,p in list(G)if kk==k and p%2==0):
   X=G[k,p];Y=G.get((k,p+1),{});parent=G[k+1,p//2]
   for key in list(set(X)&set(Y)):
    if X[key] and X[key]==Y[key]:parent[key]+=X[key];del X[key];del Y[key]
 nodes=defaultdict(list);stats=Counter()
 for (k,p),terms in G.items():
  z=Trie(W-k,p);z.data=[(s,[v for v,h in vh],[h for v,h in vh],a)for (s,vh),a in sorted(terms.items())if a]
  if not z.data:continue
  n=len(z.data);z.data,a,b=fold(z.data,seed+p);stats.update({'rank2_removed':a,'complement_folds':b,'term_delta':len(z.data)-n});nodes[z.d].append(z)
 S=set(json.load(open('v58_selection_dirty.json'))['frequencies']) if mode=='dirty' else set();e=Echo24(MOD//P['scale'],S);f=e.flags[0]
 for d,L in sorted(nodes.items()):
  cur=min(L,key=lambda z:z.p);L.remove(cur);e.prefix(d,cur.p,f);e.leaf_basis(cur,f,[])
  while L:
   nxt=min(L,key=lambda z:((z.p^cur.p).bit_count(),z.p));L.remove(nxt);e.transition(d,cur.p,nxt.p,f);e.leaf_basis(nxt,f,[]);cur=nxt
  e.prefix(d,cur.p,f,True)
 e.sweep(None,list(e.plain.items()),0,0,[],[]);best,_=cancel(e.ops)
 for pol in (0,1,2):
  F=Frame(24,pol)
  for o in e.ops:F.take(o)
  r,_=cancel(F.finish());r,_=cancel(r)
  if len(r)<len(best):best=r
 stem=f'fold24_{mode}_{seed}';p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,best,e.angles,24,True);K=NativeKMB.read(p);c=Counter(o.raw for o in K.ops);r=dict(width=24,ops=len(K.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t,**e.stats,**stats);Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles]),separators=(',',':')));print(stem,r,flush=True)
if __name__=='__main__':runfold(sys.argv[1],int(sys.argv[2]))
