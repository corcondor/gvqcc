"""Exact inter-prefix Walsh lifting: two sibling cosets become parent sum/difference.
The canonical representative is chosen modulo the entire local condition span.
All operations are emitted by the persistent conditional basis compiler.
"""
from collections import defaultdict,Counter
import json,sys,time,hashlib
from pathlib import Path
from unified import Unified
from global_transport import Trie,NativeKMB,MOD,W,choices,write_hmr
from affine_transport import cancel,Frame

def normalize(s,V,H,a):
 d={0:1}
 for v,h in zip(V,H):
  d.update({k^v:z*h for k,z in list(d.items())})
 basis=[];span={0}
 for u in sorted(d):
  if u not in span:basis.append(u);span|={v^u for v in list(span)}
 t=min(s^u for u in d);return (t,tuple((u,d[u])for u in basis)),a*d[s^t]

def run(Q,mode):
 P=json.load(open('parent.plan.json'));G=defaultdict(lambda:defaultdict(int));start=time.time()
 for b in P['blocks']:
  k=b['k'];p=b['start']>>k
  for s,V,H,a in b['cosets']:
   key,a=normalize(s,V,H,a);G[k,p][key]+=a
 counts=Counter();detail=[]
 for k in range(W):
  for p in sorted(p for kk,p in list(G)if kk==k and p%2==0):
   X=G[k,p];Y=G.get((k,p+1),{});parent=G[k+1,p//2];ss=list(set(X)&set(Y))
   for key in ss:
    a,b=X[key],Y[key]
    if not a or not b:continue
    s,vh=key;div=1<<len(vh)
    if (a+b)%(2*div) or (a-b)%(2*div):continue
    if mode=='equal' and a!=b:continue
    # Avoid full-root conditional flag use. Root has no prefix.
    if k+1==W and vh:continue
    parent[key]+=(a+b)//2
    parent[(s^(1<<k),vh)]+=(a-b)//2
    del X[key];del Y[key];counts[k]+=1;detail.append((k,p,s,vh,a,b))
 # In order to independently verify, keep the original dyadic partition in parent.plan.json.
 # lifted parent terms overlap the original partition, but exact spectral contraction is checked against it.
 nodes=defaultdict(list)
 for (k,p),terms in G.items():
  z=Trie(W-k,p);z.data=[(s,[v for v,h in vh],[h for v,h in vh],a)for (s,vh),a in sorted(terms.items())if a]
  if z.data:nodes[z.d].append(z)
 S=set(json.load(open('v58_selection_dirty.json'))['frequencies']);e=Unified(Q,MOD//P['scale'],S,'dirty','route');f=e.flags[0];free=e.flags[1:]
 for d,L in sorted(nodes.items()):
  if d==0:
   assert len(L)==1
   for s,V,H,a in L[0].data:assert not V;e.plain[s]+=a*(MOD//P['scale'])
   continue
  cur=min(L,key=lambda z:z.p);L.remove(cur);e.prefix(d,cur.p,f);e.leaf_basis(cur,f,free)
  while L:
   nxt=min(L,key=lambda z:((z.p^cur.p).bit_count(),z.p));L.remove(nxt);e.transition(d,cur.p,nxt.p,f);e.leaf_basis(nxt,f,free);cur=nxt
  e.prefix(d,cur.p,f,True)
 e.sweep(None,list(e.plain.items()),0,0,[],[]);best,_=cancel(e.ops)
 for pol in (0,1,2):
  F=Frame(Q,pol)
  for o in e.ops:F.take(o)
  r,_=cancel(F.finish());r,_=cancel(r)
  if len(r)<len(best):best=r
 stem=f'lift_Q{Q}_{mode}';p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,best,e.angles,Q,True);K=NativeKMB.read(p);c=Counter(o.raw for o in K.ops);r=dict(lifted=sum(counts.values()),counts=dict(counts),ops=len(K.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-start);Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles]),separators=(',',':')));Path(stem+'.lifts.json').write_text(json.dumps(detail));print(stem,r,flush=True)
if __name__=='__main__':run(int(sys.argv[1]),sys.argv[2])
