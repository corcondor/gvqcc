"""Joint prefix lifetime and carrier-basis scheduler, widths 23..36.
Builds a global trie including hoisted internal-node phase data. Selects
prefix partition by DP using physical leaf capacity, including exact
rank-intersection costs. No padded 37Q circuits.
"""
from multiwidth import *
from v58_prefix_route import dp

class TreeMulti(Multi):
    def __init__(self,Q,scale,S,policy,seed,penalty):
        super().__init__(Q,scale,S,policy,seed)
        self.penalty=penalty;self._leaf={};self._split={};self._walk={};self._pc={}

    def prepare(self,z,nfree):
        key=(id(z),nfree)
        if key in self._leaf:return self._leaf[key]
        if not z.data:
            ans=(0,None)
        elif not nfree:
            D=expand_rank(z.data,0);verify_repr(z.data,D)
            # Count extra Fourier terms conservatively; phase comp may merge.
            extra=max(0,len(D)-len(z.data));ans=(self.penalty*extra,('expand',D))
        else:
            data=z.data;opts=[]
            modes=[False,True] if self.policy=='auto' else [self.policy=='clean']
            if nfree==1:modes=[False]
            for use_clean in modes:
                cap=nfree-int(use_clean)
                if cap<1:continue
                for pol in range(2):
                    base,sub=groups_policy(data,self.scale,pol,z.p+37*pol+self.seed)
                    keys=sorted(sub)
                    if not keys:
                        opts.append((0,0,0,use_clean,base,sub,[]));continue
                    cost2=sum((1 if use_clean else 2*len(co)) for Z in sub.values() for k,co in Z.items() if k is not None)
                    for keep in sorted({0,min(2,cap-1),max(0,cap-2),cap//2}):
                        _,plan=batches(keys,cap,self.seed,keep);plan=order_plan(plan,self.seed)
                        c=plan_rank_cost(plan);weight=sum(v.bit_count() for B,_ in plan for v in B)
                        opts.append((c+cost2,c,weight,use_clean,base,sub,plan))
            chosen=min(opts,key=lambda a:a[:3]);ans=(chosen[0],('basis',chosen))
        self._leaf[key]=ans;return ans

    def leaf_basis(self,z,f,free):
        if not z.data:return
        _,plan=self.prepare(z,len(free))
        if plan[0]=='expand':
            self.local_sweep(f,[(s,a*self.scale) for s,V,H,a in plan[1]],z.d,z.p,[],[])
            self.stats['expanded_leaves']+=1
            return
        paid,first,_,use_clean,base,sub,plan=plan[1];d,p=z.d,z.p
        self.local_sweep(f,base,d,p,[],[])
        if not plan:return
        pool=free[:-1] if use_clean else free;second=free[-1] if use_clean else None
        A=[];wires=[];actual=0
        for B,K in plan:
            I=intersection(A,B)
            if A:
                X=independent(I+A)
                for a,b in basis_xors(A,X):self.op(33,wires[a],wires[b])
                for v,t in zip(X[len(I):],wires[len(I):]):self.condition(f,v,-1,t,True)
                wires=wires[:len(I)]
            A=independent(I+B)
            for v in A[len(I):]:
                t=next(t for t in pool if t not in wires);self.condition(f,v,-1,t);wires.append(t);actual+=1
            T=pivot_basis(A)
            for v,h,_ in K:
                r,c=reduce(v,T);assert not r
                js=list(bits(c));pivot=js[-1];t=wires[pivot]
                for j in js[:-1]:self.op(33,wires[j],t)
                if h==1:self.op(33,f,t)
                Z=sub[v,h];self.local_sweep(t,Z.get(None,[]),d,p,[v],[h])
                for k,co in sorted((s,c) for s,c in Z.items() if s is not None):
                    u,j=k
                    if use_clean:
                        self.condition(t,u,j,second);self.local_sweep(second,co,d,p,[v,u],[h,j]);self.condition(t,u,j,second,True)
                    else:self.c1=t;self.second_echo(v,h,u,j,co,d,p)
                if h==1:self.op(33,f,t)
                for j in js[-2::-1]:self.op(33,wires[j],t)
        for v,t in zip(A,wires):self.condition(f,v,-1,t,True)
        assert first==actual
        self.stats['resident_basis_products']+=actual;self.stats['estimated_leaf_paid']+=paid
        self.stats['leaf_first_groups']+=len(sub);self.stats['leaf_cache_batches']+=len(plan)

    def pcost(self,d):
        if d in self._pc:return self._pc[d]
        if not d:return 0
        if self.Q==23 and d==22:return float('inf')
        # Exact CCX cost from existing emitter with given physical width.
        x=Multi(self.Q,self.scale,set(),'auto',0);x.prefix(d,0,22);x.prefix(d,0,22,True)
        v=sum(o.raw==49 for o in x.ops);self._pc[d]=v;return v

    def walk_cost(self,z,free):
        key=(id(z),free)
        if key in self._walk:return self._walk[key]
        local=self.prepare(z,free)[0]
        if z.ch:
            if free<1:local=float('inf')
            else:local+=(1 if z.d else 0)+sum(self.walk_cost(c,free-1) for c in z.ch.values())
        self._walk[key]=local;return local

    def split_cost(self,z):
        key=id(z)
        if key in self._split:return self._split[key]
        cap=self.Q-W-1
        direct=self.pcost(z.d)+self.walk_cost(z,cap)
        local=(self.pcost(z.d)+self.prepare(z,cap)[0]) if z.data else 0
        split=local+sum(self.split_cost(c)[0] for c in z.ch.values()) if z.ch else float('inf')
        ans=(direct,True) if direct<=split else (split,False);self._split[key]=ans;return ans

    def walk_tree(self,z,f,free):
        self.leaf_basis(z,f,free)
        if not z.ch:return
        assert free;g=free[0];q=W-z.d-1
        if len(z.ch)==1:
            b,c=next(iter(z.ch.items()));self.child(f,q,g,b);self.walk_tree(c,g,free[1:]);self.child(f,q,g,b,True)
        else:
            self.child(f,q,g,1);self.walk_tree(z.ch[1],g,free[1:]);self.op(33,f,g);self.walk_tree(z.ch[0],g,free[1:]);self.child(f,q,g,0,True)

    def split_tree(self,z):
        _,direct=self.split_cost(z);f=22;free=list(range(23,self.Q))
        if direct:
            self.prefix(z.d,z.p,f);self.walk_tree(z,f,free);self.prefix(z.d,z.p,f,True);self.stats['prefix_subtrees']+=1
        else:
            if z.data:self.prefix(z.d,z.p,f);self.leaf_basis(z,f,free);self.prefix(z.d,z.p,f,True);self.stats['prefix_subtrees']+=1
            for c in z.ch.values():self.split_tree(c)


def make_nodes(P,Q):
    G=defaultdict(lambda:defaultdict(int))
    for b in P['blocks']:
        k=b['k'];p=b['start']>>k
        for s,V,H,a in b['cosets']:G[k,p][s,tuple(zip(V,H))]+=a
    for k in range(W):
        for p in sorted(p for kk,p in list(G) if kk==k and p%2==0):
            X=G[k,p];Y=G.get((k,p+1),{});parent=G[k+1,p//2]
            for key in list(set(X)&set(Y)):
                if X[key] and X[key]==Y[key]:parent[key]+=X[key];del X[key];del Y[key]
    if Q==23:
        # At d=22 there is no spare for an exact reversible MCX on 23 wires.
        # Lift terminal point predicates into their d=21 parent (half signed
        # Walsh expansion). This changes only the representation, not phase.
        for k,p in list(G):
            if k!=0:continue
            for (s,vh),a in G[k,p].items():
                if not a:continue
                assert s==0 and not vh and a%2==0
                G[1,p//2][(0,())]+=a//2
                G[1,p//2][(1,())]+=a//2*(1 if p%2==0 else -1)
            del G[k,p]
    root=Trie(0,0)
    for (k,p),terms in sorted(G.items()):
        data=[(s,[v for v,h in vh],[h for v,h in vh],a)for (s,vh),a in sorted(terms.items())if a]
        if not data:continue
        d=W-k;z=root
        for i in range(d):
            b=p>>(d-1-i)&1
            if b not in z.ch:z.ch[b]=Trie(z.d+1,z.p*2+b)
            z=z.ch[b]
        z.data=data
    return root


def run(Q,plan,stem,mode,penalty,seed):
    start=time.time();P=json.load(open(plan));root=make_nodes(P,Q)
    S=set(json.load(open('v58_selection_dirty.json'))['frequencies']) if mode=='dirty' else set()
    e=TreeMulti(Q,MOD//P['scale'],S,'auto',seed,penalty)
    assert root.data is None
    proxy=sum(e.split_cost(c)[0] for c in root.ch.values())
    for c in root.ch.values():e.split_tree(c)
    e.local_sweep(None,list(e.plain.items()),0,0,[],[]);best,_=cancel(e.ops)
    p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,best,e.angles,Q,True)
    K=NativeKMB.read(p);c=Counter(o.raw for o in K.ops)
    r=dict(width=Q,ops=len(K.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],proxy=proxy,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-start,**e.stats)
    Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x) for x in e.angles]),separators=(',',':')))
    print(stem,r,flush=True)
if __name__=='__main__':run(int(sys.argv[1]),sys.argv[2],sys.argv[3],sys.argv[4],float(sys.argv[5]),int(sys.argv[6]))
