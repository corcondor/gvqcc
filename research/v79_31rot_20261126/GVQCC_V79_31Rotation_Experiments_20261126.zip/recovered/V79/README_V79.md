# GVQCC V79: width-parametric conditional carrier transport (research only)

This package contains 14 candidate complete native invsqrt KMBs at widths 23..36 and 14 complete matched controls, with independent exact verification and cost-model receipts. The 24Q control is the V78 native KMB; the other controls are newly generated using the same fixed V78 reciprocal phase plan. All candidate and control circuits restore inputs and work wires and pass full-cube phase replay and legal tolerance. No official KickMix invocation or Kaggle submission. No new DQI/chemistry experiment. 22Q has a prior zero-CCX diagnostic in PR #92; no strict decrease of zero is possible. The phase circuits here remain noncompetitive relative to historical cost 60,927.56. The 25Q and 26Q candidates reduce CCX and instructions but increase formula cost versus their newly generated same-plan route controls, since generic rotations rise. They do improve on older V64 spectral formula costs. No claim of all-time best at every width.

## Methods
- Resident conditional-linear products are represented by the span of their input masks. Transport the intersection of consecutive bases by CNOT changes of basis and erase the complement by HMR. Materialize a requested conditional parity in an existing basis slot rather than reserving a separate slot. Generate second guards with either a clean measured target or exact dirty echo. See `multiwidth.py`, `treewidth.py`.
- Joint prefix lifetime and basis-capacity dynamic program chooses a trie partition. The narrow-width compiler uses shortest paths between different prefix depths (`tourwidth.py`). Parent/child transitions toggle the complementary child; equal-depth transitions use the established affine chart. The 24Q candidate preserves V78's leaf emitter (`tour24orig.py`).
- Rank-one phase expansion was tested and rejected for a cost-oriented candidate when extra rotations outweigh CCX savings (`fold79.py`).

## Reproduction
Requires Python 3.10+ with numpy and scipy, and a C++17 compiler. Run in package root. `reference_header.kmb` is inherited serialization metadata; not a new submitted circuit.

```sh
mkdir -p runs
g++ -O3 -std=c++17 phasecheck.cpp -o phasecheck
python tourwidth.py 23 recip.plan.json runs/tour23 plain 0
python tour24orig.py recip.plan.json runs/tour24orig dirty
for q in $(seq 25 36); do
  python treewidth.py "$q" recip.plan.json "runs/tree$q" plain 8 0
  python multiwidth.py "$q" recip.plan.json "runs/q$q" auto 0 dirty
done
python treewidth.py 23 recip.plan.json runs/tree23 plain 8 0
python verify_echo.py recip24 recip.plan.json
for stem in runs/tour23 runs/tour24orig runs/tree23 $(seq 25 36 | sed 's/^/runs\/tree/') $(seq 25 36 | sed 's/^/runs\/q/'); do
  python verify_echo.py "$stem" recip.plan.json
done
python cost.py recip24 runs/tour23 runs/tour24orig runs/tree23 $(seq 25 36 | sed 's/^/runs\/tree/') $(seq 25 36 | sed 's/^/runs\/q/')
```

`verify_echo.py` recreates 128-bit phase arrays; these large scratch files are omitted from the ZIP. The comparison table is `width_grid.csv` and `width_grid.json`. `SHA256SUMS` covers package files. Shortest-path tie choices and numerical library versions may affect byte-for-byte regeneration; included native bytes and receipts are authoritative.

## Sources
PR #92, #160, #162, #164, #167, #168, #169 and Issue #163 in corcondor/gvqcc. Amy/Azimzadeh/Mosca, arXiv:1712.01859 (parity networks); Khattar/Gidney, Quantum 9 1752, DOI 10.22331/q-2025-05-21-1752 (conditionally clean ancillae); Khattar et al., arXiv:2610.23832 (competition verification structure); Yang/Yuan, arXiv:2611.02345 (MBU static analysis). These motivate independently implemented scheduling and phase validation; not claimed as complete reproductions of the papers.
