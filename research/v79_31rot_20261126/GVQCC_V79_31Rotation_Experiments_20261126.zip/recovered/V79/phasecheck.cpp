#include <cstdint>
#include <vector>
#include <fstream>
#include <cassert>
#include <iostream>
using U=__uint128_t;
constexpr uint32_t W=22,N=1<<W;
template<typename T>T read(std::ifstream&f){T t;f.read((char*)&t,sizeof(t));assert(f);return t;}
std::vector<U> eval(const char*name){std::ifstream f(name,std::ios::binary);assert(f);std::vector<U>out(N);auto n=read<uint32_t>(f);for(uint32_t i=0;i<n;i++){auto d=read<uint32_t>(f),p=read<uint32_t>(f),r=read<uint32_t>(f);assert(d<=W && p<(1u<<d));uint32_t m=1u<<(W-d);std::vector<U>a(m);for(uint32_t j=0;j<r;j++){auto s=read<uint32_t>(f);auto c=read<U>(f);assert(s<m);a[s]+=c;}for(uint32_t h=1;h<m;h*=2)for(uint32_t k=0;k<m;k+=2*h)for(uint32_t j=k;j<k+h;j++){auto x=a[j],y=a[j+h];a[j]=x+y;a[j+h]=x-y;}for(uint32_t j=0;j<m;j++)out[p*m+j]+=a[j];}assert(f.peek()==EOF);return out;}
int main(int argc,char**argv){assert(argc==4);auto a=eval(argv[1]),b=eval(argv[2]);for(size_t i=0;i<N;i++)if(a[i]!=b[i]){std::cerr<<"mismatch "<<i<<std::endl;return 1;}std::ofstream out(argv[3],std::ios::binary);out.write((char*)a.data(),a.size()*16);assert(out);std::cout<<"Independent unsigned 128-bit modular phase contraction PASS: "<<N<<" inputs\n";}
