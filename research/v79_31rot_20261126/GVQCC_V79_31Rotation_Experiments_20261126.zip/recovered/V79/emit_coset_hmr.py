"""Shared hierarchical prefix flags and exact measurement uncompute.
Each erased flag is a product of current controls; HMR + guarded Z/CZ
restores phase exactly for both outcomes. Width is a hard constraint.
"""
import sys,json,time,hashlib,struct
from pathlib import Path
from collections import defaultdict,Counter
from emit_coset import Emitter,select_reps,bits,mcx,NativeKMB,Op,MOD,W

class Trie:
 def __init__(self,d,p):self.d=d;self.p=p;self.ch={};self.data=None;self.height=0

def write_hmr(ref,path,ops,angles,Q,hmr):
 C={i:bytearray()for i in range(1,12)};C[10]+=b''.join(a.to_bytes(16,'little')for a in angles);C[11]+=dict(ref.sections)[11]
 for o in ops:
  assert max(o.wires,default=-1)<Q;C[1].append(o.raw)
  cols={0:(),1:(7,),2:(5,6),3:(2,3,4)}[(o.raw>>4)&3]
  for i,q in zip(cols,o.wires):C[i]+=struct.pack('<I',q)
  if o.raw&64:C[8]+=struct.pack('<I',o.measurement)
  if o.raw&128:C[9]+=struct.pack('<I',o.condition)
 h=list(ref.header);h[1]=Q;h[2]=1 if hmr else 0;h[4]=len(ops);h[5]=sum(o.raw&127==49 for o in ops);h[6]=len(C[5])//4;h[7]=len(C[7])//4;h[8]=len(C[8])//4;h[9]=len(C[9])//4;h[10]=len(angles)
 path.write_bytes(ref.prefix16+struct.pack('<4I9Q',*h)+b''.join(struct.pack('<QQ',t,len(v if t==0 else C[t]))+(v if t==0 else C[t])for t,v in ref.sections))

class Shared(Emitter):
 def __init__(self,Q,hmr):super().__init__(Q);self.hmr=hmr;self.c1=Q-2;self.c2=Q-1;self.flags=list(range(W,Q-2));assert self.flags
 def erase(self,t,controls):
  if not self.hmr:
   self.ops+=mcx(controls,t,self.Q);return
  assert len(controls) in (1,2)
  self.ops.append(Op(80,(t,),measurement=0));self.ops.append(Op((16 if len(controls)==1 else 32)|128,tuple(controls),condition=0));self.stats['local_hmr']+=1
 def condition(self,parent,mask,h,t,clear=False):
  ps=list(bits(mask));p=ps[-1];assert mask
  for q in ps[:-1]:self.op(33,q,p)
  if h==1:self.op(17,p)
  if clear:self.erase(t,[parent,p])
  else:self.op(49,parent,p,t)
  if h==1:self.op(17,p)
  for q in ps[-2::-1]:self.op(33,q,p)
 def leaf(self,flag,d,p,cosets,scale):
  base=[];sub=defaultdict(lambda:defaultdict(list));scores=Counter()
  for s,V,H,a in cosets:
   for v,h in zip(V,H):scores[v,h]+=1 if len(V)==2 else 3
   if len(V)==2:scores[V[0]^V[1],H[0]*H[1]]+=1
  for s,V,H,a in cosets:
   a*=scale
   if not V:base.append((s,a));continue
   if len(V)==1:sub[V[0],H[0]][None].append((s,a));continue
   assert len(V)==2
   opts=list(zip(V,H))+[(V[0]^V[1],H[0]*H[1])];first=max(opts,key=lambda t:(scores[t],-t[0].bit_count(),-t[0]));second=min((t for t in opts if t!=first),key=lambda t:(-scores[t],t[0].bit_count(),t[0]));sub[first][second].append((s,a))
  self.sweep(flag,base,d,p,[],[])
  for (v,h),z in sorted(sub.items()):
   self.condition(flag,v,h,self.c1);self.stats['first_condition']+=1
   self.sweep(self.c1,z.get(None,[]),d,p,[v],[h])
   for second,co in sorted((s,c)for s,c in z.items()if s is not None):
    u,j=second;self.condition(self.c1,u,j,self.c2);self.stats['second_condition']+=1;self.sweep(self.c2,co,d,p,[v,u],[h,j]);self.condition(self.c1,u,j,self.c2,True)
   self.condition(flag,v,h,self.c1,True)
 def child(self,parent,q,g,b,clear=False):
  if not b:self.op(17,q)
  controls=[q]if parent is None else [parent,q]
  if clear:self.erase(g,controls)
  else:self.op(33 if parent is None else 49,*controls,g)
  if not b:self.op(17,q)
 def walk(self,z,f,free,scale):
  if z.data is not None:assert f is not None and not z.ch;self.leaf(f,z.d,z.p,z.data,scale);return
  assert free;g=free[0];q=W-z.d-1
  if len(z.ch)==1:
   b,c=next(iter(z.ch.items()));self.child(f,q,g,b);self.walk(c,g,free[1:],scale);self.child(f,q,g,b,True)
  else:
   self.child(f,q,g,1);self.walk(z.ch[1],g,free[1:],scale)
   if f is None:self.op(17,g)
   else:self.op(33,f,g)
   self.walk(z.ch[0],g,free[1:],scale);self.child(f,q,g,0,True)
 def split(self,z,scale):
  if z.d==0 and z.height<=len(self.flags):self.walk(z,None,self.flags,scale);return
  if z.d and z.height+1<=len(self.flags):
   f=self.flags[0];self.pred(z.d,z.p,f);self.stats['direct_prefix']+=1;self.walk(z,f,self.flags[1:],scale);self.pred(z.d,z.p,f);return
  assert z.data is None
  for c in z.ch.values():self.split(c,scale)

def emit(planpath,Q=25,hmr=True):
 t=time.time();P=json.load(open(planpath));rep,nrep=select_reps(P);scale=MOD//P['scale'];e=Shared(Q,hmr);root=Trie(0,0)
 for i,b in enumerate(P['blocks']):
  d=W-b['k'];p=b['start']>>b['k'];z=root
  for j in range(d):
   bit=p>>(d-j-1)&1
   if bit not in z.ch:z.ch[bit]=Trie(z.d+1,z.p*2+bit)
   z=z.ch[bit]
  assert z.data is None and not z.ch;z.data=rep[i]
 def height(z):z.height=max((height(c)+1 for c in z.ch.values()),default=0);return z.height
 height(root);e.split(root,scale);e.sweep(None,list(e.plain.items()),0,0,[],[])
 ref=NativeKMB.read('reference_header.kmb');stem=f'v55_shared_{Path(planpath).stem}_Q{Q}_'+('hmr'if hmr else 'unitary');p=Path(stem+'.kmb');write_hmr(ref,p,e.ops,e.angles,Q,hmr);c=Counter(o.raw for o in e.ops);r=dict(width=Q,ops=len(e.ops),ccx=c[49],cx=c[33],x=c[17],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],terms_before=P['terms_before'],cosets=P['cosets'],representatives=nrep,**e.stats,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t)
 Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles]),separators=(',',':')));print('SHARED',r,flush=True);return stem
if __name__=='__main__':emit(sys.argv[1],int(sys.argv[2]),bool(int(sys.argv[3]))if len(sys.argv)>3 else True)
