"""V55: full <=36Q affine-coefficient oracle, no HMR. Shared vector trie.
Native gates X/CX/CCX/Z_POW; a,b are integer coefficient words on dyadic
prefix leaves; phase is (a-b*x)/2^48 turns. All temporaries restored.
"""
import json,struct,time,hashlib,itertools,sys
from pathlib import Path
from collections import Counter
from native_kmb import NativeKMB,Op
W=22;MOD=1<<128;S=1<<48

def bits(v):
 while v:
  b=v&-v;yield b.bit_length()-1;v^=b

def mcx(cs,t,Q):
 cs=tuple(cs);n=len(cs);assert t not in cs and len(set(cs))==n
 if n==0:return [Op(17,(t,))]
 if n==1:return [Op(33,(cs[0],t))]
 if n==2:return [Op(49,(*cs,t))]
 sp=[q for q in range(Q) if q!=t and q not in cs];assert sp
 if len(sp)>=n-2:
  a=sp[:n-2];l=[Op(49,(cs[0],cs[1],a[0]))]+[Op(49,(cs[i+1],a[i-1],a[i])) for i in range(1,n-2)];g=[Op(49,(cs[-1],a[-1],t))]
  return l+g+l[::-1]+l[1:]+g+l[1:][::-1]
 k=(n+1)//2;d=sp[0];u=mcx(cs[:k],d,Q);v=mcx(cs[k:]+(d,),t,Q);return u+v+u+v

def write(ref,out,ops,angles,Q):
 C={i:bytearray() for i in range(1,12)};C[10]+=b''.join(a.to_bytes(16,'little') for a in angles);C[11]+=dict(ref.sections)[11]
 for o in ops:
  assert max(o.wires,default=-1)<Q;C[1].append(o.raw)
  cols={0:(),1:(7,),2:(5,6),3:(2,3,4)}[(o.raw>>4)&3]
  for i,q in zip(cols,o.wires):C[i]+=struct.pack('<I',q)
 h=list(ref.header);h[1]=Q;h[2]=0;h[4]=len(ops);h[5]=sum(o.raw==49 for o in ops);h[6]=len(C[5])//4;h[7]=len(C[7])//4;h[8]=h[9]=0;h[10]=len(angles)
 out.write_bytes(ref.prefix16+struct.pack('<4I9Q',*h)+b''.join(struct.pack('<QQ',t,len(v if t==0 else C[t]))+(v if t==0 else C[t]) for t,v in ref.sections))

# Full prefix tree, exact on the entire input cube (zero on omitted leaves).
class Node:
 __slots__=('d','p','value','ch','opts','delta','height')
 def __init__(self,d,p):self.d=d;self.p=p;self.value=0;self.ch=None;self.opts=None;self.delta=0;self.height=0

def make_tree(rows,word,group):
 root=Node(0,0)
 for st,k,a,b in rows:
  d=W-k;p=st>>k;z=root
  for i in range(d):
   if z.ch is None:z.ch=[Node(z.d+1,z.p*2),Node(z.d+1,z.p*2+1)]
   z=z.ch[(p>>(d-i-1))&1]
  assert z.ch is None
  v=(a,b)[word];z.value=sum(((v>>j)&1)<<i for i,j in enumerate(group))
 # Word-valued Fitch: minimize number of nonzero prefix updates; tie-break XOR weight.
 def up(z):
  if z.ch is None:z.opts={z.value};return
  l,r=z.ch;up(l);up(r)
  if l.ch is None and r.ch is None and l.value==r.value:
   z.value=l.value;z.ch=None;z.opts={z.value};return
  z.opts=(l.opts&r.opts) or (l.opts|r.opts)
 def down(z,v):
  q=v if v in z.opts else min(z.opts,key=lambda a:((a^v).bit_count(),a))
  z.delta=v^q
  if z.ch:
   for c in z.ch:down(c,q)
   z.ch=[c for c in z.ch if c.delta or c.ch]
   if not z.ch:z.ch=None
  z.height=max([1+c.height for c in z.ch] if z.ch else [0])
 up(root);down(root,0);return root

# Independent receipt for every emitted compute macro: primitive operations
# + multi-control macro with exact coordinates and sequence offsets.
class Loader:
 def __init__(self,Q,outs):self.Q=Q;self.outs=outs;self.flags=[q for q in range(W,Q) if q not in outs];self.ops=[];self.macros=[]
 def op(self,g,*w):self.ops.append(Op(g,w));self.macros.append([g,list(w),len(self.ops)-1,1])
 def gate(self,cs,t):
  seq=mcx(cs,t,self.Q);self.macros.append([100,list(cs)+[t],len(self.ops),len(seq)]);self.ops+=seq
 def pred(self,z,t):
  cs=list(range(W-z.d,W));neg=[q for q in cs if not ((z.p>>(q-(W-z.d)))&1)]
  for q in neg:self.op(17,q)
  self.gate(cs,t)
  for q in neg[::-1]:self.op(17,q)
 def output(self,z,f):
  for i in bits(z.delta):
   if f is None:self.op(17,self.outs[i])
   else:self.op(33,f,self.outs[i])
 def subtree(self,z,f,free):
  self.output(z,f)
  if not z.ch:return
  assert free;g=free[0];rem=free[1:];q=W-z.d-1
  # Both child flags with same target; use parent XOR to change branch.
  ch=sorted(z.ch,key=lambda c:-c.p%2) # order immaterial; explicit sign below
  def init(c):
   if not (c.p&1):self.op(17,q)
   if f is None:self.op(33,q,g)
   else:self.op(49,f,q,g)
   if not (c.p&1):self.op(17,q)
  if len(ch)==1:
   init(ch[0]);self.subtree(ch[0],g,rem);init(ch[0])
  else:
   assert {c.p&1 for c in ch}=={0,1};p=next(c for c in ch if c.p&1);n=next(c for c in ch if not c.p&1)
   init(p);self.subtree(p,g,rem)
   if f is None:self.op(17,g)
   else:self.op(33,f,g)
   self.subtree(n,g,rem)
   if f is None:self.op(17,g)
   else:self.op(33,f,g)
   init(p)
 def split(self,z):
  # Split only if the subtree needs more clean flags than the budget.
  if z.d==0 and z.height<=len(self.flags):self.subtree(z,None,self.flags);return
  if z.d and z.height+1<=len(self.flags):
   f=self.flags[0];self.pred(z,f);self.subtree(z,f,self.flags[1:]);self.pred(z,f);return
  if z.delta:
   if z.d==0:self.output(z,None)
   else:
    f=self.flags[0];self.pred(z,f);self.output(z,f);self.pred(z,f)
  if z.ch:
   for c in z.ch:self.split(c)
 def emit(self,z):self.split(z);return self.ops,self.macros

def compile(Q=36,group_size=7):
 t=time.time();P=json.load(open('affine_plan.json'));rows=P['blocks'];assert P['scale']==S
 A=0;B=0
 for st,k,a,b in rows:A|=a;B|=b
 ops=[];angles=[];rec=[];all_stats=[]
 # For each coefficient bit, classify input-product masks on the actual
 # dyadic blocks. Constant-in-support bits are absorbed into the same angle.
 slope_info={}
 for j in bits(B):
  active=[(st,k) for st,k,a,b in rows if b>>j&1];rot=[];const=0
  for i in range(W):
   if i+j>=48:continue
   can0=any(i<k or not (st>>i&1) for st,k in active)
   can1=any(i<k or (st>>i&1) for st,k in active)
   if not can1:continue
   if not can0:const-=1<<(i+j)
   else:rot.append(i)
  slope_info[j]=(const%S,rot)
 def r(q,a):
  a=(a%S)*(MOD//S)
  if a:ops.append(Op(19,(q,)));angles.append(a)
 for word,bits_all in enumerate([list(bits(A)),list(bits(B))]):
  for h in range(0,len(bits_all),group_size):
   group=bits_all[h:h+group_size];outs=list(range(W,W+len(group)));tmp=W+len(group)
   assert tmp<Q
   L=Loader(Q,outs);root=make_tree(rows,word,group);seq,mac=L.emit(root);start=len(ops);ops+=seq;phase_start=len(ops);r0=len(angles)
   for q,j in zip(outs,group):
    if word==0:r(q,1<<j)
    else:
     c,ii=slope_info[j];r(q,c)
     for i in ii:
      ops.append(Op(49,(q,i,tmp)));r(tmp,-(1<<(i+j)));ops.append(Op(49,(q,i,tmp)))
   phase_end=len(ops);ops+=seq[::-1]
   rec.append(dict(word=word,group=group,outs=outs,temp=tmp,start=start,phase_start=phase_start,phase_end=phase_end,end=len(ops),rotation_start=r0,rotation_end=len(angles),macros=mac))
   all_stats.append(dict(word=word,group=group,loader_ops=len(seq),loader_ccx=sum(o.raw==49 for o in seq),rotations=len(angles)-r0));print(all_stats[-1],flush=True)
 ref=NativeKMB.read('reference_header.kmb');stem=f'v55_affine_Q{Q}_g{group_size}';p=Path(stem+'.kmb');write(ref,p,ops,angles,Q)
 c=Counter(o.raw for o in ops);s=dict(width=Q,ops=len(ops),ccx=c[49],cx=c[33],x=c[17],rotations=len(angles),generic=sum(a%(1<<125)!=0 for a in angles),hmr=0,blocks=len(rows),groups=len(rec),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t,details=all_stats)
 Path(stem+'.json').write_text(json.dumps(dict(stats=s,receipts=rec),separators=(',',':')));print(stem,s,flush=True)
if __name__=='__main__':compile(int(sys.argv[1]) if len(sys.argv)>1 else 36,int(sys.argv[2]) if len(sys.argv)>2 else 7)
