"""Joint reciprocal representative exchange and exact phase debt cancellation.
Operate on the *new* refitted basis; generate native 24Q candidate separately.
"""
import json,time,collections,sys
from pathlib import Path
from reciprocal import data,sums,setcover,exact_cancellations,optimize
from emit_coset import choices
P=json.load(open(sys.argv[1]));groups,forced,fixed,opt,by=data(P);base={j: (fixed[j] if j in fixed else s)for j,(_,s,_,_,_,_)in enumerate(groups)};n0=sum(x!=0 for x in sums(groups,base).values());print('base',n0,flush=True)
a,mi=setcover(forced,opt,base);Z=exact_cancellations(groups,forced,opt,by,a);cands=[(base,{'initial':n0,'final':n0})]
for seed,initial in [(78,a),(79,base)]:cands.append(optimize(groups,forced,opt,by,initial,Z,seed))
A,st=min(cands,key=lambda x:x[1]['final']);rep=collections.defaultdict(list)
for j,(bi,s,V,H,a,o)in enumerate(groups):
 u=A[j];assert choices(u,V,H,o[u])==o;rep[bi].append([u,V,H,o[u]])
for i,b in enumerate(P['blocks']):b['cosets']=rep[i]
Path(sys.argv[2]).write_text(json.dumps(P));print('best',st,flush=True);Path('sparse_reciprocal_receipt.json').write_text(json.dumps(dict(baseline=n0,final=st['final'],stats=st,milp=mi),indent=2))
