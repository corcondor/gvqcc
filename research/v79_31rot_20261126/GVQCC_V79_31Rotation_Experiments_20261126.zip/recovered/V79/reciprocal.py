"""Signed reciprocal-coset optimization, exact integer compensation cancellation.
Based on PR131. No approximation changes; all representations expand identically.
"""
import sys,json,math,time,collections,random
from pathlib import Path
from collections import defaultdict,Counter
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
from scipy.sparse import coo_matrix
import emit_coset_hmr as E
from emit_coset import choices,select_reps

def data(P):
 groups=[];forced=Counter();fixed={};opt={};by=defaultdict(list)
 for bi,b in enumerate(P['blocks']):
  for s,V,H,a in b['cosets']:
   o=choices(s,V,H,a);j=len(groups);groups.append((bi,s,V,H,a,o))
   if 0 in o:fixed[j]=0
   elif len(o)==1:fixed[j]=s;forced[s]+=a
   else:
    opt[j]=o
    for u,v in o.items():by[u].append((j,v))
 return groups,forced,fixed,opt,by

def sums(groups,assign):
 s=Counter()
 for j,u in assign.items():
  if u:s[u]+=groups[j][-1][u]
 return s

def get_initial(P,groups):
 base,_=select_reps(P);idx=Counter();a={}
 for j,(bi,s,V,H,v,o)in enumerate(groups):
  u,_,_,c=base[bi][idx[bi]];idx[bi]+=1;assert o[u]==c;a[j]=u
 return a

def setcover(forced,opt,baseline):
 # Exact 0-1 support objective, excluding already available forced frequencies.
 rows=[list(o)for j,o in opt.items()if not any(s in forced for s in o)]
 cols=sorted(set(s for r in rows for s in r));pos={s:i for i,s in enumerate(cols)}
 ii=[];jj=[]
 for i,r in enumerate(rows):
  for s in r:ii.append(i);jj.append(pos[s])
 C=coo_matrix((np.ones(len(ii)),(ii,jj)),shape=(len(rows),len(cols))).tocsc()
 print('set cover',len(rows),len(cols),flush=True)
 ans=milp(np.ones(len(cols)),integrality=np.ones(len(cols)),bounds=Bounds(0,1),constraints=LinearConstraint(C,1,np.inf),options={'time_limit':15,'mip_rel_gap':0.001})
 print('MILP',ans.message,'obj',ans.fun,'gap',getattr(ans,'mip_gap',None),flush=True)
 if ans.x is None:return baseline.copy(),dict(status=str(ans.message))
 available={s for s,x in zip(cols,ans.x)if x>.5}|set(forced)
 a=baseline.copy();F=Counter(forced)
 for j,o in opt.items():
  cand=[s for s in o if s in available];assert cand
  # Prefer cancellation, then reuse old and smaller parity masks.
  u=min(cand,key=lambda s:(int(F[s]+o[s]!=0)-int(F[s]!=0),int(s!=baseline[j]),s.bit_count(),s));a[j]=u;F[u]+=o[u]
 return a,dict(status=str(ans.message),objective=float(ans.fun),gap=float(getattr(ans,'mip_gap',1)))

def subset_sums(seq):
 out=[(0,0)]
 for j,(_,v) in enumerate(seq):out += [(a+v,b|(1<<j))for a,b in out]
 return out

def exact_cancellations(groups,forced,opt,by,assignment):
 """For each frequency, list exact integer zero subsets. Use meet-in-middle.
 Keep at most 96 candidates per frequency, favoring small support. Exact search
 for possible zeros; truncation only affects selection of alternatives.
 """
 result={};feasible_forced=0;nonempty=0
 for u,items in by.items():
  target=-forced[u];k=len(items);m=k//2;R=defaultdict(list)
  for val,b in subset_sums(items[m:]):
   r=R[val]
   if len(r)<96:r.append(b)
  cur=sum(1<<j for j,(g,v)in enumerate(items)if assignment[g]==u);hits=[]
  for val,a in subset_sums(items[:m]):
   for b in R.get(target-val,[]):hits.append(a|(b<<m))
  if hits:
   hits=sorted(set(hits),key=lambda b:((b^cur).bit_count(),b.bit_count(),b))[:96]
   result[u]=hits;feasible_forced+=bool(forced[u]);nonempty+=any(hits)
 print('exact zero subsets',len(result),'forced nonzero with zero witness',feasible_forced,'nonempty',nonempty,flush=True)
 return result

def optimize(groups,forced,opt,by,assign,Z,seed):
 rng=random.Random(seed);A=assign.copy();F=sums(groups,A);n0=sum(x!=0 for x in F.values());history=[n0];n=n0;accepted=0
 def nz(x):return int(x!=0)
 def move(j,u,D,change):
  v=change.get(j,A[j]);
  if v==u:return
  D[v]-=opt[j][v];D[u]+=opt[j][u];change[j]=u
 def delta(D):return sum(nz(F[u]+v)-nz(F[u])for u,v in D.items())
 def adopt(D,change):
  nonlocal n,accepted
  d=delta(D);assert d<=0
  for u,v in D.items():F[u]+=v
  A.update(change);n+=d;accepted+=1
 # Explore target-frequency elimination across multiple cosets, simultaneously.
 for epoch in range(12):
  order=list(Z);rng.shuffle(order);order.sort(key=lambda u:(F[u]==0, len(by[u])))
  for u in order:
   if not F[u]:continue
   items=by[u];cur=sum(1<<i for i,(j,v)in enumerate(items)if A[j]==u)
   best=None
   for mask in sorted(Z[u],key=lambda b:((b^cur).bit_count(),b))[:24]:
    D=Counter();changes={};remove=[]
    for i,(j,v)in enumerate(items):
     if mask>>i&1:move(j,u,D,changes)
     elif A[j]==u:remove.append(j)
    rng.shuffle(remove)
    for j in remove:
     alt=[v for v in opt[j]if v!=u];assert alt
     v=min(alt,key=lambda v:(nz(F[v]+D[v]+opt[j][v])-nz(F[v]+D[v]),abs(F[v]+D[v]+opt[j][v]),v.bit_count(),v));move(j,v,D,changes)
    assert F[u]+D[u]==0
    d=delta(D);score=(d,len(changes))
    if best is None or score<best[0]:best=(score,D,changes)
   if best and (best[0][0]<0 or (best[0][0]==0 and epoch%3==1 and rng.random()<.12)):
    adopt(best[1],best[2])
  # Single signed moves including zero-sum creation on destination.
  order=list(opt);rng.shuffle(order)
  for j in order:
   u=A[j];a=opt[j][u];c=[(nz(F[u]-a)-nz(F[u])+nz(F[v]+b)-nz(F[v]),v)for v,b in opt[j].items()if v!=u]
   if not c:continue
   d,v=min(c)
   if d<0:
    D=Counter();ch={};move(j,v,D,ch);adopt(D,ch)
  assert sum(x!=0 for x in sums(groups,A).values())==n
  history.append(n);print('seed',seed,'epoch',epoch,'nonzero',n,flush=True)
  if len(history)>4 and len(set(history[-4:]))==1 and epoch%3==2:break
 return A,dict(initial=n0,history=history,accepted=accepted,final=n)

def run(planpath,Q=35):
 P=json.load(open(planpath));groups,forced,fixed,opt,by=data(P);base=get_initial(P,groups);n0=sum(v!=0 for v in sums(groups,base).values());print('baseline',n0,'groups',len(groups),flush=True)
 a,mi=setcover(forced,opt,base);Z=exact_cancellations(groups,forced,opt,by,a)
 cand=[(base,{'initial':n0,'final':n0})]
 for seed,start in [(0,a),(1,base),(2,a)]:cand.append(optimize(groups,forced,opt,by,start,Z,seed))
 best,st=min(cand,key=lambda x:x[1]['final']);
 rep=defaultdict(list)
 for j,(bi,s,V,H,v,o)in enumerate(groups):
  u=best[j];assert u in o;rep[bi].append((u,V,H,o[u]))
  # Independent re-expansion: each selected reciprocal representative is identical.
  assert choices(u,V,H,o[u])==o
 F=sums(groups,best);assert st['final']==sum(v!=0 for v in F.values());print('best',st,flush=True)
 stats=dict(base=n0,final=st['final'],milp=mi,zero_frequency_count=len(Z),trials=[c[1]for c in cand],assignments_changed=sum(base[j]!=best[j]for j in base),exact_nonempty_zero=[s for s in F if F[s]==0],assignment=list(best.items()))
 Path('reciprocal_assignment.json').write_text(json.dumps(stats,indent=2))
 E.select_reps=lambda P:(rep,len({s for g in rep.values()for s,V,H,a in g if s}))
 stem=E.emit(planpath,Q,True);return stem
if __name__=='__main__':print('RESULT',run(sys.argv[1],int(sys.argv[2])if len(sys.argv)>2 else 35),flush=True)
