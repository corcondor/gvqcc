"""Use prior V78 leaf emitter under the V79 mixed-depth guard tour."""
from tourwidth import *
from affine_transport import Frame
import phase_echo24

def run(plan,stem,mode):
    P=json.load(open(plan));root=make_nodes(P,24);S=set(json.load(open('v58_selection_dirty.json'))['frequencies']) if mode=='dirty' else set()
    e=CondClean24(MOD//P['scale'],S);cost,route,nn=path_plan(24,root,e.scale);f=22
    for acts,z in route:
        for a in acts:
            if a[0]=='prefix':e.prefix(a[1],a[2],f,a[3])
            else:e.transition(a[1],a[2],a[3],f)
        if z is not None:e.leaf_basis(z,f,[])
    e.sweep(None,list(e.plain.items()),0,0,[],[]);best,_=cancel(e.ops)
    for pol in (0,1,2):
        F=Frame(24,pol)
        for o in e.ops:F.take(o)
        r,_=cancel(F.finish());r,_=cancel(r)
        if len(r)<len(best):best=r
    p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,best,e.angles,24,True);K=NativeKMB.read(p);c=Counter(o.raw for o in K.ops)
    r=dict(width=24,ops=len(K.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],prefix_path_proxy=cost,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),**e.stats)
    Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles]),separators=(',',':')));print(r)
if __name__=='__main__':run(sys.argv[1],sys.argv[2],sys.argv[3])
