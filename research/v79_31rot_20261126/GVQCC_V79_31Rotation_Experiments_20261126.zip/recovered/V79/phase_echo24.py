"""Q24 complete oracle: second condition is a reversible parity target update,
not a separately stored nonlinear flag. Uses conditional borrowing on a fixed
prefix bit for constant terms. Native exact signed phase compensation.
"""
from collections import defaultdict,Counter
import json,sys,time,hashlib
from pathlib import Path
from unified import Unified
from global_transport import Trie,NativeKMB,MOD,W,choices,write_hmr
from affine_transport import cancel,Frame
from emit_coset import Emitter,Op,bits
from conditional_basis_prefix import leaf_groups

class Echo24(Unified):
 def __init__(self,scale,S):
  Emitter.__init__(self,24);self.scale=scale;self.S=S;self.mode='dirty';self.route_policy='route';self.hmr=True;self.flags=[22];self.c1=23;self.ledger=[];self.plan_cache={}
 def second_echo(self,v,h,u,j,terms,d,p):
  # c1 = prefix * predicate(v,h). u is independent of v.
  z=defaultdict(int)
  for s,a in terms:z[s]=(z[s]+a)%MOD
  for s,a in sorted(z.items()):
   if not a:continue
   # s can be shifted by either constraint; choose a constant or a form independent of u.
   opts=choices(s,[v,u],[h,j],a)
   if 0 in opts:s=0;a=opts[0]
   assert s!=u
   ps=list(bits(u));q=max(ps);pre=[Op(33,(b,q)) for b in ps if b!=q];self.ops+=pre
   if s:
    # In new chart, x_q = new_x_q + xor(other u inputs).
    ss=s^(u^(1<<q)) if s>>q&1 else s
    assert ss&~(1<<q);t=max(bits(ss&~(1<<q)));aff=[Op(33,(b,t))for b in bits(ss)if b!=t];self.ops+=aff
    if j==1:self.op(17,q)
    self.op(49,self.c1,q,t);self.r(t,a,('toggle',s,d,p,[v,u],[h,j]));self.op(49,self.c1,q,t)
    if j==1:self.op(17,q)
    self.ops+=aff[::-1];self.plain[s]-=a
   else:
    t=W-1;assert t!=q and t>=W-d
    b=(p>>(d-1))&1;beta=a*(1-2*b)
    if j==1:self.op(17,q)
    self.op(49,self.c1,q,t);self.r(t,beta,('borrow_flag',0,d,p,[v,u],[h,j],str(a),t));self.op(49,self.c1,q,t)
    if j==1:self.op(17,q)
    self.plain[1<<t]-=beta
   self.ops+=pre[::-1];self.stats['echo_terms']+=1
 def leaf_basis(self,z,f,free):
  base,sub=leaf_groups(z.data,self.scale);d,p=z.d,z.p
  self.sweep(f,base,d,p,[],[])
  for (v,h),Z in sorted(sub.items()):
   self.condition(f,v,h,self.c1);self.stats['first_condition']+=1
   self.sweep(self.c1,Z.get(None,[]),d,p,[v],[h])
   for second,co in sorted((s,c)for s,c in Z.items()if s is not None):
    u,j=second;self.second_echo(v,h,u,j,co,d,p)
   self.condition(f,v,h,self.c1,True)

def run(mode):
 P=json.load(open('parent.plan.json'));G=defaultdict(lambda:defaultdict(int));start=time.time()
 for b in P['blocks']:
  k=b['k'];p=b['start']>>k
  for s,V,H,a in b['cosets']:G[k,p][(s,tuple(zip(V,H)))]+=a
 # same exact previously equalized sibling pairs; preserve chosen reps.
 for k in range(W):
  for p in sorted(p for kk,p in list(G)if kk==k and p%2==0):
   X=G[k,p];Y=G.get((k,p+1),{});parent=G[k+1,p//2]
   for key in list(set(X)&set(Y)):
    if X[key] and X[key]==Y[key]:parent[key]+=X[key];del X[key];del Y[key]
 nodes=defaultdict(list)
 for (k,p),terms in G.items():
  z=Trie(W-k,p);z.data=[(s,[v for v,h in vh],[h for v,h in vh],a)for (s,vh),a in sorted(terms.items())if a]
  if z.data:nodes[z.d].append(z)
 S=set(json.load(open('v58_selection_dirty.json'))['frequencies']) if mode=='dirty' else set();e=Echo24(MOD//P['scale'],S);f=e.flags[0]
 for d,L in sorted(nodes.items()):
  assert d>0
  cur=min(L,key=lambda z:z.p);L.remove(cur);e.prefix(d,cur.p,f);e.leaf_basis(cur,f,[])
  while L:
   nxt=min(L,key=lambda z:((z.p^cur.p).bit_count(),z.p));L.remove(nxt);e.transition(d,cur.p,nxt.p,f);e.leaf_basis(nxt,f,[]);cur=nxt
  e.prefix(d,cur.p,f,True)
 e.sweep(None,list(e.plain.items()),0,0,[],[]);best,_=cancel(e.ops)
 for pol in (0,1,2):
  F=Frame(24,pol)
  for o in e.ops:F.take(o)
  r,_=cancel(F.finish());r,_=cancel(r)
  if len(r)<len(best):best=r
 stem=f'echo24_{mode}';p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,best,e.angles,24,True);K=NativeKMB.read(p);c=Counter(o.raw for o in K.ops);r=dict(width=24,ops=len(K.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-start,**e.stats);Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles]),separators=(',',':')));print(stem,r,flush=True)
if __name__=='__main__':run(sys.argv[1])
