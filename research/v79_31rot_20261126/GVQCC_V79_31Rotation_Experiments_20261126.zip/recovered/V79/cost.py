"""Official arithmetic formula, exact simulated phase margins; NOT official simulator."""
import json,math,sys
import numpy as np
from pathlib import Path
N=3133452;MASK=(1<<64)-1
# pinned official reference r=isqrt(2^130/x); phase 128-bit rounded to uint64
x=np.arange(1,N+1,dtype=np.uint64);r=[math.isqrt((1<<130)//int(a)) for a in x];tar=np.array([((a+1)>>1)&MASK for a in r],np.uint64);tol=np.array([a>>25 for a in r],np.uint64)
for stem in sys.argv[1:]:
 a=np.memmap(stem+'.phase.u128',dtype='<u8',mode='r',shape=(1<<22,2))[1:N+1];theta=a[:,1]+(a[:,0]>>np.uint64(63));err=np.abs((theta-tar).view(np.int64)).view(np.uint64);assert np.all(err<=tol);margin=int((tol-err).min());j=int(np.argmin(tol-err))+1
 z=json.load(open(stem+'.receipt.json'));q=z['width'];r=z['generic'];p=z['ccx'];eps=math.pi*margin/2**64/r;rot=0.56*math.log2(1/eps)+5.3;c=q*(p+r*rot/4);out=dict(stem=stem,Q=q,CCX=p,R=r,margin=margin,margin_x=j,eps=eps,t_per_rot=rot,official_formula_cost=c,independent_not_official=True);print(out,flush=True);Path(stem+'.cost.json').write_text(json.dumps(out,indent=2))
