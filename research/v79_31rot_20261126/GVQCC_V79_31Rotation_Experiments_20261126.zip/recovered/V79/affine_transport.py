"""Whole-circuit affine coordinate virtualization with exact target covectors.
No HMR outcome is moved across a new HMR. Phase-control tags remain in order.
"""
from native_kmb import NativeKMB,Op
import sys,collections,json,hashlib,time
from pathlib import Path

def bits(x):
 while x:
  y=x&-x;yield y.bit_length()-1;x^=y
class Frame:
 def __init__(self,Q,policy):
  self.Q=Q;self.F=[1<<i for i in range(Q)];self.G=self.F[:];self.C=1<<Q;self.mask=self.C-1;self.ops=[];self.policy=policy
 def physical(self,g,a,b=None):
  if g==17:
   self.ops.append(Op(g,(a,)));u=1<<a
   for j in range(self.Q):
    if self.F[j]&u:self.F[j]^=self.C
  elif g==33:
   assert a!=b;self.ops.append(Op(g,(a,b)));u=1<<b;v=1<<a
   for j in range(self.Q):
    if self.F[j]&u:self.F[j]^=v
   self.G[b]^=self.G[a]
  else:raise ValueError(g)
 def virtual(self,g,a,b=None):
  if g==17:self.F[a]^=self.C
  elif g==33:
   self.F[b]^=self.F[a];u=1<<b;v=1<<a
   for i in range(self.Q):
    if self.G[i]&u:self.G[i]^=v
  else:raise ValueError(g)
 def materialize(self,l,lock=(),prefer=None):
  f=self.F[l];u=f&self.mask;choices=[p for p in bits(u) if p not in lock];assert choices
  if self.policy==0:p=l if l in choices else min(choices)
  elif self.policy==1:p=min(choices,key=lambda q:(sum(bool(v>>q&1) for i,v in enumerate(self.F) if i!=l),q!=l,q))
  else:p=max(choices)
  if prefer is not None:assert prefer in choices;p=prefer
  for q in bits(u^(1<<p)):self.physical(33,q,p)
  if self.F[l]&self.C:self.physical(17,p)
  assert self.F[l]==1<<p;return p
 def align_target(self,l):
  vs=[p for p in range(self.Q)if self.G[p]>>l&1];assert vs
  if self.policy==0:p=l if l in vs else vs[0]
  elif self.policy==1:p=min(vs,key=lambda q:(sum(bool(v>>q&1) for i,v in enumerate(self.F)if i!=l),q!=l,q))
  else:p=vs[-1]
  for q in vs:
   if p!=q:self.physical(33,p,q)
  assert [i for i,f in enumerate(self.F)if f>>p&1]==[l];return p
 def take(self,o):
  g=o.raw;w=o.wires
  if g==17 or g==33:self.virtual(g,*w);return
  if g==49:
   a,b,t=w;p=self.align_target(t);p1=self.materialize(a,(p,));p2=self.materialize(b,(p,p1));assert [i for i,f in enumerate(self.F)if f>>p&1]==[t]
   self.ops.append(Op(g,(p1,p2,p)));return
  if g==80:
   t=w[0];p=self.align_target(t);self.materialize(t,prefer=p);self.ops.append(Op(g,(p,),measurement=o.measurement));return
  if g in (19,144,160):
   q=[]
   for l in w:q.append(self.materialize(l,tuple(q)))
   self.ops.append(Op(g,tuple(q),condition=o.condition));return
  raise ValueError(o)
 def finish(self):
  # Invariant: earlier physical coordinates already coincide with logical wires.
  for l in range(self.Q):
   p=self.materialize(l,tuple(range(l)))
   if p!=l:
    for a,b in [(p,l),(l,p),(p,l)]:self.physical(33,a,b)
   assert self.F[l]==1<<l
  assert self.F==[1<<i for i in range(self.Q)]
  assert self.G==self.F
  return self.ops

def commute(a,b):
 # a is unconditional X or CX. Conservative read/write criterion.
 wa=a.wires[-1];ra=set(a.wires[:-1]);g=b.raw;w=b.wires
 if g in (17,33,49):return wa not in w[:-1] and w[-1] not in ra
 if g==80:return w[0]!=wa and w[0] not in ra
 if g in (19,144,160):return wa not in w
 return False

def cancel(ops,limit=600):
 out=[];n=0
 for o in ops:
  if o.raw not in (17,33):out.append(o);continue
  for j in range(len(out)-1,max(-1,len(out)-1-limit),-1):
   a=out[j]
   if o==a:out.pop(j);n+=1;break
   if not commute(o,a):out.append(o);break
  else:out.append(o)
 return out,n

def run(src,stem):
 K=NativeKMB.read(src+'.kmb');opts=[];base,n=cancel(K.ops);opts.append((len(base),-1,base,n));print('commute',len(K.ops),len(base),n,flush=True)
 for pol in range(3):
  f=Frame(K.header[1],pol)
  for o in K.ops:f.take(o)
  r=f.finish();r,n=cancel(r);opts.append((len(r),pol,r,n));print('frame',pol,len(r),n,flush=True)
 ln,pol,ops,n=min(opts,key=lambda p:p[:2]);p=Path(stem+'.kmb');p.write_bytes(NativeKMB(K.prefix16,K.header,K.sections,ops).to_bytes());assert NativeKMB.read(p).ops==ops
 T=json.load(open(src+'.json'));T['stats'].update(ops=ln,affine_policy=pol,cancel_pairs=n,sha256=hashlib.sha256(p.read_bytes()).hexdigest());Path(stem+'.json').write_text(json.dumps(T,separators=(',',':')));print('best',stem,pol,ln,flush=True)
if __name__=='__main__':run(sys.argv[1],sys.argv[2])
