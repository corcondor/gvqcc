"""Shortest-path shared-guard transport across different prefix depths.
Transitions are XOR differences of predicates, not resets. Equal-depth
prefixes use an affine chart; adjacent parent/child use the other child.
Exact shortest paths also allow reset/recompute via the zero state.
"""
from treewidth import *
from scipy.sparse.csgraph import shortest_path
import numpy as np


def path_plan(Q,root,scale):
    vs=[];data=[]
    def visit(z):
        vs.append((z.d,z.p))
        if z.data:data.append(z)
        for c in z.ch.values():visit(c)
    visit(root)
    vs=[(-1,0)]+sorted(vs);idx={x:i for i,x in enumerate(vs)};n=len(vs)
    M=np.full((n,n),np.inf);np.fill_diagonal(M,0)
    actions={};C={}
    def cost(kind,d,clear=False):
        key=(kind,d,clear)
        if key not in C:
            e=Multi(Q,scale,set(),'auto',0)
            if kind=='prefix':e.prefix(d,0,22,clear)
            else:e.transition(d,0,1,22)
            C[key]=sum(o.raw==49 for o in e.ops)+1e-5*len(e.ops)+1e-7
        return C[key]
    def put(a,b,w,op):
        i,j=idx[a],idx[b]
        if w<M[i,j]:M[i,j]=w;actions[i,j]=op
    zero=vs[0]
    for a in vs[1:]:
        d,p=a
        put(zero,a,cost('prefix',d),('prefix',d,p,False));put(a,zero,cost('prefix',d,True),('prefix',d,p,True))
        if d:
            par=(d-1,p//2)
            if par in idx:
                w=cost('prefix',d);op=('prefix',d,p^1,False)
                put(a,par,w,op);put(par,a,w,op)
    by=defaultdict(list)
    for a in vs[1:]:by[a[0]].append(a)
    for d,L in by.items():
        if d==0:continue
        w=cost('transition',d)
        for a in L:
            for b in L:
                if a!=b:put(a,b,w,('transition',d,a[1],b[1]))
    # scipy treats zeros as missing; all non-diagonal real edges >0
    D,pred=shortest_path(M,method='FW',return_predecessors=True,directed=True)
    todo=[idx[(z.d,z.p)] for z in data];where={idx[(z.d,z.p)]:z for z in data}
    # nearest-neighbor and directed insertion/relocation, then 2opt
    def score(L):return sum(D[a,b] for a,b in zip(L,L[1:]))
    def improve(L):
        cur=score(L)
        while True:
            best=cur;out=None
            for i in range(1,len(L)-1):
                for j in range(1,len(L)-1):
                    if i==j:continue
                    Z=L[:];v=Z.pop(i);Z.insert(j,v);vscore=score(Z)
                    if vscore<best-1e-7:best=vscore;out=Z
            for i in range(1,len(L)-2):
                for j in range(i+1,len(L)-1):
                    Z=L[:i]+L[i:j+1][::-1]+L[j+1:];vscore=score(Z)
                    if vscore<best-1e-7:best=vscore;out=Z
            if out is None:return cur,L
            cur,L=best,out
    candidates=[]
    R=todo[:];L=[0]
    while R:
        x=min(R,key=lambda v:(D[L[-1],v],v));L.append(x);R.remove(x)
    candidates.append(L+[0]);candidates.append([0]+sorted(todo,key=lambda v:(vs[v][0],vs[v][1]))+[0]);candidates.append([0]+sorted(todo,key=lambda v:(vs[v][0],vs[v][1]),reverse=True)+[0])
    val,L=min((improve(v)for v in candidates),key=lambda x:x[0])
    out=[]
    for a,b in zip(L,L[1:]):
        x=b;rev=[]
        while x!=a:
            prev=int(pred[a,x]);assert prev>=0,(a,b,x)
            rev.append(actions[prev,x]);x=prev
        out.append((rev[::-1],where.get(b)))
    return val,out,len(vs)


def run(Q,plan,stem,mode,seed):
    start=time.time();P=json.load(open(plan));root=make_nodes(P,Q);S=set(json.load(open('v58_selection_dirty.json'))['frequencies']) if mode=='dirty' else set()
    e=TreeMulti(Q,MOD//P['scale'],S,'auto',seed,8);f=22;free=list(range(23,Q))
    cost,route,nn=path_plan(Q,root,e.scale)
    for acts,z in route:
        for a in acts:
            if a[0]=='prefix':e.prefix(a[1],a[2],f,a[3])
            else:e.transition(a[1],a[2],a[3],f)
        if z is not None:e.leaf_basis(z,f,free)
    e.local_sweep(None,list(e.plain.items()),0,0,[],[]);best,_=cancel(e.ops)
    p=Path(stem+'.kmb');write_hmr(NativeKMB.read('reference_header.kmb'),p,best,e.angles,Q,True)
    K=NativeKMB.read(p);c=Counter(o.raw for o in K.ops)
    r=dict(width=Q,ops=len(K.ops),ccx=c[49],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],prefix_path_proxy=cost,nodes=nn,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-start,**e.stats)
    Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x) for x in e.angles]),separators=(',',':')))
    print(stem,r,flush=True)
if __name__=='__main__':run(int(sys.argv[1]),sys.argv[2],sys.argv[3],sys.argv[4],int(sys.argv[5]))
