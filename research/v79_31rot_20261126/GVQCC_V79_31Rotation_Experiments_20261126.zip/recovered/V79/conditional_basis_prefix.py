"""Conditional dual basis hubs, bounded by 36 physical qubits.
Based on PR131.  For each prefix f, cache f*(v dot x), transport any
conditional affine predicate using CNOT, and erase each basis with HMR.
"""
import sys,json,time,hashlib,random,functools
from pathlib import Path
from collections import defaultdict,Counter
from emit_coset import Emitter,choices,select_reps,bits,mcx,NativeKMB,Op,MOD,W
from emit_coset_hmr import Shared,Trie,write_hmr
from reciprocal import data

def leaf_groups(cosets,scale):
 base=[];sub=defaultdict(lambda:defaultdict(list));scores=Counter()
 for s,V,H,a in cosets:
  for v,h in zip(V,H):scores[v,h]+=1 if len(V)==2 else 3
  if len(V)==2:scores[V[0]^V[1],H[0]*H[1]]+=1
 for s,V,H,a in cosets:
  a*=scale
  if not V:base.append((s,a));continue
  if len(V)==1:sub[V[0],H[0]][None].append((s,a));continue
  opts=list(zip(V,H))+[(V[0]^V[1],H[0]*H[1])];first=max(opts,key=lambda t:(scores[t],-t[0].bit_count(),-t[0]));second=min((t for t in opts if t!=first),key=lambda t:(-scores[t],t[0].bit_count(),t[0]));sub[first][second].append((s,a))
 return base,sub

def pivot_basis(B):
 tab={}
 for j,v in enumerate(B):
  c=1<<j
  while v:
   p=v.bit_length()-1
   if p not in tab:tab[p]=(v,c);break
   a,b=tab[p];v^=a;c^=b
  assert v,'dependent basis'
 return tab

def reduce(v,tab):
 c=0;r=0
 while v:
  p=v.bit_length()-1
  if p in tab:a,b=tab[p];v^=a;c^=b
  else:r^=1<<p;v^=1<<p
 return r,c

def batches(keys,cap,seed,keep):
 # Greedy largest quotient coset gain; retain selected old basis elements
 # across multiple batches. No approximation or sample-domain identities.
 rng=random.Random(seed);rem=set(v for v,h in keys);B=[];out=[];paid=0
 while rem:
  old=B[:];B=[]
  if keep and old:
   for _ in range(min(keep,len(old),cap)):
    T=pivot_basis(B);cand=[v for v in old if reduce(v,T)[0]]
    if not cand:break
    def merit(v):
     q=reduce(v,T)[0];return sum(reduce(a,T)[0]==q for a in rem)
    B.append(max(cand,key=lambda v:(merit(v),-v.bit_count(),-v)))
  while len(B)<cap:
   T=pivot_basis(B);C=defaultdict(list)
   for v in sorted(rem):
    r,_=reduce(v,T)
    if r:C[r].append(v)
   if not C:break
   # Use the shortest actual vector in the chosen residual class, or residual itself.
   q=max(C,key=lambda r:(len(C[r]),-min(v.bit_count()for v in C[r]),rng.random()if seed else -r))
   cand=C[q]+[q];v=min(cand,key=lambda a:(a not in old,a.bit_count(),a));B.append(v)
  T=pivot_basis(B);sel=sorted(v for v in rem if reduce(v,T)[0]==0)
  if not sel:
   # A retention policy may otherwise exhaust the basis with stale vectors.
   B=[min(rem)];T=pivot_basis(B);sel=[v for v in sorted(rem)if reduce(v,T)[0]==0]
  rem.difference_update(sel);paid+=sum(v not in old for v in B);out.append((B[:],[(v,h,reduce(v,T)[1])for v,h in keys if v in sel]))
 return paid,out

class Basis(Shared):
 def __init__(self,Q,scale):super().__init__(Q,True);self.scale=scale;self.ledger=[];self.plan_cache={}
 def plan(self,z,cap):
  key=(id(z),cap)
  if key in self.plan_cache:return self.plan_cache[key]
  base,sub=leaf_groups(z.data,self.scale);keys=sorted(sub);n=len(keys)
  if cap==0 or not keys:ans=(n,None)
  else:
   opts=[(n,None)]
   for keep in sorted({0,min(2,cap-1),min(4,cap-1),max(0,cap//2)}):
    for seed in range(3):opts.append(batches(keys,cap,seed,keep))
   ans=min(opts,key=lambda p:(p[0],len(p[1])if p[1]is not None else 0))
  self.plan_cache[key]=(ans,base,sub);return self.plan_cache[key]
 def leaf_basis(self,z,f,free):
  (cost,plan),base,sub=self.plan(z,len(free));d,p=z.d,z.p;assert f is not None
  self.sweep(f,base,d,p,[],[])
  def second(v,h,Z):
   self.sweep(self.c1,Z.get(None,[]),d,p,[v],[h])
   for s,co in sorted((s,c)for s,c in Z.items()if s is not None):
    u,j=s;self.condition(self.c1,u,j,self.c2);self.stats['second_condition']+=1
    self.sweep(self.c2,co,d,p,[v,u],[h,j]);self.condition(self.c1,u,j,self.c2,True)
  if plan is None:
   for (v,h),Z in sorted(sub.items()):
    self.condition(f,v,h,self.c1);self.stats['first_condition']+=1;second(v,h,Z);self.condition(f,v,h,self.c1,True)
   self.ledger.append([d,p,len(free),len(sub),len(sub),0]);return
  resident={};actual=0
  for B,K in plan:
   for v,t in list(resident.items()):
    if v not in B:self.condition(f,v,-1,t,True);del resident[v]
   for v in B:
    if v not in resident:
     t=next(t for t in free if t not in resident.values());self.condition(f,v,-1,t);resident[v]=t;actual+=1
   for v,h,c in K:
    assert v==self.xor_mask(B,c)
    ctr=[resident[B[j]]for j in bits(c)];ctr+=([f]if h==1 else [])
    for t in ctr:self.op(33,t,self.c1)
    second(v,h,sub[v,h]);self.stats['basis_served']+=1
    for t in ctr[::-1]:self.op(33,t,self.c1)
  for v,t in resident.items():self.condition(f,v,-1,t,True)
  assert actual==cost;self.stats['basis_products']+=actual;self.ledger.append([d,p,len(free),len(sub),actual,len(plan)])
 @staticmethod
 def xor_mask(B,c):
  v=0
  for i in bits(c):v^=B[i]
  return v
 def prefixcost(self,d):
  if not d:return 0
  if d<=self.Q-W+1:return max(0,2*d-3)
  return 2*sum(o.raw==49 for o in mcx(list(range(W-d,W)),self.flags[0],self.Q))
 def prefix(self,d,p,t,clear=False):
  cs=list(range(W-d,W));neg=[q for q in cs if not(p>>(q-(W-d))&1)]
  if d>self.Q-W+1:
   self.pred(d,p,t);return
  for q in neg:self.op(17,q)
  if d==1:self.op(33,cs[0],t)
  else:
   free=[q for q in range(W,self.Q)if q!=t];anc=free[:d-2];assert len(anc)==d-2
   chain=[]
   for i,g in enumerate(anc):
    a,b=(cs[0],cs[1])if i==0 else(anc[i-1],cs[i+1]);self.op(49,a,b,g);chain.append((g,[a,b]))
   ab=cs if d==2 else[anc[-1],cs[-1]]
   if clear:self.erase(t,ab)
   else:self.op(49,*ab,t)
   for g,ab in reversed(chain):self.erase(g,ab)
  for q in neg[::-1]:self.op(17,q)
 @functools.lru_cache(None)
 def walkcost(self,z,cap):
  if z.data is not None:
   if z.d==0:return 10**8
   return self.plan(z,cap)[0][0] # second conditions are invariant under cut choice
  if cap<1:return 10**8
  return (1 if z.d else 0)+sum(self.walkcost(c,cap-1)for c in z.ch.values())
 @functools.lru_cache(None)
 def splitcost(self,z):
  cap=len(self.flags);prefix=self.prefixcost(z.d)
  direct=prefix+self.walkcost(z,cap-int(bool(z.d)))
  nested=sum(self.splitcost(c)[0]for c in z.ch.values())if z.ch else 10**8
  return (direct,True)if direct<=nested else (nested,False)
 def walk(self,z,f,free,scale):
  if z.data is not None:self.leaf_basis(z,f,free);return
  assert free;g=free[0];q=W-z.d-1
  if len(z.ch)==1:
   b,c=next(iter(z.ch.items()));self.child(f,q,g,b);self.walk(c,g,free[1:],scale);self.child(f,q,g,b,True)
  else:
   self.child(f,q,g,1);self.walk(z.ch[1],g,free[1:],scale)
   if f is None:self.op(17,g)
   else:self.op(33,f,g)
   self.walk(z.ch[0],g,free[1:],scale);self.child(f,q,g,0,True)
 def split(self,z,scale):
  cost,direct=self.splitcost(z)
  if direct:
   if z.d==0:self.walk(z,None,self.flags,scale);return
   f=self.flags[0];self.prefix(z.d,z.p,f);self.stats['direct_prefix']+=1;self.walk(z,f,self.flags[1:],scale);self.prefix(z.d,z.p,f,True);return
  for c in z.ch.values():self.split(c,scale)

def run(planpath,Q=36,assignment=None):
 t=time.time();P=json.load(open(planpath));scale=MOD//P['scale'];rep,nrep=select_reps(P)
 if assignment:
  groups,*_=data(P);a=dict(json.load(open(assignment))['assignment']);rep=defaultdict(list)
  for j,(bi,s,V,H,v,o)in enumerate(groups):
   u=a[j];assert choices(u,V,H,o[u])==o;rep[bi].append((u,V,H,o[u]))
  nrep=len({s for cs in rep.values()for s,V,H,a in cs if s})
 e=Basis(Q,scale);root=Trie(0,0)
 for i,b in enumerate(P['blocks']):
  d=W-b['k'];p=b['start']>>b['k'];z=root
  for j in range(d):
   bit=p>>(d-j-1)&1
   if bit not in z.ch:z.ch[bit]=Trie(z.d+1,z.p*2+bit)
   z=z.ch[bit]
  assert z.data is None and not z.ch;z.data=rep[i]
 print('opt prefix+basis cost',e.splitcost(root),flush=True);e.split(root,scale);e.sweep(None,list(e.plain.items()),0,0,[],[])
 ref=NativeKMB.read('reference_header.kmb');stem=f'reciprocal_prefix_Q{Q}';p=Path(stem+'.kmb');write_hmr(ref,p,e.ops,e.angles,Q,True);c=Counter(o.raw for o in e.ops)
 r=dict(width=Q,ops=len(e.ops),ccx=c[49],cx=c[33],x=c[17],rotations=len(e.angles),generic=sum(a%(1<<125)!=0 for a in e.angles),hmr=c[80],cosets=P['cosets'],representatives=nrep,**e.stats,sha256=hashlib.sha256(p.read_bytes()).hexdigest(),seconds=time.time()-t)
 Path(stem+'.json').write_text(json.dumps(dict(stats=r,tags=e.tags,angles=[str(x)for x in e.angles],ledger=e.ledger),separators=(',',':')));print(r,flush=True)
 print('first predicate',sum(x[3]for x in e.ledger),'->',sum(x[4]for x in e.ledger),'batches',sum(x[5]for x in e.ledger),flush=True);return stem
if __name__=='__main__':run(sys.argv[1],int(sys.argv[2]),sys.argv[3]if len(sys.argv)>3 else None)
