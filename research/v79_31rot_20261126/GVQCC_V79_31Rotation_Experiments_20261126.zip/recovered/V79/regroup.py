"""Repartition Fourier support into equal-magnitude signed affine cosets.
Unlike lattice rounding alone, this rebuilds the actual nonlinear guards.
A compatible parallelogram uses four frequencies with product of signs +1.
"""
import json,collections,itertools,random,sys,time,copy
from pathlib import Path
from emit_coset import choices

def decomp(q,seed=0,weights=(1,0,0)):
 by=collections.defaultdict(dict)
 for s,a in q.items():
  if a:by[abs(a)][int(s)]=1 if a>0 else -1
 rng=random.Random(seed);out=[];guards=collections.Counter()
 for a,D in sorted(by.items(),key=lambda x:-len(x[1])):
  keys=sorted(D);quad=[]
  # Enumerate compatible affine planes by parallel edge pairs; exact
  # disjoint packing via weighted greedy; orientation is also optimized.
  dif=collections.defaultdict(list)
  for s,t in itertools.combinations(keys,2):dif[s^t,D[s]*D[t]].append((s,t))
  seen=set()
  for (v,h),L in dif.items():
   for (s,t),(u,z) in itertools.combinations(L,2):
    if len({s,t,u,z})!=4:continue
    k=tuple(sorted((s,t,u,z)))
    if k in seen:continue
    seen.add(k);S=k[0];A=k[1]^S;B=k[2]^S
    assert (S^A^B)==k[3]
    vs=[A,B,A^B];hs=[D[S]*D[S^j] for j in vs]
    assert hs[0]*hs[1]==hs[2]
    quad.append((k,S,vs,hs))
  remain=set(keys)
  # Existing guard sharing and sparsity prioritize cheap physical products.
  while quad:
   cand=[]
   for k,S,vs,hs in quad:
    if not set(k)<=remain:continue
    opts=list(zip(vs,hs));u=max(opts,key=lambda x:(guards[x],-x[0].bit_count(),x));v=max((x for x in opts if x!=u),key=lambda x:(guards[x],-x[0].bit_count(),x));
    vscore=weights[0]*(guards[u]+guards[v]) - weights[1]*(u[0].bit_count()+v[0].bit_count()) - weights[2]*min(s.bit_count() for s in k)
    cand.append((vscore,rng.random(),k,S,u,v))
   if not cand:break
   _,_,k,S,u,v=max(cand);remain.difference_update(k);guards[u]+=1;guards[v]+=1;out.append([S,[u[0],v[0]],[u[1],v[1]],4*a*D[S]])
   # For large group avoid repeated scanning all invalid planes.
   quad=[c for c in quad if not set(c[0]).intersection(k)]
  while len(remain)>1:
   s,t=max(itertools.combinations(sorted(remain),2),key=lambda st:(weights[0]*guards[st[0]^st[1],D[st[0]]*D[st[1]]]-weights[1]*(st[0]^st[1]).bit_count()-weights[2]*min(st[0].bit_count(),st[1].bit_count()),rng.random()));v=s^t;h=D[s]*D[t];remain.remove(s);remain.remove(t);guards[v,h]+=1;out.append([s,[v],[h],2*a*D[s]])
  for s in remain:out.append([s,[],[],a*D[s]])
 check=collections.Counter()
 for s,V,H,a in out:check.update(choices(s,V,H,a//(1<<len(V))))
 assert {s:v for s,v in check.items() if v}=={int(s):v for s,v in q.items() if v}
 return out

def run(src,out,seed):
 P=json.load(open(src));t=time.time();old=0;new=0;stat=[]
 for i,b in enumerate(P['blocks']):
  C={int(s):a for s,a in b['coeff'].items()};n=len(b['cosets']);old+=n
  # Reject representations with more terms. Try distinct sharing/sparsity priorities.
  best=b['cosets'];merit=lambda a:(len(a),sum(len(c[1]) for c in a),sum(v.bit_count() for c in a for v in c[1]))
  for j,w in enumerate(((1,1,0),(1,0,1),(0,1,1),(3,1,1))):
   a=decomp(C,seed+i*7+j,w)
   if merit(a)<merit(best):best=a
  b['cosets']=best;new+=len(best);stat.append([b['start'],n,len(best)])
 P['cosets']=new;P['regroup_stats']=stat;P['regroup_seconds']=time.time()-t;Path(out).write_text(json.dumps(P));print('regroup',old,'->',new,'sec',time.time()-t,flush=True)
if __name__=='__main__':run(sys.argv[1],sys.argv[2],int(sys.argv[3]))
