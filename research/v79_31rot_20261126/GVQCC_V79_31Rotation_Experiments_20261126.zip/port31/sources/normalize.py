import sys,struct,json,hashlib,math
from pathlib import Path
from collections import Counter
import numpy as np
P=Path(__file__).parent
SRC=P/'source_template.kmb'
from native_kmb import Op,NativeKMB
K=NativeKMB.read(SRC);N=3133452

def mcx(cs,t,Q):
 cs=list(cs);n=len(cs);assert t not in cs and len(set(cs))==n
 if n==0:return [Op(17,(t,))]
 if n==1:return [Op(33,(cs[0],t))]
 if n==2:return [Op(49,(*cs,t))]
 spare=[q for q in range(Q) if q not in cs+[t]]
 if len(spare)>=n-2:
  a=spare[:n-2];l=[Op(49,(cs[0],cs[1],a[0]))]+[Op(49,(cs[i+1],a[i-1],a[i]))for i in range(1,n-2)];g=[Op(49,(cs[-1],a[-1],t))]
  return l+g+l[::-1]+l[1:]+g+l[1:][::-1]
 assert spare
 d=spare[0];k=(n+1)//2;u=mcx(cs[:k],d,Q);v=mcx(cs[k:]+[d],t,Q)
 return u+v+u+v

def fredkin(h,a,b):return [Op(33,(a,b)),Op(49,(h,b,a)),Op(33,(a,b))]

def normalize(radix=4,mode='chains',Q=None):
 shifts=[16,8,4,2] if radix==4 else [16,8,4,2,1];Q=Q or 22+len(shifts);ops=[];stats=[]
 for k,d in enumerate(shifts):
  h=22+k;cs=list(range(22-d,22));neg=[Op(17,(q,)) for q in cs];test=neg+mcx(cs,h,Q)+neg[::-1]
  if mode=='chains':pairs=[(i,i+d)for i in range(21-d,-1,-1)]
  elif mode=='cycles':
   seen=set();pairs=[]
   for i in range(22):
    if i in seen:continue
    c=[];j=i
    while j not in seen:seen.add(j);c.append(j);j=(j+d)%22
    pairs += [(c[0],v) for v in c[1:]]
  else:raise ValueError(mode)
  body=sum((fredkin(h,a,b) for a,b in pairs),[]);ops+=test+body;stats.append(dict(shift=d,flag=h,zero_test_ccx=sum(o.raw==49 for o in test),move_ccx=len(pairs)))
 return ops,stats,Q

def emit(ops,Q,angles,out):
 h=list(K.header);h[1]=Q;h[2]=0;h[10]=len(angles)
 sections=[(i,b''.join(struct.pack('<QQ',0,int(a)%(1<<64)) for a in angles) if i==10 else b) for i,b in K.sections]
 C=NativeKMB(K.prefix16,tuple(h),sections,ops);out.write_bytes(C.to_bytes());D=NativeKMB.read(out);assert D.ops==ops and D.header[1]==Q
 return D

def masks(Q,N=N):
 x=np.arange(1,N+1,dtype=np.uint32)
 def pk(y):return int.from_bytes(np.packbits(y,bitorder='little').tobytes(),'little')
 return x,pk,[pk((x>>j)&1) for j in range(22)]+[0]*(Q-22),(1<<N)-1

def apply(s,one,ops):
 for o in ops:
  g=o.raw;w=o.wires
  if g==17:s[w[0]]^=one
  elif g==33:s[w[1]]^=s[w[0]]
  elif g==49:s[w[2]]^=s[w[0]]&s[w[1]]
  elif g==34:s[w[0]],s[w[1]]=s[w[1]],s[w[0]]
  else:raise ValueError(o)

def check(C,radix,mid):
 x,pk,s,one=masks(C.header[1]);orig=s[:];e=np.zeros(len(x),np.uint32)
 for k in range(1,22):e[x>=1<<k]=k
 sh=21-e if radix==2 else 2*((21-e)//2)
 y=x<<sh;apply(s,one,C.ops[:mid]);assert s[:22]==[pk((y>>j)&1) for j in range(22)]
 shifts=[16,8,4,2]if radix==4 else [16,8,4,2,1]
 for k,d in enumerate(shifts):assert s[22+k]==pk((sh&d)!=0)
 assert not any(s[22+len(shifts):]);apply(s,one,C.ops[mid:]);assert s==orig
 return dict(legal=len(x),normalization='PASS',restoration='PASS')

if __name__=='__main__':
 rows=[]
 for radix in (2,4):
  for mode in ('cycles','chains'):
   o,st,Q=normalize(radix,mode);C=emit(o+o[::-1],Q,[],P/f'normalizer_r{radix}_{mode}_Q{Q}_ROUNDTRIP_ONLY.kmb');r=dict(radix=radix,mode=mode,width=Q,forward_ccx=sum(z.raw==49 for z in o),total_ccx=sum(z.raw==49 for z in C.ops),ops=len(C.ops),stages=st,verification=check(C,radix,len(o)),sha=C.stats()['sha256']);rows.append(r);print(r,flush=True)
 (P/'normalize.json').write_text(json.dumps(rows,indent=2))
