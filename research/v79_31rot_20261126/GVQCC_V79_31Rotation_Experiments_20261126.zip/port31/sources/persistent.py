"""Persistent mixed nonlinear factors across ALL coefficient groups.
Exact tensor identity on normalized high!=00 care set. Global finite dictionary
optimization, not repeated local native-window search. Includes measured normalizer.
"""
from loader import *
from normalize_measured import Builder as NormBuilder
from functools import lru_cache

DIC=tuple([(v,1,v)for v in range(1,128)]+[(v<<7,2,v)for v in range(1,128)]+[(v|(v<<7),3,v)for v in range(1,128)])
DECODE={z:(k,v)for z,k,v in DIC}

def frames(C,nout,order):
 widths=[int(np.max(np.abs(C[:,k]))).bit_length() for k in range(C.shape[1])];fs=[(k,j)for k,w in enumerate(widths)for j in range(w)]
 if order=='bitplane':fs.sort(key=lambda z:(z[1],z[0]))
 out=[]
 for i in range(0,len(fs),nout):
  g=fs[i:i+nout];A=[[anf((np.abs(C[h*8:(h+1)*8,k])>>j)&1)for k,j in g]for h in range(3)];a=[x^y for x,y in zip(A[0],A[2])];b=[x^y for x,y in zip(A[1],A[2])];v=tuple((x>>1)|((y>>1)<<7) for x,y in zip(a,b));out.append(dict(group=g,base=2,other=[0,1],base_masks=A[2],const=[sum((x&1)<<j for j,x in enumerate(a)),sum((x&1)<<j for j,x in enumerate(b))],V=v))
 return out,widths

def cache_basis(ca):
 B={}
 for i,z in enumerate(ca):
  x=z;t=1<<i
  while x:
   k=x.bit_length()-1
   if k not in B:B[k]=(x,t);break
   y,u=B[k];x^=y;t^=u
  else:return None
 return sorted(B.items(),reverse=True)

def reduce(v,B):
 r=0
 for j,(x,t)in B:
  if v>>j&1:v^=x;r^=t
 return v,r

def screen(fr,ca):
 B=cache_basis(ca)
 if B is None:return 10**9
 cost=0
 for f in fr:
  vs=[reduce(v,B)[0]for v in f['V']];cost+=rank([x&127 for x in vs])+rank([x>>7 for x in vs])
 return cost

def detail(fr,ca):
 B=cache_basis(ca);assert B is not None;out=[];cost=0
 for f in fr:
  z=[reduce(v,B)for v in f['V']];vs=[x for x,t in z];ts,orig,shr,att=joint([x&127 for x in vs],[x>>7 for x in vs],True);p={**f,'terms':ts,'cached_coeff':[t for x,t in z],'rank_sum':orig,'shared':shr,'attempts':att};out.append(p);cost+=len(ts)
 return cost,out

def search(fr,k,beam=3):
 # Fixed whole-group partition. Across all coefficient outputs, score each dictionary addition.
 states=[(screen(fr,()),())];probes=0
 for i in range(k):
  cand={}
  for _,ca in states:
   for z,_,_ in DIC:
    if z in ca:continue
    cc=tuple(sorted((*ca,z)))
    if cc in cand:continue
    cand[cc]=screen(fr,cc);probes+=1
  states=sorted((v,cc)for cc,v in cand.items())[:beam]
 best=None
 for _,ca in states:
  cost,pl=detail(fr,ca);p=(cost,ca,pl)
  if best is None or p[:2]<best[:2]:best=p
 return *best,probes

class Cached(Builder):
 def __init__(self,Q):super().__init__(Q)
 def atom(self,z,t,erase=False):
  k,v=DECODE[z];h={1:H[0],2:H[1],3:H[0]^H[1]}[k];pa,a=form_ops(h,{1:20,2:21});pb,b=form_ops(v<<1,LOW);self.add(pa+pb)
  if erase:self.erase_and(a,b,t)
  else:self.add([Op(49,(a,b,t))])
  self.add(pb[::-1]+pa[::-1])
 def loadcached(self,pl,targets,ncache):
  for j,t in enumerate(targets):self.add([Op(33,(31+c,t)) for c in bits(pl['cached_coeff'][j])]);
  self.load(pl,targets)
 def normpart(self,rev=False):
  a=NormBuilder(self.Q,False);a.m=self.records;ss=list(enumerate([16,8,4,2]));ss=ss[::-1]if rev else ss
  for k,d in ss:a.stage(k,d,rev)
  self.add(a.ops);self.records=a.m

def build_cached(C,Q,k,order):
 nout=Q-31-k;assert nout>=1;fr,width=frames(C,nout,order);cost,ca,pl,probes=search(fr,k);B=Cached(Q);B.normpart();cache=[(17,18,26),(17,19,27),(18,19,28),(26,19,29)];B.add([Op(49,t)for t in cache]);
 for i,z in enumerate(ca):B.atom(z,31+i)
 snap=[]
 for p in pl:
  t=list(range(31+k,31+k+len(p['group'])));B.loadcached(p,t,k);snap.append((len(B.ops),p['group'],t));B.loadcached(p,t,k)
 for i in reversed(range(len(ca))):B.atom(ca[i],31+i,True)
 for a,b,t in cache[::-1]:B.erase_and(a,b,t)
 B.normpart(True)
 return B,snap,dict(Q=Q,k=k,order=order,cache=list(ca),cache_atoms=[DECODE[z]for z in ca],probes=probes,rank_products_forward=cost,groups=len(pl),ccx=sum(o.raw==49 for o in B.ops),ops=len(B.ops),hmr=B.records)

if __name__=='__main__':
 C=np.load(P/'B34_model1.npz')['C'];allrows=[];t=time.time()
 for Q in [33,34,35,36]:
  for k in range(Q-31):
   for order in ('coefficient','bitplane'):
    B,sn,r=build_cached(C,Q,k,order);allrows.append(r);print(r,'sec',round(time.time()-t,1),flush=True);(P/'persistent_search.json').write_text(json.dumps(allrows,indent=2))
 out=[]
 for Q in [33,34,35,36]:
  r=min((x for x in allrows if x['Q']==Q),key=lambda x:(x['ccx'],x['ops']));B,sn,r2=build_cached(C,Q,r['k'],r['order']);assert r2==r;f=P/f'persistent_Q{Q}_PARTIAL.kmb';D=native(B,f);r={**r,'verification':verify(D,sn,C),'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'file':f.name};out.append(r);print('PASS',r,flush=True);(P/'persistent_receipts.json').write_text(json.dumps(out,indent=2));(P/f'persistent_Q{Q}_snap.json').write_text(json.dumps(sn))
