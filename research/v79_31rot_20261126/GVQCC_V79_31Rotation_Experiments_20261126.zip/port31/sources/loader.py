"""V55 global multi-output coefficient loader (not complete invsqrt oracle).
Uses radix-4 normalized care set, simultaneous two-slice GF2 tensor factorization,
and measurement-erased shared rank-one products. Reuses the low ANF basis
across every coefficient batch; no need to keep the entire coefficient word.
"""
import numpy as np, json, time, hashlib, struct, sys, itertools
from pathlib import Path
from normalize import *
P=Path(__file__).parent

def bits(x):
 while x:
  a=x&-x; yield a.bit_length()-1; x^=a

def basis(rows):
 B={}
 for r in rows:
  while r:
   k=r.bit_length()-1
   if k not in B:B[k]=r;break
   r^=B[k]
 return list(B.values())
def rank(rows): return len(basis(rows))
def span(rows):
 vals=[0]
 for r in basis(rows):vals += [v^r for v in vals]
 return set(vals)
def columns(rows):return [sum(((v>>i)&1)<<j for j,v in enumerate(rows)) for i in range(7)]
def outer_xor(rows,u,v):return tuple(r^(v if (u>>j)&1 else 0) for j,r in enumerate(rows))
def decompose(rows):
 # select independent rows and exact multi-output representations
 R=[]; piv={}
 for r in rows:
  t=r;c=0
  while t:
   k=t.bit_length()-1
   if k not in piv:
    piv[k]=(t,c^(1<<len(R)));R.append(r);break
   z,d=piv[k];t^=z;c^=d
 masks=[]
 for r in rows:
  t=r;c=0
  while t:
   z,d=piv[t.bit_length()-1];t^=z;c^=d
  masks.append(c)
 return [(sum(((m>>i)&1)<<j for j,m in enumerate(masks)),r) for i,r in enumerate(R)]
def joint(A,B,enabled=True):
 A,B=tuple(A),tuple(B);orig=rank(A)+rank(B);shared=[];attempts=0
 if enabled:
  # A shared rank-one term that drops both slice ranks saves one product.
  while True:
   us=span(columns(A))&span(columns(B));vs=span(A)&span(B)
   us.discard(0);vs.discard(0);cand=None;ra,rb=rank(A),rank(B)
   for u in sorted(us,key=lambda x:(-x.bit_count(),x)):
    for v in sorted(vs,key=lambda x:(x.bit_count(),x)):
     attempts+=1;a=outer_xor(A,u,v);b=outer_xor(B,u,v)
     if rank(a)==ra-1 and rank(b)==rb-1:
      cand=(u,v,a,b);break
    if cand:break
   if not cand:break
   u,v,A,B=cand;shared.append((u,v))
 terms=[(1,u,v)for u,v in decompose(A)]+[(2,u,v)for u,v in decompose(B)]+[(3,u,v)for u,v in shared]
 assert len(terms)==orig-len(shared)
 return terms,orig,len(shared),attempts

def anf(vals):
 a=list(map(int,vals))
 for j in range(3):
  for i in range(8):
   if i>>j&1:a[i]^=a[i^(1<<j)]
 return sum(v<<i for i,v in enumerate(a))

def plan(C,group,jointflag):
 # table address [1..3]*8 + low 3 bits. coefficient sign constant per column
 A=[[anf((np.abs(C[h*8:(h+1)*8,k])>>j)&1) for k,j in group] for h in range(3)]
 best=None
 for base in range(3):
  i,j=[a for a in range(3) if a!=base];a=[x^y for x,y in zip(A[i],A[base])];b=[x^y for x,y in zip(A[j],A[base])];terms,orig,shared,attempts=joint([x>>1 for x in a],[x>>1 for x in b],jointflag)
  # products cost 1 each with measurement-erased shared product, regardless of fanout.
  score=(len(terms),sum(v.bit_count()+u.bit_count() for _,u,v in terms))
  rec=dict(base=base,other=[i,j],base_masks=A[base],const=[sum((x&1)<<k for k,x in enumerate(a)),sum((x&1)<<k for k,x in enumerate(b))],terms=terms,rank_sum=orig,shared=shared,attempts=attempts)
  if best is None or score<best[0]:best=score,rec
 return best[1]

# Affine high selectors on the normalized care set high two bits != 00.
# branches: 01,10,11; bit mask has bit0 constant, bit1 q20, bit2 q21.
H=[5,3,7]
LOW={1:17,2:18,3:26,4:19,5:27,6:28,7:29}

def form_ops(mask,wiremap):
 # mask's low bit is constant, other positions are stored basis functions.
 ids=[wiremap[i] for i in bits(mask&~1)];assert ids;t=ids[0]
 ops=[Op(33,(q,t))for q in ids[1:]]+([Op(17,(t,))] if mask&1 else [])
 return ops,t

class Builder:
 def __init__(self,Q):self.Q=Q;self.ops=[];self.records=0
 def add(self,ops):self.ops.extend(ops)
 def erase_and(self,a,b,t):
  m=self.records;self.records+=1
  self.add([Op(80,(t,),measurement=m),Op(160,(a,b),condition=m),Op(64,(),measurement=m)])
 def load(self,P,targets,shared=True):
  # base masks: linear in low ANF basis, plus constant. Free CX.
  for t,m in zip(targets,P['base_masks']):
   if m&1:self.add([Op(17,(t,))])
   self.add([Op(33,(LOW[i],t))for i in bits(m&~1)])
  hs=[H[i] for i in P['other']];hs.append(hs[0]^hs[1]);hm={1:hs[0],2:hs[1],3:hs[2]}
  for h,mask in zip(hs,P['const']):
   if not mask:continue
   prep,a=form_ops(h,{1:20,2:21});self.add(prep)
   self.add([Op(33,(a,targets[j]))for j in bits(mask)]);self.add(prep[::-1])
  # Keep high affine coordinate in the same gauge across all terms of a slice.
  for kind in (1,2,3):
   sub=[(u,v)for k,u,v in P['terms']if k==kind]
   if not sub:continue
   pre,a=form_ops(hm[kind],{1:20,2:21});self.add(pre)
   for u,v in sub:
    prep,b=form_ops(v<<1,LOW);self.add(prep)
    ts=[targets[j]for j in bits(u)]
    if len(ts)==1:self.add([Op(49,(a,b,ts[0]))])
    else:
     self.add([Op(49,(a,b,30))]+[Op(33,(30,t))for t in ts]);self.erase_and(a,b,30)
    self.add(prep[::-1])
   self.add(pre[::-1])

def build(C,Q,enabled,order='coefficient'):
 width=[int(np.max(np.abs(C[:,k]))).bit_length() for k in range(C.shape[1])]
 fields=[(k,j)for k,w in enumerate(width)for j in range(w)]
 if order=='bitplane':fields.sort(key=lambda v:(v[1],v[0]))
 nout=Q-31;assert nout>=1
 # Global coefficient basis remains live across every group.
 norm,_,_=normalize(4,'chains',26);B=Builder(Q);B.add(norm)
 cache=[(17,18,26),(17,19,27),(18,19,28),(26,19,29)]
 B.add([Op(49,t)for t in cache]);snap=[];groups=[]
 for start in range(0,len(fields),nout):
  group=fields[start:start+nout];p=plan(C,group,enabled);tg=list(range(31,31+len(group)))
  B.load(p,tg);snap.append((len(B.ops),group,tg));B.load(p,tg);groups.append(p)
 for a,b,t in cache[::-1]:B.erase_and(a,b,t)
 B.add(norm[::-1]);return B,snap,groups,width

def native(B,out):
 h=list(K.header);h[1]=B.Q;h[2]=B.records;h[10]=0
 sections=[(i,b'' if i==10 else b)for i,b in K.sections];D=NativeKMB(K.prefix16,tuple(h),sections,B.ops);out.write_bytes(D.to_bytes());R=NativeKMB.read(out);assert R.ops==B.ops and R.header[1]==B.Q;return R

def verify(D,snap,C):
 x,pk,s,one=masks(D.header[1]);orig=s[:];e=np.zeros(len(x),np.uint32)
 for k in range(1,11):e[x>=1<<(2*k)]=k
 U=x<<(2*(10-e));a=(U>>17)-8;ph={};checks=0;coins=0;sn=dict((i,(g,t))for i,g,t in snap)
 for i,o in enumerate(D.ops,1):
  w=o.wires;g=o.raw
  if g in (17,33,49,34):apply(s,one,[o])
  elif g==80:
   assert o.measurement not in ph;ph[o.measurement]=s[w[0]];s[w[0]]=0;coins+=1
  elif g==160:ph[o.condition]^=s[w[0]]&s[w[1]]
  elif g==64:assert ph.pop(o.measurement)==0
  else:raise ValueError(o)
  if i in sn:
   gr,tg=sn[i]
   for (k,b),t in zip(gr,tg):assert s[t]==pk((np.abs(C[a,k])>>b)&1),(i,k,b);checks+=1
 assert s==orig and not ph
 return dict(legal=len(x),coefficient_bits_checked=checks,independent_HMR=coins,restoration='PASS',phase_coefficients='PASS')

if __name__=='__main__':
 model=np.load(P/'B34_model1.npz');C=model['C'];results=[];start=time.time()
 # all variants share the same exact model; evaluate global group order and factorization.
 for Q in [32,33,34,35,36]:
  for enabled in [False,True]:
   for order in ['coefficient','bitplane']:
    B,sn,g,w=build(C,Q,enabled,order);r=dict(Q=Q,joint=enabled,order=order,widths=w,ccx=sum(o.raw==49 for o in B.ops),ops=len(B.ops),hmr=B.records,groups=len(g),rank_sum=sum(x['rank_sum']for x in g),shared=sum(x['shared']for x in g),probes=sum(x['attempts']for x in g));results.append(r);print(r,flush=True)
 (P/'loader_search.json').write_text(json.dumps(results,indent=2));out=[]
 for Q in range(32,37):
  for enabled in [False,True]:
   r=min((r for r in results if r['Q']==Q and r['joint']==enabled),key=lambda r:(r['ccx'],r['ops']));B,sn,g,w=build(C,Q,enabled,r['order']);path=P/f'loader_Q{Q}_joint{int(enabled)}_PARTIAL.kmb';D=native(B,path);r={**r,'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'verification':verify(D,sn,C)};out.append(r);print('PASS',r,'sec',round(time.time()-start,1),flush=True);(P/'loader_receipts.json').write_text(json.dumps(out,indent=2));(P/f'loader_Q{Q}_joint{int(enabled)}_snap.json').write_text(json.dumps(sn))
