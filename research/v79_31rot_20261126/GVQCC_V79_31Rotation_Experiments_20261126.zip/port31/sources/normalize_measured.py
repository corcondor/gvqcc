"""Width-adaptive exact AND tree: choose dirty MCX vs clean product cache,
with free HMR+CZ cleanup or conditional CCZ for three factors.
No postselection. Every random measurement phase is canceled before its
record is cleared. Used for a radix-4 normalizer roundtrip.
"""
from normalize import *
from functools import lru_cache
from fractions import Fraction

@lru_cache(None)
def direct_cost(n,Q):return 2*sum(o.raw==49 for o in mcx(list(range(n)),n,Q))
@lru_cache(None)
def dp(n,c,Q,allow_ccz=True):
 # Units 1/2 expected paid; all clean slots available can also be borrowed dirty.
 z=(direct_cost(n,Q),('dirty',))
 if n<=2 or not c:return z
 for k in range(2,n):
  a,aa=dp(k,c-1,Q,allow_ccz);b,bb=dp(n-k+1,c-1,Q,allow_ccz)
  # An exact temporary XOR oracle can be rerun to erase its output.
  # HMR + CZ or CCZ eliminates compute recurrence where controls survive.
  erase=0 if k==2 else 1 if k==3 and allow_ccz else a
  p=(a+b+erase,('split',k,k==2 or (k==3 and allow_ccz)))
  if p[0]<z[0]:z=p
 return z

class Builder:
 def __init__(self,Q,allow_ccz=True):self.Q=Q;self.allow_ccz=allow_ccz;self.ops=[];self.m=0
 def add(self,o):self.ops+=o
 def andxor(self,cs,t,clean):
  c=len(clean);n=len(cs);cost,op=dp(n,c,self.Q,self.allow_ccz)
  if op[0]=='dirty':self.add(mcx(cs,t,self.Q));return
  _,k,measure=op;d=clean[0];cc=clean[1:]
  self.andxor(cs[:k],d,cc);self.andxor(cs[k:]+[d],t,cc)
  if measure:
   m=self.m;self.m+=1;self.add([Op(80,(d,),measurement=m),Op(160 if k==2 else 176,tuple(cs[:k]),condition=m),Op(64,(),measurement=m)])
  else:self.andxor(cs[:k],d,cc)
 def stage(self,k,d,reverse=False):
  h=22+k;cs=list(range(22-d,22));cl=list(range(h+1,self.Q));neg=[Op(17,(q,))for q in cs]
  moves=sum((fredkin(h,i,i+d)for i in range(21-d,-1,-1)),[])
  if reverse:self.add(moves[::-1])
  self.add(neg);self.andxor(cs,h,cl);self.add(neg[::-1]);
  if not reverse:self.add(moves)

def write(B,path):
 h=list(K.header);h[1]=B.Q;h[2]=B.m;h[10]=0
 sections=[(i,b'' if i==10 else b)for i,b in K.sections];D=NativeKMB(K.prefix16,tuple(h),sections,B.ops);path.write_bytes(D.to_bytes());R=NativeKMB.read(path);assert R.ops==B.ops;return R

def verify(C,mid):
 x,pk,s,one=masks(C.header[1]);orig=s[:];ph={};e=np.zeros(len(x),np.uint32)
 for k in range(1,11):e[x>=1<<(2*k)]=k
 sh=2*(10-e);y=x<<sh
 for i,o in enumerate(C.ops,1):
  g=o.raw;w=o.wires
  if g in (17,33,49,34):apply(s,one,[o])
  elif g==80:ph[o.measurement]=s[w[0]];s[w[0]]=0
  elif g in (160,176):
   p=one
   for q in w:p&=s[q]
   ph[o.condition]^=p
  elif g==64:assert ph.pop(o.measurement)==0
  else:raise ValueError(o)
  if i==mid:
   assert s[:22]==[pk((y>>j)&1)for j in range(22)]
   for k,d in enumerate([16,8,4,2]):assert s[22+k]==pk((sh&d)!=0)
   assert not any(s[26:]);assert not ph
 assert s==orig and not ph
 return dict(legal=len(x),normalization='PASS',restoration='PASS',phase='PASS')
if __name__=='__main__':
 out=[]
 for Q in range(26,33):
  for allow in (False,True):
   B=Builder(Q,allow);shifts=[16,8,4,2]
   for k,d in enumerate(shifts):B.stage(k,d)
   mid=len(B.ops)
   for k,d in reversed(list(enumerate(shifts))):B.stage(k,d,True)
   f=P/f'normalizer_measured_Q{Q}_ccz{int(allow)}_ROUNDTRIP_ONLY.kmb';C=write(B,f);ccx=sum(o.raw==49 for o in C.ops);ccz=sum(o.raw==176 for o in C.ops);r=dict(Q=Q,allow_ccz=allow,ops=len(C.ops),ccx=ccx,guarded_ccz=ccz,expected_paid=ccx+ccz/2,hmr=B.m,mid=mid,dp=[dp(d,Q-(22+k)-1,Q,allow)[0]/2 for k,d in enumerate(shifts)],sha256=hashlib.sha256(f.read_bytes()).hexdigest(),verification=verify(C,mid));out.append(r);print(r,flush=True);(P/'normalize_measured.json').write_text(json.dumps(out,indent=2))
