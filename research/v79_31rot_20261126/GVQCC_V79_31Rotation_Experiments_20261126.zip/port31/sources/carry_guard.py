"""Exact finite partial-product omission and carry repair audit.
The low terms of integer multipliers are omitted before rounding. Tests final
integer phase tolerance, not just per-multiply error. This is a classical
arithmetic specification audit; no claim that products equal native CCX counts.
"""
from design import *
from itertools import product

def truncprod(v,t,l,g):
 k=max(0,l-g);a=np.abs(v);L=np.zeros_like(v)
 for i in range(k):L+=(((a>>i)&1)*(t&((1<<(k-i))-1)))<<i
 return (a*t-L)*np.sign(v),L

def evaluate_guard(C,B=34,F=32,guards=(17,)*4,qbits=(0,)*5):
 b=3;d=4;l=20-b;a=(U>>l)-(1<<b);t=U&((1<<l)-1)
 C1=C.copy()
 for j,k in enumerate(qbits):
  if k:C1[:,j]=((C1[:,j]+(1<<(k-1)))>>k)<<k
 v=C1[a,d];data=[];terms=0;base=0
 for j in reversed(range(d)):
  g=guards[j];width=int(np.max(np.abs(v))).bit_length();nfull=width*l;omitted=sum(max(0,min(l,l-g-i)) for i in range(width));p,L=truncprod(v,t,l,g);z=(p+(1<<(l-1)))>>l;exact=(v*t+(1<<(l-1)))>>l;dv=z-exact
  data.append(dict(stage=j,width=width,guard=g,partial_products=nfull-omitted,full_products=nfull,different_rounding=int(np.count_nonzero(dv)),max_rounding_delta=int(np.abs(dv).max()),max_omitted=int(L.max())))
  terms+=nfull-omitted;base+=nfull;v=C1[a,j]+z
 sh=F+e-B;z=np.empty_like(v)
 for k in np.unique(sh):
  m=sh==k;z[m]=(v[m]+(1<<(int(k)-1)))>>int(k)if k>0 else v[m]<<int(-k)
 phase=z.astype(np.uint64)<<np.uint64(64-B);err=np.abs((phase-target).view(np.int64));slack=tol.astype(np.int64)-err;return dict(guards=guards,qbits=qbits,partial_products=terms,full_products=base,coefficient_nonzero_bit_positions=[int(np.max(np.abs(C1[:,j]))).bit_length()-qbits[j]for j in range(5)],bad=int((slack<0).sum()),min_slack=int(slack.min()),max_ratio=float(np.max(err/tol)),stages=data),z
if __name__=='__main__':
 C=np.load(P/'B34_model1.npz')['C'];rows=[];st=time.time();seen=set();best=None
 # All stages varied jointly, plus front-loaded / rear-loaded guard allocation.
 choices=[(g,)*4 for g in [17,12,10,8,6,5,4,3,2,1,0]]+[(a,b,c,d)for a,b,c,d in [(7,5,3,2),(6,4,2,0),(7,4,2,0),(8,6,4,2),(9,6,3,0),(10,6,3,1),(8,8,2,2),(9,4,4,0),(5,5,5,0),(3,6,8,10),(4,6,8,10)]]
 for g in choices:
  r,z=evaluate_guard(C,guards=g);rows.append(r);print(g,r['partial_products'],r['bad'],r['min_slack'],'sec',round(time.time()-st,1),flush=True)
  if r['bad']==0 and (best is None or (r['partial_products'],-r['min_slack'])<(best[0]['partial_products'],-best[0]['min_slack'])):best=(r,z)
  (P/'carry_guard.json').write_text(json.dumps(rows,indent=2))
 if best:
  r,z=best;print('BEST',r,flush=True);np.savez(P/'carry_guard_best.npz',C=C,phase_code=z,guards=r['guards'])
  g0=r['guards'];choices=[(1,)*5,(2,)*5,(3,)*5,(4,)*5,(1,2,3,4,5),(0,1,2,3,4),(2,2,3,3,4),(1,1,1,2,2),(0,0,1,1,2)]
  for q in choices:
   r,z=evaluate_guard(C,guards=g0,qbits=q);rows.append(r);print('coeff',q,r['partial_products'],r['bad'],r['min_slack'],flush=True);(P/'carry_guard.json').write_text(json.dumps(rows,indent=2))
