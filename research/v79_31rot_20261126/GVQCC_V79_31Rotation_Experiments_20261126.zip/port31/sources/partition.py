"""Globally partition coefficient bit outputs by shared tensor subspaces.
Candidate-family set partitioning (MILP); exact native emission & replay.
The model is not the full invsqrt oracle. No global optimum outside candidate
family is claimed. Output order is an explicit ABI, not a bit-serial schedule.
"""
from persistent import *
from scipy.optimize import milp, Bounds, LinearConstraint
from scipy.sparse import coo_matrix
import random
from functools import lru_cache

def partition(C,Q,seed=55):
 rng=random.Random(seed);capacity=Q-31;w=[int(np.max(np.abs(C[:,k]))).bit_length()for k in range(C.shape[1])];allfields=[(k,b)for k,z in enumerate(w)for b in range(z)]
 fields=[(k,b)for k,b in allfields if np.unique((np.abs(C[:,k])>>b)&1).size>1];const=[(k,b,int((abs(C[0,k])>>b)&1))for k,b in allfields if (k,b)not in fields];n=len(fields)
 @lru_cache(None)
 def evalg(g):return len(plan(C,[fields[j]for j in g],True)['terms'])
 def cost(g):return evalg(tuple(sorted(g)))
 group_set={(j,)for j in range(n)}
 def add(g):g=tuple(sorted(g));group_set.add(g);return g
 # Exact pair similarity over all nonconstant outputs, then construct full covers
 # across the whole coefficient tensor rather than local circuit windows.
 if capacity>1:
  single=[cost((i,))for i in range(n)];near=[[]for i in range(n)]
  for i in range(n):
   for j in range(i+1,n):
    c=cost((i,j));s=single[i]+single[j]-c;near[i].append((-s,c,j));near[j].append((-s,c,i))
    if s>0:add((i,j))
  for i in range(n):near[i].sort()
  for i in range(n):
   cand=[j for _,_,j in near[i][:min(10,n-1)]]
   for seed2 in cand[:5]:
    g=add((i,seed2));pool=[j for j in cand if j not in g]
    while len(g)<capacity and pool:
     z=min(pool,key=lambda j:(cost((*g,j))-cost(g),cost((*g,j)),j));g=add((*g,z));pool.remove(z)
   # Diverse global groups, including uphill choices to avoid a single ranking.
   for _ in range(12):
    g=add((i,*rng.sample(cand,min(capacity-1,len(cand)))))
 # complete simple covers and random covers available to solver
 for order in (list(range(n)),sorted(range(n),key=lambda i:(fields[i][1],fields[i][0]))):
  for a in range(0,n,capacity):add(order[a:a+capacity])
 for _ in range(25):
  perm=list(range(n));rng.shuffle(perm)
  for a in range(0,n,capacity):add(perm[a:a+capacity])
 G=sorted(group_set);cc=np.array([cost(g)for g in G],float);ix=[];iy=[]
 for j,g in enumerate(G):ix+=list(g);iy+=[j]*len(g)
 M=coo_matrix((np.ones(len(ix)),(ix,iy)),shape=(n,len(G))).tocsc();res=milp(cc,integrality=np.ones(len(G)),bounds=Bounds(0,1),constraints=LinearConstraint(M,1,1),options={'time_limit':12.0,'mip_rel_gap':0.005})
 assert res.x is not None;chosen=[G[i]for i,z in enumerate(res.x)if z>.5];assert sorted(j for g in chosen for j in g)==list(range(n));groups=[ [fields[i]for i in g]for g in chosen]
 stats=dict(Q=Q,variable_bits=n,constant_bits=const,candidates=len(G),unique_cost_evals=evalg.cache_info().currsize,solver_status=int(res.status),lower_bound=float(res.mip_dual_bound),objective=int(sum(cost(g)for g in chosen)),groups=len(groups));return groups,stats

def build_partition(C,Q,groups):
 B=Cached(Q);B.normpart();cache=[(17,18,26),(17,19,27),(18,19,28),(26,19,29)];B.add([Op(49,t)for t in cache]);snap=[]
 for group in groups:
  p=plan(C,group,True);tg=list(range(31,31+len(group)));B.load(p,tg);snap.append((len(B.ops),group,tg));B.load(p,tg)
 for a,b,t in cache[::-1]:B.erase_and(a,b,t)
 B.normpart(True);return B,snap
if __name__=='__main__':
 C=np.load(P/'B34_model1.npz')['C'];qbits=[1,2,3,4,5]
 for j,k in enumerate(qbits):C[:,j]=((C[:,j]+(1<<(k-1)))>>k)<<k
 assert all(np.all(C[:,j]>=0)if j%2==0 else np.all(C[:,j]<=0)for j in range(5));np.save(P/'quantized_coefficients.npy',C)
 out=[];t=time.time()
 for Q in [33,34,35,36]:
  groups,r=partition(C,Q);B,sn=build_partition(C,Q,groups);f=P/f'partition_Q{Q}_PARTIAL.kmb';D=native(B,f);r.update(ccx=sum(o.raw==49 for o in B.ops),ops=len(B.ops),hmr=B.records,sha256=hashlib.sha256(f.read_bytes()).hexdigest(),file=f.name,verification=verify(D,sn,C));out.append(r);print('PASS',r,'sec',round(time.time()-t,1),flush=True);(P/'partition_receipts.json').write_text(json.dumps(out,indent=2));(P/f'partition_Q{Q}_snap.json').write_text(json.dumps(sn))
