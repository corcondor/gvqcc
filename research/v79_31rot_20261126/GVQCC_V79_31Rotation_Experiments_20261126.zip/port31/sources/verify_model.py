"""Independent exact integer reference and selected model replay."""
from carry_guard import *
from hashlib import sha256
import sys
N=3133452
ref=np.empty(N,np.uint64);tt=np.empty(N,np.int64)
for x in range(1,N+1):
 r=math.isqrt((1<<130)//x);ref[x-1]=((r+1)//2)%MOD;tt[x-1]=r>>25
assert np.array_equal(ref,target) and np.array_equal(tt,tol)
C=np.load(P/'B34_model1.npz')['C'];r,z=evaluate_guard(C,guards=(0,)*4,qbits=(1,2,3,4,5));assert r['bad']==0 and r['min_slack']==54096592
# Independently evaluate as sums of retained terms, not as full product-minus-omission.
a=(U>>17)-8;t=U&((1<<17)-1);D=np.load(P/'quantized_coefficients.npy');v=D[a,4].copy();pc=0
for j in reversed(range(4)):
 av=np.abs(v);p=np.zeros_like(v);w=int(av.max()).bit_length()
 for i in range(w):
  for k in range(max(0,17-i),17):
   p+=(((av>>i)&1)*((t>>k)&1))<<(i+k-17);pc+=1
 v=D[a,j]+np.sign(v)*p
sh=32+e-34;q=np.empty_like(v)
for k in np.unique(sh):
 m=sh==k;q[m]=(v[m]+(1<<(int(k)-1)))>>int(k) if k>0 else v[m]<<int(-k)
assert np.array_equal(q,z);phase=q.astype(np.uint64)<<np.uint64(30);err=np.abs((phase-ref).view(np.int64));assert np.all(err<=tt)
out=dict(legal=N,integer_reference='PASS',independent_retained_terms='PASS',partial_products=pc,phase_code_sha256=sha256(q.astype('<i8').tobytes()).hexdigest(),min_slack=int((tt-err).min()),max_ratio=float(np.max(err/tt)),generic_rotation_spec=31,scope='integer math only; full quantum evaluator not emitted')
print(out,flush=True);(P/'model_verify.json').write_text(json.dumps(out,indent=2))
