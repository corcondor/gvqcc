"""Single-output streaming low-width coefficient loader. A selected subset of
low monomials is cached globally. Missing terms use exact dirty-control gates.
All inputs and exponent flags restored at each coefficient observation.
"""
from persistent import *
from itertools import combinations

def atom_controls(j,cache):
 if j in cache:return [cache[j]]
 z=[i for i in (1,2,4)if j&i]
 # Choose a stored sub-product to shorten a missing monomial.
 opt=[[LOW[i]for i in z]]
 for k,q in cache.items():
  if k!=j and k&j==k:
   opt.append([q]+[LOW[i]for i in z if not k&i])
 return min(opt,key=lambda x:(len(x),x))

def low_form(mask,h,t,cache,Q):
 ops=[];have={i:LOW[i]for i in (1,2,4)};have.update(cache)
 if h is not None:prep,a=form_ops(h,{1:20,2:21});ops+=prep
 else:prep=[];a=None
 if mask&1:ops.append(Op(17,(t,))if a is None else Op(33,(a,t)))
 known=sum(1<<i for i in bits(mask&~1)if i in have)
 if known:
  if a is None:ops += [Op(33,(have[i],t))for i in bits(known)]
  else:
   pp,b=form_ops(known,have);ops+=pp+[Op(49,(a,b,t))]+pp[::-1]
 for j in bits(mask&~1&~known):
  cs=atom_controls(j,cache);cs=cs+([a]if a is not None else []);ops+=mcx(cs,t,Q)
 return ops+prep[::-1]

def build_low(C,Q,cacheids):
 target=Q-1;cache={j:26+i for i,j in enumerate(cacheids)};assert all(q<target for q in cache.values())
 B=Cached(Q);B.normpart();g=[]
 for j,q in cache.items():
  controls=atom_controls(j,{k:v for k,v in cache.items()if k<j});ops=mcx(controls,q,Q);B.add(ops);g.append((controls,q,ops))
 snap=[];width=[int(np.max(np.abs(C[:,k]))).bit_length() for k in range(C.shape[1])]
 for k,w in enumerate(width):
  for b in range(w):
   A=[anf((np.abs(C[h*8:(h+1)*8,k])>>b)&1)for h in range(3)];opts=[]
   for base in range(3):
    oo=low_form(A[base],None,target,cache,Q)
    for i in range(3):
     if i!=base:oo+=low_form(A[i]^A[base],H[i],target,cache,Q)
    opts.append(oo)
   oo=min(opts,key=lambda x:(sum(o.raw==49 for o in x),len(x)));B.add(oo);snap.append((len(B.ops),[(k,b)],[target]));B.add(oo[::-1]);
 for cs,q,ops in g[::-1]:
  if len(cs)==2:B.erase_and(*cs,q)
  else:B.add(ops[::-1])
 B.normpart(True)
 return B,snap,dict(Q=Q,cache=list(cacheids),ccx=sum(o.raw==49 for o in B.ops),ops=len(B.ops),hmr=B.records)
if __name__=='__main__':
 C=np.load(P/'B34_model1.npz')['C'];out=[];allrows=[]
 for Q in range(27,32):
  opts=[]
  for c in combinations([3,5,6,7],Q-27):
   B,sn,r=build_low(C,Q,c);opts.append((B,sn,r));allrows.append(r)
  B,sn,r=min(opts,key=lambda z:(z[2]['ccx'],z[2]['ops']));f=P/f'low_width_Q{Q}_PARTIAL.kmb';D=native(B,f);r={**r,'file':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'verification':verify(D,sn,C)};out.append(r);print(r,flush=True);(P/'low_width_receipts.json').write_text(json.dumps(out,indent=2));(P/f'low_width_Q{Q}_snap.json').write_text(json.dumps(sn))
 (P/'low_width_search.json').write_text(json.dumps(allrows,indent=2))
