import numpy as np, json, math, time
from pathlib import Path
N=3133452; MOD=1<<64
P=Path(__file__).parent
if not (P/'reference.npz').exists():
 ref=np.empty(N,np.uint64); tt=np.empty(N,np.int64)
 for xx in range(1,N+1):
  rr=math.isqrt((1<<130)//xx);ref[xx-1]=((rr+1)//2)%MOD;tt[xx-1]=rr>>25
 np.savez(P/'reference.npz',target=ref,tol=tt)
R=np.load(P/'reference.npz'); target=R['target']; tol=R['tol']; print(target.dtype,tol.dtype,target[:5],tol[:5],flush=True)
x=np.arange(1,N+1,dtype=np.int64); e=np.zeros(N,np.int64)
for j in range(1,11): e[x>=1<<(2*j)]=j
s=10-e; U=x<<(2*s)
assert U.min()==1<<20 and U.max()<1<<22
# One master 1/sqrt(y) over 1<=y<4, intervals indexed by U's leading b+2 bits.
def coeff(b,d,F):
 n=3*(1<<b); C=np.empty((n,d+1),np.int64)
 t=(1+np.cos(np.pi*(np.arange(32)+.5)/32))/2
 for i in range(n):
  a=1+i/(1<<b); y=1/np.sqrt(a+t/(1<<b)); c=np.polynomial.polynomial.polyfit(t,y,d)
  C[i]=np.rint(c*(1<<F)).astype(np.int64)
 return C

def evaluate(b,d,F,B,C):
 l=20-b; a=(U>>l)-(1<<b); t=U&((1<<l)-1)
 v=C[a,d]
 for j in reversed(range(d)):v=C[a,j]+((v*t+(1<<(l-1)))>>l)
 sh=F+e-B; z=np.empty_like(v)
 for k in np.unique(sh):
  m=sh==k
  z[m]=(v[m]+(1<<(int(k)-1)))>>int(k) if k>0 else v[m]<<int(-k)
 phase=(z.astype(np.uint64)<<np.uint64(64-B)); err=np.abs((phase-target).view(np.int64)); slack=tol.astype(np.int64)-err
 return dict(b=b,d=d,F=F,B=B,segments=len(C),widths=[int(np.max(np.abs(C[:,i]))).bit_length() for i in range(d+1)],bad=int((slack<0).sum()),min_slack=int(slack.min()),max_ratio=float(np.max(err/tol))),z
if __name__=='__main__':
 rows=[];best=[]; start=time.time()
 for b,d in [(3,4),(4,3),(4,4),(5,2),(5,3),(5,4),(6,2),(6,3),(7,2),(8,1),(8,2),(9,1),(10,1)]:
  for F in (30,32,34,36):
   C=coeff(b,d,F)
   for B in (34,35):
    r,z=evaluate(b,d,F,B,C);rows.append(r)
    if r['bad']==0:best.append(r); print(r,flush=True)
  print('completed',b,d,'sec',round(time.time()-start,1),flush=True)
  (P/'design.json').write_text(json.dumps(dict(scope='integer Horner and integer phase tolerance; not emitted arithmetic evaluator',rows=rows),indent=2))
 for B in (34,35):
  good=[r for r in best if r['B']==B]; good.sort(key=lambda r:(r['segments']*sum(r['widths']),sum(r['widths']),-r['min_slack']))
  for i,r in enumerate(good[:4]):
   C=coeff(r['b'],r['d'],r['F']);_,z=evaluate(r['b'],r['d'],r['F'],B,C);np.savez(P/f'B{B}_model{i}.npz',C=C,phase_code=z,**r);print('SELECT',r,flush=True)
