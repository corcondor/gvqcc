"""Carry-free weighted digit stream for FIRST truncated Horner product.
Computes exact integer block sums of c4*t, omitting all products below 2^17.
Not the remaining 3 Horner steps or full diagonal oracle.
"""
from persistent import *
from functools import lru_cache

C=np.load(P/'quantized_coefficients.npy');inds=[i for i in range(int(C[:,4].max()).bit_length())if np.any((C[:,4]>>i)&1)];L=17
plans={i:plan(C,[(4,i)],True)for i in inds}
# Each coefficient bit is an XOR of live affine and bilinear factors.
# HMR erasure pulls back Z phase to those same factors, no paid gate.
class ProductBuilder(Cached):
 def erase_coeff(self,p,q):
  m=self.records;self.records+=1;self.add([Op(80,(q,),measurement=m)])
  mask=p['base_masks'][0]
  if mask&1:self.add([Op(128,(),condition=m)])
  self.add([Op(144,(LOW[i],),condition=m)for i in bits(mask&~1)])
  hs=[H[i]for i in p['other']];hm={1:hs[0],2:hs[1],3:hs[0]^hs[1]}
  for h,z in zip(hs,p['const']):
   if z:
    pre,a=form_ops(h,{1:20,2:21});self.add(pre+[Op(144,(a,),condition=m)]+pre[::-1])
  for k,u,v in p['terms']:
   assert u==1;pa,a=form_ops(hm[k],{1:20,2:21});pb,b=form_ops(v<<1,LOW);self.add(pa+pb+[Op(160,(a,b),condition=m)]+pb[::-1]+pa[::-1])
  self.add([Op(64,(),measurement=m)])

def inc(cs,acc,j,Q):
 return sum((mcx(cs+acc[j:k],acc[k],Q)for k in range(len(acc)-1,j-1,-1)),[])

def block(k,b,Q,measure):
 terms=[(i,j,i+j-L-k)for i in inds for j in range(L)if k<=i+j-L<k+b];mx=sum(1<<d for i,j,d in terms);w=max(1,mx.bit_length());
 if w>Q-31:return None
 acc=list(range(31,31+w));B=ProductBuilder(Q);ci=30
 by={i:[]for i,j,d in terms}
 for i,j,d in terms:by[i].append((j,d))
 for rev in (False,True):
  order=list(by.items());order=order[::-1]if rev else order
  for i,jj in order:
   p=plans[i];B.load(p,[ci]);ls=jj[::-1]if rev else jj
   for j,d in ls:
    o=inc([ci,j],acc,d,Q);B.add(o[::-1]if rev else o)
   if measure:B.erase_coeff(p,ci)
   else:B.load(p,[ci])
  if not rev:mid=len(B.ops)
 return B,mid,terms,acc,w

def choose(Q,measure,group):
 end=max(i+j-L for i in inds for j in range(L))+1
 cache={}
 def get(k,b):
  key=k,b
  if key not in cache:cache[key]=block(k,b,Q,measure)
  return cache[key]
 @lru_cache(None)
 def dp(k):
  if k==end:return (0,0),[]
  opts=[]
  for b in range(1,min(5,end-k)+1 if group else 2):
   a=get(k,b)
   if a is None:continue
   B,_,_,_,_=a;cost,rest=dp(k+b)
   opts.append(((cost[0]+sum(o.raw==49 for o in B.ops),cost[1]+len(B.ops)),[(k,b)]+rest))
  return min(opts)
 cost,bs=dp(0);return bs,cache,cost

def build(Q,measure,group):
 bs,cache,cost=choose(Q,measure,group);B=ProductBuilder(Q);B.normpart();lb=[(17,18,26),(17,19,27),(18,19,28),(26,19,29)];B.add([Op(49,t)for t in lb]);snap=[]
 for k,b in bs:
  q,mid,terms,acc,w=cache[k,b];snap.append(dict(cut=len(B.ops)+mid,start=k,width=b,terms=terms,acc=acc,count_bits=w));base=B.records
  B.add([Op(o.raw,o.wires,o.measurement+base if o.measurement is not None else None,o.condition+base if o.condition is not None else None)for o in q.ops]);B.records+=q.records
 for a,b,t in lb[::-1]:B.erase_and(a,b,t)
 B.normpart(True);return B,snap,dict(Q=Q,measure=measure,group=group,blocks=bs,arithmetic_ccx=cost[0],ccx=sum(o.raw==49 for o in B.ops),ops=len(B.ops),hmr=B.records)

def verify_product(D,snap):
 x,pk,s,one=masks(D.header[1]);orig=s[:];e=np.zeros(len(x),np.uint32)
 for k in range(1,11):e[x>=1<<(2*k)]=k
 U=x<<(2*(10-e));a=(U>>17)-8;t=U&((1<<17)-1);cv=C[a,4];ph={};sn={g['cut']:g for g in snap};out=np.zeros(len(x),np.int64);coins=0
 for i,o in enumerate(D.ops,1):
  w=o.wires;g=o.raw
  if g in (17,33,49,34):apply(s,one,[o])
  elif g==80:assert o.measurement not in ph;ph[o.measurement]=s[w[0]];s[w[0]]=0;coins+=1
  elif g in (128,144,160):
   v=one
   for q in w:v&=s[q]
   ph[o.condition]^=v
  elif g==64:assert ph.pop(o.measurement)==0
  else:raise ValueError(o)
  if i in sn:
   g=sn[i];d=np.zeros(len(x),np.int64)
   for ii,j,k in g['terms']:d+=(((cv>>ii)&1)*((t>>j)&1))<<k
   assert all(s[q]==pk((d>>j)&1)for j,q in enumerate(g['acc']));out+=d<<g['start']
 assert s==orig and not ph
 expected=np.zeros(len(x),np.int64)
 for i in inds:
  for j in range(L):
   if i+j>=L:expected+=(((cv>>i)&1)*((t>>j)&1))<<(i+j-L)
 assert np.array_equal(out,expected)
 return dict(legal=len(x),independent_HMR=coins,restoration='PASS',phase='PASS',exact_weighted_first_product='PASS')
if __name__=='__main__':
 rows=[];st=time.time()
 for Q in [35,36]:
  for measure,group in [(False,False),(True,False),(True,True)]:
   B,sn,r=build(Q,measure,group);path=P/f'product_Q{Q}_m{int(measure)}_g{int(group)}_PARTIAL.kmb';D=native(B,path);r.update(file=path.name,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),verification=verify_product(D,sn));rows.append(r);print(r,'sec',round(time.time()-st,1),flush=True);(P/'product_receipts.json').write_text(json.dumps(rows,indent=2));(P/(path.stem+'_snap.json')).write_text(json.dumps(sn))
