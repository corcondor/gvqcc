"""Exact care-set gate replacements on PR132 normalizer. No 37Q candidate."""
import sys,os,json,hashlib,time,struct
from pathlib import Path
import numpy as np
BASE=(Path(__file__).parent/'source');sys.path.insert(0,str(BASE))
from native_kmb import Op,NativeKMB
P=Path(__file__).parent;N=3133452

def pack(a):return int.from_bytes(np.packbits(a,bitorder='little').tobytes(),'little')
def basis_fit(v,arr,one):
 basis={}
 for i,w in enumerate([one]+arr):
  z=1<<i
  while w:
   k=w.bit_length()-1
   if k not in basis:basis[k]=(w,z);break
   u,a=basis[k];w^=u;z^=a
 z=0
 while v:
  k=v.bit_length()-1
  if k not in basis:return None
  u,a=basis[k];v^=u;z^=a
 return z

def evaluate(arr,one,mask):
 z=one if mask&1 else 0
 while mask>>1:
  k=(mask&-mask).bit_length()-1
  if k==0:mask^=1;continue
  z^=arr[k-1];mask^=1<<k
 return z

def exact_fit(v,V,arr,ARR,one,ONE):
 m=basis_fit(V,ARR,ONE)
 if m is None:return None
 if evaluate(arr,one,m)==v:return m
 # Sample relation can be false on rare rows. Solve the exact problem.
 return basis_fit(v,arr,one)

def linops(m,qs,target):return ([Op(17,(target,))] if m&1 else [])+[Op(33,(q,target)) for j,q in enumerate(qs,1) if m>>j&1]
def phaseops(m,qs,event):return ([Op(128,(),condition=event)] if m&1 else [])+[Op(144,(q,),condition=event) for j,q in enumerate(qs,1) if m>>j&1]
def step(s,o,one):
 w=o.wires;g=o.raw
 if g==17:s[w[0]]^=one
 elif g==33:s[w[1]]^=s[w[0]]
 elif g==49:s[w[2]]^=s[w[0]]&s[w[1]]
 elif g==34:s[w[0]],s[w[1]]=s[w[1]],s[w[0]]
 elif g==80:s[w[0]]=0

def run(Q):
 src=BASE/f'normalizer_measured_Q{Q}_ccz1_ROUNDTRIP_ONLY.kmb';K=NativeKMB.read(src)
 records=json.load(open(BASE/'normalize_measured.json'));mid=next(r['mid'] for r in records if r['Q']==Q and r['allow_ccz'])
 x=np.arange(1,N+1,dtype=np.uint32);rng=np.random.default_rng(167);sx=np.unique(np.r_[np.arange(1,128),rng.integers(1,N+1,1024),[min(N,1<<j)for j in range(22)] ]).astype(np.uint32)
 s=[pack((x>>j)&1)for j in range(22)]+[0]*(Q-22);t=[pack((sx>>j)&1)for j in range(22)]+[0]*(Q-22);one=(1<<N)-1;ONE=(1<<len(sx))-1
 event=K.header[2];out=[];edits=[];midnew=None
 for i,o in enumerate(K.ops):
  if i==mid:midnew=len(out)
  repl=None
  if o.raw==49:
   a,b,c=o.wires; qs=[j for j in range(Q) if j!=c];A=[s[j]for j in qs];T=[t[j]for j in qs];f=s[a]&s[b];F=t[a]&t[b]
   m=exact_fit(f,F,A,T,one,ONE)
   if m is not None:
    repl=linops(m,qs,c);typ='affine_product'
   else:
    m=exact_fit(s[c]^f,t[c]^F,A,T,one,ONE)
    if m is not None:
     repl=[Op(80,(c,),measurement=event),Op(160,(a,b),condition=event)]+phaseops(m,qs,event)+[Op(64,(),measurement=event)]+linops(m,qs,c);event+=1;typ='measured_affine_output'
   if repl is not None:
    edits.append(dict(index=i,kind=typ,wires=o.wires,constant=m&1,linear=[q for j,q in enumerate(qs,1)if m>>j&1],new_ops=len(repl)))
  out.extend([o] if repl is None else repl)
  step(s,o,one);step(t,o,ONE)
 h=list(K.header);h[2]=event;D=NativeKMB(K.prefix16,tuple(h),K.sections,out);dst=P/f'normalizer_Q{Q}_care_RESEARCH.kmb';dst.write_bytes(D.to_bytes());R=NativeKMB.read(dst);assert R.ops==out and R.header[1]==Q
 # Independent serialized verification: normalization snapshot, restoration, every HMR sign coefficient.
 s=[pack((x>>j)&1)for j in range(22)]+[0]*(Q-22);orig=s[:];ph={};e=np.zeros(N,np.uint32)
 for j in range(1,11):e[x>=1<<(2*j)]=j
 sh=2*(10-e);y=x<<sh
 for i,o in enumerate(R.ops,1):
  g=o.raw;w=o.wires;assert all(0<=q<Q for q in w)
  if g in (17,33,49,34):step(s,o,one)
  elif g==80:assert o.measurement not in ph;ph[o.measurement]=s[w[0]];s[w[0]]=0
  elif g in (128,144,160,176):
   p=one
   for q in w:p&=s[q]
   ph[o.condition]^=p
  elif g==64:assert ph.pop(o.measurement)==0,(i,o)
  else:raise ValueError(o)
  if i==midnew:
   assert s[:22]==[pack((y>>j)&1)for j in range(22)]
   assert s[22:26]==[pack((sh&d)!=0)for d in [16,8,4,2]];assert not any(s[26:]) and not ph
 assert s==orig and not ph
 count=lambda ops:sum(o.raw==49 for o in ops)+.5*sum(o.raw==176 for o in ops)
 rec=dict(Q=Q,source=src.name,before_ops=len(K.ops),ops=len(out),before_paid=count(K.ops),expected_paid=count(out),before_ccx=sum(o.raw==49 for o in K.ops),ccx=sum(o.raw==49 for o in out),hmr=sum(o.raw==80 for o in out),mid=midnew,edits=edits,legal=N,verification='PASS',sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),scope='normalization+inverse only, no full oracle')
 (P/f'normalizer_Q{Q}_receipt.json').write_text(json.dumps(rec,indent=2));print({k:v for k,v in rec.items()if k!='edits'},'edits',len(edits),flush=True)
if __name__=='__main__':
 for Q in map(int,sys.argv[1:]):run(Q)
