"""Exact in-place small-variable multiplication with a 4-bit carry word.
36Q packed normalizer + load + native carry transducer + inverse + unload.
Zero coefficient uses reserved code 15; decoded product is then zero.
No claim of a full invsqrt oracle; snapshots form an explicit consumer ABI.
"""
import sys,json,hashlib,time
from pathlib import Path
import numpy as np
P=Path(__file__).parent;BASE=(Path(__file__).parent/'source');sys.path.insert(0,str(BASE))
from native_kmb import Op,NativeKMB
from normalize_reduce import pack,step,N
import loader
from tagged_normalizer import tag

M=list(range(23,27));C=list(range(27,31));T=list(range(5,17));R=list(range(31,35));TMP=35
class Bld:
 def __init__(self,m=0):self.m=m;self.ops=[]
 def add(self,*op):self.ops.extend(op)
 def X(self,a):self.add(Op(17,(a,)))
 def CX(self,a,b):self.add(Op(33,(a,b)))
 def CCX(self,a,b,c):self.add(Op(49,(a,b,c)))
 def erase(self,q,cs,lin=(),const=0):
  m=self.m;self.m+=1;self.add(Op(80,(q,),measurement=m));
  if const:self.add(Op(128,(),condition=m))
  for a in lin:self.add(Op(144,(a,),condition=m))
  if cs:self.add(Op(128+16*len(cs),tuple(cs),condition=m))
  self.add(Op(64,(),measurement=m))
 def maj(self,a,b,r,t):
  self.CX(r,a);self.CX(r,b);self.CCX(a,b,t);self.CX(r,t);self.CX(r,b);self.CX(r,a)
 def erase_maj(self,a,b,r,t):
  self.CX(r,a);self.CX(r,b);self.erase(t,[a,b],[r]);self.CX(r,b);self.CX(r,a)
 def cadd(self,x,negative=False):
  # c <- c + x*m mod 16, using carry word for UNCONTROLLED m+c.
  # Carries can be erased descending before their source lower bits change.
  if negative:
   for q in C:self.X(q)
  self.CCX(M[0],C[0],R[0]);self.maj(M[1],C[1],R[0],R[1]);self.maj(M[2],C[2],R[1],R[2]);
  for i in range(3,0,-1):
   self.CX(R[i-1],M[i]);self.CCX(x,M[i],C[i]);self.CX(R[i-1],M[i]);
   if i>1:self.erase_maj(M[i-1],C[i-1],R[i-2],R[i-1])
   else:self.erase(R[0],[M[0],C[0]])
  self.CCX(x,M[0],C[0]);
  if negative:
   for q in C:self.X(q)
 def cmp(self,x):
  # x ^= [c>=m]. Four temporary-AND majority stages; clean all carries.
  # c + (~m) + 1: r1 = 1 XOR (m0 AND NOT c0).
  self.X(R[0]);self.X(C[0]);self.CCX(M[0],C[0],R[0]);self.X(C[0]);
  for i in range(1,4):
   self.X(M[i]);self.maj(M[i],C[i],R[i-1],x if i==3 else R[i]);self.X(M[i])
  for i in range(2,0,-1):
   self.X(M[i]);self.erase_maj(M[i],C[i],R[i-1],R[i]);self.X(M[i])
  self.X(C[0]);self.erase(R[0],[M[0],C[0]],const=1);self.X(C[0])
 def rotate(self,x,inv=False):
  ls=[(x,C[0]),(C[0],C[1]),(C[1],C[2]),(C[2],C[3])]
  for a,b in (reversed(ls) if inv else ls):self.add(Op(34,(a,b)))
 def cell(self,x,inv=False):
  if inv:self.rotate(x,True);self.cmp(x);self.cadd(x,True)
  else:self.cadd(x);self.cmp(x);self.rotate(x)
 def coeff(self,eff):
  # Shared low ANF basis (four products) and exact joint high/low decomposition.
  ca=[(17,18,31),(17,19,32),(18,19,33),(31,19,34)]
  for a,b,t in ca:self.CCX(a,b,t)
  qmap={26:31,27:32,28:33,29:34,30:35,31:23,32:24,33:25,34:26}
  L=loader.Builder(36);pl=loader.plan(eff.reshape(-1,1),[(0,i)for i in range(4)],True);L.load(pl,list(range(31,35)))
  for o in L.ops:
   self.add(Op(o.raw,tuple(qmap.get(q,q)for q in o.wires),None if o.measurement is None else o.measurement+self.m,None if o.condition is None else o.condition+self.m))
  self.m+=L.records
  for a,b,t in reversed(ca):self.erase(t,[a,b])
  return pl

def replay(ops,s,one,callback=None):
 ph={}
 for i,o in enumerate(ops,1):
  g=o.raw;w=o.wires
  if g in (17,33,49,34):step(s,o,one)
  elif g==80:assert o.measurement not in ph;ph[o.measurement]=s[w[0]];s[w[0]]=0
  elif g in (128,144,160,176):
   p=one
   for q in w:p&=s[q]
   ph[o.condition]^=p
  elif g==64:assert ph.pop(o.measurement)==0,(i,o)
  else:raise ValueError(o)
  if callback:callback(i,s,ph)
 assert not ph

def microtest():
 a=np.array([(m,c,x)for m in range(1,16)for c in range(m)for x in (0,1)],dtype=np.uint32);n=len(a);one=(1<<n)-1;s=[0]*36
 for j,q in enumerate(M):s[q]=pack((a[:,0]>>j)&1)
 for j,q in enumerate(C):s[q]=pack((a[:,1]>>j)&1)
 s[5]=pack(a[:,2]);orig=s[:];B=Bld();B.cell(5);forward=len(B.ops);expected=a[:,0]*a[:,2]+a[:,1]
 replay(B.ops,s,one);assert s[5]==pack(expected&1) and [s[q]for q in C]==[pack((expected>>(j+1))&1)for j in range(4)];assert [s[q]for q in M]==[orig[q]for q in M] and not any(s[q]for q in R+[TMP]);B.ops=[];B.cell(5,True);replay(B.ops,s,one);assert s==orig
 return dict(local_cases=n,forward_ops=forward,forward_ccx=11,inverse_ops=len(B.ops),inverse_ccx=sum(o.raw==49 for o in B.ops))

def run():
 micro=microtest();print('LOCAL PASS',micro,flush=True);model=np.load(P/'repaired_k12.npz');assert int(model['k'][-1])==12 and int(model['z'][-1])==14;true=(model['C'][:,4]>>14).astype(np.int64);assert np.all(true>=0) and true.max()<15;eff=np.where(true==0,15,true);print('COEFF',true.tolist(),flush=True)
 K=NativeKMB.read(P/'tagged_normalizer_Q36_23active_RESEARCH.kmb');rec=json.load(open(P/'tagged_normalizer_Q36_receipt.json'));mid=rec['snapshot'];B=Bld(K.header[2]);pl=B.coeff(eff);loadops=B.ops[:];B.ops=[]
 for q in T:B.cell(q)
 forward=B.ops[:];B.ops=[]
 for q in reversed(T):B.cell(q,True)
 inverse=B.ops[:];B.ops=[];B.coeff(eff);unload=B.ops[:]
 ops=K.ops[:mid]+loadops+forward+inverse+unload+K.ops[mid:];snap=mid+len(loadops)+len(forward);h=list(K.header);h[1]=36;h[2]=B.m;D=NativeKMB(K.prefix16,tuple(h),K.sections,ops);path=P/'first_product_Q36_inplace_RESEARCH.kmb';path.write_bytes(D.to_bytes());D=NativeKMB.read(path);assert D.ops==ops
 x=np.arange(1,N+1,dtype=np.uint32);e=np.zeros(N,np.uint32)
 for j in range(1,11):e[x>=1<<(2*j)]=j
 sh=10-e;U=x<<(2*sh);p=U^np.array([tag(j)for j in range(11)],np.uint32)[sh];a=(U>>17)-8;coeff=eff[a].astype(np.uint32);tv=(U>>5)&4095;v=coeff*tv;logical=true[a].astype(np.uint32)*tv;one=(1<<N)-1;s=[pack((x>>j)&1)for j in range(22)]+[0]*14;orig=s[:];checks=0
 def callback(i,s,ph):
  nonlocal checks
  if i==mid+len(loadops):
   assert [s[q]for q in M]==[pack((coeff>>j)&1)for j in range(4)];assert not any(s[q]for q in C+R+[TMP]);assert not ph;checks+=1
  if i==snap:
   assert [s[q]for q in T+C]==[pack((v>>j)&1)for j in range(16)];assert [s[q]for q in M]==[pack((coeff>>j)&1)for j in range(4)];assert not any(s[q]for q in R+[TMP]);assert not ph
   assert all(s[q]==pack((p>>q)&1)for q in range(22)if q not in T) and s[22]==pack(sh!=0)
   # Check the decoded zero-marker product from the actual output bits.
   def unpack(q):return np.unpackbits(np.frombuffer(s[q].to_bytes((N+7)//8,'little'),np.uint8),bitorder='little')[:N].astype(np.uint32)
   yy=sum(unpack(q)<<j for j,q in enumerate(T+C));mm=sum(unpack(q)<<j for j,q in enumerate(M));assert np.array_equal(np.where(mm==15,0,yy),logical);checks+=1
 replay(D.ops,s,one,callback);assert s==orig and checks==2
 paid=lambda o:sum(x.raw==49 for x in o)+.5*sum(x.raw==176 for x in o)
 out=dict(Q=36,legal=N,model='repaired_k12.npz',phase_spec_sha=str(model['phase_sha']),scope='native first canonical product roundtrip; consumer must decode zero marker and apply rounding/add C3; not full phase oracle',active_normalized=23,offset_bits=12,coeff_width=4,product_width=16,zero_code=15,coeffs=true.tolist(),coefficient_load_paid=paid(loadops),coefficient_unload_paid=paid(unload),forward_multiplier_paid=paid(forward),inverse_multiplier_paid=paid(inverse),forward_multiplier_ops=len(forward),inverse_multiplier_ops=len(inverse),normalizer_paid=paid(K.ops),total_expected_paid=paid(D.ops),ccx=sum(o.raw==49 for o in D.ops),HMR=sum(o.raw==80 for o in D.ops),ops=len(D.ops),snapshot=snap,checks=checks,local=micro,verification='PASS',sha256=hashlib.sha256(path.read_bytes()).hexdigest())
 (P/'first_product_receipt.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2),flush=True)
if __name__=='__main__':run()
