"""23-active-wire normalized ABI: one flag + self-delimiting low-bit tags.
Complete normalize/pack/unpack/denormalize roundtrip, exact legal-domain replay.
No full inverse-square-root phase oracle or score claim.
"""
import sys,json,heapq,itertools,hashlib
from pathlib import Path
import numpy as np
P=Path(__file__).parent
sys.path.insert(0,str((Path(__file__).parent/'source')))
from native_kmb import Op,NativeKMB
from normalize_reduce import pack,step,N
FLAGS=[25,24,23,22] # s in binary, s=(16,8,4,2 decisions)/2
H=26

def tag(s):
 if s==0:return 0
 if s==1:return 1
 if s==2:return 2
 return (s-3)<<2

def synth_encode():
 # Weighted shortest paths in truth-mask space on 11 actual shift values.
 cubes={}
 for trits in itertools.product((-1,0,1),repeat=4):
  cs=tuple((i,v)for i,v in enumerate(trits)if v>=0)
  m=sum(1<<s for s in range(11)if all((s>>i)&1==v for i,v in cs))
  if not m:continue
  cost=100*max(0,len(cs)-1)+1
  if m not in cubes or (cost,cs)<cubes[m]:cubes[m]=(cost,cs)
 dist=[10**9]*2048;prev=[None]*2048;dist[0]=0;queue=[(0,0)]
 while queue:
  d,x=heapq.heappop(queue)
  if d!=dist[x]:continue
  for m,(c,cs)in cubes.items():
   y=x^m;nd=d+c
   if nd<dist[y]:dist[y]=nd;prev[y]=(x,cs);heapq.heappush(queue,(nd,y))
 targets={H:sum(1<<s for s in range(1,11))}|{j:sum(1<<s for s in range(11)if tag(s)>>j&1)for j in range(5)}
 shared={}
 for q,m in targets.items():
  x=m
  while x:
   x,cs=prev[x];shared.setdefault(cs,[]).append(q)
 for s in range(11):
  out=0;hv=0
  for cs,qs in shared.items():
   if all(((s>>i)&1)==v for i,v in cs):
    for q in qs:
     if q==H:hv^=1
     else:out^=1<<q
  assert hv==bool(s) and out==tag(s)
 return [(cs,tuple(qs))for cs,qs in sorted(shared.items())]

class Builder:
 def __init__(self,Q,event):self.Q=Q;self.m=event;self.ops=[]
 def add(self,ops):self.ops.extend(ops)
 def X(self,q):self.add([Op(17,(q,))])
 def CX(self,a,b):self.add([Op(33,(a,b))])
 def CCX(self,a,b,c):self.add([Op(49,(a,b,c))])
 def erase(self,q,cs,linear=()):
  m=self.m;self.m+=1;self.add([Op(80,(q,),measurement=m)])
  self.add([Op(128+16*len(cs),tuple(cs),condition=m)])
  self.add([Op(144,(a,),condition=m)for a in linear]);self.add([Op(64,(),measurement=m)])
 def cube(self,cs,targets):
  qs=[FLAGS[i]for i,v in cs];neg=[FLAGS[i]for i,v in cs if not v]
  for q in neg:self.X(q)
  if not qs:
   for t in targets:self.X(t)
  elif len(qs)==1:
   for t in targets:self.CX(qs[0],t)
  else:
   a=qs[0];hist=[]
   for j,b in enumerate(qs[1:]):
    last=j==len(qs)-2
    if last and len(targets)==1:t=targets[0]
    else:t=27+j;hist.append((t,a,b))
    assert t<self.Q;self.CCX(a,b,t);a=t
   if len(targets)>1:
    for t in targets:self.CX(a,t)
   for t,a,b in reversed(hist):self.erase(t,[a,b])
  for q in reversed(neg):self.X(q)
 def encode(self,terms):
  for cs,targets in terms:self.cube(cs,targets)
 def decode(self):
  # f0 = h*q0 XOR g*(1 XOR a); f1 = h*q1 XOR g*(1 XOR a XOR b)
  # f2 = g*c XOR g*(a OR b); f3 = g*c*(a OR b)
  # g = h*(1 XOR q0 XOR q1), a=q2,b=q3,c=q4.
  a,b,c=2,3,4;g,w,z=27,28,29
  self.CCX(H,0,FLAGS[0]);self.CCX(H,1,FLAGS[1]);self.CX(1,0);self.X(0);self.CCX(H,0,g);self.X(0);self.CX(1,0)
  self.X(a);self.CCX(g,a,FLAGS[0]);self.X(a)
  self.CX(b,a);self.X(a);self.CCX(g,a,FLAGS[1]);self.X(a);self.CX(b,a)
  self.CX(a,w);self.CX(b,w);self.CCX(a,b,w)
  self.CCX(g,w,z);self.CCX(g,c,FLAGS[2]);self.CX(z,FLAGS[2]);self.CCX(z,c,FLAGS[3]);self.erase(z,[g,w]);self.erase(w,[a,b],[a,b]);
  self.CX(1,0);self.X(0);self.erase(g,[H,0]);self.X(0);self.CX(1,0)

def run(Q,baseQ):
 K=NativeKMB.read(P/f'normalizer_Q{baseQ}_care_RESEARCH.kmb');rec=json.load(open(P/f'normalizer_Q{baseQ}_receipt.json'));mid=rec['mid'];terms=synth_encode();B=Builder(Q,K.header[2]);B.encode(terms);enc=len(B.ops);B.decode();B.add([Op(34,(22,H))]);packops=B.ops.copy();B.ops=[];B.add([Op(34,(22,H))]);B.decode();B.encode(terms);unpackops=B.ops.copy();ops=K.ops[:mid]+packops+unpackops+K.ops[mid:];snap=mid+len(packops);h=list(K.header);h[1]=Q;h[2]=B.m;D=NativeKMB(K.prefix16,tuple(h),K.sections,ops);path=P/f'tagged_normalizer_Q{Q}_23active_RESEARCH.kmb';path.write_bytes(D.to_bytes());R=NativeKMB.read(path);assert R.ops==ops and R.header[1]==Q
 x=np.arange(1,N+1,dtype=np.uint32);s=[pack((x>>j)&1)for j in range(22)]+[0]*(Q-22);orig=s[:];one=(1<<N)-1;ph={};e=np.zeros(N,np.uint32)
 for j in range(1,11):e[x>=1<<(2*j)]=j
 shift=10-e;U=x<<(2*shift);tags=np.array([tag(i) for i in range(11)],np.uint32)[shift];packed=U^tags
 assert np.all(U&tags==0);assert np.all(((packed>>5)==(U>>5)))
 # Independent explicit decode, from only packed values and flag.
 nz=shift!=0;out_s=np.where(~nz,0,np.where(packed&1,1,np.where(packed&2,2,3+((packed>>2)&7))))
 assert np.array_equal(out_s,shift);assert np.array_equal(packed^np.array([tag(i)for i in range(11)],np.uint32)[out_s],U)
 for i,o in enumerate(R.ops,1):
  g=o.raw;w=o.wires;assert all(0<=q<Q for q in w)
  if g in (17,33,49,34):step(s,o,one)
  elif g==80:assert o.measurement not in ph;ph[o.measurement]=s[w[0]];s[w[0]]=0
  elif g in (128,144,160,176):
   v=one
   for q in w:v&=s[q]
   ph[o.condition]^=v
  elif g==64:assert ph.pop(o.measurement)==0,(i,o)
  else:raise ValueError(o)
  if i==snap:
   assert s[:22]==[pack((packed>>j)&1)for j in range(22)] and s[22]==pack(nz) and not any(s[23:]) and not ph
 assert s==orig and not ph
 cost=lambda o:sum(z.raw==49 for z in o)+.5*sum(z.raw==176 for z in o)
 r=dict(Q=Q,base_Q=baseQ,active_normalized=23,free_normalized=Q-23,source_paid=cost(K.ops),pack_paid=cost(packops),unpack_paid=cost(unpackops),expected_paid=cost(ops),ops=len(ops),CCX=sum(o.raw==49 for o in ops),HMR=sum(o.raw==80 for o in ops),legal=N,snapshot=snap,pack_terms=[dict(cube=cs,targets=ts)for cs,ts in terms],source_sha=rec['sha256'],sha256=hashlib.sha256(path.read_bytes()).hexdigest(),verification='PASS',scope='packed normalization roundtrip, not full phase oracle')
 (P/f'tagged_normalizer_Q{Q}_receipt.json').write_text(json.dumps(r,indent=2));print({k:v for k,v in r.items()if k!='pack_terms'},flush=True)
if __name__=='__main__':
 for q,b in [(30,28),(32,32),(36,32)]:run(q,b)
