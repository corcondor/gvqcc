"""Dependency-free certificate checker for the 44 reachable local rows."""
import json
from pathlib import Path
P=Path(__file__).parent
R=json.loads((P/'meet_native_path.json').read_text())
rows=[(k,c,b,m) for k,m in enumerate((1,3,5,13)) for c in range(m) for b in (0,1)]
assert len(rows)==44
mask=lambda f:sum(int(bool(f(k,c,b,m)))<<i for i,(k,c,b,m) in enumerate(rows))
F=[(1<<44)-1,mask(lambda k,c,b,m:k&1),mask(lambda k,c,b,m:k&2)]
A=F+[mask(lambda k,c,b,m,j=j:c>>j&1)for j in range(4)]+[mask(lambda k,c,b,m:b)]
B=F+[mask(lambda k,c,b,m,j=j:((c+m*b)//2)>>j&1)for j in range(4)]+[mask(lambda k,c,b,m:(c+m*b)&1)]
assert A==R['A'] and B==R['B']
# Check that the restricted transducer is bijective.
assert len({(k,(c+m*b)//2,(c+m*b)%2)for k,c,b,m in rows})==44

def reduce(v,b):
 for j in sorted(b,reverse=True):
  if v>>j&1:v^=b[j]
 return v

def basis(xs):
 b={}
 for x in xs:
  v=reduce(x,b)
  if v:b[v.bit_length()-1]=v
 return b

def check(start,atoms):
 S=start[:]
 for u,v,p in atoms:
  b=basis(S)
  assert not reduce(u,b) and not reduce(v,b) and p==u&v and reduce(p,b)
  S.append(p)
 return S
L=check(A,R['fa']);H=check(B,R['fb']);W=basis(R['W'])
assert len(W)==len(basis(L))==len(basis(H))==15
assert all(not reduce(x,W) for x in L+H)
print('PASS: 44 rows, 7+7 nonlinear atoms, identical rank-15 common span')
