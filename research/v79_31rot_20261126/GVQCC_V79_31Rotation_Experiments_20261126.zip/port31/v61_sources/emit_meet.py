"""Compile and independently verify an exact local common-span measured
transducer and the PR141 first-product roundtrip on all legal inputs.
The product is encoded by its odd factor; the power of two and zero marker
are reconstructed from the unchanged address. No full invsqrt claim.
"""
import sys,json,hashlib,time
from pathlib import Path
from collections import Counter
import numpy as np
P=Path(__file__).parent; SRC=Path('/mnt/data/v60work/v59')
if (P/'pr141').exists():SRC=P/'pr141'
sys.path.insert(0,str(SRC));sys.path.insert(0,str(SRC/'source'))
from native_kmb import Op,NativeKMB
from small_multiplier import Bld,replay
from normalize_reduce import pack,N
from tagged_normalizer import tag
from base_cell import bits,span_split,solve,extend,canon,basis,dot

R=json.loads((P/'meet_native_path.json').read_text());ONE=R['F'][0]
A=R['A'];B=R['B'];FA=R['fa'];FB=R['fb'];CODES={1:0,3:1,5:2,13:3};ROWS=[(j,c,x,m)for j,m in enumerate(CODES)for c in range(m)for x in range(2)]

# Exact affine basis exchange, no extra line. Choose two target factor rows by
# extending them to a basis. Construct linear map using elementary row ops.
def affine(src,dst,qs):
 assert len(src)==len(dst)==len(qs)+1 and src[0]==dst[0]==ONE
 D=span_split(src);rows=[];const=[]
 for v in dst[1:]:
  z=solve(v,D);assert z is not None;const.append(z&1);rows.append(z>>1)
 n=len(qs);op=[]
 for j in range(n):
  k=next(i for i in range(j,n)if rows[i]>>j&1)
  if j!=k:rows[j],rows[k]=rows[k],rows[j];op.append(Op(34,(qs[j],qs[k])))
  for i in range(n):
   if i!=j and rows[i]>>j&1:rows[i]^=rows[j];op.append(Op(33,(qs[j],qs[i])))
 assert rows==[1<<i for i in range(n)]
 return op[::-1]+[Op(17,(q,))for q,c in zip(qs,const)if c]

def form(S,u,v,qs):
 # Often a pair of existing rows plus one parity is enough. Choose placement
 # preserving the maximum number of existing wires, then affine conjugate.
 # Can always extend independent {1,u,v}.
 assert len(basis([ONE,u,v]))==3
 best=None
 for p in range(1,len(S)):
  for q in range(1,len(S)):
   if p==q:continue
   H=[ONE,u,v];ret=list(S);ret[p]=u;ret[q]=v
   if len(basis(ret))!=len(S):continue
   pre=affine(S,ret,qs)
   score=len(pre)
   if best is None or score<best[0]:best=(score,pre,qs[p-1],qs[q-1])
 if best is not None:return best[1:]
 H=extend([ONE,u,v],S,len(S));assert len(H)==len(S)
 return affine(S,H,qs),qs[0],qs[1]

def cell(builder,x,inv=False):
 core=[23,24,27,28,29,30,x];scratch=[25,26,31,32,33,34,35];qs=core[:]
 src,dst,fa,fb=(B,A,FB,FA)if inv else (A,B,FA,FB)
 S=src[:]
 for (u,v,p),z in zip(fa,scratch):
  assert p==u&v and solve(p,span_split(S))is None
  pre,a,b=form(S,u,v,qs);builder.add(*pre,Op(49,(a,b,z)),*pre[::-1]);S.append(p);qs.append(z)
 T=dst[:]+[p for u,v,p in fb];assert canon(S)==canon(T)
 builder.add(*affine(S,T,qs));S=T
 for u,v,p in reversed(fb):
  assert p==S[-1];z=qs.pop();S.pop();pre,a,b=form(S,u,v,qs);builder.add(*pre);builder.erase(z,[a,b]);builder.add(*pre[::-1])
 assert S==dst

def micro():
 n=len(ROWS);assert n==44;s=[0]*36;core=[23,24,27,28,29,30,5]
 for q,z in zip(core,A[1:]):s[q]=z
 orig=s[:];b=Bld();cell(b,5);mid=len(b.ops);replay(b.ops,s,ONE);assert [s[q]for q in core]==B[1:] and not any(s[q]for q in [25,26,31,32,33,34,35]);print('micro forward',mid,Counter(o.raw for o in b.ops),flush=True)
 b.ops=[];cell(b,5,True);replay(b.ops,s,ONE);assert s==orig;print('micro inverse',len(b.ops),Counter(o.raw for o in b.ops),flush=True)
 return mid,len(b.ops)

def run():
 start=time.time();mi=micro();model=np.load(SRC/'repaired_k12.npz');true=(model['C'][:,4]>>14).astype(np.int64);assert set(true)=={0,1,2,3,5,8,13}
 odd=np.array([int(m)//(int(m)&-int(m))if m else 1 for m in true],dtype=np.int64);codes=np.array([CODES[m]for m in odd],dtype=np.int64)
 K=NativeKMB.read(SRC/'tagged_normalizer_Q36_23active_RESEARCH.kmb');rec=json.load(open(SRC/'tagged_normalizer_Q36_receipt.json'));mid=rec['snapshot'];bb=Bld(K.header[2]);bb.coeff(codes);load=bb.ops[:];bb.ops=[];Ts=list(range(5,17));Cs=list(range(27,31));work=[25,26,31,32,33,34,35]
 for q in Ts:cell(bb,q)
 forward=bb.ops[:];bb.ops=[]
 for q in reversed(Ts):cell(bb,q,True)
 inverse=bb.ops[:];bb.ops=[];bb.coeff(codes);unload=bb.ops[:]
 ops=K.ops[:mid]+load+forward+inverse+unload+K.ops[mid:];snap=mid+len(load)+len(forward);hdr=list(K.header);hdr[1]=36;hdr[2]=bb.m;D=NativeKMB(K.prefix16,tuple(hdr),K.sections,ops);path=P/'v61_odd_factor_first_product_Q36_PARTIAL.kmb';path.write_bytes(D.to_bytes());D=NativeKMB.read(path);assert D.ops==ops and max(q for o in D.ops for q in o.wires)<36
 x=np.arange(1,N+1,dtype=np.uint32);e=np.zeros(N,np.uint32)
 for j in range(1,11):e[x>=1<<(2*j)]=j
 sh=10-e;U=x<<(2*sh);p=U^np.array([tag(j)for j in range(11)],np.uint32)[sh];a=(U>>17)-8;cc=codes[a].astype(np.uint32);tv=(U>>5)&4095;v=odd[a].astype(np.uint32)*tv;one=(1<<N)-1;s=[pack((x>>j)&1)for j in range(22)]+[0]*14;orig=s[:];checks=0
 def cb(i,s,ph):
  nonlocal checks
  if i==mid+len(load):
   assert [s[q]for q in [23,24]]==[pack((cc>>j)&1)for j in range(2)] and not any(s[q]for q in Cs+work) and not ph;checks+=1
  if i==snap:
   assert [s[q]for q in Ts+Cs]==[pack((v>>j)&1)for j in range(16)] and [s[q]for q in [23,24]]==[pack((cc>>j)&1)for j in range(2)] and not any(s[q]for q in work) and not ph
   assert all(s[q]==pack((p>>q)&1)for q in range(22)if q not in Ts) and s[22]==pack(sh!=0)
   # Reconstruct coefficient and product from the actual retained address and physical word, not the overwritten T.
   def up(q):return np.unpackbits(np.frombuffer(s[q].to_bytes((N+7)//8,'little'),np.uint8),bitorder='little')[:N].astype(np.uint32)
   ad=sum(up(q)<<(q-17)for q in range(17,22))-8;yy=sum(up(q)<<j for j,q in enumerate(Ts+Cs));fac=(true//odd).astype(np.uint32);assert np.array_equal(yy*fac[ad],true[a].astype(np.uint32)*tv);checks+=1
 replay(D.ops,s,one,cb);assert s==orig and checks==2
 paid=lambda ops:sum(o.raw==49 for o in ops)+.5*sum(o.raw==176 for o in ops)
 r=dict(Q=36,scope='partial first encoded canonical product roundtrip, odd factor word + retained address. No downstream phase or full oracle',legal=N,local_cases=44,common_rank=len(R['W']),forward_ccx_per_cell=7,inverse_ccx_per_cell=7,forward_ccx=paid(forward),inverse_ccx=paid(inverse),load_paid=paid(load),unload_paid=paid(unload),normalizer_paid=paid(K.ops),expected_paid=paid(ops),CCX=sum(o.raw==49 for o in ops),HMR=sum(o.raw==80 for o in ops),ops=len(ops),snapshot=snap,checks=checks,verification='PASS',sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=time.time()-start,odd=odd.tolist(),true=true.tolist())
 (P/'v61_receipt.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2),flush=True)
if __name__=='__main__':run()
