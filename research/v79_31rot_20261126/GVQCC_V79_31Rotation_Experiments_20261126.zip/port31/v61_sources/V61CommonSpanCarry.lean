import Std.Tactic
namespace GVQCC.V61

def digit (m c : Nat) (b : Bool) : Nat := c + (if b then m else 0)

theorem digit_range (m c : Nat) (b : Bool) (h : c < m) :
    digit m c b / 2 < m := by
  cases b <;> simp [digit] <;> omega

theorem digit_reconstruct (m c : Nat) (b : Bool) :
    2 * (digit m c b / 2) + digit m c b % 2 = digit m c b := by
  omega

theorem digit_inverse (m c : Nat) (b : Bool) (h : c < m) :
    (m ≤ digit m c b ↔ b = true) ∧
    digit m c b - (if b then m else 0) = c := by
  cases b <;> simp [digit] <;> omega

theorem measured_atom (u v r : Bool) :
    Bool.xor (r && (u && v)) (r && u && v) = false := by
  cases u <;> cases v <;> cases r <;> decide

theorem measured_parity (u v r : Bool) :
    (r && Bool.xor u v) = Bool.xor (r && u) (r && v) := by
  cases u <;> cases v <;> cases r <;> decide

theorem rounding_quotient (p k : Nat) :
    (p + k) / 8 = p / 8 + (p % 8 + k) / 8 := by
  omega

theorem odd_factor_booth_round (p m : Nat) :
    (4 * p + 2 * m + 16) / 32 = (p + m / 2 + 4) / 8 := by
  omega

theorem cost_receipt : 2 * 132 - (67 + 63) = 134 ∧
    217 + 6 + 6 + 1 + 67 + 63 = 360 ∧ 360 + 92 + 151 = 603 := by decide
end GVQCC.V61
