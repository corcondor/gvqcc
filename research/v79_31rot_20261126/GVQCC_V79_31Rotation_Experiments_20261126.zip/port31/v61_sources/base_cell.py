from itertools import permutations
import random,time,json

def bits(v):
 while v:
  j=(v&-v).bit_length()-1;yield j;v^=1<<j

def dot(a,v):
 z=0
 for i in bits(a):z^=v[i]
 return z

def basis(v):
 B={}
 for x in v:
  while x:
   k=x.bit_length()-1
   if k in B:x^=B[k]
   else:B[k]=x;break
 return B

def canon(v):
 B=basis(v)
 for i in sorted(B):
  for j in sorted(k for k in B if k>i):
   if B[j]>>i&1:B[j]^=B[i]
 return tuple(B[i] for i in sorted(B,reverse=True))

def red(x,B):
 for k in sorted(B,reverse=True):
  if x>>k&1:x^=B[k]
 return x

def span_split(V):
 B={}
 for i,x in enumerate(V):
  m=1<<i
  while x:
   k=x.bit_length()-1
   if k in B:x^=B[k][0];m^=B[k][1]
   else:B[k]=(x,m);break
 return B

def solve(x,B):
 m=0
 while x:
  k=x.bit_length()-1
  if k not in B:return None
  v,t=B[k];x^=v;m^=t
 return m

def intersection(S,T):
 B=basis(T);P={};I=[]
 for i,x in enumerate(S):
  r=red(x,B);m=1<<i
  while r:
   k=r.bit_length()-1
   if k in P:r^=P[k][0];m^=P[k][1]
   else:P[k]=(r,m);break
  if not r:I.append(dot(m,S))
 return I

def extend(base,opts,n):
 ret=[];B={}
 for v in list(base)+list(opts):
  r=red(v,B)
  if r:B[r.bit_length()-1]=r;ret.append(v)
  if len(ret)==n:return ret
 return ret

def make(codes):
 rows=[(codes[m],c,x,m)for m in codes for c in range(m)for x in range(2)]
 vec=lambda fn:sum((int(fn(*r))&1)<<j for j,r in enumerate(rows))
 F=[vec(lambda k,c,x,m:1)]+[vec(lambda k,c,x,m:k>>j&1)for j in range(2)]
 A=F+[vec(lambda k,c,x,m:c>>j&1)for j in range(4)]+[vec(lambda k,c,x,m:x)]
 B=F+[vec(lambda k,c,x,m:((c+m*x)>>1)>>j&1)for j in range(4)]+[vec(lambda k,c,x,m:(c+m*x)&1)]
 return F,A,B,rows

def search(F,A,B,beam=12,depth=6,seed=0):
 n=len(A);rng=random.Random(seed);T=canon(B);S0=canon(A);assert len(S0)==len(T)==n
 def nexts(S):
  I=intersection(S,T);C=extend(F,I+list(S),n);arr=[dot(i<<1,C)for i in range(1,1<<(n-1))]
  SB=basis(S);JB=basis(list(S)+list(T));D=span_split(list(S)+list(T));cur=len(I);seen={}
  for ui,u in enumerate(arr):
   for v in arr[ui+1:]:
    p=u&v
    if red(p,SB)==0 or red(p,JB):continue
    z=solve(p,D);d,t=dot(z&((1<<n)-1),S),dot(z>>n,T)
    if not red(t,SB):continue
    H0=extend(F+I+[u,v],[],n)
    if not red(d,basis(H0)):continue
    E=extend(H0+[d],S,n);ext=E[len(H0)+1:]
    for mask in range(1<<len(ext)):
     H=H0+[a^(d if mask>>j&1 else 0)for j,a in enumerate(ext)]
     assert len(H)==n-1
     Q=canon(H+[d^p]);s=len(intersection(Q,T))
     if s>cur and Q not in seen:seen[Q]=(s,(H,d,u,v),Q)
  return list(seen.values())
 front=[(S0,[])];seen={S0};stats=[]
 for i in range(depth):
  for s,p in front:
   if s==T:return p,stats
  can=[];t0=time.time()
  for s,p in front:
   for sc,op,Q in nexts(s):
    if Q in seen:continue
    seen.add(Q);can.append((sc,rng.random(),Q,p+[op]))
  can.sort(key=lambda z:(-z[0],z[1]));stats.append([i,len(can),max([z[0]for z in can],default=0),round(time.time()-t0,2)])
  front=[(s,p)for _,__,s,p in can[:beam]]
  if not front:break
 for s,p in front:
  if s==T:return p,stats
 return None,stats
if __name__=='__main__':
 best=None;log=[]
 for perm in permutations(range(4)):
  codes=dict(zip([1,3,5,13],perm));F,A,B,rows=make(codes)
  p,stats=search(F,A,B)
  print(codes,'intersection',len(intersection(A,B)),'result',len(p)if p is not None else None,stats,flush=True);log.append([codes,stats,None if p is None else len(p)])
  if p is not None and (best is None or len(p)<len(best['path'])):best=dict(codes=codes,F=F,A=A,B=B,path=p,rows=rows)
  if best is not None and len(best['path'])<=4:break
  # all 24 encodings equivalent up to affine (GL(2,2) plus translations)
  break
 print('BEST',None if best is None else len(best['path']),flush=True)
 open('search.json','w').write(json.dumps(dict(best=best,log=log),indent=2))
