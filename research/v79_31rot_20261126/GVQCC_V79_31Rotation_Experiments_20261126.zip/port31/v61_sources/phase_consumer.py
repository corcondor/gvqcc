"""Consume the odd product as the exact first normalized Horner phase /32.
Not a full inverse-square-root oracle. Native verification uses all legal rows."""
from emit_meet import *
from normalize import mcx
from itertools import product
from functools import lru_cache
D=np.load(SRC/'repaired_k12.npz');C=D['C'];m=(C[:,4]>>14).astype(np.int64)
assert np.all(C[:,3]%32==0)
# Exact ESOP over 24 reachable normalized addresses, up to three cubes
# (fallback: individual singleton cubes).
dictc={}
for pat in product((-1,0,1),repeat=5):
 mask=sum(1<<a for a in range(24) if all(v<0 or (((a+8)>>i)&1)==v for i,v in enumerate(pat)))
 if not mask:continue
 cs=[17+i for i,v in enumerate(pat) if v>=0];cost=sum(o.raw==49 for o in mcx(cs,26,36));sc=(cost,len(cs),pat)
 if mask not in dictc or sc<dictc[mask]:dictc[mask]=sc
@lru_cache(None)
def cover(mask):
 if not mask:return []
 best=[dictc[1<<i][2]for i in bits(mask)];bs=(sum(dictc[1<<i][0]for i in bits(mask)),len(best))
 if mask in dictc:best=[dictc[mask][2]];bs=(dictc[mask][0],1)
 for a,(c,_,p) in dictc.items():
  b=mask^a
  if b in dictc and (c+dictc[b][0],2)<bs:best=[p,dictc[b][2]];bs=(c+dictc[b][0],2)
  if c>bs[0]:continue
  for d,(cc,_,pp) in dictc.items():
   if c+cc>bs[0]:continue
   e=b^d
   if e in dictc and (c+cc+dictc[e][0],3)<bs:best=[p,pp,dictc[e][2]];bs=(c+cc+dictc[e][0],3)
 return best
def flag(mask,q):
 ops=[]
 for pat in cover(mask):
  cs=[17+i for i,v in enumerate(pat)if v>=0];xs=[Op(17,(17+i,))for i,v in enumerate(pat)if v==0];ops+=xs+mcx(cs,q,36)+xs[::-1]
 return ops
def am(fn):return sum(1<<a for a in range(24)if fn(int(m[a])))
def run():
 t0=time.time();K=NativeKMB.read(P/'v61_pipeline_p1_r1_Q36_PARTIAL.kmb');snap=json.loads((P/'v61_pipeline_p1_r1_receipt.json').read_text())['snapshot'];norm=json.loads((SRC/'tagged_normalizer_Q36_receipt.json').read_text())['snapshot'];B=Bld(K.header[2]);angles=[];tags=[];base=-C[:,3]//32
 def rot(q,w,tag):
  B.add(Op(19,(q,)));angles.append((int(w)<<96)%(1<<128));tags.append([int(w),tag])
 for start in range(0,int(base.max()).bit_length(),4):
  vals=(base>>start)&15;B.coeff(vals)
  for j in range(4):
   if np.any((vals>>j)&1):rot(23+j,-(1<<(start+j)),['base',start+j])
  B.coeff(vals)
 baseops=B.ops[:];B.ops=[];prodq=list(range(5,17))+list(range(27,31));groups=[(am(lambda x:x in (1,3,5,13)),3,26,13),(am(lambda x:x==2),2,31,1),(am(lambda x:x==8),0,32,1)]
 for mask,d,q,mm in groups:B.add(*flag(mask,q))
 for j in range(16):
  z=33;terms=[]
  for mask,d,q,mm in groups:
   if j+d>=16 or mm*4095<1<<(j+d):continue
   terms.append((q,prodq[j+d]));B.CCX(q,prodq[j+d],z)
  if not terms:continue
  rot(z,1<<j,['quotient',j]);coin=B.m;B.m+=1;B.add(Op(80,(z,),measurement=coin));B.add(*[Op(160,t,condition=coin)for t in terms],Op(64,(),measurement=coin))
 for mask,d,q,mm in reversed(groups):B.add(*flag(mask,q)[::-1])
 def lowval(v,p):
  if v==0:return 0
  d=(v&-v).bit_length()-1
  return (((p<<d)&7)+v//2+4)//8
 cstart=len(B.ops)
 for j in range(2):
  co=[0]*8
  for a,v in enumerate(m):
   f=[(lowval(int(v),p)>>j)&1 for p in range(8)]
   for k in range(3):
    for i in range(8):
     if i>>k&1:f[i]^=f[i^(1<<k)]
   for i,g in enumerate(f):co[i]|=int(g)<<a
  by={}
  for s,mask in enumerate(co):
   if mask:by.setdefault(mask,[]).append(s)
  for mask,ss in sorted(by.items()):
   fop=flag(mask,26);B.add(*fop)
   for s in ss:B.add(*mcx([26]+[prodq[k]for k in bits(s)],31+j,36))
   B.add(*fop[::-1])
 corr=B.ops[cstart:];rot(31,1,['carry',0]);rot(32,2,['carry',1]);B.add(*corr[::-1]);consumer=B.ops[:]
 ops=K.ops[:norm]+baseops+K.ops[norm:snap]+consumer+K.ops[snap:];h=list(K.header);h[2]=B.m;h[10]=len(angles);sections=[(i,b''.join(a.to_bytes(16,'little')for a in angles)if i==10 else v)for i,v in K.sections];path=P/'v61_first_Horner_phase_Q36_PARTIAL.kmb';path.write_bytes(NativeKMB(K.prefix16,tuple(h),sections,ops).to_bytes());Z=NativeKMB.read(path);assert Z.ops==ops and max(q for o in Z.ops for q in o.wires)<36
 # Independent signed Booth reference on every legal x.
 x=np.arange(1,N+1,dtype=np.int64);e=np.zeros(N,np.int64)
 for j in range(1,11):e[x>=1<<(2*j)]=j
 U=x<<(2*(10-e));a=(U>>17)-8;tv=(U&((1<<17)-1))>>5;av=C[a,4];p=np.zeros_like(av)
 for j in range(0,13,2):
  digit=(((tv>>(j-1))&1)if j else 0)+((tv>>j)&1)-2*((tv>>(j+1))&1);p+=digit*(av>>(12-j))
 p+=(av+(1<<12))>>13;expected=(C[a,3]+p+16)>>5;raw=m[a]*tv;quot=raw>>3;cr=np.where(m[a]!=0,((raw&7)+m[a]//2+4)>>3,0);assert np.array_equal(expected,C[a,3]//32+quot+cr)
 one=(1<<N)-1;s=[pack((x>>j)&1)for j in range(22)]+[0]*14;orig=s[:];ph={};ri=0;phase=np.zeros(N,np.int64);ab=dict(Z.sections)[10];assert len(ab)==16*len(tags)
 for i,o in enumerate(Z.ops,1):
  w=o.wires;g=o.raw
  if g==17:s[w[0]]^=one
  elif g==33:s[w[1]]^=s[w[0]]
  elif g==49:s[w[2]]^=s[w[0]]&s[w[1]]
  elif g==34:s[w[0]],s[w[1]]=s[w[1]],s[w[0]]
  elif g==80:assert o.measurement not in ph;ph[o.measurement]=s[w[0]];s[w[0]]=0
  elif g in (128,144,160,176):
   z=one
   for q in w:z&=s[q]
   ph[o.condition]^=z
  elif g==64:assert ph.pop(o.measurement)==0,(i,o)
  elif g==19:
   wt,(kind,j)=tags[ri];ang=int.from_bytes(ab[16*ri:16*(ri+1)],'little');assert ang==(wt<<96)%(1<<128)
   ref={'base':base[a],'quotient':quot,'carry':cr}[kind];assert s[w[0]]==pack((ref>>j)&1),(i,kind,j)
   vec=np.unpackbits(np.frombuffer(s[w[0]].to_bytes((N+7)//8,'little'),np.uint8),bitorder='little')[:N];phase+=wt*vec.astype(np.int64);ri+=1
  else:raise ValueError(o)
 assert ri==len(tags) and s==orig and not ph and np.array_equal(phase,expected)
 paid=lambda ops:sum(o.raw==49 for o in ops)+.5*sum(o.raw==176 for o in ops)
 receipt=dict(Q=36,scope='first normalized Horner-stage v3/32 only, not full inverse square root',legal=N,expected_paid=paid(Z.ops),baseline=paid(K.ops),base_paid=paid(baseops),consumer_paid=paid(consumer),rotations=len(tags),generic_rotations=sum(a%(1<<125)!=0 for a in angles),ops=len(Z.ops),HMR=sum(o.raw==80 for o in Z.ops),verification='PASS exact signed first stage phase all legal inputs, all HMR branch phases zero, full restoration',phase_sha256=hashlib.sha256(phase.astype('<i8').tobytes()).hexdigest(),sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=time.time()-t0)
 (P/'v61_phase_consumer_receipt.json').write_text(json.dumps(receipt,indent=2));(P/'v61_phase_consumer_tags.json').write_text(json.dumps(tags));print(receipt,flush=True)
if __name__=='__main__':run()
