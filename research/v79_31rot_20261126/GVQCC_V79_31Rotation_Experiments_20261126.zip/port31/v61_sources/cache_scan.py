from base_cell import *
from meet import closure
import json
from pathlib import Path
P=Path(__file__).parent
R=json.loads((P/'meet_native_path.json').read_text());F,A,B,W=[R[k]for k in ('F','A','B','W')];M=[1,3,5,13];rows=[(j,c,x,m)for j,m in enumerate(M)for c in range(m)for x in range(2)];lookup={(k,c,x):i for i,(k,c,x,m)in enumerate(rows)}
perm=[lookup[(k,(c+m*x)//2,(c+m*x)&1)]for k,c,x,m in rows];assert len(set(perm))==44

def pull(v):return sum(((v>>p)&1)<<i for i,p in enumerate(perm))
def push(v):return sum(((v>>i)&1)<<p for i,p in enumerate(perm))
D=[3<<(2*i)for i in range(22)]
Wc=intersection(W,D);Wb=intersection([push(v)for v in W],D);common=intersection(Wc,Wb)
base=A[:-1];cache=extend(base,common,len(common));assert len(cache)==len(common);extras=cache[len(base):]
print('Wcarry ranks',len(Wc),len(Wb),'common',len(common),'base',len(base),'extra',extras,flush=True)
for q in extras:
 print('cache',q,[[int(q>>lookup[(k,c,0)]&1)for c in range(m)]for k,m in enumerate(M)],'init',[int(q>>lookup[(k,0,0)]&1)for k,m in enumerate(M)])
# extend forward and backward with persistent nonlinear functions. Each original product can be skipped if already in span; the other products still available.
SA=A+extras;SB=B+[pull(v)for v in extras]
fa=[];fb=[]
for S,path,trace in [(SA,R['fa'],fa),(SB,R['fb'],fb)]:
 for u,v,p in path:
  assert solve(u,span_split(S)) is not None and solve(v,span_split(S))is not None
  if solve(p,span_split(S)) is None:S.append(p);trace.append([u,v,p])
 assert canon(S)==canon(W)
print('new costs',len(fa),len(fb),flush=True)
(P/'cache_scan.json').write_text(json.dumps(dict(common=common,extra=extras,pull_extra=[pull(q)for q in extras],fa=fa,fb=fb,init=[[int(q>>lookup[(k,0,0)]&1)for k,m in enumerate(M)]for q in extras]),indent=2))
