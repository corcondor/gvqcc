# V61 — measured common-span carry transducer (NOT SUBMISSION)

**Scope:** first encoded canonical product roundtrip and separate exact first normalized Horner-stage phase only. Neither KMB is the inverse-square-root oracle. No official verifier, score improvement, or Kaggle submission claim. Every emitted physical circuit is 36Q, using only q0..35; no 37Q candidate. Base arithmetic model and packed normalizer are from PR141 (`9cc208f1bd7ee5cf102bf1db0cf33d991520a05c`); the exact retained product is unchanged after decoding the new odd-factor ABI. PR139's analytical Booth budgets are not used as native costs.

## Results

| variant | Q | E_paid | ops | Scope |
|---|---:|---:|---:|---|
| PR141 baseline |36|497|3558|encoded product roundtrip|
| 7+7 common-span |36|397|5602|odd-factor product roundtrip|
| persistent cache |36|374|5830|same|
| restricted digit without cache |36|383|5123|same|
| persistent + restricted |36|360|5324|same|
| first normalized stage phase, dirty controls |36|737|6736|v3/32 phase only, R=32|
| first normalized stage phase, clean measured controls |36|603|6780|v3/32 phase only, R=32|

Each new KMB is serialized, reread and replayed on all 3,133,452 legal input rows. Exact product snapshot and original input/work restoration checked; symbolic independent HMR signs cancel. Phase consumers separately verify every rotation control and angle and reconstruct the signed integer first-stage phase, hash `1c05552f7be2b134e85c73d91903cb038c68043e8e76d70984ff89a900462408`. No floating-point tolerance proxy needed for this partial equivalence. Final phase target, later Horner stages, exponent scaling and official rotation synthesis remain open. Cost E=CCX+0.5*independently conditioned CCZ, not official score. All native files use maximum physical index 35.

## Construction

Encode m in {0,1,2,3,5,8,13} as the odd factor in {1,3,5,13}, with the original address retaining the 2-adic shift and zero sentinel. A digit maps `(k,c,b)` to `(k,floor((c+mb)/2),(c+mb) mod 2)` on 44 reachable rows (0<=c<m). Two rank-eight affine spaces (constant included) are extended into the same rank-15 space via seven rank-one products each. Forward compute, affine basis exchange, and backward-side HMR erasure make the forward native cost seven CCX; inverse likewise seven. The C++ bidirectional quotient beam uses exact factor-kernel solves and common residual directions; 37,894,446 product probes, 3,622 closures. One persistent coefficient product is present in both charts, saving one product per full-row digit; exact row compression on the early digits reduces cost further. Forward 67, inverse 63, cache init 1, loader/unloader 6+6, normalizer 217: total E360. Cache mask 3 is indicator of odd m=1. Failed rank-13, sparse quadratic MBU, 35,000 recodings and further-cache beam searches are retained as logs, not universal lower bounds.

For first-stage phase, the signed Booth product for these coefficients is `4*m*T + 2*m` (T is the 12 retained offset bits). Since C3 is a multiple of 32, `v3/32=C3/32+floor((m*T+floor(m/2)+4)/8)`. The odd product is read in three one-hot shift groups; low three bits determine only a two-bit rounding correction. The compiler does not reconstruct a second full 17-bit word. It applies the coefficient offset, quotient and rounding correction as 32 weighted rotations, then uncomputes. The clean variant builds and measurement-erases multi-controlled chains instead of dirty ladders, saving 134 expected paid. This is a partial phase diagnostic, not an ABI for the remaining stages or a competitive circuit.

## Reproduce

Python 3 with NumPy; C++17 compiler optional. From archive root:

```
python verify_common_span.py
# Optional: regenerate exact search witness (bounded, deterministic seed):
g++ -O3 -std=c++17 meet_beam.cpp -o meet_beam
./meet_beam 24 120
python cache_scan.py
python emit_meet.py
python emit_pipeline.py
python phase_consumer.py
python phase_consumer_clean.py
python check_invsqrt_width.py v61_pipeline_p1_r1_Q36_PARTIAL.kmb
python check_invsqrt_width.py v61_first_Horner_phase_clean_Q36_PARTIAL.kmb
```

The package includes the actual search witness, portable emitters, independent certificate checker, KMBs, receipts, local Lean identities, and relevant PR141 inputs/dependencies. Source search witness may be reused without rerunning beam search. Lean only verifies local algebra; native all-domain replay is separate.

## Literature and limitations

Meuli et al., *The Role of Multiplicative Complexity in Compiling Low T-count Oracle Circuits* (arXiv:1908.01609); XAG nonlinearity/space tradeoff and measured uncomputation. Soeken et al., *Determining Multiplicative Complexity of Boolean Functions using SAT*: motivates bounded rank-one synthesis, not a port of their SAT solver. Halpenny/Sireesh/Wallden (arXiv:2611.26605), in-place odd multiplication: motivates odd-factor representation. Measurement-based uncomputation of quantum circuits for modular arithmetic: erase nonlinear temporary functions with phase corrections. These are finite-domain adaptations, not claims that asymptotic bounds or complete algorithms transfer. No global minimum or final score claim. Main and Kaggle unchanged.

Portable import template is a copy of the verified 36Q packed normalizer, not a 37Q reference circuit. Separate-directory replay reproduced both best KMB byte hashes.
