from cell_mbu import *
from collections import Counter
M=[1,3,5,13];rows=[(j,c,x,m)for j,m in enumerate(M)for c in range(m)for x in range(2)]
vec=lambda fn:sum((int(fn(*r))&1)<<j for j,r in enumerate(rows))
F=[(1<<len(rows))-1]+[vec(lambda k,c,x,m:k>>j&1)for j in range(2)]
xv=vec(lambda k,c,x,m:x);yv=vec(lambda k,c,x,m:(c+m*x)&1)

def state(E):
 A=F+[vec(lambda k,c,x,m:E[k][c]>>j&1)for j in range(4)]+[xv]
 B=F+[vec(lambda k,c,x,m:E[k][(c+m*x)//2]>>j&1)for j in range(4)]+[yv]
 return A,B

def dim(E):
 A,B=state(E)
 a,b=basis(A),basis(B)
 if len(a)!=8 or len(b)!=8:return (-1,-1,-1,-1)
 qa,qb=qbasis(A),qbasis(B)
 ab=len(intersection(A,B));f=len(intersection(list(qa.values()),B));r=len(intersection(list(qb.values()),A))
 return min(f,r),f+r,ab,-(len(qa)+len(qb))

def randomize(r,E):
 G=[list(x)for x in E];j=r.choice([1,2,3]);u=r.randrange(1,M[j]);v=r.randrange(1,16)
 if v in G[j]:k=G[j].index(v);G[j][u],G[j][k]=G[j][k],G[j][u]
 else:G[j][u]=v
 return G

def run():
 r=random.Random(61);init=[list(range(m))for m in M];E=init;best=dim(E);be=[];count=Counter();t=time.time()
 for i in range(35000):
  if i%500==0:E=r.choice(be)[1]if be and r.random()<.75 else init;sc=dim(E)
  G=randomize(r,E);s=dim(G);count[s[:3]]+=1
  if s>best:best=s;print('BEST',i,s,G,time.time()-t,flush=True)
  if s>=sc or r.random()<.02:E=G;sc=s
  if s[0]>=5 and (not be or all(G!=x[1]for x in be)):
   be.append((s,G));be.sort(reverse=True);be=be[:30]
 print('count',count.most_common(25));open('encoding_scan.json','w').write(json.dumps(dict(candidates=be,counts=[(list(k),v)for k,v in count.items()],sec=time.time()-t),indent=2))
 for s,E in be[:8]:
  A,B=state(E);print('try',s,E,flush=True);f,fl=search(A,B,F,beam=16);print('forward',f and f[0]);inv,il=search(B,A,F,beam=16);print('inverse',inv and inv[0]);
  if f and inv:
   open('encoded_path.json','w').write(json.dumps(dict(E=E,F=F,A=A,B=B,rows=rows,forward=f,inverse=inv),indent=2));break
if __name__=='__main__':run()
