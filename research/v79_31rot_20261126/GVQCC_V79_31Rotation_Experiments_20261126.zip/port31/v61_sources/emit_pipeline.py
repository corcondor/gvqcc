"""Persistent coefficient/carry chart and exact reachable digit compression.
All per-digit restricted bases are derived from all legal inputs. Forward and
backward XAGs share a common span; no backward CCX is needed for erasure.
"""
import emit_meet as E
from emit_meet import *
import itertools
from pathlib import Path
P=Path(__file__).parent

# Physical affine compression with exact dependency certificates. The inverse
# reconstructs all original redundant coordinates on the specified care set.
def compress(vals,qs,one):
 assert vals[0]==one
 S=[one];W=[];ops=[]
 for v,q in zip(vals[1:],qs):
  z=solve(v,span_split(S))
  if z is None:S.append(v);W.append(q);continue
  if z&1:ops.append(Op(17,(q,)))
  ops.extend(Op(33,(W[j-1],q))for j in bits(z&~1))
 return S,W,ops

def remap(src,dst,allw):
 assert len(src)==len(dst) and len(set(src))==len(src) and len(set(dst))==len(dst)
 # Move live independent coordinates in the given order; remaining wires zero.
 cur={q:i for i,q in enumerate(src)};by={i:q for q,i in cur.items()};ops=[]
 for i,t in enumerate(dst):
  a=by[i]
  if a==t:continue
  j=cur.pop(t,None);cur.pop(a);cur[t]=i;by[i]=t
  if j is not None:cur[a]=j;by[j]=a
  ops.append(Op(34,(a,t)))
 assert [by[i]for i in range(len(src))]==dst
 return ops

def compile_cell(b,x,mask,inv=False,persist=True,cachefile='cache_scan.json',pathfile='meet_native_path.json'):
 R=json.loads((P/pathfile).read_text());C=json.loads((P/cachefile).read_text());extras=C['extra']if persist else [];pull=C['pull_extra']if persist else []
 fa,fb=C['fa']if persist else R['fa'],C['fb']if persist else R['fb']
 A=R['A']+extras;B=R['B']+pull;full=R['F'][0];oldone=E.ONE;E.ONE=mask
 if inv:A,B,fa,fb=B,A,fb,fa
 cacheqs=[25,26,31,32,33,34,35][:len(extras)];core=[23,24,27,28,29,30,x]+cacheqs;work=[q for q in [25,26,31,32,33,34,35]if q not in cacheqs];allw=core+work
 start,srcq,pre=compress([v&mask for v in A],core,mask);goal,dstq,post=compress([v&mask for v in B],core,mask)
 def plan(S,qs,path):
  S=S[:];qs=qs[:];free=[q for q in allw if q not in qs];trace=[]
  for u,v,p in path:
   u&=mask;v&=mask;p&=mask;assert p==u&v and solve(u,span_split(S))is not None and solve(v,span_split(S))is not None
   if solve(p,span_split(S))is not None:continue
   assert free;z=free.pop(0);trace.append((u,v,p,z));qs.append(z);S.append(p)
  return S,qs,trace
 L,lq,lf=plan(start,srcq,fa);H,hq,hf=plan(goal,dstq,fb);assert canon(L)==canon(H)
 before=len(b.ops);b.add(*pre);S=start[:];qs=srcq[:]
 for u,v,p,z in lf:
  op,a,c=E.form(S,u,v,qs);b.add(*op,Op(49,(a,c,z)),*op[::-1]);S.append(p);qs.append(z)
 b.add(*remap(lq,hq,allw),*E.affine(L,H,hq));S=H[:];qs=hq[:]
 for u,v,p,z in reversed(hf):
  assert p==S.pop() and z==qs.pop();op,a,c=E.form(S,u,v,qs);b.add(*op);b.erase(z,[a,c]);b.add(*op[::-1])
 b.add(*post[::-1]);E.ONE=oldone
 return dict(rows=mask.bit_count(),src_rank=len(start),dst_rank=len(goal),shared_rank=len(L),ccx=len(lf),hmr=len(hf),ops=len(b.ops)-before)

def masks_exact(x,U,odd,codes,a):
 t=(U>>5)&4095;m=odd[a].astype(np.uint32);k=codes[a].astype(np.uint32);lookup={(k,c,z):i for i,(k,c,z,m)in enumerate(E.ROWS)};rows=[]
 # each table row index determined by actual previous carry; all x considered.
 lookup_np=np.full((4,16,2),-1,dtype=np.int32)
 for (kk,c,z),i in lookup.items():lookup_np[kk,c,z]=i
 for j in range(12):
  c=(m*(t&((1<<j)-1)))>>j;b=(t>>j)&1;rs=np.unique(lookup_np[k,c,b]);assert rs.min()>=0;rows.append(sum(1<<int(i)for i in rs))
 return rows

def cache_init(bb,extras,inv=False):
 # cache at c=0 is a Boolean function of two selector bits. Current variant
 # uses !(k0|k1), compute once and measurement-erase once after the inverse.
 assert extras==[3]
 if not inv:bb.X(23);bb.X(24);bb.CCX(23,24,25);bb.X(24);bb.X(23)
 else:bb.X(23);bb.X(24);bb.erase(25,[23,24]);bb.X(24);bb.X(23)

def run(persist=True,restrict=True):
 start=time.time();model=np.load(SRC/'repaired_k12.npz');true=(model['C'][:,4]>>14).astype(np.int64);odd=np.array([int(m)//(int(m)&-int(m))if m else 1 for m in true]);codes=np.array([CODES[m]for m in odd]);
 K=NativeKMB.read(SRC/'tagged_normalizer_Q36_23active_RESEARCH.kmb');rec=json.load(open(SRC/'tagged_normalizer_Q36_receipt.json'));mid=rec['snapshot'];bb=Bld(K.header[2]);bb.coeff(codes);load=bb.ops[:];bb.ops=[]
 x=np.arange(1,N+1,dtype=np.uint32);e=np.zeros(N,np.uint32)
 for j in range(1,11):e[x>=1<<(2*j)]=j
 sh=10-e;U=x<<(2*sh);p=U^np.array([tag(j)for j in range(11)],np.uint32)[sh];a=(U>>17)-8;cc=codes[a].astype(np.uint32);tv=(U>>5)&4095;v=odd[a].astype(np.uint32)*tv;one=(1<<N)-1
 masks=masks_exact(x,U,odd,codes,a)if restrict else [E.ONE]*12
 extras=json.loads((P/'cache_scan.json').read_text())['extra'];rows=[];T=list(range(5,17));C=list(range(27,31));W=[25,26,31,32,33,34,35];cacheqs=[25]if persist else [];W=[q for q in W if q not in cacheqs]
 if persist:cache_init(bb,extras)
 init=bb.ops[:];bb.ops=[]
 for q,m in zip(T,masks):rows.append(compile_cell(bb,q,m,False,persist))
 forward=bb.ops[:];bb.ops=[];back=[]
 for q,m in reversed(list(zip(T,masks))):back.append(compile_cell(bb,q,m,True,persist))
 inverse=bb.ops[:];bb.ops=[]
 if persist:cache_init(bb,extras,True)
 finish=bb.ops[:];bb.ops=[];bb.coeff(codes);unload=bb.ops[:]
 ops=K.ops[:mid]+load+init+forward+inverse+finish+unload+K.ops[mid:];snap=mid+len(load)+len(init)+len(forward);h=list(K.header);h[1]=36;h[2]=bb.m;D=NativeKMB(K.prefix16,tuple(h),K.sections,ops);name=f'v61_pipeline_p{int(persist)}_r{int(restrict)}';path=P/(name+'_Q36_PARTIAL.kmb');path.write_bytes(D.to_bytes());D=NativeKMB.read(path);assert D.ops==ops and max(q for o in ops for q in o.wires)<36
 s=[pack((x>>j)&1)for j in range(22)]+[0]*14;orig=s[:];checks=0
 def cb(i,s,ph):
  nonlocal checks
  if i==mid+len(load)+len(init):
   assert [s[q]for q in [23,24]]==[pack((cc>>j)&1)for j in range(2)] and not any(s[q]for q in C+W) and not ph
   if persist:assert s[25]==pack(cc==0)
   checks+=1
  if i==snap:
   assert [s[q]for q in T+C]==[pack((v>>j)&1)for j in range(16)] and [s[q]for q in [23,24]]==[pack((cc>>j)&1)for j in range(2)] and not any(s[q]for q in W) and not ph
   if persist:assert s[25]==pack(cc==0)
   assert all(s[q]==pack((p>>q)&1)for q in range(22)if q not in T) and s[22]==pack(sh!=0)
   def up(q):return np.unpackbits(np.frombuffer(s[q].to_bytes((N+7)//8,'little'),np.uint8),bitorder='little')[:N].astype(np.uint32)
   ad=sum(up(q)<<(q-17)for q in range(17,22))-8;yy=sum(up(q)<<j for j,q in enumerate(T+C));assert np.array_equal(yy*(true//odd)[ad],true[a]*tv);checks+=1
 replay(D.ops,s,one,cb);assert s==orig and checks==2
 paid=lambda ops:sum(o.raw==49 for o in ops)+.5*sum(o.raw==176 for o in ops)
 r=dict(Q=36,scope='partial first odd-encoded product roundtrip, not full oracle',legal=N,persist=persist,restrict=restrict,forward=rows,backward=back,forward_paid=paid(forward),inverse_paid=paid(inverse),init_paid=paid(init),finish_paid=paid(finish),load_paid=paid(load),unload_paid=paid(unload),normalizer_paid=paid(K.ops),expected_paid=paid(ops),CCX=sum(o.raw==49 for o in ops),HMR=sum(o.raw==80 for o in ops),ops=len(ops),snapshot=snap,checks=checks,verification='PASS',sha256=hashlib.sha256(path.read_bytes()).hexdigest(),seconds=time.time()-start,masks=masks)
 (P/(name+'_receipt.json')).write_text(json.dumps(r,indent=2));print(name,'PASS',r['expected_paid'],r['ops'],'forward',[(v['rows'],v['ccx'],v['hmr'])for v in rows],'backward',[v['ccx']for v in back],flush=True)
if __name__=='__main__':
 for p,r in [(True,False),(False,True),(True,True)]:run(p,r)
