"""Exact common-span synthesis: a forward and backward XAG compute the same
augmented space. Convert between bases, then measure the backward XAG's
products in reverse. Only one side's ANDs are charged per direction.
"""
from cell_mbu import *
from collections import Counter

def products_residue(S,U,F):
 L=forms(S,F)[1];B=basis(S);out={}
 for i,a in enumerate(L):
  for b in L[i+1:]:
   p=a&b
   if red(p,B):out.setdefault(red(p,U),p)
 return out

def compute_candidates(S,W,F,first=True):
 # For fixed u, solve the linear constraints u*v in W, v in span S.
 n=len(S);SB=basis(S);WB=basis(W);out={}
 U=extend(F,S,n)
 # all combinations except constant shifts (same quotient)
 for k in range(1,1<<(n-1)):
  u=dot(k<<1,U);R={}
  for j,v in enumerate(U):
   p=u&v;r=red(p,WB);m=1<<j
   while r:
    t=r.bit_length()-1
    if t not in R:R[t]=(r,m);break
    a,b=R[t];r^=a;m^=b
   if not r:
    v=dot(m,U);p=u&v;d=red(p,SB)
    if d and d not in out:
     out[d]=(u,v,p)
     if first:return out
 return out

def closure(S,W,F):
 S=extend(F,S,len(S));trace=[]
 while len(S)<len(W):
  C=compute_candidates(S,W,F)
  if not C:break
  u,v,p=next(iter(C.values()));trace.append((u,v,p));S.append(p)
 return S,trace

def main():
 F,A,B,rows=make(dict(zip([1,3,5,13],range(4))));U=extend(A,B,12);UB=basis(U);PA=products_residue(A,UB,F);PB=products_residue(B,UB,F);t=time.time();results=[]
 for i,r in enumerate(sorted(PA.keys()&PB.keys())):
  W=U+[r];SA,fa=closure(A,W,F);SB,fb=closure(B,W,F);print(i,r,len(SA),len(SB),time.time()-t,flush=True);results.append((r,len(SA),len(SB)))
  if len(SA)==len(SB)==len(W):
   open('meet_path.json','w').write(json.dumps(dict(A=A,B=B,F=F,rows=rows,W=W,fa=fa,fb=fb),indent=2));break
 open('meet_results.json','w').write(json.dumps(results,indent=2))
if __name__=='__main__':main()
