"""Finite measurement-based quotient synthesis for the small odd carry transducer.
A state is the affine span of physical lines on the entire local legal domain.
Fixed selector forms persist. A transition computes a new coordinate as at most
k rank-one products, then erases an old coordinate with an exact phase polynomial.
"""
from base_cell import bits,dot,basis,canon,red,span_split,solve,intersection,extend,make
from itertools import combinations,product
import random, time, heapq,json,sys

def quotient(v,B):
 for k in sorted(B,reverse=True):
  if v>>k&1:v^=B[k]
 return v

def qbasis(S):
 Q=list(S)+[a&b for a,b in combinations(S[1:],2)] # S[0]=1
 return basis(Q)

def forms(S,F):
 U=extend(F,list(S),len(S));assert len(U)==len(S)
 return U,[dot(i<<1,U) for i in range(1,1<<(len(S)-1))]

def dictionary(S,F):
 U,L=forms(S,F);B=basis(S);P={}
 for i,u in enumerate(L):
  for j in range(i+1,len(L)):
   v=L[j];p=u&v;r=quotient(p,B)
   if r and r not in P:P[r]=(u,v,p)
 return U,P,B

def hyperplanes(S,F,I,dest):
 # All codim-one spaces containing the invariant selector and shared target intersection.
 H0=extend(F,I,len(S));U=extend(H0,S,len(S));k=len(H0);n=len(U)
 if k==n:return
 for f in range(1,1<<(n-k)):
  pivot=(f&-f).bit_length()-1+k;d=U[pivot]
  H=U[:k]+[U[i]^(d if f>>(i-k)&1 else 0)for i in range(k,n)if i!=pivot]
  yield H,d

def rank_one_or_two(S,T,F,limit=2,beam=20):
 I=intersection(S,T);U,P,SB=dictionary(S,F);TB=basis(T)
 base=extend(I,T,len(T));k=len(I);qs=[dot(i<<k,base)for i in range(1,1<<(len(T)-k))]
 out=[];stats=[len(P),len(qs),0,0]
 for q in qs:
  r=quotient(q,SB);assert r
  prods=[]
  if r in P:prods=[P[r]]
  elif limit>=2:
   for p,v in P.items():
    t=r^p
    if t>p and t in P:
     prods=[v,P[t]];break
  if not prods:continue
  stats[2]+=1
  for H,d in hyperplanes(S,F,I,q):
   N=H+[q];stats[3]+=1
   if red(d,qbasis(N)):continue
   out.append((len(prods),(H,d,q,prods),canon(N)))
 return out,stats

def search(A,B,F,beam=16,limit=2,seed=0):
 t=time.time();rng=random.Random(seed);S0=canon(A);T=canon(B);front=[(0,S0,[])];seen={S0:0};logs=[];best=None
 for stage in range(8):
  new=[];stats=[0,0,0,0]
  for c,S,p in front:
   if S==T:
    if best is None or c<best[0]:best=(c,p)
    continue
   if best and c>=best[0]:continue
   edges,ss=rank_one_or_two(S,T,F,limit)
   for j in range(4):stats[j]+=ss[j]
   for cost,op,N in edges:
    v=c+cost
    if v>=seen.get(N,9999):continue
    seen[N]=v;new.append((v,N,p+[op]))
  if not new:break
  new.sort(key=lambda v:(v[0]+len(T)-len(intersection(v[1],T)),v[0],rng.random()));front=new[:beam]
  logs.append(dict(stage=stage,stats=stats,accepted=len(new),mincost=new[0][0],seconds=time.time()-t));print('stage',logs[-1],flush=True)
 for c,S,p in front:
  if S==T and (best is None or c<best[0]):best=(c,p)
 return best,logs

if __name__=='__main__':
 F,A,B,rows=make(dict(zip([1,3,5,13],range(4))));out={}
 for n,X,Y in [('forward',A,B),('inverse',B,A)]:
  z,l=search(X,Y,F,beam=int(sys.argv[1])if len(sys.argv)>1 else 32);out[n]=dict(result=z,logs=l);print(n,'RESULT',None if z is None else z[0],flush=True)
 out.update(F=F,A=A,B=B,rows=rows);open('cell_mbu.json','w').write(json.dumps(out,indent=2))
