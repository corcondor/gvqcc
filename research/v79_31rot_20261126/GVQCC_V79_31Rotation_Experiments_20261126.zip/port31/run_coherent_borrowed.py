"""Compile the first-Horner chart using borrowed-register linear incrementers."""
from pathlib import Path
import json
import coherent_horner as H
from borrowed_increment import controlled_increment

def increment(bit,sign):
    return controlled_increment(H.FLAG,H.WORD[bit:],36,negative=(sign<0))

if __name__=='__main__':
    H.increment=increment
    H.main(modes=("address_naf_commute","shared_signed_digits_commute"),suffix="_borrowed")
