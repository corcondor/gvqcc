# Graphene参考文献 [29]–[42]：主本文読解の補完記録

対象14件の主本文の全節を、取得済み一次ソースで実読した。主本文の文章は14/14件を通読したが、[31]の外部表と[32]の画像化数式には取得欠落があるため、この2件を「全構成要素の読了」とはしない。別付録・Supplementaryの全読、全図画像の独立検査、数値計算の再現を行ったという主張も含めない。

元台帳を変更せずに追加したレビューである。原著本文の転載は含めない。読解日：2026-11-15。

## 読解範囲の集計

| 区分 | 件数 | 対象 |
|---|---:|---|
| 主本文全節の文章を通読 | 14 | [29]–[42] |
| 主本文内の表・画像数式の取得欠落を検出 | 2 | [31] Table 1、[32] 式(3)–(6),(8),(9)など |
| 主本文の途中切れを検出 | 0 | 取得された文章に途中切れなし |
| 本文末のMethodsを全小節通読 | 3 | [31]、[34]、[35] |
| 本文中のComputational methodology/Methodsを通読 | 2 | [32]、[37] |

その他の論文も本文中の模型・計算法の記述を全て読んだ。[30]の製作Methodsは別Supplemental Materialのため今回未読。[36]は実際に取得したv1に独立Methods節がなく、出版版Methodsの読了へ拡張しない。

## 版と完了状態

| 文献 | 実際に読んだ版 | 主本文の状態 |
|---|---|---|
| [29] | arXiv:1803.08057v2, 2018-04-02。HTML再生成日2026-08-24を版更新とは扱わない。 | 主本文全節を通読 |
| [30] | 取得PDFの arXiv:2209.14730。抽出本文にはversion suffixがなく、原キャッシュSHA256に固定。 | 主本文全節を通読 |
| [31] | Nature Communications 15,8437, published 2024-09-30。出版社本文HTML。 | 全節の文章を通読・埋込資料に取得欠落 |
| [32] | Phys. Chem. Chem. Phys.27,11541–11550, first published 2025-05-15; DOI10.1039/D5CP00337G。 | 全節の文章を通読・埋込資料に取得欠落 |
| [33] | arXiv:2505.24146v2, 2025-07-15。HTML再生成日2026-08-24を版更新とは扱わない。 | 主本文全節を通読 |
| [34] | arXiv:2410.16269v2, 2026-01-24。引用先のNature Materials出版版と区別し、この取得版に固定。 | 主本文全節を通読 |
| [35] | arXiv:2310.12204v1, 2023-10-18。実際の題名は Helical trilayer graphene: a moiré platform for strongly-interacting topological bands。引用題名 Topological bands and correlated states in helical trilayer graphene（Nat. Phys. 2025）とは異なる版で、出版版本文を全読したとは扱わない。 | 主本文全節を通読 |
| [36] | arXiv:2305.03031v1, 2023-05-04。Sci. Advances出版版のMethods・補足の読了へ拡張しない。 | 主本文全節を通読 |
| [37] | arXiv:2308.09706v1, 2023-08-18。引用のPhys. Rev. B出版版本文との差分は今回未検査。 | 主本文全節を通読 |
| [38] | arXiv:2404.15452v2, 2024-07-23。 | 主本文全節を通読 |
| [39] | arXiv:2411.08880v1, 2024-11-13。引用のPhys. Rev. Research出版版の全読とは区別。 | 主本文全節を通読 |
| [40] | arXiv:2305.03702v1, 2023-05-05。引用の2024年出版版との変更は未検査。 | 主本文全節を通読 |
| [41] | arXiv:2210.11507v2, 2023-03-20。 | 主本文全節を通読 |
| [42] | arXiv:2006.00399v2, 2020-10-08。 | 主本文全節を通読 |

## 個別記録

文字位置は保存されたUTF-8本文をUnicode文字列として数える0始まりの半開区間 `[開始, 終了)`。ソースSHA-256はその保存ファイル全体のbytesに対する値であり、読解した範囲の長さとは別に固定している。

### [29] C. Xu and L. Balents, Topological Superconductivity in Twisted Multilayer Graphene, Phys. Rev. Lett. **121** , 087001 (2018).

一次ソース：[実読版を開く](https://arxiv.org/html/1803.08057v2)。

**版：** arXiv:1803.08057v2, 2018-04-02。HTML再生成日2026-08-24を版更新とは扱わない。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、節番号のない本文全体（単一バンドSU(4) Hubbard模型、超交換・Fierz分解、Hund結合、A/B候補、時間反転・半量子渦・端状態、結論とv2追加議論）、謝辞まで。

**結果と前提：** 単一三角格子バンド、谷間散乱の抑制、反強磁性的超交換と正のHund結合を仮定して、谷一重項・スピン三重項d波の二候補を得る。Aは時間反転を破るchiral状態、Bは時間反転を保つhelical状態で、平均場では縮退し優劣を決めていない。2DかつSU(2)対称なら有限温度で通常の秩序は崩れ、charge-4eの代数秩序とhc/(4e)半渦を論じる。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 単一バンド模型の有効範囲が重要で、v2末尾は二本の絡み合ったバンドがある場合に単純三角格子記述が不十分と明記。A/Bの選択、無秩序・磁場などは今後の課題。図説明は読んだが原画像・独立再導出は未実施。参考文献一覧は今回の範囲外。

**再照合用：** `graphene_refs/ref_29.md`、全体 32,932 文字、読解区間 `[0, 25677)`。

SHA-256: `9258cc52266f427a74c883dde63c7b46f0cf5caff21a96f0d2e2268a95b749ca`

### [30] X.-F. Zhou, Y.-W. Liu, C.-Y. Hao, C. Yan, Q. Zheng, Y.-N. Ren, Y.-X. Zhao, K. Watanabe, T. Taniguchi, and L. He, Coexistence of reconstructed and unreconstructed structures in the structural transition regime of twisted bilayer graphene, Phys Rev B **107** , 125410 (2023).

一次ソース：[実読版を開く](https://arxiv.org/pdf/2209.14730)。

**版：** 取得PDFの arXiv:2209.14730。抽出本文にはversion suffixがなく、原キャッシュSHA256に固定。

**状態：** `main_text_complete`。

**読んだ範囲：** 取得した26,629文字全部：Abstract、節番号のない主本文、結論、謝辞、参考文献43件、Fig.1–4のキャプション。独立Methods節はなく、製作・解析の詳細Methodsは別Supplemental Materialへ参照。

**結果と前提：** 0.10–3.59度のTBGをhBN/WSe2上で調べ、60試料以上のDW/AA高さ比とVHSの空間分布から、約0.90度未満の再構成、約1.80度超の剛体、その間の二構造共存を報告する。AA領域はVHS空間分布のGaussian幅から推定し、stackingエネルギー比較は原子数固定・既報の領域面積・層間隔3.2–3.6Åに基づく。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 再構成と剛体の共存をエネルギーの釣合いで解釈するが、全弾性エネルギーの独立計算や普遍的角度境界の証明ではない。Supplemental Materialの製作Methods・追加データ・解析詳細は本キャッシュになく今回未読。原図画像・生データの再解析は未実施。

**再照合用：** `graphene_refs/ref_30.md`、全体 26,629 文字、読解区間 `[0, 26629)`。

SHA-256: `f212425abe63f9d98d44de716c95f875f4f45b4ab22423b0ce130e1aaf73b6d0`

### [31] C.-Y. Hao, Z. Zhan, P. A. Pantaleón, J.-Q. He, Y.-X. Zhao, K. Watanabe, T. Taniguchi, F. Guinea, and L. He, Robust flat bands in twisted trilayer graphene moiré quasicrystals, Nat. Commun. **15** , 8437 (2024).

一次ソース：[実読版を開く](https://www.nature.com/articles/s41467-024-52784-7)。

**版：** Nature Communications 15,8437, published 2024-09-30。出版社本文HTML。

**状態：** `main_prose_complete_with_embedded_source_gaps`。

**読んだ範囲：** Abstract、Introduction、Resultsの全4小節、Discussion、Methods全4小節（製作、STM、TB/LDOS、continuum/Hartree）、Data/Code availabilityまでを通読。

**結果と前提：** 五つのTTG角度対で、局所C3対称性、stacking、flat-bandの層別局在、moiré間結合をSTM/STSとTB/continuum/Hartree計算で比較する。78K・5mV変調のSTS幅には熱・歪み・再構成・相互作用の寄与があり、理論帯域より広い。大角度側は二つのTBGの弱い重ね合わせ、小角度の一部は三層へ広がる強い混成となり、Hartree計算は孤立した狭いbandを持つsample3/4に適用する。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 本文全節とMethodsは取得済みで通読したが、Table1は外部リンクだけで表セルが抽出されていない。全原図画像と別Supplementary Notes/Figuresは今回未読。無限個のmagic-angle pairは理論の主張を五試料で支持するもので、無限個を実測したわけではない。

**再照合用：** `graphene_refs/ref_31.md`、全体 106,522 文字、読解区間 `[0, 49330)`。

SHA-256: `05afd4dfe8b4f7350267c15985b9dbf0612aab9e6567a9fe2a616acccc0b8a99`

### [32] O. Aguilar-Spíndola, A. Rubio-Ponce, F. López-Urías, and F. Sánchez-Ochoa, Electronic and optical properties in helical trilayer graphene under compression, Phys Chem Chem Phys **27** , 11541 (2025).

一次ソース：[実読版を開く](https://pubs.rsc.org/en/content/articlehtml/2025/cp/d5cp00337g)。

**版：** Phys. Chem. Chem. Phys.27,11541–11550, first published 2025-05-15; DOI10.1039/D5CP00337G。

**状態：** `main_prose_complete_with_embedded_source_gaps`。

**読んだ範囲：** Abstract、§1 Introduction、§2 Computational methodology、§3.1–3.3、§4 Conclusions、著者貢献・Data availability・利益相反・謝辞冒頭まで。

**結果と前提：** 21.78度・294原子の三つのcommensurate HTG配置をPBE/SIESTAで比較し、層間距離を固定して面内座標を緩和する。高圧縮で電子正孔非対称・低エネルギーDOSと光学応答が増強するが、光学計算は単粒子・垂直interband遷移でDrude成分を除外する。圧力換算は二層の既報パラメーターによる概算で、低角度magic HTGの直接計算ではない。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 本文の文章と全節は読了。式(3)–(6),(8),(9)および一部の式中項が外部画像で、抽出本文には内容がないため数式全体の読了とはしない。別ESI・原図画像・DFT再計算は未実施。磁性相転移は高DOSからの可能性の指摘で実証ではない。

**再照合用：** `graphene_refs/ref_32.md`、全体 60,046 文字、読解区間 `[0, 37700)`。

SHA-256: `54a7c9b2a98cf943a4c61816bd5df985ec5276e65abef2e9842c967aaebbbc37`

### [33] S. Niu, J. Alicea, D. N. Sheng, and Y. Peng, Quantum Anomalous Hall Effects and Emergent SU(2) Hall Ferromagnets at Fractional Filling of Helical Trilayer Graphene, Phys Rev Lett **135** , 146505 (2025).

一次ソース：[実読版を開く](https://arxiv.org/html/2505.24146v2)。

**版：** arXiv:2505.24146v2, 2025-07-15。HTML再生成日2026-08-24を版更新とは扱わない。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、Introduction、モデル/投影Hamiltonian、QHC、FCI、QHF、global phase diagram、Summary、謝辞の全主本文。Figures1–4の抽出キャプションも読了。

**結果と前提：** hBNを模した層別sublattice potential、固定twist1.44度・誘電率4で|C|=2バンドを分離し、flavor偏極を仮定した有限サイズEDを行う。ν=2/3は√3×√3の電荷秩序Hall結晶、1/3はHalperin(112)型FCI、1/2は準縮退する擬スピン強磁性を予測する。三flavorが満たされた3+νではHartreeによる帯域縮小が相を安定化し、SU(2)量子数は厳密でなく数%の誤差を伴う近似対称性として示される。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 有限サイズ・単一バンド投影・flavor偏極・基板potentialに依存する予測で、観測された実験相の確定同定ではない。補足I–Vにあるcluster詳細・PES・擬スピン構成・pair correlationの全検査は今回未読。全図画像、ED再実行、熱力学極限の独立検証は未実施。

**再照合用：** `graphene_refs/ref_33.md`、全体 69,120 文字、読解区間 `[0, 30431)`。

SHA-256: `500a6d5a15f701a6f3776078fcebefc35f4c58a927b3da9872db7846ac17fe30`

### [34] J. C. Hoke, Y. Li, Y. Hu, J. May-Mann, K. Watanabe, T. Taniguchi, T. Devakul, and B. E. Feldman, Imaging supermoiré relaxation in helical trilayer graphene, Nat. Mater. (2026). https://doi.org/10.1038/s41563-025-02423-3

一次ソース：[実読版を開く](https://arxiv.org/html/2410.16269v2)。

**版：** arXiv:2410.16269v2, 2026-01-24。引用先のNature Materials出版版と区別し、この取得版に固定。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、Introduction、電子構造と格子緩和、実空間のsupermoiré観測、domain wallの伝導、磁場応答、Conclusion、謝辞・著者貢献・Data availability、Methods全3小節（試料製作、SET測定、twist angle決定）。抽出された主図キャプションも通読。

**結果と前提：** 約1.45度のHTGを走査SETで測定し、ν=±4の単一対の非圧縮ピークと空間像から、大きなmoiré周期domainへの緩和を支持する。thermal cycling後にsupermoiréの面積・形状が変わり、moireの有効twist角は保たれるため、微小な層間strainへの高感度と整合する。ACとDCの応答差からdomain wallの相対的な高伝導を示すが、著者自身が測定は相対伝導度を調べるもので境界のtopologyを直接判定しないと明記する。MethodsではSETの有限径・高さ、測定温度と周波数、chemical potential gapのfit、Landau levelからの密度校正を説明し、推定角は緩和後の有効moiré角である。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 単一非圧縮ピークは緩和の証拠だが、緩和前の二つのtwist角を個別に決める測定ではない。非magic角試料で中間充填の相関gapは観測されず、有限磁場の多くの構造は単粒子理論でも説明される。境界のbackscattering保護や絶対伝導度は未実証。Supplementary I–VI、Extended Dataの全図・生データ、原画像の独立検査は今回未読・未実施。

**再照合用：** `graphene_refs/ref_34.md`、全体 170,173 文字、読解区間 `[0, 37060)`。

SHA-256: `65261876a6ab5e955e567fe18636c605dfc52e0e6c193852a311e68faf444e3d`

### [35] L.-Q. Xia et al., Topological bands and correlated states in helical trilayer graphene, Nat. Phys. **21** , 239 (2025).

一次ソース：[実読版を開く](https://arxiv.org/html/2310.12204v1)。

**版：** arXiv:2310.12204v1, 2023-10-18。実際の題名は Helical trilayer graphene: a moiré platform for strongly-interacting topological bands。引用題名 Topological bands and correlated states in helical trilayer graphene（Nat. Phys. 2025）とは異なる版で、出版版本文を全読したとは扱わない。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、IntroductionからOutlookまでの主本文全節（HTG、相関状態、異常Hall効果、電場駆動遷移、Chern domain、length scale）、Methods .1–.13全小節、謝辞・著者貢献・Data availabilityまで。主図キャプションと本文中に抽出された数式も通読。

**結果と前提：** 約1.8度の複数HTG試料で、電子側の整数・分数充填に抵抗異常と非量子化の異常Hall効果を観測し、緩和した局所domainのvalley Chern bandと対比する。ν=2/3の分数充填AHEはFCIの可能性を示す一方、topological charge density waveも候補として残す。電場によるgapの閉鎖・再開はtopological transitionを示唆し、Chern mosaicの履歴はdomainごとの磁化を用いて説明するが、著者は説明の未完性を認める。Methodsには対称化・密度校正・Curie推定・二中心bandに投影したHF・磁化模型・4D configuration-space弾性緩和が含まれ、HFの秩序/gap過大評価とparticle-hole非対称の未説明部分を明記する。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** AHEは量子化されておらず、ν=2/3のFCI確定やdomain-wall networkの直接画像化とは区別する。Curie解析はHall抵抗を磁化proxyに用い、磁化反転の一部計算は剛体band shiftの模型である。Methods全13小節は読了したが、参照されるExtended Data Fig.1–12とTable1–2の全内容、別補足、原図画像の独立検査は今回未読。v1から出版版への変更は今回調査していない。

**再照合用：** `graphene_refs/ref_35.md`、全体 92,150 文字、読解区間 `[0, 64879)`。

SHA-256: `c1fa8e4e06e3e43179a6ac3e7d82265a8276e054836e1260695d83872dad92b9`

### [36] T. Devakul, P. J. Ledwith, L.-Q. Xia, A. Uri, S. C. de la Barrera, P. Jarillo-Herrero, and L. Fu, Magic-angle helical trilayer graphene, Sci. Adv. **9** , eadi6063 (2023).

一次ソース：[実読版を開く](https://arxiv.org/html/2305.03031v1)。

**版：** arXiv:2305.03031v1, 2023-05-04。Sci. Advances出版版のMethods・補足の読了へ拡張しない。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、導入部、§I Reconstruction、§II Electronic structure、§III Chiral limit、§IV Correlated states、§V Discussion、謝辞まで。本文内のTable1–2、主図キャプション、抽出数式を含む。このv1に独立Methods/Appendix節はない。

**結果と前提：** 格子緩和によりHTGが局所的にC2zを破るh/反転h domainへ分かれ、相反するChern数を持つ孤立した狭帯域が生じると予測する。局所周期BM模型のchiral limitでは特定magic angleで厳密なflat bandとholomorphicな理想量子幾何を構成し、現実的corrugationでは厳密flatではない近似理想bandを得る。Jastrow型状態が厳密なground stateとなる主張はflat band、短距離に投影した相互作用、空真空基準のnormal orderingなどの条件付きであり、現実的長距離Coulomb下のFCI安定性は別の多体検証を要する。微小strainで巨大な単一domainを作る案は可能性の提案で、実験的達成ではない。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 局所周期近似とcontinuum模型パラメーターに依存し、全原子緩和の全効果を定量的に含む模型ではない。整数強磁性の厳密固有状態と実際のground stateは同義ではなく、分散・Hartree項・競合秩序に留保がある。今回読んだv1には独立Methods/Appendix節がなく、出版版やPMCの補足を全読したとは扱わない。原図画像・独立解析/数値再実行は未実施。

**再照合用：** `graphene_refs/ref_36.md`、全体 86,609 文字、読解区間 `[0, 47740)`。

SHA-256: `e1bd0b05de67d4ee4e9fb169cfddcc3d261029cc7cdf3dcf67108c890b55bb59`

### [37] Y. H. Kwan, P. J. Ledwith, C. F. B. Lo, and T. Devakul, Strong-coupling topological states and phase transitions in helical trilayer graphene, Phys Rev B **109** , 125141 (2024).

一次ソース：[実読版を開く](https://arxiv.org/html/2308.09706v1)。

**版：** arXiv:2308.09706v1, 2023-08-18。引用のPhys. Rev. B出版版本文との差分は今回未検査。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、§I–VIの全主本文、§II.1–II.3 Methods、§III.1–III.2、Tables1–2、Figures1–15の抽出キャプション、謝辞まで。

**結果と前提：** 緩和後の一つの周期domainで、中心bandへの投影、gate-screened Coulomb、平均密度subtractionを用いた強結合解析とHFにより整数充填相を分類する。HFはspin-collinearな状態と限られた倍周期・三倍周期を調べ、近似particle-hole対称性や谷間Hund項の省略を含む。displacement fieldでband inversionとChern数変化、さらにKekulé spiralや電荷秩序が現れると予測する。HFのflavor縮退を説明する「一方のspinだけの時間反転」は二次のエネルギー汎関数の対称性であり、全Hilbert空間のunitary/antiunitary対称操作ではないと本文が明確に区別する。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 相図は制限したHF/強結合近似内の結果で、微小な相間エネルギー差は基板・省略相互作用・量子揺らぎで変わり得る。部分充填のFCIをここで確定計算したわけではない。Appendix Aの強結合補正、Bのspin basis、CのHF flavor symmetry全体はこの補完では未読。原図画像・独立HF再実行・熱力学極限検証は未実施。

**再照合用：** `graphene_refs/ref_37.md`、全体 166,274 文字、読解区間 `[0, 86673)`。

SHA-256: `e97960327282a917ad81d8ff78af74eb40b8b1184896e16d5065b853c244594e`

### [38] A. Datta, D. Guerci, M. O. Goerbig, and C. Mora, Helical trilayer graphene in magnetic field: Chern mosaic and higher Chern number ideal flat bands, Phys Rev B **110** , 075417 (2024).

一次ソース：[実読版を開く](https://arxiv.org/html/2404.15452v2)。

**版：** arXiv:2404.15452v2, 2024-07-23。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、導入部、§I Model、§II.1–II.2 Numerical study、§III.1–III.3 Analytical construction、§IV Second magic angle、§V Away from chiral limit、§VI Conclusion、謝辞まで。本文Tables1–2、主図キャプション、抽出されたtheta-functionとzero-modeの式を含む。

**結果と前提：** 局所ABA/BAB continuum模型で、Zeeman効果を無視しchiral limitを取ると、第一magic angleのzero-energy flat bandが有限磁場でも保持される。chosen valley/stackingで正負の磁束に非対称な一量子・半量子磁束のtopological transitionを示し、theta-functionで構成するzero modeとB=0では特異なhidden stateの正則化で説明する。第二magic angleでは四flat bandとDirac coneを扱い、対応する解析解は今後の課題とする。有限corrugationではbandは分散し、magic angleとtransitionの一致も一般に失われる。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 第一chiral magic angleの代表磁場は約34/68Tで、有限corrugation・異なるtwist角の例も14/40T程度などパラメーター依存である。低磁場実験へ値を直接移す根拠にはしない。Appendices A–F（数値法、対称性、index/zero-mode補足、非chiral spectra等）はこの補完では未読。全式の独立証明、原図画像、数値再現は未実施。

**再照合用：** `graphene_refs/ref_38.md`、全体 97,553 文字、読解区間 `[0, 55551)`。

SHA-256: `8473b958b050d957f1385edf8dc1b172a869cf1c0e8f2c1879e873c8b2a36176`

### [39] Y. H. Kwan, T. Tan, and T. Devakul, Fractional Chern mosaic in supermoiré graphene, Phys Rev Res **7** , L032070 (2025).

一次ソース：[実読版を開く](https://arxiv.org/html/2411.08880v1)。

**版：** arXiv:2411.08880v1, 2024-11-13。引用のPhys. Rev. Research出版版の全読とは区別。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、§I Introduction、Non-interacting model、Interactions、Hartree–Fock phase diagram、Sublattice transitions、Exact diagonalization、Fractional Chern mosaics、Discussion、謝辞まで。Figures1–3の抽出キャプション、式(1)–(6)、脚注も通読。

**結果と前提：** h-HTGの局所周期模型に有限範囲hopping由来のmomentum-dependent tunnelingを加えると、粒子正孔非対称とChern-sublattice間の平均エネルギー差が生まれ、ν=3から約3.5まで狭い|C|=1 conduction bandが保たれる。七HF bandを満たして残り一bandへ投影したN=30のEDでは、ν=3+1/3に三重準縮退とflux threading下のgapが得られ、FCIを支持する。二band EDは最大spin-valley偏極sector内では厳密だが、全八bandのground stateを無制約で調べるものではなく、FCIの直接徴候は有限サイズのため十分頑健ではない。局所FCIが成立すると仮定した先に、domainごとの谷偏極次第でHall伝導度やanyon統計が空間変調するfractional Chern mosaicを予測する。

**今回の回路最適化への適用：** 分数電荷とanyon統計の理論予測はあるが、符号化qubit、braidingによる論理ゲート、magic-state準備またはcoherent XORローダーの回路は構成しない。fractionalizationから今回のToffoli数改善を導くことはできない。

**未確認範囲・制約：** Coulomb screening、中心band投影、有限cluster、flavor偏極という条件を伴う理論予測であり、mosaicの実験観測ではない。domain間偏極配置の選択はdomain-wall energeticsに依存し未確定。Appendix A–DのMDT導出、追加HF/ED、FCI競合・finite-size検査全体はこの補完では未読。原図画像・ED再実行・多体熱力学極限検証は未実施。

**再照合用：** `graphene_refs/ref_39.md`、全体 85,037 文字、読解区間 `[0, 28854)`。

SHA-256: `cf2a55e7b48b5bbf13878f45ed8f7878e55cd95e4d0a81b2fc2b0497217048a8`

### [40] D. Guerci, Y. Mao, and C. Mora, Chern mosaic and ideal flat bands in equal-twist trilayer graphene, Phys Rev Res **6** , L022025 (2024).

一次ソース：[実読版を開く](https://arxiv.org/html/2305.03702v1)。

**版：** arXiv:2305.03702v1, 2023-05-05。引用の2024年出版版との変更は未検査。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、Introduction、Chern mosaic on the supermoiré scale、ABA stacking、AAA stacking/domain-wall lines、Stability away from chiral limit、Conclusions、謝辞とNote addedまで。Figures1–5の抽出キャプション、式(1)–(16)を含む主本文の全節。

**結果と前提：** 等twistのstaircase TTGでmoireとsupermoiréの長さを分離し、ゆっくり変わる位相をparametricに扱う局所HamiltonianからABA/BAB周辺の総Chern数±1とAAAを結ぶgaplessな境界を得る。chiral limitの約1.69度では、sublatticeに分けたChern +2と−1のflat bandをtheta-functionによって解析構成し、holomorphicな理想量子幾何を示す。AAAの約0.75度では四重flat sectorがDirac coneと接続し、Γ点ではBerry curvatureの定義に例外がある。有限corrugationではbandが分散しても総Chern数とmosaicが保持される例をWilson loopで確認する。

**今回の回路最適化への適用：** color-entangled bandやholomorphicな波動関数は電子バンドの構成であり、量子回路のmagic state、CCZ/Toffoliのphase-polynomial分解とは別の対象である。今回のローダー合成・HMR補正・qubit数削減に適用できるゲート列は提示しない。

**未確認範囲・制約：** 主に非相互作用・局所断熱模型の結論で、FCIの多体ground stateの確定ではない。等しくないtwistへの拡張は本文ではconjectureとして置く。付録/補足A–Gはこの補完では未読。抽出式にはsubscriptの重複や未展開macroがあり、原PDFによる全式の照合・原図画像の独立検査は未実施。

**再照合用：** `graphene_refs/ref_40.md`、全体 78,337 文字、読解区間 `[0, 26974)`。

SHA-256: `abe2e317bb61202fee321799b050c39fd82197f977d756b3dd61fc09b7343fab`

### [41] Y. Mao, D. Guerci, and C. Mora, Supermoiré low-energy effective theory of twisted trilayer graphene, Phys Rev B **107** , 125423 (2023).

一次ソース：[実読版を開く](https://arxiv.org/html/2210.11507v2)。

**版：** arXiv:2210.11507v2, 2023-03-20。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、§I–VII全主本文、§IV.1–IV.3を含む有効模型の導出・gauge symmetry、等角と1/2角度比の数値結果、全主図キャプション、謝辞まで。

**結果と前提：** moireとsupermoiréの空間尺度が十分離れる場合に、局所固有状態へ射影した長波長有効Hamiltonianを導く。位置依存のDirac速度だけでなくnon-Abelian connectionを残すことでgauge covarianceとcoherentな長距離状態を表し、局所DOSの単純加算では失われるpseudo-minibandを得る。C2zTと孤立Dirac coneの保護により等角のbandは接続し、角度比1/2では二coneのsectorにgapが生じ得る。小角度で速度成分がゼロになるとmomentum cutoffへの収束が失われ、短距離正則化が必要になることを明記する。

**今回の回路最適化への適用：** non-Abelian connectionは連続空間の有効Hamiltonianでgauge covarianceを保つ項であり、non-Cliffordゲート合成ではない。任意の基底変更を費用ゼロの回路操作と読み替える根拠はなく、今回のToffoli/qubit削減を直接導かない。

**未確認範囲・制約：** 一般の任意twist対を無条件に扱う模型ではなく、近い有理数比と尺度分離を要する。図14の数値地図は|δq|/|q̄|≤0.2を課し、等角は2度より上、1/2または2比は小さい方の角≥1.8度に制限する。約2度未満などのDOS増強について著者の定性的期待はあるが、その領域のcutoff-independentな定量予測ではない。Appendices A–F、原図画像、独立数値再現はこの補完では未読・未実施。

**再照合用：** `graphene_refs/ref_41.md`、全体 101,934 文字、読解区間 `[0, 53218)`。

SHA-256: `492510b5627b46968018c7ee3d4d31ddbf09a980e65ea912276ecfa205b93a27`

### [42] Z. Zhu, S. Carr, D. Massatt, M. Luskin, and E. Kaxiras, Twisted Trilayer Graphene: A Precisely Tunable Platform for Correlated Electrons, Phys Rev Lett **125** , 116404 (2020).

一次ソース：[実読版を開く](https://arxiv.org/html/2006.00399v2)。

**版：** arXiv:2006.00399v2, 2020-10-08。

**状態：** `main_text_complete`。

**読んだ範囲：** Abstract、Introduction、Momentum-space Hamiltonian、Density of states、Evolution of VHS、Moiré of moiré、まとめ、謝辞まで。Figures1–4の抽出キャプション、式(1)–(7)、脚注を含む主本文全節。

**結果と前提：** 二つの独立twist角を持つ一般の非整合TTGをmomentum-spaceで記述し、有限energy cutoffでも二段散乱で低energyに戻る状態が無限にあり、通常のmoire Brillouin zoneでは閉じないことを示す。実計算では各単層reciprocal vectorにも追加cutoffを置き、約5600momentumとGaussian smearingでDOS/VHSを評価する。異なるtwist角では第三層の非整合摂動によりTBG型magic条件が曲線へ広がる一方、等角のVHS hybridizationは別機構で、perturbativeな速度消失条件と数値結果が一致しない。強相関や超伝導を直接計算したのではなく、DOS/VHSを相関効果のproxyとして用いる。

**今回の回路最適化への適用：** グラフェンの電子構造・超伝導・相関状態を扱う研究であり、coherent XORローダー、CCZ/Toffoli分解、HMR補正または物理qubit削減の実装は提示しない。今回の回路最適化への直接適用は導けない。

**未確認範囲・制約：** 追加cutoffが低energy状態も落とすため一般の収束保証はないと本文が明記し、調べたDOS最大・VHS位置の安定性と厳密収束を区別する。first-shell摂動のmagic条件はω0=ω1を仮定し、等角付近には適用できない。Supplemental Material I–IV、原図画像、公開MATLABの再実行は今回未読・未実施。原文数式の単位・組版を独立に全検証したものではない。

**再照合用：** `graphene_refs/ref_42.md`、全体 81,517 文字、読解区間 `[0, 26302)`。

SHA-256: `834dc214733367b6a55e2fbdeec7ae1b9bbea73dcc0e42e520ef968ce7839310`

## 元台帳の保全

元台帳 `graphene_refs_29_56.json` のSHA-256：`230a6087bed895936ce61cf7492d37d1ec90e64a11b751a99afb42fab0a8f41f`。この補完による変更はない。
