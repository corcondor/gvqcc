# 主論文 v2 参考文献 [26]–[43] 読書台帳

A cached full text is not treated as read. Every entry states actual read scope. Full-text reading does not imply independent reproduction of every proof or numerical result.

状態の `full_text_read` は取得本文を全体として読んだことを表し、原論文の実験・全証明を独立再現した意味ではない。`partial_text_read`、`blocked_fulltext` は読了に含めない。

## [26] D. Gottesman and I. L. Chuang, Demonstrating the viability of universal quantum computation using teleportation and single-qubit operations, Nature 402 , 390 (1999).

**状態:** full_text_read

**実際に読んだ範囲:** 著者 arXiv quant-ph/9908010v1 全6頁。本文、回路図の説明、Appendix A（cat状態を用いる資源準備）、参考文献。

**内容:** ゲートをBell資源 (I⊗U)|Bell〉へ移し、Bell測定のPauli誤りを U R U† で補正する。Clifford階層の第3層では補正がCliffordになり、資源状態の準備を本体から分けられる。

**GVQCCへの適用:** 測定分岐ごとの補正を含めた証明の設計に有用。GVQCCには任意Bell/magic資源の無料供給はなく、資源準備・補助量子ビット・実際の許可演算まで算入しなければ採点改善にならない。

**限界・版の注意:** arXiv題名 Quantum Teleportation is a Universal Computational Primitive と掲載誌題名は異なる。Appendix Aのfault-tolerant準備を無料の処理としては扱わない。

**一次資料:** <https://arxiv.org/pdf/quant-ph/9908010>

## [27] D. Shepherd and M. J. Bremner, Temporally unstructured quantum computation, Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences 465 , 1413 (2009).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv:0809.0847v3全27頁。本文1–5、すべての定理/lemmaと証明、AppendixのTheorem1証明、参考文献。

**内容:** IQPをX積Hamiltonianの可換和で定義し、線形符号/二項matroidの重み列挙から方向バイアスを計算する。Zネットワーク（CNOT/X/対角回転）との変換、graph-state非適応測定への変換を与える。位相関数の方向差分を繰り返すと次数が下がることを利用する古典samplerも提案。

**GVQCCへの適用:** CNOTでの可逆な基底変更は、パリティ位相表現や高位/低位アドレス分割の整理に役立つ。可換性で順序を変えられることと、各演算の個数を減らせることは別。Graph変換には|+〉準備・測定・補助線が必要で、現在のKMBへ無費用で移せない。

**限界・版の注意:** arXiv題名Instantaneous Quantum Computation、掲載題名Temporally unstructured quantum computation。hidden-code検証と古典手法の最適性は当時のconjectureであり、ここで現在も成立と主張しない。

**一次資料:** <https://arxiv.org/pdf/0809.0847>

## [28] M. J. Bremner, R. Jozsa, and D. J. Shepherd, Classical simulation of commuting quantum computations implies collapse of the polynomial hierarchy, Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences 467 , 459 (2011).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv:1005.1407v1全13頁。本文1–4、Theorems1–3と証明、Hadamard gadget、参考文献。

**内容:** post-IQP = post-BQP = PP。IQPの全出力確率を点ごとに1/c〜c、1≤c<√2で古典samplingできればPHが第3層へ崩壊する。postselectionで比を取ると誤差はc²になり、加法誤差では小さい分母が問題になる。O(log n)出力bitだけなら残りを一様に固定して小状態を直接計算し、exact weak samplingが可能。

**GVQCCへの適用:** 主論文の少数Pauli/少数出力と全分布の区別の一次根拠。Hadamardを1ancilla+CZ+postselectionへ移すのは複雑性理論の構成で、全測定結果で成功するoracleの合成ではない。

**限界・版の注意:** PH非崩壊は仮定。1/c≤比≤cの乗法誤差と|estimate−value|≤epsilon|value|の定義は数値範囲が違うので同じ定数として引用しない。

**一次資料:** <https://arxiv.org/pdf/1005.1407>

## [29] M. J. Bremner, A. Montanaro, and D. J. Shepherd, Average-case complexity versus approximate simulation of commuting quantum computations, Physical review letters 117 , 080501 (2016).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv:1504.07999v2全10頁。本文全体、Appendices A–F（Ising対応、三次gap対応、Hadamard gadget、相対誤差困難性、Stockmeyer、反集中）と全参考文献。

**内容:** ランダムな三次GF(2)多項式gap²または複素温度Ising分配関数の平均時相対近似が#P困難という仮定の下で、IQP分布をl1誤差1/192以内にsamplingできればPH崩壊。反集中は証明し、必要な平均時困難性は仮定として残す。Appendix Dはshiftと反復で相対近似からgapの厳密値を回収する。

**GVQCCへの適用:** 加法精度のPauli期待値計算を全分布samplingの容易性と混同しない根拠。三次位相関数の識別や厳密検証の数学的背景にはなるが、特定75語ローダーのToffoli下界・上界を与えるものではない。

**限界・版の注意:** 1/192は論文が定義したl1ノルム（標準TV距離の1/2係数を付けたものと同じ数値ではない）。平均時困難性を無条件定理としない。

**一次資料:** <https://arxiv.org/pdf/1504.07999>

## [30] D. Bluvstein, S. J. Evered, A. A. Geim, S. H. Li, H. Zhou, T. Manovitz, S. Ebadi, M. Cain, M. Kalinowski, D. Hangleiter, et al. , Logical quantum processor based on reconfigurable atom arrays, Nature 626 , 58 (2024).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv:2312.03982v1 のPDF全32頁。主本文1–8頁、全参考文献9–11頁、Methods12–22頁、謝辞・著者情報23頁、Extended Data Fig.1–9と全キャプション24–32頁を通読。論理CCZの符号・ゲート図であるFig.5（6頁）は原画像も確認。

**内容:** 中性原子の移動可能な符号ブロックと保存・ゲート・読出し領域を用い、transversal CNOTと相関復号を実験。[[8,3,2]]符号では8物理量子ビットに3論理量子ビットを保持し、8個のT/T†による論理CCZ、S/S†によるCZ、物理置換によるブロック内CNOTを実装。48論理量子ビット・48 CCZのIQP型回路、誤り検出によるXEB改善、2コピーBell測定による純度・Pauli期待値絶対値・magic推定を提示。Methodsはstate preparationの非fault-tolerantな箇所と、postselection・simulation costの仮定を明示する。

**GVQCCへの適用:** 符号内の位相式、共有CNOTや置換の扱い、相関復号は構造理解・検証に有用。しかしGVQCCは符号化後の論理ゲートと生存幅を直接数えるため、8物理Tによる論理CCZやエラー検出の採用だけではnative CCZ=1 Toffoli相当を安くしない。サンプリングとPauli推定の精度・postselectionは、任意入力に作用するcoherentなローダーの契約を置き換えない。[31]は本論文の回路に対する改善された古典シミュレーションなので、ここでの将来runtime予測を普遍的下界と解釈しない。

**限界・版の注意:** 取得したarXiv本文・Methods・追加図は全読。別ファイルのSupplementary Movieは未取得・未視聴。実験数値、全ゲート較正、誤りモデルを独立再現した意味ではない。

**一次資料:** <https://arxiv.org/pdf/2312.03982>

## [31] D. Maslov, S. Bravyi, F. Tripier, A. Maksymov, and J. Latone, Fast classical simulation of harvard/quera iqp circuits, arXiv preprint arXiv:2402.03211 (2024).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv:2402.03211v1全9頁。本文I–V、Lemmas1–2、Eq.(1)–(4)の導出、実装・性能・限界の議論、参考文献。

**内容:** 三次位相多項式の各項を覆う変数集合Sを固定すると残りは二次式。対象の3色構造では|S|=n/3なので2^{n/3}回のClifford振幅計算に分解できる。固定した赤変数に対して緑青の式はxG·ΓxB+δG·xG+δB·xB。行/列空間条件とGF(2) rank/線形方程式で各項を厳密計算。Gray順序でΓをXOR更新する。

**GVQCCへの適用:** 高位アドレスを固定して低位二次構造を整理する手法、および厳密検証の高速化の参考になる。古典的に2^{|S|}個のスライスを列挙できても、coherent loaderでその制御付き回路を安く実装できるとは限らない。既存のbranch差分と基底共有探索と重なる。

**限界・版の注意:** 48/96量子ビットの性能値は著者の報告で、こちらで再現していない。192量子ビットについては実測ではなく資源見積り。一般の三次多項式に同じn/3の被覆構造があるわけではない。

**一次資料:** <https://arxiv.org/pdf/2402.03211>

## [32] S. A. Fenner, L. J. Fortnow, and S. A. Kurtz, Gap-definable counting classes, Journal of Computer and System Sciences 48 , 116 (1994).

**状態:** full_text_read

**実際に読んだ範囲:** 著者公開版全33頁。通常のPDF文字抽出が崩れるため全頁をOCRし、その全テキスト（Sections1–10、Appendix A、参考文献）を読んだ。GapP定義と#P−#P等価性の原画像も確認。

**内容:** GapPを非決定性機械の受理経路数−拒否経路数として定義し、GapP=#P−#P=#P−FP=FP−#Pを証明。加減乗算、指数個の和、poly個の積などに閉じる。PP等のgapによる定義、SPPの最小性/lowness、gap-definableクラスの格子構造も扱う。

**GVQCCへの適用:** 量子干渉の符号付き和を#Pの非負計数と区別して扱うための複雑性理論の基礎。GapPの閉包性は数値の安価な計算法や小Toffoli回路の構成法ではないため、直接の採点改善策には数えない。

**限界・版の注意:** 1992年著者原稿にJCSS1994掲載情報が付く。OCRの一部数式には認識誤りが残るため、全式を厳密転写/独立検証したとはしない。根拠として使う定義・主要等価式は原画像で確認。

**一次資料:** <https://www.cse.sc.edu/~fenner/papers/gaps.pdf>

## [33] A. Ehrenfeucht and M. Karpinski, The computational complexity of (XOR, AND) counting problems (International Computer Science Inst., 1990).

**状態:** full_text_read

**実際に読んだ範囲:** Bonn著者報告8543-CS、全8頁の本文・定理証明・参考文献をweb全文とPDF抽出で確認。

**内容:** GF(2)上のXOR/AND多項式の解数計算。2次以下では変数変換で対積と線形項に正規化でき、3次では#P完全となる境界を与える。

**GVQCCへの適用:** 二次位相和を厳密に計算する根拠として有用。既存のGF(2)二次形式の整理と重なる。位相和の計算容易性から、75語の多出力ローダーの乗算回数やToffoli下界は導けない。

**限界・版の注意:** 古いPDFの数式抽出には崩れがある。記載定理と証明全体は読んだが、全式の独立再導出はしていない。

**一次資料:** <https://theory.cs.uni-bonn.de/ftp/reports/cs-reports/1990/8543-CS.pdf>

## [34] B. Fefferman, Lecture notes for the 2023 ias/pcmi graduate summer school (2013).

**状態:** full_text_read

**実際に読んだ範囲:** IAS/PCMI 2023一次配布スライド On the theory of near-term quantum advantage 全63枚。全文テキストを読み、抽出欠落の34–36枚目は再取得、14枚目の符号付き和の議論は図版も確認。 IAS公式PCMI 2023講義一覧がLecture 1を当該63頁PDF、Lecture 2–5を同内容の別名PDFへ結ぶことも一次ページで照合。

**内容:** 量子回路出力確率の#P困難性、Stockmeyer近似計数とPH崩壊、最悪時から平均時への多項式補間、XEB/QUATH/XQUATH、Pauli経路表現、depolarizing雑音下の高重み経路切捨てを扱う。

**GVQCCへの適用:** 加法誤差・相対誤差・全分布の距離・benchmark値が異なる要求であることを整理する一次講義資料。量子samplingを古典的に近似できることやnoise下の切捨ては、無雑音で全入力のoracle一致を要求するKMBのゲート削減根拠にはならない。

**限界・版の注意:** 主論文の参考文献中の「2023 ... (2013)」には年の不一致がある。IAS公式一覧に掲載されたPCMI 2023資料を読んだ。別添の4頁problem setは本文読了範囲に含めない。

**一次資料:** <https://www.ias.edu/sites/default/files/billfefferman-lectures-pcmi-out.pdf> / <https://www.ias.edu/pcmi/pcmi-2023-gss-lecture-notes-and-problem-sets> / <https://www.ias.edu/sites/default/files/billfefferman-lectures-pcmi-out_1.pdf>

## [35] P. Selinger, Quantum circuits of t-depth one, Physical Review A—Atomic, Molecular, and Optical Physics 87 , 042302 (2013).

**状態:** full_text_read

**実際に読んだ範囲:** 著者公開PDF全5頁。本文全体、ToffoliのT-depth 1構成、Theorem 4.1のほぼ古典ゲート集合に関する構成と証明、Theorem 5.1のHTHTHTに対する不可能性、参考文献。

**内容:** 7TのToffoliを4個のclean ancillaでT-depth 1にする。一般には計算基底のBooleanラベルを補助線へ計算し、T位相を並列適用してuncomputeする。任意Clifford+T回路が同様にT-depth 1になるという定理ではない。

**GVQCCへの適用:** 主論文Fig3と同じ7T/4ancillaのCCZを実KMBとして独立合成し、8入力すべて位相・ancilla一致を確認。Invsqrt式ではnative CCZ 1に対して7T/4=1.75。Chemistry/DQIの禁止Z_POWにも適合しない。

**限界・版の注意:** 主論文v1では[34]、v2/掲載版では[35]。T-depthとT-countとToffoli換算費用を混同しない。

**一次資料:** <https://www.mathstat.dal.ca/~selinger/papers/toffoli.pdf> / <https://arxiv.org/abs/1210.0974>

## [36] J. Dehaene and B. De Moor, Clifford group, stabilizer states, and linear and quadratic operations over gf (2), Physical Review A 68 , 042318 (2003).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv quant-ph/0304125v1 全9頁。本文I–VI、Theorems 1–6と証明、Appendix Eq.(4)の証明、全参考文献。

**内容:** PauliとCliffordをGF(2)のsymplectic行列＋二次位相で表現する。安定化子状態の振幅はアフィン部分空間に支持され、非零振幅の位相は二次式。CliffordをO(n²)個の1/2量子ビット演算へ構成する。

**GVQCCへの適用:** HMR位相追跡、線形回路の等価性、到達可能部分空間での位相を含む厳密検証に利用可能。Clifford数だけが減っても現在のToffoli費用は減らない。

**限界・版の注意:** magic論文[27]と重複。全本文を読了した共有キャッシュとして利用可。

**一次資料:** <https://arxiv.org/pdf/quant-ph/0304125>

## [37] E. Knill, Fault-tolerant postselected quantum computation: Schemes, arXiv preprint quant-ph/0402171 (2004).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv quant-ph/0402171v1全17頁。本文I–XI、回路の全図説明、注記・参考文献。7–8頁の抽出欠落も再読補完。

**内容:** 4qubit error-detecting codeで論理bitとspectator bitを符号化し、purification、Bell teleportation、transversal Clifford、postselectionを連結する。concatしても一定depthを維持する設計と、magic one-qubit状態の注入/蒸留を示す。

**GVQCCへの適用:** 既知のspectator状態を利用して検査を省略/追加する考え方は到達部分空間の仕様確認に関係する。一方、postselectionの成功確率と大量の並列資源を落とせないため、低depthだけをKMB費用改善と評価できない。

**限界・版の注意:** この論文自身が閾値・性能の定量的error analysisは未実施と明記する。成功確率が小さくなりうる理論設計であり、実装可能な低費用oracleを保証する論文ではない。

**一次資料:** <https://arxiv.org/pdf/quant-ph/0402171>

## [38] S. Bravyi and A. Kitaev, Universal quantum computation with ideal clifford gates and noisy ancillas, Physical Review A—Atomic, Molecular, and Optical Physics 71 , 022316 (2005).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv quant-ph/0403025v2 全15頁。本文I–VII、5→1と15→1蒸留の導出、Appendix A、全参考文献。

**内容:** 理想Clifford、Pauli測定、独立に供給される雑音混合状態ρからmagic状態を蒸留して普遍計算する。T-typeは5qubit code、H-typeは15qubit CSS codeでエラー検出後にpostselectしdecodeする。

**GVQCCへの適用:** 符号空間へ制限すると非Pauli測定がPauli測定に一致する仕組みは、到達部分空間の最適化を考える参考になる。ただし蒸留や注入が無料ではなく、既製magic ancillaを認めないKMB実装の直接費用改善にはならない。

**限界・版の注意:** 同論文のT-typeはBloch(1,1,1)/√3の状態で、現代のπ/8 T状態と命名が違う。現代のT状態は同論文H-typeのClifford同値類。magic論文[1]と重複。

**一次資料:** <https://arxiv.org/pdf/quant-ph/0403025>

## [39] H. J. Garcia-Ramirez, Hybrid Techniques for Simulating Quantum Circuits using the Heisenberg Representation. , Ph.D. thesis, University of Michigan (2014).

**状態:** main_results_reviewed

**実際に読んだ範囲:** Michigan公式公開PDFの完全抽出本文（432,782文字）を取得。表紙・著者・学位・目次を確認し、Abstract、§§1.7–1.8、§§2.3–2.5、§§3.2–3.3、Chapter IV–VIIIの全テキストを実読した。特に基底正規化・内積・直交化、frames/multiframes/COALESCE、p-blocking、Pauli展開によるstateless simulation、MPS/QMDD、全Conclusions/Open Challengesを確認。実読区間はref39_read_scope.jsonに記録。主結果レビューであり、全学位論文読了ではない。

**内容:** 純粋安定化子状態を同一のPauli生成元行列＋複数の符号ベクトル＋複素係数で共有するstabilizer frameを導入。各成分のglobal phaseは重ね合わせではrelative phaseとなるため追跡する。COFACTORでToffoliの制御条件を分岐し、COALESCEは係数比がi^dとなる候補対を別のframeへまとめる。行階段形維持で1 Clifford更新O(n²+n|F|)、状態重なりはH–CNOT–CZ–P–H基底正規化を用いO(n³)。直交化・非Clifford適用で状態数は指数的に増え得る。特定の等重ね合わせ入力のCuccaro adderでは多重frameが線形個数になり実測計算時間は多項式。QFTのp-blockingは計算基底入力の可分性に依存する。逆向きPauli観測量伝播は単一出力確率を計算し、一般の非CliffordではPauli項数が指数増大。Pauli MDDの圧縮を提案するが一般の演算・更新の高速化は今後の課題。

**GVQCCへの適用:** 直接役立つのは検証器の表現と位相管理。主論文の単一Pauli期待値計算を支える安定化子内積・位相計算の背景となる。候補ローダーやInvsqrtの分岐を共有して古典的検証を速める可能性はあるが、その共有データ構造は実行される量子oracleのゲートを消さない。合成されるH–CNOT–CZ–P–Hは安定化子状態の基底正規化であり、任意のBoolean loaderのToffoli削減ではない。任意の重ね合わせ入力とHMR補正を持つKMB回路への置換には別途、出力写像・相対位相・測定分布の証明と実回路の資源計数が必要。

**限界・版の注意:** 未読は基礎章§§1.1–1.6、§§2.1–2.2、§3.1の詳細証明、付録Aの1080状態一覧、参考文献全一覧。図はキャプション・抽出表中心で全画像の個別視認はしていない。全Toffoli回路や一般入力のQFTを多項式で計算する定理ではない。本文の「unbiased」等の簡略表現を十分条件として流用せず、§5.2の係数比i^dと生成元条件まで必要。§5.4の速度は計算基底入力の実測で、掲載fitにはn²項があり一般的な厳密linear-time保証と解釈しない。§3.2の一般近似・最適圧縮の主張を今回の費用下界に使わない。古いソフトウェア間の実測比較は現在の性能順位ではない。

**一次資料:** <https://deepblue.lib.umich.edu/bitstream/handle/2027.42/107198/hjgarcia_1.pdf> / <https://deepblue.lib.umich.edu/bitstream/2027.42/107198/1/hjgarcia_1.pdf>

## [40] S. X. Cui, D. Gottesman, and A. Krishna, Diagonal gates in the clifford hierarchy, Physical Review A 95 , 012329 (2017).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv:1608.06596v1 全9頁。本文I–VI、Theorems1–3、Lemmas1–4と証明、Corollaries、参考文献。

**内容:** 素数次元quditの対角Clifford階層を、p^m乗根の位相と基底ラベルの多項式で特徴付ける。単項の階層位置は(p−1)(m−1)+degreeで決まる。対角部分は群だが第3層以上の全体は一般に群ではない。

**GVQCCへの適用:** 小ブロックの位相多項式の次数と位相精度を分ける整理に有用。qubitのT, CS, CCZはいずれも第3層だが、同じ階層であることから同じ費用・等価なoracle実装とはならない。

**限界・版の注意:** 分類定理でありゲート数最小化アルゴリズムでもToffoli削減保証でもない。

**一次資料:** <https://arxiv.org/pdf/1608.06596>

## [41] N. Schuch and J. Siewert, Programmable networks for quantum algorithms, Physical review letters 91 , 027902 (2003).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv quant-ph/0303063全4頁。本文全体、Eq.(4)周辺の途中抽出欠落を再読して補完、全参考文献。

**内容:** 任意の対角ゲートをWalsh-Hadamard変換した角度とパリティ演算のネットワークで実装。最近接CNSゲートによるGray順序のネットワークを与える。

**GVQCCへの適用:** 小さな局所位相関数をパリティ回転へ変換する候補比較に使える。一般のnビット関数では2^n−1個の回転になり、Toffoliを一般的に低減する方法ではない。Invsqrtの既存Walsh探索と範囲が重なる。

**限界・版の注意:** 回転数、角度精度、実際のZ_POW費用をすべて算入する必要がある。

**一次資料:** <https://arxiv.org/pdf/quant-ph/0303063>

## [42] C. Gidney and N. C. Jones, A cccz gate performed with 6 t gates, arXiv preprint arXiv:2106.11513 (2021).

**状態:** full_text_read

**実際に読んだ範囲:** arXiv:2106.11513全1頁。全文と回路図をPDF画像で確認、参考文献も確認。

**内容:** i^(ab XOR cd)=i^ab i^cd (−1)^abcdという位相関係を用い、相対位相ANDのTを相殺してCCCZを6T＋測定補正で実装する。

**GVQCCへの適用:** 仮に全Cliffordを利用できれば6Tは1.5 Toffoli換算。だが図はHで補助線を準備しXの平方根逆を経て測定する。実際のKMBではH/X_SQRTが未対応で、掲載図をそのまま有効候補にできない。

**限界・版の注意:** Hを含む図を既製magic状態や無料初期化で置換して費用を過少計上しない。全8/16入力などの真理値表一致だけでなくcoherent phaseと測定補正も必要。

**一次資料:** <https://arxiv.org/pdf/2106.11513>

## [43] How can we implement controlled-t gate using cnot and h, s and t gates?, quantumcomputing.stackexchange.com/questions/13132 (2020), [Accessed: Sep 16th, 2024].

**状態:** partial_text_read

**実際に読んだ範囲:** 一次Q&Aの質問および3回答の本文をすべて読んだ。図の4ファイルは直接CDN取得403、一部web表示が取得可能だが全図の視認は未完了。API JSONを保存。

**内容:** Craig Gidney回答はclean ancillaへANDを計算してTを作用しANDを測定消去するCT構成。別回答は√Tを用いる制御位相分解で、元の指定ゲート集合から外れる。

**GVQCCへの適用:** 計算AND＋T＋HMR/CZ補正ならInvsqrtで1+1/4の局所費用として評価できる。これは一般のCT合成の一例で、全回路の幅や後続依存を別に評価する必要がある。

**限界・版の注意:** Q&A本文は一次の提案そのもの。著者の主張を査読定理扱いしない。√Tがある分解が示されても、補助線を使う別分解が不可能とはいえない。

**一次資料:** <https://api.stackexchange.com/2.3/questions/13132/answers?site=quantumcomputing&filter=withbody> / <https://api.stackexchange.com/2.3/questions/13132?site=quantumcomputing&filter=withbody> / <https://quantumcomputing.stackexchange.com/questions/13132/how-can-we-implement-controlled-t-gate-using-cnot-and-h-s-and-t-gates>

