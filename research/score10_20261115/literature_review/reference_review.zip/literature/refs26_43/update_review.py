"""Maintain an explicit reading ledger; download manifests do not imply reading."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
LEDGER = HERE / "reading_ledger.json"

def update(number, status, scope, mechanisms, applicability, caveats="", urls=None):
    data = json.loads(LEDGER.read_text()) if LEDGER.exists() else {
        "bibliography": "Classical Simulability of Quantum Circuits with Shallow Magic Depth, arXiv:2409.13809v2",
        "assigned_references": list(range(26, 44)),
        "scope_rule": "A cached full text is not treated as read. Every entry states actual read scope. Full-text reading does not imply independent reproduction of every proof or numerical result.",
        "references": [],
    }
    bib = json.loads((ROOT / "main_references.json").read_text())
    cite = next(x for x in bib["references"] if x["number"] == number)
    manifests = []
    for fn in ["download_manifest.json", "download_manifest_supplement.json"]:
        manifests.extend(json.loads((HERE / fn).read_text()))
    sources = [x["url"] for x in manifests if x["number"] == number]
    if urls:
        sources.extend(urls)
    files = []
    for p in sorted(HERE.glob(f"ref{number}*")):
        if p.is_file():
            files.append({"path": str(p), "bytes": p.stat().st_size,
                          "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
    if number == 35:
        for p in [ROOT / "selinger_tdepth_one.pdf", ROOT / "selinger_tdepth_one.txt"]:
            if p.exists():
                files.append({"path": str(p), "bytes": p.stat().st_size,
                              "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
    entry = {"number": number, "v1_number": cite.get("v1_number"),
             "citation": cite["citation"], "status": status,
             "read_scope_ja": scope, "mechanisms_ja": mechanisms,
             "gvqcc_applicability_ja": applicability, "caveats_ja": caveats,
             "primary_urls": list(dict.fromkeys(sources)), "cached_files": files}
    data["references"] = sorted([x for x in data["references"] if x["number"] != number] + [entry], key=lambda x: x["number"])
    LEDGER.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")
    render(data)

def render(data):
    lines = ["# 主論文 v2 参考文献 [26]–[43] 読書台帳", "", data["scope_rule"], "",
             "状態の `full_text_read` は取得本文を全体として読んだことを表し、原論文の実験・全証明を独立再現した意味ではない。`partial_text_read`、`blocked_fulltext` は読了に含めない。", ""]
    for e in data["references"]:
        lines += [f"## [{e['number']}] {e['citation']}", "", f"**状態:** {e['status']}", "",
                  f"**実際に読んだ範囲:** {e['read_scope_ja']}", "",
                  f"**内容:** {e['mechanisms_ja']}", "",
                  f"**GVQCCへの適用:** {e['gvqcc_applicability_ja']}", ""]
        if e["caveats_ja"]:
            lines += [f"**限界・版の注意:** {e['caveats_ja']}", ""]
        lines += ["**一次資料:** " + " / ".join(f"<{u}>" for u in e["primary_urls"]), ""]
    (HERE / "reading_ledger_ja.md").write_text("\n".join(lines) + "\n")

if __name__ == "__main__":
    render(json.loads(LEDGER.read_text()))
