"""Manual reading ledger for magic-paper reference 31; never infer reading from retrieval."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'linked_sources/magic_refs/ref_31.md'
READ_RANGES = [[0, 513129]]
READ_SECTIONS = ['I Introduction (including summary and prior work)', 'II Anyon algebra: fusion, braiding, gauge transformations', 'III Topological/global symmetry and H3 obstruction invariant', 'IV Symmetry fractionalization, including projective and locality-preserving cases', 'V Extrinsic defects: construction and types', 'VI Defect fusion, G-crossed braiding, gauge transformations, invariants', 'VII G-crossed modularity, torus and higher-genus sectors', 'VIII Gauging: microscopic models and topological data', 'IX Classification, relabeling, PSG limitations, non-finite/non-unitary cases', 'X Explicit solution for non-permuting symmetry actions', 'XI Examples A–N, including all displayed extracted tables', 'Acknowledgments', 'Appendices A–D', 'References 1–174 and endnotes 175–192']
UNREAD_SECTIONS = []
NOTES = [
    dict(section='I', evidence='I.A.1–I.A.3; Eqs. (1)–(2)',
         result_ja='有限オンサイトunitary対称性のSETを、対称性作用、fractionalization、defectificationのデータで分類する。欠陥は元の模型の自由な有限エネルギー粒子ではなく、Hamiltonianの外的変更で導入される。Gaugingはこれを脱閉じ込めし、異なるtopological phaseを作る。',
         conditions_ja='H3のfractionalization obstructionとH4のdefectification obstructionを区別する。後者の一般定理は引用数学文献に依拠し、本論文は非置換作用の場合の明示式も後で構成する。',
         applicability_ja='同じ計算を安く表す回路変形と、物理系・Hilbert空間を変えるgaugingは異なる。欠陥生成やbraidを今回の許可ゲートとして無料に追加する根拠にならない。'),
    dict(section='II', evidence='Eqs. (10)–(12), (33)–(34), (43)–(52)',
         result_ja='F-moveをfusion空間のunitary基底変更として定義し、pentagon/hexagon条件でfusion/braidingの整合性を課す。Γによる基底変更はFとRを連動して変換する。真空とのfusion/braidingを自明に保つためΓにも条件がある。',
         conditions_ja='描画されたanyonic charge lineは常に実粒子worldlineと同義ではない。Frobenius–Schur符号は一部gaugeで消せず、Tはmodular twist行列であってClifford+TのTゲート数ではない。',
         applicability_ja='基底変更を採用するなら入出力の符号・係数・変換費も合わせるという原則には有用。一般複素unitary ΓをCNOTのみのGF(2)変換と扱えず、fusion multiplicityやquantum dimensionはToffoli複雑度の下界ではない。'),
    dict(section='III', evidence='Eqs. (58)–(66), (81)–(112)',
         result_ja='Topological symmetryはanyon labelの置換だけではなく、fusion頂点のU_g作用を含む。自然同型の位相を除いた自己同値群Aut(C)へGを写し、β位相の結合から一意なH3 obstruction classを得る。',
         conditions_ja='U_gをgaugeで常にidentityへできるわけではないと明記する。指定したC,G,[ρ]で実現するobstruction classは一つであり、H3の全要素を独立な候補と数えることは誤り。Antiunitaryでは複素共役が必要。',
         applicability_ja='語の置換が同じでもHMR測定枝の相対位相が一致するとは限らないという監査上の対応がある。ただしこの分類から語表の新しい恒等式や実ゲート削減は出ていない。'),
    dict(section='IV', evidence='Eqs. (113)–(120), (133)–(167), (175)–(188), (206)–(235)',
         result_ja='局所演算とtopological作用に分けた対称性の積を比較し、局所projective位相ηとβの整合性からO=dwを導く。Obstructionが消える場合のfractionalization解はH2 torsorであり、各anyonに独立なprojective表現を割り当てる分類ではない。',
         conditions_ja='物理的局在分解はwell-separated quasiparticlesと指数減衰相関を仮定し、Eq.(133)はO(exp(-r/ξ))補正を省略する。空間対称性には追加制約があり、antiunitaryでは複素共役を含む。局所Kramers符号とtopological spinは一般には別。',
         applicability_ja='局所の位相を一つずつ消す操作の整合性を全体で確認する重要性が読み取れる。指数的小ささや同じuniversality classは、全1232アドレス・任意ターゲットに対する厳密XOR同値性の代用にならない。'),
    dict(section='V', evidence='Eqs. (237)–(240); V.A.2–V.B',
         result_ja='対称性欠陥を、切断線を横切るHamiltonian項の片側を対称性で共役して構成する。欠陥線を横切るanyonはρ_gに従って種類が変わる。g欠陥の位置と種類は外部から指定した古典パラメータであり、自由に量子重ね合わせできる励起ではない。',
         conditions_ja='Hamiltonian変更と断熱移動が必要で、動的にすると一般に閉じ込めを受ける。Aut(C)の形式的欠陥構成が全て微視的に実現可能とは主張していない。',
         applicability_ja='欠陥の導入を補助bit追加や無料の語置換と読み替えることはできない。今回は固定された可逆ゲート列を要するため、直接の合成方式は示されていない。'),
    dict(section='VI', evidence='Eqs. (241)–(245), (258)–(294), (298), (315)–(342)',
         result_ja='G-graded fusionの非空セクターは同じ総quantum dimensionを持つ。G-crossed braidではanyonの型が共役作用で変化し、頂点を滑らせるとU行列とη位相が必要になる。通常のhexagonではなくheptagonが整合性を課す。',
         conditions_ja='G-crossed Yang–Baxter関係にもη因子がある。g≠0のdefect twistはsymmetry-action gaugeで変わり、S行列の定義には相互不変なchargeと可換なg,hが必要。Gauge変更はR,U,ηを連動して変える。',
         applicability_ja='位相を省いて可逆語写像だけ比較する最適化は正当化されない。Measurement-only braidingへの言及も、今回のHMR回路に同じ基本操作を無料追加できる証拠ではない。'),
    dict(section='VII', evidence='Eqs. (343)–(404); VII.A–VII.C',
         result_ja='G-crossed Verlinde式とloop projectorを導き、torus上の各(g,h)セクター間を移すS/Tを構成する。Higher-genusのbranch配置はcommutator積がidentityである制約を持ち、ground-state degeneracyはfusionとη位相から決まる。',
         conditions_ja='複数charge線を囲むprojectorには追加η積が必要。S/Tは全体でprojective表現であり、異なる外因的欠陥セクターを量子重ね合わせする演算ではない。各sectorのSユニタリ性とC0のmodularityを要する。',
         applicability_ja='整数SL(2,Z)のDehn twistやsector等価性はGF(2)出力変換のゲート費を与えない。特定の閉じたsectorでのみgauge不変となる量を、全入力のoperator等価と混同しない。'),
    dict(section='VIII', evidence='Eqs. (405)–(453); VIII.C',
         result_ja='有限Gをgaugingすると欠陥が脱閉じ込めされ、chargeはG軌道とstabilizer subgroupのη-projective irrepで分類される。Quantum dimensionはd_a×軌道サイズ×irrep次元、総次元は|G|D0。Fusionには頂点のprojective作用を含める必要があり、twistはdefect twistとirrep characterの積でgauge不変となる。',
         conditions_ja='微視的Z2模型は各bondに新しいHilbert空間を追加し、大きなUによる低energy Gauss則へ射影する。一般有限Gの微視的構成は後続研究に残している。中央電荷一致はmod 8。S/TデータによるMTC一意性はこの本文ではconjectureと明記され、証明済みとして採用しない。',
         applicability_ja='Gauge-invariant subspaceへの射影、追加自由度、低energy極限は、元の全Hilbert空間の厳密XOR回路同値を意味しない。別々にはgauge依存な位相の積を保持する考え方はHMR枝の監査に対応するが、実CCX削減は未導出。'),
    dict(section='IX', evidence='Eqs. (454)–(466); IX.A.1–IX.C',
         result_ja='有限オンサイトunitary Gの分類では対称性作用とH2 fractionalizationの後にH4 obstructionを確認し、消える場合にH3 defectification torsorが残る。さらにanyon/defectのrelabelingで同じSETに同定される場合があり、cohomology要素数は物理phase数と一致しない。',
         conditions_ja='明示した3-cocycle変更が全解を尽くすことの全証明は本論文にはなく、引用数学定理を根拠にしている。PSGはcharge/fluxを交換する対称性等を捕捉しない。連続・空間・antiunitary対称性への完全分類は未完成で、有限オンサイトの定理を無条件拡張していない。',
         applicability_ja='候補の記述重複を除く原則には参考になるが、relabelingが固定された75語を保持することと実装費は別途示す必要がある。分類の個数をToffoli最小数や探索下界には使えない。'),
    dict(section='X', evidence='Eqs. (467)–(491)',
         result_ja='C0のanyonを置換しない対称性ではH3 obstructionが消え、各defect sectorにAbelian chargeを選べる。Fusionは2-cocycle wでtwistされ、F/R/U/ηを構成し、四欠陥pentagonからH4 obstructionの明示式を得る。',
         conditions_ja='表示された明示解は途中からfusion multiplicity≤1に限定する。Pentagonを満たしてもheptagon込みの全G-crossed条件が満たせない場合があり、obstructionはwと元MTCのデータに依存する。',
         applicability_ja='一部の等式だけを満たす候補は完全なoperator同値を保証しないという監査上の示唆がある。CNOT/CCXの新しい積共有恒等式や128Q内のローダー回路はこの解からまだ得ていない。'),
    dict(section='XI.A–D', evidence='Eqs. (492)–(534); XI.D.2',
         result_ja='自明bosonic/fermionic phase、semionとZ2およびZ2×Z2対称性を具体的に構成する。Semionの一部fractionalizationではfusion categoryのpentagonを満たす解はあっても、braidingを含むG-crossed条件全体には解がなく、defectificationが阻害される。',
         conditions_ja='Fermionic C0は非modularなので、modularityを用いた前節の一般分類をそのまま適用しないと本文が注意する。Z2でηをgauge-fixできることも、他のR/Uデータを固定したまま位相だけ消せる意味ではない。',
         applicability_ja='出力語だけの一致や一部回路identityの検査では相対位相の正当性を保証しないという具体的類例である。Semion位相を今回の許可されない任意位相ゲートとして持ち込むことはできない。'),
    dict(section='XI.E–H', evidence='Eqs. (535)–(598)',
         result_ja='Ising、巡回群anyon、奇数・偶数NのZ2作用を分類する。巡回群の素因数分解に沿ってanyonモデルと対称性を分け、作用がfactorを交換しない場合はgluingで再構成する。偶数Nの一部ではdefect relabelingにより見かけ上4通りの分類が3通りに同定される。',
         conditions_ja='素因数分解の写像にはmodular arithmeticとF/Rのgauge変更が含まれる。Nが偶数か奇数か、gcd条件、charge conjugationの固定点、fusion multiplicityを区別する。本文中には残されたTBD表記や隣接説明との不整合があり、全式を独立検証したわけではない。',
         applicability_ja='Factor化できる対称性と、factorを混ぜる作用を区別する発想は合成探索に参考となる。ただし固定語表の77×16分割がこの数学構造を持つ証明はなく、Chinese remainder変換を無料CNOTへ変換した実装もない。'),
    dict(section='XI.I–K', evidence='Eqs. (599)–(665)',
         result_ja='Toric codeの電磁双対、ZN toric code、および同一の二層を交換するZ2対称性を解析する。Toric codeではvertex gauge変更がR-symbolにも作用し、defect Fだけを任意に選べない。二層交換では対称性fractionalizationが自明となることを示し、gauged phaseのcharge数と高genus縮退を導く。',
         conditions_ja='二層模型は独立の二つの物理層を備えたHilbert空間であり、未知の任意入力をコピーする回路ではない。相の同一視にはcharge relabelingとgauge変更を伴う。抽出でconjugation barが落ちている式は符号を推測して再利用しない。',
         applicability_ja='表記上の二層分解やgauge自由度だけでは、任意ターゲットXORとclean ancilla条件を満たすコピー・uncomputeのゲート費は消えない。'),
    dict(section='XI.L–N', evidence='Eqs. (666)–(799); especially (685)–(700), (778)–(797)',
         result_ja='D(S3)および3-fermion SO(8)1の例では、ラベルが固定されても対称性作用で−1を受ける状態があり、gauging後の縮退計数から除く必要がある。Fusion multiplicity空間でも非自明な行列作用が残る。最後のRep(D10)例はfusionとmodular dataを保つ置換でもfractionalizationが阻害されうることを示す。',
         conditions_ja='S3をZ3と残りZ2に順次gaugingする例のfusion規則にはheuristic導出が明記され、全Ukを解いて一般公式へ代入した独立導出ではない。Rep(D10)は非modularで、H3 classとの直接同定にはmodular quantum doubleへの埋め込みを使う。',
         applicability_ja='今回に最も近い示唆は、bit値や固定点だけの照合に加え、測定枝と任意入力の相対位相を追跡する必要性である。例中の負位相の控除を、ローダーの減算や積共有の実ゲート削減と解釈しない。'),
    dict(section='Appendices A–C', evidence='Eqs. (A1)–(A10), (B1)–(B15), (C1)–(C2)',
         result_ja='Group cohomology、同じfactor setを持つprojective表現のcharacter orthogonality、G-crossed理論の対角G-gradingによるgluingを整理する。Projective表現のtensor productではfactor setも積になり、異なるfactor set間には自然なdirect sumがない。',
         conditions_ja='Gluingが全extensionを得るという主張は、対称性作用が二つのfactor間のchargeを交換しない場合。Characterは普通の表現と違い、単なるconjugacy classの関数にはならず位相が必要。',
         applicability_ja='共有積や共同合成を類推するだけでは足りず、具体的な演算空間と位相の対応を示す必要がある。多出力Boolean tensor rankやCCX数をこのfusion-category次元から計算できない。'),
    dict(section='Appendix D; endnotes', evidence='Theorems D.1–D.5; D.5 New Mathematical Results; endnotes 175–192, especially 176 and 190',
         result_ja='Categorical functorのliftingとしてH3/H4 obstructionとtorsorを整理し、gaugingとcondensation、normal subgroupからの逐次gaugingを記述する。厳密化で対象数を増やす記述と、skeletal化して位相を明示する記述は一般に同時に実現できないと説明する。',
         conditions_ja='D.4/D.5の証明は引用文献へ送り、D.5はgauged twistの式をconjectureと表現する。脚注176は全BTCでの自然同型とgauge同値の関係を仮定として明記し、一般証明は与えない。脚注190はfermion parityのmodular extensionと本論のG-crossed extensionを区別する。',
         applicability_ja='数学上の厳密化による演算の自明化が、固定した量子bit数とゲート集合で無料になるわけではない。今回の公式費用は実回路CCX等で測り、記述の単純さやT-depthと区別する。'),
]

def write():
    txt = SOURCE.read_text()
    record = dict(number=31, parent='The resource cost of magic in a code block',
        title='Symmetry Fractionalization, Defects, and Gauging of Topological Phases',
        authors=['Maissam Barkeshli', 'Parsa Bonderson', 'Meng Cheng', 'Zhenghan Wang'],
        publication_year=2019, doi='10.1103/PhysRevB.100.115147',
        primary_fulltext_url='https://arxiv.org/pdf/1410.4540v4',
        primary_metadata_url='https://arxiv.org/abs/1410.4540',
        retrieved_version='arXiv:1410.4540v4, 2019-10-15; 108 pages, 22 figures',
        access_scope='full_text', fulltext_retrieved=True, fulltext_read=True,
        main_text_complete=True, appendices_complete=True, references_complete=True,
        review_status='full_extracted_text_complete',
        read_character_ranges=READ_RANGES, read_sections=READ_SECTIONS,
        unread_sections=UNREAD_SECTIONS, source_file=str(SOURCE),
        source_sha256=hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
        extracted_characters=len(txt), reviewer='shared_synthesis', review_date='2026-11-15',
        extraction_limitations='PDF text was read in explicit contiguous ranges. Mathematical subscripts, conjugation bars, and diagrams can be lost in extraction; this is not an independent proof/figure verification. Unread ranges are not counted as read.',
        demonstrated_gate_saving=False, analysis=NOTES)
    (BASE/'magic_ref_31_review.json').write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n')
    out=['# Magic本論文・引用[31]の内容監査\n',
         '**Symmetry Fractionalization, Defects, and Gauging of Topological Phases** — Barkeshli, Bonderson, Cheng, Wang (2019).\n',
         '[一次PDF](https://arxiv.org/pdf/1410.4540v4) / [版と公刊情報](https://arxiv.org/abs/1410.4540)\n',
         '## 確認範囲\n',
         '108頁のv4の抽出本文を通読しました。取得だけでなく、本文I–XI・付録A–D・参考文献1–174・脚注175–192を実際に読んだ記録です。確認済みのUnicode文字範囲: '+str(READ_RANGES)+'。\n',
         '確認した節: '+'; '.join(READ_SECTIONS)+'。\n',
         '未読の抽出本文: '+('; '.join(UNREAD_SECTIONS) if UNREAD_SECTIONS else 'なし')+'。\n',
         '抽出テキストの読解であり、図のピクセル検証やOCRが壊れた全数式の独立証明ではありません。\n',
         '## 回路最適化への判定\n',
         'この読解から、今回の固定語表ローダーを削減した実装・実CCX数は得ていません。対称性の分類、記述上のgauge、物理的なgauging、実ゲート置換を区別します。許可ゲート、任意32ターゲットXOR、補助bit復元、HMR測定枝の相対位相を満たす具体的回路が別途必要です。\n',
         '## 節別の結果\n']
    for n in NOTES:
        out += ['### '+n['section']+'\n', '**根拠:** '+n['evidence']+'\n',
                n['result_ja']+'\n', '**条件:** '+n['conditions_ja']+'\n',
                '**今回への適用:** '+n['applicability_ja']+'\n']
    (BASE/'magic_ref_31_review.md').write_text('\n'.join(out))
    print(json.dumps(dict(read_ranges=READ_RANGES, read_sections=len(READ_SECTIONS), chars=len(txt))))

if __name__=='__main__':
    write()
