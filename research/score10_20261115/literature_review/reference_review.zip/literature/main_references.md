# 主論文の参考文献一覧

基準版：arXiv:2409.13809v2（2025-02-06）。全61件。出版版 PRX Quantum6,010337（2025-02-28）も61件。初版v1は55件。

番号と引用文字列は著者公開版から抽出。参考文献の記載確認と、その引用先本文の通読は別の作業として扱う。

[著者公開版](https://arxiv.org/html/2409.13809v2) · [出版版](https://journals.aps.org/prxquantum/abstract/10.1103/PRXQuantum.6.010337)

## v2 / 出版版の番号

1. S. Aaronson and A. Arkhipov, The computational complexity of linear optics, in Proceedings of the forty-third annual ACM symposium on Theory of computing (2011) pp. 333–342. [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib1)
2. S. Aaronson and A. Arkhipov, Bosonsampling is far from uniform, arXiv preprint arXiv:1309.7460 (2013). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib2)
3. A. M. Childs, D. Gosset, and Z. Webb, Universal computation by multiparticle quantum walk, Science 339 , 791 (2013). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib3)
4. S. Aaronson and L. Chen, Complexity-theoretic foundations of quantum supremacy experiments, arXiv preprint arXiv:1612.05903 (2016). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib4)
5. D. Deutsch and R. Jozsa, Rapid solution of problems by quantum computation, Proceedings of the Royal Society of London. Series A: Mathematical and Physical Sciences 439 , 553 (1992). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib5)
6. P. W. Shor, Algorithms for quantum computation: discrete logarithms and factoring, in Proceedings 35th annual symposium on foundations of computer science (Ieee, 1994) pp. 124–134. [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib6)
7. D. R. Simon, On the power of quantum computation, SIAM journal on computing 26 , 1474 (1997). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib7)
8. P. W. Shor, Polynomial-time algorithms for prime factorization and discrete logarithms on a quantum computer, SIAM review 41 , 303 (1999). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib8)
9. R. P. Feynman, Simulating physics with computers, in Feynman and computation (cRc Press, 2018) pp. 133–153. [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib9)
10. A. M. Childs, D. Maslov, Y. Nam, N. J. Ross, and Y. Su, Toward the first quantum simulation with quantum speedup, Proceedings of the National Academy of Sciences 115 , 9456 (2018). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib10)
11. A. J. Daley, I. Bloch, C. Kokail, S. Flannigan, N. Pearson, M. Troyer, and P. Zoller, Practical quantum advantage in quantum simulation, Nature 607 , 667 (2022). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib11)
12. E. Knill, D. Leibfried, R. Reichle, J. Britton, R. B. Blakestad, J. D. Jost, C. Langer, R. Ozeri, S. Seidelin, and D. J. Wineland, Randomized benchmarking of quantum gates, Physical Review A—Atomic, Molecular, and Optical Physics 77 , 012307 (2008). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib12)
13. D. Gottesman, Stabilizer codes and quantum error correction (California Institute of Technology, 1997). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib13)
14. A. Y. Kitaev, Quantum error correction with imperfect gates, in Quantum communication, computing, and measurement (Springer, 1997) pp. 181–188. [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib14)
15. D. Gottesman, The heisenberg representation of quantum computers, arXiv preprint quant-ph/9807006 (1998). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib15)
16. S. Aaronson and D. Gottesman, Improved simulation of stabilizer circuits, Physical Review A—Atomic, Molecular, and Optical Physics 70 , 052328 (2004). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib16)
17. H. J. Garcia, I. L. Markov, and A. W. Cross, Efficient inner-product algorithm for stabilizer states, arXiv preprint arXiv:1210.6646 (2012). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib17)
18. H. J. García, I. L. Markov, and A. W. Cross, On the geometry of stabilizer states, Quantum Information & Computation 14 , 683 (2014). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib18)
19. S. Bravyi and D. Gosset, Improved classical simulation of quantum circuits dominated by clifford gates, Physical review letters 116 , 250501 (2016). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib19)
20. S. Bravyi, G. Smith, and J. A. Smolin, Trading classical and quantum computational resources, Physical Review X 6 , 021043 (2016). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib20)
21. S. Bravyi, D. Browne, P. Calpin, E. Campbell, D. Gosset, and M. Howard, Simulation of quantum circuits by low-rank stabilizer decompositions, Quantum 3 , 181 (2019). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib21)
22. L. Kocia, Improved strong simulation of universal quantum circuits, arXiv preprint arXiv:2012.11739 (2020). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib22)
23. H. Qassim, H. Pashayan, and D. Gosset, Improved upper bounds on the stabilizer rank of magic states, Quantum 5 , 606 (2021). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib23)
24. Y. Shi, Quantum and classical tradeoffs, Theoretical computer science 344 , 335 (2005). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib24)
25. A. Y. Kitaev, Quantum measurements and the abelian stabilizer problem, arXiv preprint quant-ph/9511026 (1995). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib25)
26. D. Gottesman and I. L. Chuang, Demonstrating the viability of universal quantum computation using teleportation and single-qubit operations, Nature 402 , 390 (1999). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib26)
27. D. Shepherd and M. J. Bremner, Temporally unstructured quantum computation, Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences 465 , 1413 (2009). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib27)
28. M. J. Bremner, R. Jozsa, and D. J. Shepherd, Classical simulation of commuting quantum computations implies collapse of the polynomial hierarchy, Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences 467 , 459 (2011). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib28)
29. M. J. Bremner, A. Montanaro, and D. J. Shepherd, Average-case complexity versus approximate simulation of commuting quantum computations, Physical review letters 117 , 080501 (2016). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib29)
30. D. Bluvstein, S. J. Evered, A. A. Geim, S. H. Li, H. Zhou, T. Manovitz, S. Ebadi, M. Cain, M. Kalinowski, D. Hangleiter, et al. , Logical quantum processor based on reconfigurable atom arrays, Nature 626 , 58 (2024). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib30)
31. D. Maslov, S. Bravyi, F. Tripier, A. Maksymov, and J. Latone, Fast classical simulation of harvard/quera iqp circuits, arXiv preprint arXiv:2402.03211 (2024). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib31)
32. S. A. Fenner, L. J. Fortnow, and S. A. Kurtz, Gap-definable counting classes, Journal of Computer and System Sciences 48 , 116 (1994). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib32)
33. A. Ehrenfeucht and M. Karpinski, The computational complexity of (XOR, AND) counting problems (International Computer Science Inst., 1990). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib33)
34. B. Fefferman, Lecture notes for the 2023 ias/pcmi graduate summer school (2013). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib34)
35. P. Selinger, Quantum circuits of t-depth one, Physical Review A—Atomic, Molecular, and Optical Physics 87 , 042302 (2013). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib35)（v1: [34]）
36. J. Dehaene and B. De Moor, Clifford group, stabilizer states, and linear and quadratic operations over gf (2), Physical Review A 68 , 042318 (2003). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib36)（v1: [35]）
37. E. Knill, Fault-tolerant postselected quantum computation: Schemes, arXiv preprint quant-ph/0402171 (2004). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib37)（v1: [36]）
38. S. Bravyi and A. Kitaev, Universal quantum computation with ideal clifford gates and noisy ancillas, Physical Review A—Atomic, Molecular, and Optical Physics 71 , 022316 (2005). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib38)（v1: [37]）
39. H. J. Garcia-Ramirez, Hybrid Techniques for Simulating Quantum Circuits using the Heisenberg Representation. , Ph.D. thesis, University of Michigan (2014). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib39)（v1: [38]）
40. S. X. Cui, D. Gottesman, and A. Krishna, Diagonal gates in the clifford hierarchy, Physical Review A 95 , 012329 (2017). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib40)（v1: [39]）
41. N. Schuch and J. Siewert, Programmable networks for quantum algorithms, Physical review letters 91 , 027902 (2003). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib41)（v1: [40]）
42. C. Gidney and N. C. Jones, A cccz gate performed with 6 t gates, arXiv preprint arXiv:2106.11513 (2021). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib42)（v1: [41]）
43. How can we implement controlled-t gate using cnot and h, s and t gates?, quantumcomputing.stackexchange.com/questions/13132 (2020), [Accessed: Sep 16th, 2024]. [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib43)（v1: [42]）
44. R. Raussendorf, D. E. Browne, and H. J. Briegel, Measurement-based quantum computation on cluster states, Physical review A 68 , 022312 (2003). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib44)（v1: [43]）
45. S. Aaronson, Quantum computing, postselection, and probabilistic polynomial-time, Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences 461 , 3473 (2005). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib45)（v1: [44]）
46. F. Arute, K. Arya, R. Babbush, D. Bacon, J. C. Bardin, R. Barends, R. Biswas, S. Boixo, F. G. Brandao, D. A. Buell, et al. , Quantum supremacy using a programmable superconducting processor, Nature 574 , 505 (2019). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib46)（v1: [45]）
47. M.-H. Yung and B. Cheng, Anti-forging quantum data: Cryptographic verification of quantum computational power, arXiv preprint arXiv:2005.01510 (2020). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib47)（v1: [46]）
48. S. Bravyi, D. Gosset, and Y. Liu, How to simulate quantum measurement without computing marginals, Physical Review Letters 128 , 220503 (2022). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib48)（v1: [47]）
49. C.-Y. Lai and H.-C. Cheng, Learning quantum circuits of some t gates, IEEE Transactions on Information Theory 68 , 3951 (2022). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib49)（v1: [48]）
50. S. Grewal, V. Iyer, W. Kretschmer, and D. Liang, Low-stabilizer-complexity quantum states are not pseudorandom, arXiv preprint arXiv:2209.14530 (2022). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib50)（v1: [49]）
51. S. Grewal, V. Iyer, W. Kretschmer, and D. Liang, Efficient learning of quantum states prepared with few non-clifford gates, arXiv preprint arXiv:2305.13409 (2023). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib51)（v1: [50]）
52. S. Grewal, V. Iyer, W. Kretschmer, and D. Liang, Improved stabilizer estimation via bell difference sampling, in Proceedings of the 56th Annual ACM Symposium on Theory of Computing (2024) pp. 1352–1363. [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib52)（v1: [51]）
53. L. Leone, S. F. Oliviero, and A. Hamma, Learning t-doped stabilizer states, Quantum 8 , 1361 (2024a). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib53)
54. D. Hangleiter and M. J. Gullans, Bell sampling from quantum circuits, Physical Review Letters 133 , 020601 (2024). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib54)（v1: [53]）
55. S. F. Oliviero, L. Leone, S. Lloyd, and A. Hamma, Unscrambling quantum information with clifford decoders, Physical Review Letters 132 , 080402 (2024). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib55)
56. L. Leone, S. F. Oliviero, S. Lloyd, and A. Hamma, Learning efficient decoders for quasichaotic quantum scramblers, Physical Review A 109 , 022429 (2024b). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib56)
57. P. Niroula, C. D. White, Q. Wang, S. Johri, D. Zhu, C. Monroe, C. Noel, and M. J. Gullans, Phase transition in magic with random quantum circuits, arXiv preprint arXiv:2304.10481 (2023). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib57)（v1: [54]）
58. M. Bejan, C. McLauchlan, and B. Béri, Dynamical magic transitions in monitored clifford+ t circuits, PRX Quantum 5 , 030332 (2024). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib58)
59. X. Turkeshi, E. Tirrito, and P. Sierant, Magic spreading in random quantum circuits (2024), arXiv:2407.03929 [quant-ph] . [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib59)
60. G. E. Fux, B. Béri, R. Fazio, and E. Tirrito, Disentangling unitary dynamics with classically simulable quantum circuits, arXiv preprint arXiv:2410.09001 (2024). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib60)
61. Z. Liu and B. K. Clark, Classical simulability of clifford+ t circuits with clifford-augmented matrix product states, arXiv preprint arXiv:2412.17209 (2024). [書誌原文](https://arxiv.org/html/2409.13809v2#bib.bib61)

## 版による番号差

Selinger の Quantum circuits of T-depth one は v1の[34]、v2／出版版の[35]。v2では Fefferman講義録が[34]に入り、末尾に[60]Fuxら、[61]Liu–Clarkが追加される。

追記：v2への追加は[34],[55],[56],[58],[59],[60],[61]の7件。v1[55] Aaronson–Zhang, On verifiable quantum advantage with peaked circuit sampling, arXiv:2404.14493 はv2で削除される。両版を合わせると62件。v2[53]はv1[52]と同一（年の接尾辞だけ変更）。
