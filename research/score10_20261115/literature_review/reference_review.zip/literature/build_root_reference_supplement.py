"""Explicit supplemental reading record; fetching is never counted as reading."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
ORIGINAL = BASE / 'refs_44_61_and_v1_only.json'
ENTRIES = [
    dict(number=53, file='ref_53.md',
         title='Learning t-doped stabilizer states',
         authors='Lorenzo Leone; Salvatore F. E. Oliviero; Alioscia Hamma',
         reviewed_version='arXiv:2305.15398v6, 2024-05-21; Quantum 8, 1361 (2024)',
         primary_url='https://arxiv.org/html/2305.15398v6',
         read_character_ranges=[[8945,49255]],
         read_sections=['II Algebraic structure (complete)', 'III Learning from characteristic-distribution samples (complete)', 'IV Sampling (complete)', 'V Learning without conjugate-state access (complete)', 'VI Concurrent work (complete)', 'VII Conclusions (complete)', 'Acknowledgments'],
         unread_sections=['Appendices A–D', 'Reference list'],
         additional_points_ja=[
             'II–IIIのfinite resolutionによるexact learningはTゲート限定。一般O(1)-local non-Clifford gateに対する代数的分解は扱うが、同じ離散間隔とexact learningの保証は成立しないと明記する。',
             'Stabilizer groupとbad-generatorのcoset分解を学ぶ。m≥n−t、bad-generator数k≤4^t−1で、poly(n,2^t)はt=O(log n)のときにpoly(n)。各測定の有限標本による失敗確率は残る。',
             'IVの直接Bell samplingは状態とその複素共役へのquery accessを使う。Vは同じ状態の2コピーへBell測定を行い、その2回のPauli標本の積を検査する別手順で、複素共役を無料の物理演算と仮定していない。',
             'Vは学習したstabilizerからClifford diagonalizerを構成して、残った少数qubitの状態をtomographyする。VIIは学習した表現からClifford+T準備回路を合成する問題をopen questionとして挙げる。',
         ],
         applicability_ja='固定初期状態のtomographic descriptionを得る結果であり、任意アドレス・任意32ターゲットに同じunitary/XOR作用をする安価な回路を自動合成する定理ではない。測定標本数やstabilizer nullityを実Toffoli数へ換算しない。',
         evidence=['II Eqs.(1)–(5)', 'III Eqs.(6)–(8)', 'IV Eq.(9)', 'V Eqs.(10)–(14)', 'VII open questions']),
    dict(number=54, file='ref_54.md',
         title='Bell sampling from quantum circuits',
         authors='Dominik Hangleiter; Michael J. Gullans',
         reviewed_version='arXiv:2306.00083v5, 2024-06-01; PRL 133, 020601 (2024)',
         primary_url='https://arxiv.org/html/2306.00083v5',
         read_character_ranges=[[9375,27691]],
         read_sections=['Bell samples as classical circuit shadows (complete)', 'Depth test (complete)', 'Magic test and Clifford+T learning (complete)', 'Error Detection and Correction (complete)', 'Discussion and outlook (complete)'],
         unread_sections=['Supplementary Material S1–S5', 'Acknowledgments and reference lists'],
         additional_points_ja=[
             'Purityからfidelityを推定する主張にはlocal circuit-level Pauli noise、平均を取る回路ensemble、noiseless Bell measurementという条件がある。測定noiseの補正にはi.i.d.条件を追加する。任意の同じcoherent errorを2コピーに掛けた場合には対応が壊れると本文にある。',
             'Depth testは指定されたgate architectureの境界をまたぐgate数とsubsystem entropyから深さをlower-boundする。今回の自由配置回路のToffoli数の下界とは違う。',
             'Magic testはO(n/epsilon)標本で近い状態のstabilizer nullityを推定し、t-qubit部分に追加tomographyを行う。推定値が元の状態のexact T-countや最適回路費用を直接決めるわけではない。',
             'Antisymmetric Bell outcomeの破棄やvirtual-distillation比による誤差抑制は、測定分布・期待値の処理である。二つのコピーと測定を使い、単一のcoherent oracleを保つuncompute手順ではない。',
             '後半のdepth/magic testはpurityが1に近い設定に移っており、noise-robustな一般版はoutlookに残されている。',
         ],
         applicability_ja='独立の統計的診断としては参考になるが、全1232アドレスとHMR枝の相対位相の厳密検証の代わりにはしない。二倍のqubit使用や追加のH・CNOT・測定費用も固定128Qの外に出せない。',
         evidence=['Bell shadows Eqs.(4)–(5)', 'Depth test', 'Magic test', 'Error Detection and Correction', 'Discussion noise-robustness questions']),
    dict(number=57, file='2304.10481.md',
         title='Phase transition in magic with random quantum circuits',
         authors='Pradeep Niroula; Christopher David White; Qingfeng Wang; Sonika Johri; Daiwei Zhu; Christopher Monroe; Crystal Noel; Michael J. Gullans',
         reviewed_version='arXiv:2304.10481v2, 2024-04-11 (citation in parent is 2023 preprint)',
         primary_url='https://arxiv.org/html/2304.10481v2',
         read_character_ranges=[[0,2086],[8649,36776],[40594,48981]],
         read_sections=['I Model (complete)', 'II Quantifying magic (complete)', 'III Vanishing rate (complete)', 'IV Constant rate (complete)', 'V Discussion (complete)', 'Acknowledgments/data availability/disclaimer', 'Supplement A Basis-minimized entropy', 'Supplement B Syndrome distribution', 'Supplement C Decoder breakdown'],
         unread_sections=['Supplement D–M', 'Reference list'],
         additional_points_ja=[
             '模型は|0>からClifford encode、全qubitへのcoherent Z rotation、inverse decode、syndrome measurementを行う。得たmagicは条件付き論理状態の性質で、元の入力に対して同じchannelを保つ変換ではない。',
             'Vanishing-rateの解析にはsyndromeごとのerror数の仮定がある。Constant-rateのcritical pointと指数は有限サイズfitとscaling hypothesisに敏感で、SSREとconditional entropyの転移が一致するか本文は結論していない。',
             '実験のmagic推定はsyndrome classへのgrouping、tomography後の最大固有状態への射影、理想分布のsupportへの投影等の古典postprocessingを使う。これを物理回路のexact動作保証と読まない。',
             'Supplement Aが示すbasis-minimized entropyの性質はpure stateでのfaithfulness、Clifford不変性、subadditivity。任意の許可stabilizer操作に対する全ての資源単調性まで証明したとは扱わない。',
             'Supplement Cは小さい測定entropyでも情報回復を保証しないと明記する。Syndrome measurementが初期状態とは異なるpure stabilizer stateへ射影しうるためである。Syndromeごとにminimizeした平均と、全syndromeで共通basisをminimizeした値も区別する。',
         ],
         applicability_ja='測定後magicが小さいというだけでは、古い中間値を自由に測定・消去できない。HMRで正しいbyproduct correctionを全入力に適用する具体的恒等式が必要。最適Toffoli数やJ=4境界をこの相転移から導けない。',
         evidence=['I–V', 'Supplement A Eqs.(1)–(4)', 'Supplement B two-errors-per-syndrome assumption', 'Supplement C Eqs.(5)–(10) and small-entropy caveat']),
    dict(number=60, file='2410.09001.md',
         title='Disentangling magic states with classically simulable quantum circuits',
         authors='Gerald E. Fux; Benjamin Béri; Rosario Fazio; Emanuele Tirrito',
         reviewed_version='arXiv:2410.09001v3, 2025-12-08; PRL 135, 260605 (2025). Parent cited 2024 title: Disentangling unitary dynamics with classically simulable quantum circuits.',
         primary_url='https://arxiv.org/html/2410.09001v3',
         read_character_ranges=[[8484,34477]],
         read_sections=['Results including Theorem 1 and proof (complete)', 'Consequences for Hamiltonian dynamics', 'Applications', 'Discussion and conclusion', 'Acknowledgments', 'End Matter: Hamiltonian dynamics and matchgate disentangling (complete)'],
         unread_sections=['Reference list'],
         additional_points_ja=[
             'Theorem 1はC(|phi>⊗|0>^(N−k))という符号化されたstateと、logical operatorではないPauli Pに適用する。Pがstabilizerなら位相のみ、anticommutingなら未使用|0>にmagicを移す。任意入力の全Hilbert空間上で同じoperatorという主張ではない。',
             '非Clifford rotationごとにfree qubitを使うか、残ったMPSのbond dimensionを最大2倍にする。Typicalなt*≈N−1.607は深いrandom Cliffordの確率模型であり、与えられた語表回路に対する無条件保証ではない。',
             'Greedy sweepは二qubit Cliffordのlocal-operation quotient 20候補を調べる。実験で少数sweepが有効という結果と、常に最適disentanglerを見つける保証を区別する。',
             'Applicationsの量子回路圧縮はsampling taskであり、free-qubit測定のランダムな結果とClifford更新を用いる。Pauli expectationがpoly-timeでも、全qubitのjoint samplingは一般に指数的という違いを本文と結論が明記する。',
             'End Matterでは一般非可積分Ising dynamicsのmagic/entanglementを十分には除去できなかった。Matchgate版は特定の逆時間発展による試算であり、一般最適化手順はfuture work。',
         ],
         applicability_ja='状態表現やsampling幅の圧縮と、実命令のCCX削減は別。固定した任意32ターゲットを|0>のfree qubitと扱えず、追加magic preparationやCliffordのH/Sを公式gate alphabetの外へ無料に置けない。',
         evidence=['Theorem 1 and Eqs.(1)–(5)', 'Applications sampling compression', 'Discussion', 'End Matter Eqs.(8)–(10)']),
    dict(number=61, file='2412.17209.md',
         title='Classical simulability of Clifford+T circuits with Clifford-augmented matrix product states',
         authors='Zejun Liu; Bryan K. Clark',
         reviewed_version='arXiv:2412.17209v2, 2025-08-26 (parent cited 2024 v1 preprint)',
         primary_url='https://arxiv.org/html/2412.17209v2',
         read_character_ranges=[[8515,85963],[98204,108470]],
         read_sections=['II Background', 'III.1–III.4 including all proofs and Algorithms 1–2', 'IV.1–IV.2 OBD and comparison', 'V.1–V.2 numerical results', 'VI.1–VI.3 probability/sampling/amplitude/entropy and Algorithms 3–4', 'VII Conclusions', 'Acknowledgments', 'Appendix B complete, including Algorithm 5 and Proposition 1 proof', 'Appendix C complete counterexample'],
         unread_sections=['Appendix A', 'Appendices D–I', 'Reference list'],
         additional_points_ja=[
             'OFDは未使用のproduct |0> qubitにPauli stringのX/Y成分が作用するとき、同じqubitをcontrolとするcontrolled-Pauli列でmagicを局所化する。|0>という入力制約を外した任意ターゲットにはそのまま適用できない。',
             'III.3のGF(2)行列はtwisted Pauliを{I,Z}→0、{X,Y}→1で写したt×N行列。Rank rはOFDで処理できる独立方向の数で、未処理数t−rがbond dimensionの上界に入る。ここでは高rankが有利であり、truth-table bilinear rank低減とは別の目的である。',
             '2^(t−r)はbond dimensionの上界であって厳密値でもToffoli下界でもない。単qubit作用、別領域への作用、T同士がCliffordへ結合する場合などで上界は緩む。Pauli順序は一般には交換できない。',
             'OBDの局所探索はOFDのlong-range controlled-Pauliを必ず発見しない。Appendix Cには5qubit・6stringsの明示反例がある。探索失敗を最適性証明として使わない。',
             'VIは小bond dimensionのCAMPSから全bitstring確率・sampling・振幅・entropyを求めるときにも一般に指数費用が残ることを示す。数値比較は有限precisionであり、truncationを使う大規模結果は厳密比較ではない。',
             'Appendix Bは任意MPS入力に対してZ stabilizerだけでは不十分とし、X/Z双方の共役像とi^sの位相を保持する。共役tableauは演算子全体のglobal phaseを同定しない点は、制御された部分演算へ移す場合に別途管理が必要。',
         ],
         implementation_cautions_ja=[
             '読解からの実装上の注意: Algorithm 3/4で逐次確率を条件付き確率として掛けるなら、各射影後の正規化を明示する必要がある。印刷された擬似コードには明示のnormalize行が見当たらないため、そのままコードへ写さず正規化の規約を決める。',
             '読解からの実装上の注意: VI.2は基準振幅を1にして隣接bitstringの振幅比を掛け、Eq.(30)でp0を割る。基準振幅または途中の分母が0の場合への分岐が必要で、全supportのphase verifierに無条件で流用しない。これは著者の新しい定理としてではなく、式の分母から生じる実装条件として記録する。',
         ],
         applicability_ja='Pauli窓の状態シミュレーションや位相追跡の設計には参考になるが、75語表のjoint XOR loaderの実CCXを直接減らす結果ではない。現在のBoolean truth-table rankとは対象も最適化方向も異なる。',
         evidence=['III Theorems 1–3 and Eqs.(8)–(18)', 'IV OBD', 'V truncation discussion', 'VI Algorithms 3–4 and Eqs.(28)–(30)', 'Appendix B Eq.(60) and Algorithm 5', 'Appendix C Eq.(70)']),
]


def write():
    originals = {r['number']: r for r in json.loads(ORIGINAL.read_text())['references']}
    rows = []
    additional_file = BASE / 'root_reference_supplement_additional_entries.json'
    additional = json.loads(additional_file.read_text()) if additional_file.exists() else []
    for raw in sorted(ENTRIES + additional, key=lambda r: r['number']):
        r = dict(raw)
        source = BASE / 'root_refs' / r.pop('file')
        txt = source.read_text()
        assert all(0 <= a < b <= len(txt) for a, b in r['read_character_ranges'])
        old = originals[r['number']]
        r.update(citation_exact=old['citation_exact'],
                 local_cache=str(source), cache_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
                 extracted_characters=len(txt), reviewer='shared_synthesis',
                 prior_reviewer='root', prior_reviewed_scope_ja=old['reviewed_scope_ja'],
                 combined_review_status=r.get('combined_review_status', 'main_text_complete'),
                 supplemental_review_status='specified_sections_complete',
                 main_text_complete_combined=r.get('main_text_complete_combined', True),
                 full_extracted_text_read=False,
                 full_text_retrieved=r.get('full_text_retrieved', True),
                 demonstrated_gate_saving=False)
        rows.append(r)
    complete_count = sum(r['main_text_complete_combined'] for r in rows)
    report = dict(title='Main-paper references: supplemental body review',
                  review_date='2026-11-15',
                  reading_rule='Only explicit character ranges were read by this reviewer; prior root scopes are retained separately. Combined main-text completion does not mean appendices were all read.',
                  original_ledger_unmodified=str(ORIGINAL),
                  figures_and_equations='Text, displayed equations, algorithms, and extracted captions were read. Figure pixels and every algebraic identity were not independently rederived.',
                  references=rows)
    (BASE/'root_reference_supplement.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    out=['# 主論文の引用：本文残部の追加読解\n',
         f'{len(rows)}件の補完記録です。root担当の既読範囲と今回の追加読解を合わせて、{complete_count}件は本文の全節を確認しました。残る本文・付録・参考文献の未読部分は下に個別記録しており、全PDF読了とはしません。新しい回路実装・Toffoli削減は行っていません。\n',
         '数式・擬似コード・抽出された図説明を読みました。全図のピクセル視認や、全定理の独立再証明ではありません。版が後年更新された[60][61]は、親論文が引用した初版と区別します。\n',
         '|番号|統合した本文の範囲|未読部分|\n|---|---|---|']
    out += [f"|{r['number']}|{'全節' if r['main_text_complete_combined'] else '結果・アルゴリズム・条件を中心に部分確認'}|{'; '.join(r['unread_sections'])}|" for r in rows]
    out += ['\n']
    for r in rows:
        out += [f"## [{r['number']}] {r['title']}\n", r['authors']+'。 '+r['reviewed_version']+'。\n',
                '[一次本文]('+r['primary_url']+')\n',
                '**今回の実読範囲:** '+str(r['read_character_ranges'])+'（Unicode文字、半開区間）。\n',
                '**読んだ節:** '+'; '.join(r['read_sections'])+'。\n',
                '**この補完前のroot範囲:** '+r['prior_reviewed_scope_ja']+'\n',
                '**未読:** '+'; '.join(r['unread_sections'])+'。\n']
        if r.get('retrieval_gap_ja'):
            out += ['**取得範囲の補正:** '+r['retrieval_gap_ja']+'\n']
        out += ['**追加の要点・条件:**\n']
        out += ['- '+p for p in r['additional_points_ja']]
        if r.get('implementation_cautions_ja'):
            out += ['\n**式を実装する場合の注意:**\n']+['- '+p for p in r['implementation_cautions_ja']]
        out += ['\n**今回への適用:** '+r['applicability_ja']+'\n',
                '**根拠箇所:** '+'; '.join(r['evidence'])+'。\n']
    (BASE/'root_reference_supplement.md').write_text('\n'.join(out))
    print(json.dumps({'references':len(rows),'combined_main_text_complete':complete_count,'full_extracted_text_read':0}))


if __name__ == '__main__':
    write()
