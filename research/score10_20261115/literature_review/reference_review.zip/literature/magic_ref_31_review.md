# Magic本論文・引用[31]の内容監査

**Symmetry Fractionalization, Defects, and Gauging of Topological Phases** — Barkeshli, Bonderson, Cheng, Wang (2019).

[一次PDF](https://arxiv.org/pdf/1410.4540v4) / [版と公刊情報](https://arxiv.org/abs/1410.4540)

## 確認範囲

108頁のv4の抽出本文を通読しました。取得だけでなく、本文I–XI・付録A–D・参考文献1–174・脚注175–192を実際に読んだ記録です。確認済みのUnicode文字範囲: [[0, 513129]]。

確認した節: I Introduction (including summary and prior work); II Anyon algebra: fusion, braiding, gauge transformations; III Topological/global symmetry and H3 obstruction invariant; IV Symmetry fractionalization, including projective and locality-preserving cases; V Extrinsic defects: construction and types; VI Defect fusion, G-crossed braiding, gauge transformations, invariants; VII G-crossed modularity, torus and higher-genus sectors; VIII Gauging: microscopic models and topological data; IX Classification, relabeling, PSG limitations, non-finite/non-unitary cases; X Explicit solution for non-permuting symmetry actions; XI Examples A–N, including all displayed extracted tables; Acknowledgments; Appendices A–D; References 1–174 and endnotes 175–192。

未読の抽出本文: なし。

抽出テキストの読解であり、図のピクセル検証やOCRが壊れた全数式の独立証明ではありません。

## 回路最適化への判定

この読解から、今回の固定語表ローダーを削減した実装・実CCX数は得ていません。対称性の分類、記述上のgauge、物理的なgauging、実ゲート置換を区別します。許可ゲート、任意32ターゲットXOR、補助bit復元、HMR測定枝の相対位相を満たす具体的回路が別途必要です。

## 節別の結果

### I

**根拠:** I.A.1–I.A.3; Eqs. (1)–(2)

有限オンサイトunitary対称性のSETを、対称性作用、fractionalization、defectificationのデータで分類する。欠陥は元の模型の自由な有限エネルギー粒子ではなく、Hamiltonianの外的変更で導入される。Gaugingはこれを脱閉じ込めし、異なるtopological phaseを作る。

**条件:** H3のfractionalization obstructionとH4のdefectification obstructionを区別する。後者の一般定理は引用数学文献に依拠し、本論文は非置換作用の場合の明示式も後で構成する。

**今回への適用:** 同じ計算を安く表す回路変形と、物理系・Hilbert空間を変えるgaugingは異なる。欠陥生成やbraidを今回の許可ゲートとして無料に追加する根拠にならない。

### II

**根拠:** Eqs. (10)–(12), (33)–(34), (43)–(52)

F-moveをfusion空間のunitary基底変更として定義し、pentagon/hexagon条件でfusion/braidingの整合性を課す。Γによる基底変更はFとRを連動して変換する。真空とのfusion/braidingを自明に保つためΓにも条件がある。

**条件:** 描画されたanyonic charge lineは常に実粒子worldlineと同義ではない。Frobenius–Schur符号は一部gaugeで消せず、Tはmodular twist行列であってClifford+TのTゲート数ではない。

**今回への適用:** 基底変更を採用するなら入出力の符号・係数・変換費も合わせるという原則には有用。一般複素unitary ΓをCNOTのみのGF(2)変換と扱えず、fusion multiplicityやquantum dimensionはToffoli複雑度の下界ではない。

### III

**根拠:** Eqs. (58)–(66), (81)–(112)

Topological symmetryはanyon labelの置換だけではなく、fusion頂点のU_g作用を含む。自然同型の位相を除いた自己同値群Aut(C)へGを写し、β位相の結合から一意なH3 obstruction classを得る。

**条件:** U_gをgaugeで常にidentityへできるわけではないと明記する。指定したC,G,[ρ]で実現するobstruction classは一つであり、H3の全要素を独立な候補と数えることは誤り。Antiunitaryでは複素共役が必要。

**今回への適用:** 語の置換が同じでもHMR測定枝の相対位相が一致するとは限らないという監査上の対応がある。ただしこの分類から語表の新しい恒等式や実ゲート削減は出ていない。

### IV

**根拠:** Eqs. (113)–(120), (133)–(167), (175)–(188), (206)–(235)

局所演算とtopological作用に分けた対称性の積を比較し、局所projective位相ηとβの整合性からO=dwを導く。Obstructionが消える場合のfractionalization解はH2 torsorであり、各anyonに独立なprojective表現を割り当てる分類ではない。

**条件:** 物理的局在分解はwell-separated quasiparticlesと指数減衰相関を仮定し、Eq.(133)はO(exp(-r/ξ))補正を省略する。空間対称性には追加制約があり、antiunitaryでは複素共役を含む。局所Kramers符号とtopological spinは一般には別。

**今回への適用:** 局所の位相を一つずつ消す操作の整合性を全体で確認する重要性が読み取れる。指数的小ささや同じuniversality classは、全1232アドレス・任意ターゲットに対する厳密XOR同値性の代用にならない。

### V

**根拠:** Eqs. (237)–(240); V.A.2–V.B

対称性欠陥を、切断線を横切るHamiltonian項の片側を対称性で共役して構成する。欠陥線を横切るanyonはρ_gに従って種類が変わる。g欠陥の位置と種類は外部から指定した古典パラメータであり、自由に量子重ね合わせできる励起ではない。

**条件:** Hamiltonian変更と断熱移動が必要で、動的にすると一般に閉じ込めを受ける。Aut(C)の形式的欠陥構成が全て微視的に実現可能とは主張していない。

**今回への適用:** 欠陥の導入を補助bit追加や無料の語置換と読み替えることはできない。今回は固定された可逆ゲート列を要するため、直接の合成方式は示されていない。

### VI

**根拠:** Eqs. (241)–(245), (258)–(294), (298), (315)–(342)

G-graded fusionの非空セクターは同じ総quantum dimensionを持つ。G-crossed braidではanyonの型が共役作用で変化し、頂点を滑らせるとU行列とη位相が必要になる。通常のhexagonではなくheptagonが整合性を課す。

**条件:** G-crossed Yang–Baxter関係にもη因子がある。g≠0のdefect twistはsymmetry-action gaugeで変わり、S行列の定義には相互不変なchargeと可換なg,hが必要。Gauge変更はR,U,ηを連動して変える。

**今回への適用:** 位相を省いて可逆語写像だけ比較する最適化は正当化されない。Measurement-only braidingへの言及も、今回のHMR回路に同じ基本操作を無料追加できる証拠ではない。

### VII

**根拠:** Eqs. (343)–(404); VII.A–VII.C

G-crossed Verlinde式とloop projectorを導き、torus上の各(g,h)セクター間を移すS/Tを構成する。Higher-genusのbranch配置はcommutator積がidentityである制約を持ち、ground-state degeneracyはfusionとη位相から決まる。

**条件:** 複数charge線を囲むprojectorには追加η積が必要。S/Tは全体でprojective表現であり、異なる外因的欠陥セクターを量子重ね合わせする演算ではない。各sectorのSユニタリ性とC0のmodularityを要する。

**今回への適用:** 整数SL(2,Z)のDehn twistやsector等価性はGF(2)出力変換のゲート費を与えない。特定の閉じたsectorでのみgauge不変となる量を、全入力のoperator等価と混同しない。

### VIII

**根拠:** Eqs. (405)–(453); VIII.C

有限Gをgaugingすると欠陥が脱閉じ込めされ、chargeはG軌道とstabilizer subgroupのη-projective irrepで分類される。Quantum dimensionはd_a×軌道サイズ×irrep次元、総次元は|G|D0。Fusionには頂点のprojective作用を含める必要があり、twistはdefect twistとirrep characterの積でgauge不変となる。

**条件:** 微視的Z2模型は各bondに新しいHilbert空間を追加し、大きなUによる低energy Gauss則へ射影する。一般有限Gの微視的構成は後続研究に残している。中央電荷一致はmod 8。S/TデータによるMTC一意性はこの本文ではconjectureと明記され、証明済みとして採用しない。

**今回への適用:** Gauge-invariant subspaceへの射影、追加自由度、低energy極限は、元の全Hilbert空間の厳密XOR回路同値を意味しない。別々にはgauge依存な位相の積を保持する考え方はHMR枝の監査に対応するが、実CCX削減は未導出。

### IX

**根拠:** Eqs. (454)–(466); IX.A.1–IX.C

有限オンサイトunitary Gの分類では対称性作用とH2 fractionalizationの後にH4 obstructionを確認し、消える場合にH3 defectification torsorが残る。さらにanyon/defectのrelabelingで同じSETに同定される場合があり、cohomology要素数は物理phase数と一致しない。

**条件:** 明示した3-cocycle変更が全解を尽くすことの全証明は本論文にはなく、引用数学定理を根拠にしている。PSGはcharge/fluxを交換する対称性等を捕捉しない。連続・空間・antiunitary対称性への完全分類は未完成で、有限オンサイトの定理を無条件拡張していない。

**今回への適用:** 候補の記述重複を除く原則には参考になるが、relabelingが固定された75語を保持することと実装費は別途示す必要がある。分類の個数をToffoli最小数や探索下界には使えない。

### X

**根拠:** Eqs. (467)–(491)

C0のanyonを置換しない対称性ではH3 obstructionが消え、各defect sectorにAbelian chargeを選べる。Fusionは2-cocycle wでtwistされ、F/R/U/ηを構成し、四欠陥pentagonからH4 obstructionの明示式を得る。

**条件:** 表示された明示解は途中からfusion multiplicity≤1に限定する。Pentagonを満たしてもheptagon込みの全G-crossed条件が満たせない場合があり、obstructionはwと元MTCのデータに依存する。

**今回への適用:** 一部の等式だけを満たす候補は完全なoperator同値を保証しないという監査上の示唆がある。CNOT/CCXの新しい積共有恒等式や128Q内のローダー回路はこの解からまだ得ていない。

### XI.A–D

**根拠:** Eqs. (492)–(534); XI.D.2

自明bosonic/fermionic phase、semionとZ2およびZ2×Z2対称性を具体的に構成する。Semionの一部fractionalizationではfusion categoryのpentagonを満たす解はあっても、braidingを含むG-crossed条件全体には解がなく、defectificationが阻害される。

**条件:** Fermionic C0は非modularなので、modularityを用いた前節の一般分類をそのまま適用しないと本文が注意する。Z2でηをgauge-fixできることも、他のR/Uデータを固定したまま位相だけ消せる意味ではない。

**今回への適用:** 出力語だけの一致や一部回路identityの検査では相対位相の正当性を保証しないという具体的類例である。Semion位相を今回の許可されない任意位相ゲートとして持ち込むことはできない。

### XI.E–H

**根拠:** Eqs. (535)–(598)

Ising、巡回群anyon、奇数・偶数NのZ2作用を分類する。巡回群の素因数分解に沿ってanyonモデルと対称性を分け、作用がfactorを交換しない場合はgluingで再構成する。偶数Nの一部ではdefect relabelingにより見かけ上4通りの分類が3通りに同定される。

**条件:** 素因数分解の写像にはmodular arithmeticとF/Rのgauge変更が含まれる。Nが偶数か奇数か、gcd条件、charge conjugationの固定点、fusion multiplicityを区別する。本文中には残されたTBD表記や隣接説明との不整合があり、全式を独立検証したわけではない。

**今回への適用:** Factor化できる対称性と、factorを混ぜる作用を区別する発想は合成探索に参考となる。ただし固定語表の77×16分割がこの数学構造を持つ証明はなく、Chinese remainder変換を無料CNOTへ変換した実装もない。

### XI.I–K

**根拠:** Eqs. (599)–(665)

Toric codeの電磁双対、ZN toric code、および同一の二層を交換するZ2対称性を解析する。Toric codeではvertex gauge変更がR-symbolにも作用し、defect Fだけを任意に選べない。二層交換では対称性fractionalizationが自明となることを示し、gauged phaseのcharge数と高genus縮退を導く。

**条件:** 二層模型は独立の二つの物理層を備えたHilbert空間であり、未知の任意入力をコピーする回路ではない。相の同一視にはcharge relabelingとgauge変更を伴う。抽出でconjugation barが落ちている式は符号を推測して再利用しない。

**今回への適用:** 表記上の二層分解やgauge自由度だけでは、任意ターゲットXORとclean ancilla条件を満たすコピー・uncomputeのゲート費は消えない。

### XI.L–N

**根拠:** Eqs. (666)–(799); especially (685)–(700), (778)–(797)

D(S3)および3-fermion SO(8)1の例では、ラベルが固定されても対称性作用で−1を受ける状態があり、gauging後の縮退計数から除く必要がある。Fusion multiplicity空間でも非自明な行列作用が残る。最後のRep(D10)例はfusionとmodular dataを保つ置換でもfractionalizationが阻害されうることを示す。

**条件:** S3をZ3と残りZ2に順次gaugingする例のfusion規則にはheuristic導出が明記され、全Ukを解いて一般公式へ代入した独立導出ではない。Rep(D10)は非modularで、H3 classとの直接同定にはmodular quantum doubleへの埋め込みを使う。

**今回への適用:** 今回に最も近い示唆は、bit値や固定点だけの照合に加え、測定枝と任意入力の相対位相を追跡する必要性である。例中の負位相の控除を、ローダーの減算や積共有の実ゲート削減と解釈しない。

### Appendices A–C

**根拠:** Eqs. (A1)–(A10), (B1)–(B15), (C1)–(C2)

Group cohomology、同じfactor setを持つprojective表現のcharacter orthogonality、G-crossed理論の対角G-gradingによるgluingを整理する。Projective表現のtensor productではfactor setも積になり、異なるfactor set間には自然なdirect sumがない。

**条件:** Gluingが全extensionを得るという主張は、対称性作用が二つのfactor間のchargeを交換しない場合。Characterは普通の表現と違い、単なるconjugacy classの関数にはならず位相が必要。

**今回への適用:** 共有積や共同合成を類推するだけでは足りず、具体的な演算空間と位相の対応を示す必要がある。多出力Boolean tensor rankやCCX数をこのfusion-category次元から計算できない。

### Appendix D; endnotes

**根拠:** Theorems D.1–D.5; D.5 New Mathematical Results; endnotes 175–192, especially 176 and 190

Categorical functorのliftingとしてH3/H4 obstructionとtorsorを整理し、gaugingとcondensation、normal subgroupからの逐次gaugingを記述する。厳密化で対象数を増やす記述と、skeletal化して位相を明示する記述は一般に同時に実現できないと説明する。

**条件:** D.4/D.5の証明は引用文献へ送り、D.5はgauged twistの式をconjectureと表現する。脚注176は全BTCでの自然同型とgauge同値の関係を仮定として明記し、一般証明は与えない。脚注190はfermion parityのmodular extensionと本論のG-crossed extensionを区別する。

**今回への適用:** 数学上の厳密化による演算の自明化が、固定した量子bit数とゲート集合で無料になるわけではない。今回の公式費用は実回路CCX等で測り、記述の単純さやT-depthと区別する。
