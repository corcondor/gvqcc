"""Local reading ledger for the assigned thirteen graphene references."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
DEST = BASE / 'graphene_supplement_43_56.json'
ASSIGNED = [n for n in range(43, 57) if n != 50]
EMBEDDED_GAP_STATUS = 'main_prose_complete_with_embedded_source_gaps'
REFERENCE_STATUS_OVERRIDES = {47: EMBEDDED_GAP_STATUS}


def add_review(number, ranges, scope, results, limitations, *, version=None,
               status='main_text_complete', applicability=None, retrieval=None):
    assert number in ASSIGNED
    originals = json.loads((BASE / 'graphene_refs_29_56.json').read_text())['references']
    old = next(r for r in originals if r['number'] == number)
    source = BASE / 'graphene_refs' / ('ref_44_preprint.md' if number == 44 else f'ref_{number:02}.md')
    txt = source.read_text()
    assert all(0 <= a < b <= len(txt) for a, b in ranges)
    status = REFERENCE_STATUS_OVERRIDES.get(number, status)
    row = dict(number=number, citation_exact=old['citation_exact'],
               primary_url=old['primary_fulltext_url'], local_cache=str(source),
               source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
               source_characters=len(txt), read_character_ranges=ranges,
               read_scope_ja=scope, combined_review_status=status,
               prior_reviewed_scope_ja=old['reviewed_scope_ja'],
               results_and_assumptions_ja=results,
               applicability_ja=applicability or '今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。',
               limitations_ja=limitations, reviewed_version=version,
               full_extracted_text_read=False, demonstrated_gate_saving=False)
    if retrieval is not None:
        row['retrieval_scope_ja'] = retrieval
    report = json.loads(DEST.read_text()) if DEST.exists() else dict(
        title='Graphene bibliography: supplemental main-text review, 43–56 excluding 50',
        review_date='2026-11-15', reviewer='shared_synthesis',
        assigned_numbers=ASSIGNED, retrieval_is_not_reading=True,
        reading_rule='Character ranges are Unicode half-open intervals in the unchanged source cache. Main-text completion includes the main-paper Methods but does not imply reading separate supplements or all references.',
        display_rule='In some HTML-cache excerpts link targets were suppressed for readability; scientific prose, equations, and extracted captions were retained.',
        figures_and_equations='Extracted prose, equations, and captions were read; figure pixels and every algebraic identity were not independently verified.',
        references=[])
    report['references'] = sorted([r for r in report['references'] if r['number'] != number] + [row], key=lambda r:r['number'])
    report['completed_main_text_numbers'] = [r['number'] for r in report['references'] if r['combined_review_status']=='main_text_complete']
    report['main_prose_complete_with_embedded_source_gaps_numbers'] = [r['number'] for r in report['references'] if r['combined_review_status']==EMBEDDED_GAP_STATUS]
    report['not_yet_recorded_numbers'] = [n for n in ASSIGNED if n not in [r['number'] for r in report['references']]]
    DEST.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n')
    out = ['# グラフェン引用43–56の本文補完（50を除く）\n',
           f"指定13件中、記録済み{len(report['references'])}件、主本文読了{len(report['completed_main_text_numbers'])}件、本文文章は全節読了したものの埋め込み資料に取得欠落があるもの{len(report['main_prose_complete_with_embedded_source_gaps_numbers'])}件です。本文末のMethodsを含め、別付録・補足資料の未読部分を個別に記録します。\n",
           '取得と読解を区別しています。全図の画像照合、数値再現、全式の独立再証明はしていません。新しい回路実装やToffoli削減は行っていません。\n',
           '|番号|本文の読解状態|実読範囲（Unicode文字、半開区間）|\n|---|---|---|']
    for r in report['references']:
        out.append(f"|{r['number']}|{r['combined_review_status']}|{r['read_character_ranges']}|")
    for r in report['references']:
        out += [f"\n## [{r['number']}]\n", r['citation_exact']+'\n', '[一次本文]('+r['primary_url']+')\n',
                '**確認した版:** '+str(r['reviewed_version'])+'\n',
                '**今回の実読範囲:** '+r['read_scope_ja']+'\n',
                '**従前の既読範囲:** '+r['prior_reviewed_scope_ja']+'\n',
                '**結果と仮定:**\n']
        out += ['- '+p for p in r['results_and_assumptions_ja']]
        out += ['\n**今回の回路への適用:** '+r['applicability_ja']+'\n', '**未読範囲・限界:**\n']
        out += ['- '+p for p in r['limitations_ja']]
        if r.get('retrieval_scope_ja'):
            out += ['\n**取得範囲:** '+r['retrieval_scope_ja']+'\n']
        out += ['\n**SHA256:** `'+r['source_sha256']+'`\n']
    (BASE/'graphene_supplement_43_56.md').write_text('\n'.join(out))
    print({'recorded':len(report['references']), 'main_text_complete':len(report['completed_main_text_numbers']), EMBEDDED_GAP_STATUS:len(report['main_prose_complete_with_embedded_source_gaps_numbers']), 'remaining':report['not_yet_recorded_numbers']})
