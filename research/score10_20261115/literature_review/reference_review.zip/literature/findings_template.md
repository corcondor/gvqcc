# 指定4リンクと参考文献：実装に使える内容と条件

**参考になる。今回の合成に近いのは、CCZの位相多項式、複数ゲート間の相殺、測定結果ごとの補正、GF(2)の位相追跡である。** 実際に図のCCZ回路を実装・検査したが、単体置換では今回の費用は下がらなかった。参考文献の全項目には一次資料・読解範囲・要点・適用判断を付け、以下の台帳に整理した。

<!-- READING_COUNTS -->

取得した文書は全文読了と同じではない。「抽出テキスト全読」はその版の本文・付録等の取得テキストを読んだ意味であり、全図の画素確認、全証明の独立再導出、全実験の再現までは含まない。「本文全節」は別途列挙した付録・補足に未読が残る。graphene[31]・[32]・[47]は本文文章の全節を読んだが、埋め込み表・画像数式に取得欠落があるため別区分にした。公開previewだけの確認も別に集計した。**全171項目を、すべてのページ・図・付録まで同じ深さで読んだとは主張しない。**

## 指定された4リンクの対応

| リンク | 実際の出典 | 今回の用途 |
|---|---|---|
| CCZ分解の図 | Zhang & Zhang, Classical Simulability of Quantum Circuits with Shallow Magic Depth, Figure 3 | Selingerの7T位相分解と、4補助ビットを使うT-depth-one化を点検する |
| Notation used throughout | Shen & Zhong, The resource cost of magic in a code block | postselection・測定枝ごとの資源と、符号ブロックの仮定を点検する |
| Atomic-Scale Imaging… | Jiang et al., arXiv:2609.39986 | 格子緩和・flat band・domain-wall stateの物性研究。現在のローダーの回路恒等式は確認できない |
| Classical Simulability…本文 | 上のCCZ図と同じ親論文 | 古典模擬が容易な量と難しい量、誤差の定義を区別する |

一次資料: [Shallow Magic Depth v2](https://arxiv.org/html/2409.13809v2)、[Code block v2](https://arxiv.org/html/2608.29438v2)、[Graphene PDF](https://arxiv.org/pdf/2609.39986)。

主論文の参考文献はv1で55件、公刊版/v2で61件。v2は7件を追加し、旧v1の55番を削除しているため和集合は62件となる。記号表の出典には53件、グラフェン論文には56件の番号付き文献がある。図と本文を別論文として二重計数していない。親論文同士で共有する原著5組は、各文献欄の項目数にはそれぞれ含めた。

## CCZ図は正しいが、単体置換の費用は増える

Selingerの構成は

\[
4abc=a+b+c-(a\oplus b)-(a\oplus c)-(b\oplus c)+(a\oplus b\oplus c)
\]

を使い、3入力と4個の補助ビットに7個のT/T†を並列に適用する。[原著](https://www.mathstat.dal.ca/~selinger/papers/toffoli.pdf)

この図を実KMBへ起こし、全8入力で位相・データ保持・補助ビット消去を検査した。native CCZは3量子ビット・1 Toffoli相当、図の構成は7量子ビット・7Tで、Invsqrtの実効費用では1.75 Toffoli相当となる。今回の採点にはT-depthの項がない。Chemistry/DQIではTの実装に使うZ_POW自体を使えない。検査のソースと結果は `score10_experiments.zip` 内の `literature/ccz_figure3_resource_check.{py,json}` に収録した。

参考になる点は、**隣接する複数ゲートをまとめたときに位相項が相殺できるか**という見方である。単一ゲートの深さ削減から、全ローダーのToffoli削減が得られるとは限らない。

## 実装判断に特に効いた参考文献

以下の「主」は主論文公刊版/v2の番号、「符号」は記号表の出典の番号を表す。

| 文献 | 読解から得た具体的な接点 | 適用時の条件 |
|---|---|---|
| 主35：Selinger, Quantum circuits of T-depth one | パリティに作用する位相の分解、T項の相殺、補助ビットを使う並列化 | T-count・深さ・幅を分けて数える。上記の実回路では単体置換は不利 |
| 主36／符号27：Dehaene & De Moor | GF(2)の線形変換と二次形式でClifford操作・位相を記述 | 真理値表だけでなく位相を追う。rankだけをToffoli費用とは扱わない |
| 主42：Gidney & Jones, A CCCZ gate performed with 6 T gates | 同じ補助ビットへ計算する二つの積の間でTを相殺し、測定消去を使う | 4量子ビットのCCCZ。H等を含む図の操作、補助ビット、補正を現在の命令へ実装する必要がある |
| 符号15：Howard & Campbell | 測定・Clifford補正を含むmagic-state合成と資源下界。CCZを4Tで実装する構成 | 4Tは今回1 Toffoli相当。native CCZを単体で上回ることにはならない |
| 主10：Childs et al. | 具体的なSELECT等の回路で共通制御や極性変更を共有する最適化 | 誤差を許すHamiltonian近似と、厳密なBooleanローダーを区別する |
| 主31：Maslov et al. | 三次位相の一部変数を固定し、残りを二次GF(2)問題として扱う | 古典的な分岐計算の速さと、coherentなアドレス分岐の実回路費用は別に評価する |
| 符号19：Gidney et al., Magic state cultivation | ノイズのある物理系でT資源状態を効率的に準備する具体的構成 | “as cheap as CNOT”は物理ゲート・信頼性の比較であり、今回Tを無料にする規則ではない |
| 符号23：Vaknin et al. | Fredkin=1 CCZ＋2 CX等の構成と、surface-codeでのcultivation | 既に用いているCSWAPの実効費用と整合するが、追加の1ゲート削減にはならない |
| 符号44：Yoshioka et al. | syndromeごとの既知論理回転と補正。既存のパリティ計算に回転を組み込む構成 | 結果確率が入力情報を漏らさない条件、分岐補正、物理誤差・工場費用の設定を確認する |
| 符号52：Heimendahl et al. | stabilizerを保つ抽象channelと、実際のClifford・Pauli測定・古典制御による操作が一致しないことを示す | magic非生成という性質だけでは、許可命令による安価な可逆回路が得られない |
| 主51・53 | 少数non-Cliffordで準備した状態の学習・記述と、準備回路への再合成が別問題であることを明示 | 状態の圧縮・学習結果を、任意入力に作用するローダーのコンパイラとは扱わない |
| 主60・61 | magicを保持したままClifford×積状態/MPSへ表現を変え、古典模擬を効率化する | 初期状態と自由量子ビットの条件がある。MPSのGF(2)rankとローダーの双線形rankを混同しない |

一次資料: [GF(2)とClifford](https://arxiv.org/pdf/quant-ph/0304125)、[6T CCCZ](https://arxiv.org/pdf/2106.11513)、[Howard–Campbell](https://arxiv.org/pdf/1609.07488)、[Childs et al.](https://arxiv.org/pdf/1711.10980)、[IQP模擬](https://arxiv.org/pdf/2402.03211)、[Cultivation](https://arxiv.org/pdf/2409.17595)、[Surface-code cultivation](https://arxiv.org/pdf/2502.01743)、[Syndrome-resolved gates](https://arxiv.org/pdf/2510.08290)、[Operational/CSPの相違](https://arxiv.org/pdf/2011.11651)、[状態学習](https://arxiv.org/pdf/2305.13409)、[t-doped learning](https://arxiv.org/pdf/2305.15398)、[Disentangling](https://arxiv.org/pdf/2410.09001)、[CAMPS](https://arxiv.org/pdf/2412.17209)。

## 主論文の「古典模擬できる」の範囲

主論文は振幅、サンプリング、Pauli期待値を区別する。T層が1つでも、乗法誤差の振幅推定・サンプリングは計算量の仮定の下で困難であり、Pauli期待値の評価は容易になる。誤差を1/poly(n)の加法誤差へ緩めた結果や、小さいmarginalのサンプリングも別に示している。[主論文](https://arxiv.org/abs/2409.13809)

この区別は検証法の選択には役立つ。だが、限定した観測量を古典的に計算できることから、同じ全ユニタリを少ないCCXで実現する回路は自動的には得られない。今回必要な条件は、許可された到達可能状態でのcoherentな作用、正しい出力、作業領域の消去、測定結果ごとの補正まで含む。新しい19本はそれより強い任意32標的ビットのXOR特性まで検証した。

測定消去で中間値f(a)を消すと、結果rに依存する位相が残り得る。値が合っているだけでは不十分であり、その位相も除く必要がある。fが二つのパリティの積ならCliffordの位相補正に落ちる場合があるが、パリティ以外の制御や非線形座標を作る費用は別途必要になる。ここが多出力共有と補助ビット再利用を評価する実装上の接点である。

## 記号表とグラフェン論文の読み分け

記号表の出典は、1論理量子ビットを含む符号ブロックのpostselected measurementを扱う。主要な抑制結果には、bounded-spreadな厳密回復構造、符号距離に比例する閾値、制約された弱い局所資源などの仮定がある。成功確率を含めてaccepted magicを評価するため、稀な成功分岐を無料で増幅できるという話ではない。今回の改善境界である4170以下を達成する構成や、固定QROM一般のToffoli下界を与える定理ではない。[一次資料](https://arxiv.org/pdf/2608.29438v2)

グラフェン論文のmagic angleは層のねじれ角を指す。局所STM/STS等で格子緩和、flat-bandの電子テクスチャ、domain-wall stateを調べた研究である。本文は、今回の測定だけでは境界状態のトポロジカルな起源やChern inversionを確立しないという限界も述べる。参考文献の模型縮約、chiral limit、低エネルギー射影は、元模型についての近似・対称性仮定を伴う。固定された75語の厳密表を書き換える回路恒等式としては使えない。[一次資料](https://arxiv.org/pdf/2609.39986)

## 書誌と読解の注意点

- 主論文のSelingerは旧v1[34]、公刊版/v2[35]。他の番号も版の差で動くため、旧番号対照を保存した。
- 記号表の出典の[52]は誌名・巻・DOI表記に不整合がある。著者と題名が一致する arXiv:2011.11651 および Journal of Mathematical Physics 63,112201 (2022), DOI 10.1063/5.0085774 の本文で照合した。
- 符号[23]は取得したv4 PDFの表紙題名とarXiv abstractページの題名に相違がある。読んだPDFの版・表紙日付・SHAを固定し、表示メタデータだけで別版の全文を読んだことにはしていない。
- グラフェン[19]は公刊版とプレプリントの題名・数値が異なる。取得して読んだプレプリントではgap最大17 meV、公刊abstractでは19 meVであり、混ぜずに記録した。
- 主[14]は出版社previewの2頁のみ取得できた。残り6頁を読んだとは扱わない。主[43]は質問と全回答本文を読んだが、回路画像4枚は未取得である。
- グラフェン[31]のTable 1、[32]の画像化数式、[47]のHTMLで欠けた数式は未取得。[47]の訂正告知の内容も未確認として残した。これらの文献は本文文章の通読と、全数式・表の確認を分けている。

これらの書誌上の注意は、論文全体を否定する判断ではない。本文に書かれたモデル、版、誤差、情報へのアクセス条件を、現在の実装の契約と取り違えないために記録した。

## 今回の合成への結論

19本の共同合成で得た5182は、改善境界4170まで **1012 Toffoli** 多い。文献から得た回路を採用するには、中間値の共有で減る量が、準備・戻し・測定補正・追加幅の費用を上回る必要がある。T-depth、stabilizer rank、状態のmagic、古典サンプリング時間の改善だけでは採用しない。

比較基準 **27.32784222155277** は維持している。図の実装と各候補の検証記録を保存したが、新しいフル公式PASSや新スコアは得ていない。具体的な回路と正しさが確認できた成果は、19本のJ=4族、費用選別のコード、およびInvsqrtの45量子ビット位相部分である。
