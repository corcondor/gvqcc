# 主論文参考文献の最終本文補完

この台帳の区間は今回実読した追加区間。本文完了は既読区間との合算であり、付録・画像・独立再証明を含むという意味ではない。

## [1] main_text_complete

**一次資料:** <https://arxiv.org/pdf/1011.3245>

**追加読解範囲:** 追加で§1後半（1.3–1.4を含む）から§§2–11までの連続186,238文字を通読。前担当の冒頭約28,000文字に1,000文字以上重ね、主本文全節・本文内の全証明・実験手順・open problems・謝辞を確認した。取得版は arXiv:1011.3245v1 (2010-11-14)、STOC2011の長編著者版。

**結果と仮定:** 非相互作用 boson の物理定義・多項式/Fock内積・永久行列式を用いる定義の同値を構成し、標準入力からの非適応 photon-number sampling を扱う。厳密 classical sampling ⇒ P^#P⊆BPP^NP を、signed permanent の乗法近似困難性＋Stockmeyer と postselected KLM の二通りで導く。近似 sampling からは Gaussian 行列の |Per(X)|² の ε n! 加法推定をBPP^NP内へ帰着し、PH collapse には Gaussian permanent の平均時乗法近似困難性および anti-concentration の追加予想が必要。Haar truncation と Gaussian の近さは m≥n^5 δ^-1 log²(n/δ) の証明範囲で、m=O(n²)への改善はこの版では未証明。§7 は小さい複素平行移動と triangulation で位相を回収し、oracle 精度と失敗確率を制御。§8は determinant の反集中と permanent の弱い確率下界を証明するが PACC を証明しない。§9はGaussian permanent の exact/指数高精度平均時困難性を示し、通常の低次数補間だけでは多項式相対精度へ進めない障壁を説明。

**実装への適用:** 適用上は、sampling・単一出力確率・任意入力 coherent oracle を区別するための基礎。§6.3 の O(mn) optical elements / O(n log m) depth 構成は既知の標準入力、最初のn列、追加n modes を使う state preparation で、未知の任意入力に同じunitaryを実装する定理ではない。J=4 loader の4170という改善境界やToffoli最適下界を与えず、postselection を無料操作としてKMBへ持ち込めない。加法精度が指数的に小さい出力確率の相対精度を保証しないという区別は公式一致判定や誤差予算に関係する。

**限界:** Appendix12 は前担当が冒頭約5,000文字のみ確認済みで、残りとAppendix13は未読。本追加台帳は主本文完了であり93頁全体の全文読了ではない。図は本文・キャプションで読解し全画像の個別確認はしていない。理論の証明読解と独立再証明・現在の実験性能検証を区別する。2010版の機器性能・実験未実施の記述・予想の状態を2026年の事実として扱わない。近似 sampling のinputは誤差逆数をunaryで与えるFPTAS型であり、任意の固定誤差での困難性までこの本文から主張しない。

**SHA256:** `fc4dfb73bfac7df411766782cf545690a3f01d91d221284109585af6a064696c`

## [2] main_text_complete

**一次資料:** <https://arxiv.org/abs/1309.7460>

**追加読解範囲:** 追加で §§5–8（§7.1・§8.1、全補題・定理の証明を含む）および謝辞を通読。既読の Abstract・§§1–4 と §9 を合わせ、主本文の全節を確認。本文は arXiv:1309.7460v2 (2013-10-01)。

**結果と仮定:** 一般の検証と、出力ラベルを捨てる symmetric verifier を区別。Haar 行列・m≥n^5.1/δ・十分大きな n の範囲で BosonSampling の衝突なし分布と一様分布の定数全変動距離を示す。行ノルム積 R*=Π_i||row_i(X)||²/n^n は O(n²) 計算で一様との定数バイアス識別を可能にする。証明は複素 Gaussian の行方向とノルムの独立性、P=Q R*、log χ² の累積量と Berry–Esseen、Haar 部分行列近似に依存。m≈n² は予想で、証明された範囲と区別。情報理論的サンプル数と計算時間は別問題。

**実装への適用:** 特定の偽分布を排除する統計と、回路の全入力・位相を検証することは別の保証。R* は永久行列式の高精度近似器ではなく、KMB oracle を合成する方法にもならない。GVQCC の全アドレス一致やコヒーレント入力の位相検証を、少数の統計量一致へ置き換える根拠にはならない。

**限界:** Appendices 11–13 は今回通読していない。本文自身、R* だけでは distinguishable-particle の mockup M_A、FermionSampling、独立行サンプリング B_A を排除できず、量子干渉さえ証明しないと明記。§8.1 のこれら別分布の他の統計での排除については future work の未証明部分を含む。過去の実験規模・計算時間見積りを現在値と扱わない。

**SHA256:** `7770d3746e4e32ff79af1faf216d229aca66162d7fa22ba68a3c441b477815ad`

## [6] main_text_read_with_extraction_gaps

**一次資料:** <https://math.mit.edu/~shor/papers/algsfqc-dlf.pdf>

**追加読解範囲:** 著者公開1994 FOCS 論文の既存抽出テキストを全49,828字通読（抽出は頁順が逆、§§1–7・謝辞・全参考文献の文字列を含む）。ただし数式の記号に大量の OCR/フォント抽出欠損があるため、このテキストだけから原論文の数式全体を読了とは扱わない。親エージェントが別途同じ一次 PDF の全11頁画像を論理順で読了し補完したことを報告済みで、その視覚証拠は shallow_root_final_supplement.json に保存される。

**結果と仮定:** 可逆古典計算、局所ユニタリ、smooth modulus の Fourier 変換を組み合わせ、order finding から整数因数分解への確率的帰着と、離散対数の smooth な簡単な場合・一般の場合を構成。Fourier 測定の良好出力、連分数による周期回収、互いに素条件の成功率・繰返し、一般離散対数の近い smooth modulus と Chinese remainder の回収手順を説明する。精度節は各振幅/位相の有限誤差を全計算の成功確率に伝播させ、多項式精度で十分とする。これは既知の入力サイズに関する漸近的アルゴリズムで、全古典計算に対する無条件指数分離ではない。

**実装への適用:** 可逆計算で入力を保持し、不要な作業情報の消去に可逆性と逆写像を要する原則、位相誤差を全演算に累積させて見積る必要性は KMB 合成にも関係する。ただし Fourier サンプリングで数論解を回収するアルゴリズムを、そのまま固定された任意入力 oracle や75語のロードに置き換えることはできない。本文の polynomial は現在の有限 Toffoli・幅スコア改善を保証しない。

**限界:** この担当者による全テキスト読解には数式抽出欠損が残る。combined_review_status は本台帳単独では main_text_read_with_extraction_gaps とし、親の同一 PDF 全11頁画像確認記録との合算でのみ full 完了へ更新可能。1996年の長い Shor 論文 [8] と1994年の本資料を同一版として代用しない。

**SHA256:** `b113a0cbf7213f91b106c34428bed4d8b1520c5171d4fd14df901c8642de1597`

## [18] main_text_complete

**一次資料:** <https://www.rintonpress.com/xxqic14/qic-14-78/0683-0720.pdf>

**追加読解範囲:** 追加で §2（stabilizer formalism・canonical form・simulation・cofactor・quadratic form）、§3（全小節、計数・極限・bivector・線形依存の証明）、§§6–7 と謝辞を通読。既読の Abstract・§1・§§4–5 と合算し、主本文全節の結果・アルゴリズム・証明を確認。

**結果と仮定:** n独立 commuting Pauli generators による状態表現、Gaussian elimination の canonical generator 形、Clifford conjugation と測定を説明。異なる非直交 stabilizer の overlap は2^(-k/2)、nearest neighbors は4(2^n−1)、k-neighbor の計数とほぼ直交への集中を導く。状態を基底状態へ移す5ブロックの Clifford 正規化回路は O(n²) gates、内積計算は一般 O(n³)、構造化入力では O(n²) の実験傾向。実験は20–500qubit、βceil(n log2 n) の random Clifford gate 生成で entanglement を変化させる。最寄 stabilizer の local search が一般に保証されないこと、poly-size stabilizer 重ね合わせで近似できない unbiased 状態族を示す。

**実装への適用:** Clifford 部分の位相付き正規化・内積・cofactor 処理は回路の独立検証や表現改善に使える。状態 preparation を canonical 化して得る Clifford gate 削減は、非線形 Boolean loader の CCX 削減と同一ではない。stabilizer の線形結合を短く表現できることも、その和を低コストのコヒーレント oracle として実装する保証ではない。KMB の入力領域・測定分岐・相対位相を含む同値性は別途必要。

**限界:** Appendix A の全1080個の3qubit stabilizer 列挙表は未読。本文中の表と図キャプションは抽出で読んだが、全図のピクセル確認・各証明の独立再証明や実験再実行はしていない。global phase を正規化した幾何の議論を、制御された回路や coherent branches の相対位相を無視する許可として扱わない。

**SHA256:** `51cba2557730cadd1f7ea8c8648cecea40a4fa655de3a8e514ff7c9532350b09`

## [39] main_text_complete

**一次資料:** <https://deepblue.lib.umich.edu/bitstream/2027.42/107198/1/hjgarcia_1.pdf>

**追加読解範囲:** 追加で Chapter I 冒頭〜§1.6、Chapter II 冒頭・§§2.1–2.2、Chapter III 冒頭・§3.1 全小節を通読。既読201,041文字（表紙・目次・Abstract、§§1.7–1.8、§§2.3–2.5、§§3.2–3.3、Chapters IV–VIII 全文）へ137,121文字を追加。合算で主本文 Chapters I–VIII の全節・本文内の全証明を読解。主本文は文字区間[29497,356596)をすべて覆う。

**結果と仮定:** 追加範囲では strong/weak と direct/stateless simulation を分離し、Pauli stabilizer と Clifford conjugation、deterministic/random measurement、Z2 affine support＋quadratic phase、canonical generator 操作、状態の global phase の8乗根、stabilizer 近傍・Gramian による線形依存を確認した。§2.2.3.3 は5ブロック H–C–X–P–CZ の状態準備が |0^n> に限ることを明記し、HPH がこのテンプレートへ同じ行列として移せない例を示す。既読の後半では、複数の符号ベクトルで生成元行列を共有する frames/multiframes、cofactor・coalescing、p-blocking、Pauli 観測量の逆伝播とその項数増大を扱う。

**実装への適用:** 具体的な利用先は古典検証器での生成元共有・位相追跡・小さな Clifford 部分の正規化。各 stabilizer 成分の global phase は線形結合内で相対位相となるため、KMB の HMR 分岐の証明でも捨てられない。|0^n> から同じ状態を作ることと、任意入力に同じ作用をする回路を作ることを区別する本文の条件は今回の oracle に直結する。frames の古典メモリ圧縮や特定入力に対する adder の高速 simulation は実量子回路の CCX 除去にはならない。

**限界:** 主本文完了は抽出テキストの実読を指し、Appendix A の1080状態一覧、末尾参考文献の全一覧、front matter の図表一覧[8130,26564)は未読。図はキャプション・抽出文字を確認したが全ピクセルの個別視認はしていない。本文の式には位相を含むPauli群と位相を除く基底の記法、正規化係数など簡略・不整合な表現があり、証明の独立再現はしていない。5ブロック state synthesis や destabilizer を省いた議論を、任意入力 oracle の等価性の証明へ直接流用しない。

**SHA256:** `ff96c5a970a82a0e36a27ac5f76fa5bd16322207a45e93e7fda3ec090033c47a`

## [44] main_text_complete

**一次資料:** <https://arxiv.org/pdf/quant-ph/0301052v2>

**追加読解範囲:** II Gの全7小節、恒等ゲート、隣接X測定の除去、X/Z/一般Euler回転、H/S、CNOTの相関・byproduct導出を含む20,674文字を追加実読。親のAbstract/I/II A/Dと先の自分のII B/C/E/F/H/I・III–VI読解と合わせ、本文I–VIの全節を読了。先の範囲はroot_reference_supplement_cost.jsonに保存済み。

**結果と仮定:** 測定projectorと可換なcluster相関が測定後にも保存されることを用い、入出力のX/Z相関を順に構成する。3-qubit chainはPauli補正付き恒等、片側1辺はHとなる。wire内の隣接2個のX測定は、周辺が空きsiteまたはZ測定という条件下で縮約できるが、結果依存のstabilizer符号を残す。一般回転の適応角は以前のX測定結果によって符号が変わり、Clifford H/Sの場合はPauli測定だけで同時実行できる。CNOTは4種類のPauli共役像と全測定結果の符号を照合して示す。

**実装への適用:** パリティや基底写像だけでなく、測定結果から生じる符号と後続ゲートへの伝播まで残すことが必要。隣接測定の削除を任意の作業ビットの無料消去へ一般化しない。以前に整理した7T/幅の費用判断は変わらない。

**限界:** Appendix A（cluster decomposition）は未読。全図の原画像を個別視認・全恒等式を独立に実装検証したわけではない。本文内の帰納・相関証明は読んだが、読了と独立証明を区別する。

**SHA256:** `67e7c4f6dca4e6e9a7baebc5af2582c7da82bcf1c30ce7152203dcea6a3a7bd1`

## [v1-only-55] main_text_complete

**一次資料:** <https://arxiv.org/html/2404.14493v2>

**追加読解範囲:** 追加で§2の全定義・Lemma・Theorem・証明、§3の数値最適化手順と全caption、§4の限界・将来課題、§5謝辞を実読した19,428文字。親のAbstract/§1全文と合わせ主本文全節を完了。今回読んだ版は取得済み2026-08-24改訂のarXiv v2であり、旧主論文v1に引用された2024年時点の版と同一だとは扱わない。

**結果と仮定:** well-spread random-circuit ensembleでは平均collision probability≤γ/2^nからδ-peaked回路の出現確率≤γ/(δ² 2^n)を得る。深いrandom回路に1/poly(n)のpeakednessを作る追加層の下界は、approximate unitary designとstrong state complexityの既知定理を用いた漸近的Ω((τ_r/n)^0.19)。固定gate集合・回路ensemble・初期状態・ancilla-free measurementによる識別という定義に依存する。数値部は1D brick wallのHaar 2-qubit層にparameterized peaking層を足し、|<0|C(θ)|0>|²をgradient optimizerで最大化する。small-nでピークを増やせるが、system sizeとともに平均peak weightは指数減少し、指数改善は数値的予想として扱う。

**実装への適用:** 特定のoutput weightを増やすことと、固定Boolean写像を全入力で同じに保つことは異なる。strong complexityによるrandom-state下界を固定75語のToffoli下界へ転用できない。最適化による相殺探索の動機にはなるが、回路を厳密に短くしたという構成やスコア改善は与えない。

**限界:** Appendix Aの2層回路に関する平均ピーク証明と参考文献表の全読は未実施。本文の全数式を独立再導出・数値コードを再実行していない。効率的なpeaked回路生成と古典的秘匿性は未解決条件。50-qubitで約5e−4という数値は小規模fitの外挿と条件付き可能性であり、実機達成値ではない。barren plateauによりoptimizerは制限され、最良初期化選択も使っている。

**SHA256:** `15bd4815b5664cb340db35c0d4799e5c0a1c1c150a6d7fd31f310f04718eef69`

