"""Record the root reviewer's actual reading scope, without equating retrieval with reading."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
BIB = json.loads((BASE / 'main_references.json').read_text())
ROWS = [
 (44, 'ref_44.md', 'https://arxiv.org/pdf/quant-ph/0301052', 'selected_sections',
  'Abstract・I、II A の cluster preparation/correlation、II D のゲート連結と byproduct。32頁全体・残りの証明は未読。',
  'Cluster state を準備し、適応的な1量子ビット測定で計算する。論理ゲートは測定結果依存の Pauli byproduct を伴い、後続測定基底へ反映する。',
  '測定分岐を含む等価性の確認には参考になる。H、任意測定基底、cluster preparation を現在の命令へ実装する費用が必要で、既存ローダーの直接置換ではない。'),
 (45, 'ref_45.md', 'https://www.scottaaronson.com/papers/pp.pdf', 'full_extracted_text_complete',
  '著者公開PDF全9頁。PostBQP=PP の証明、閉包性、関連する非線形・postselection議論まで。',
  'PostBQP=PP を示し、確率が指数的に小さい非零分岐でも条件付けできる計算モデルの強さを特徴づける。',
  '望ましい測定結果だけを残すことと、全測定分岐を補正して同じ coherent oracle を得ることを混同しないための根拠。'),
 (46, 'ref_46.md', 'https://www.nature.com/articles/s41586-019-1666-5', 'main_text_complete',
  '出版社の本文 Main から The future まで。classical computational cost・digital error model・図説明を含む。別ファイルの Supplementary Information は未読。',
  '53量子ビットの超伝導プロセッサで random circuit sampling と XEB を実施。古典費用は2019年時点のアルゴリズム・計算機に対する外挿である。',
  'XEB とハードウェア忠実度は全入力の厳密一致証明ではない。歴史的な古典時間見積もりを現在の性能や論理ゲート費用に流用しない。'),
 (47, '2005.01510.md', 'https://arxiv.org/html/2005.01510', 'full_extracted_text_complete',
  '本文 I–III と Appendices A–C。IQP 相関推定、secret strings、GF(2) scrambling、乱択解析を含む抽出全文。',
  'IQP の秘密相関に基づく認証案。theta=pi/8 では Pauli 相関計算が Clifford に帰着し、一般角には加法誤差の推定を使う。厳密な安全性証明は未完と明記される。',
  'GF(2) 基底変換に伴う秘密ベクトルの逆変換、位相相関の検査に参考。サンプリング認証を全アドレス・任意標的・位相の一致の代用にはしない。'),
 (48, 'ref_48.md', 'https://arxiv.org/pdf/2112.08499', 'selected_sections',
  'Abstract・Introduction、Section I（Algorithms 1/2 と帰納的正当性）、Section II Eq.11まで、Appendix B冒頭。残部は未読。',
  '出力 marginal を全計算せず、振幅問い合わせからゲートごとの更新でサンプリングする。対角ゲート・置換ゲートの特別扱いと近似誤差の累積を解析する。',
  '古典シミュレータの省力化には有用だが、対角ゲートを sampling で省けることは coherent oracle から位相を削除できる意味ではない。'),
 (49, 'ref_49.md', 'https://arxiv.org/pdf/2106.12524', 'selected_sections',
  'Abstract・I の定理と計算量、Lemma 15 付近の Bell 測定、VI Discussions。II–V 全体の証明は未読。',
  '未知 Clifford を多項式問い合わせで学習し、条件を満たす T-depth-one 回路では計算基底入力の出力を学習できる。任意入力のユニタリ再構成は別の高い計算量を持つ。',
  '計算基底で得た出力状態の位相自由度が残ると、重ね合わせや任意標的入力上の一致は保証できない。単なる真理値表検査の不足を明確化する。'),
 (50, '2209.14530.md', 'https://arxiv.org/pdf/2209.14530', 'selected_sections',
  'Abstract・I、Theorem 1.1/Corollary 1.2、Section 4 Algorithm 1 と Theorem 4.1 の冒頭証明。残りの証明・付録は未読。',
  '安定化子忠実度が無視できない状態を Haar random と区別する Bell-difference-sampling 法を与え、擬似乱数状態の non-Clifford 資源下界を導く。',
  '状態アンサンブルの識別困難性の下界であり、固定の75語ローダーの4170境界や最小 Toffoli 数を与えない。'),
 (51, '2305.13409.md', 'https://arxiv.org/pdf/2305.13409', 'selected_sections',
  'Abstract・I と main theorem、Section 7 Algorithm 3/Theorem 7.1 の証明、Corollary 7.2 冒頭。その他の長い証明・付録は未読。',
  '少数 non-Clifford ゲートで準備した状態を、stabilizer dimension と Bell/single-copy measurements を用いて poly(n,2^t,1/epsilon) の資源で学習する。',
  '近似状態 tomography の効率化であり、既知の厳密な多出力Boolean写像に最少回路を与える結果ではない。'),
 (52, 'ref_52.md', 'https://arxiv.org/pdf/2304.13915', 'selected_sections',
  'Abstract・I の Theorems 1.1/1.2 と Section 8 discussion/open questions。詳細な証明・付録は未読。',
  'Bell difference sampling による stabilizer fidelity 推定を改善し、擬似乱数状態に必要な T/non-Clifford ゲート数の下界を強める。',
  '固定 oracle の最小 Toffoli 問題とは異なる資源・入力・誤差の設定。一般的な magic 下界を今回の数値下界とは扱わない。'),
 (53, 'ref_53.md', 'https://arxiv.org/pdf/2305.15398', 'selected_sections',
  'Abstract・I、Algorithms 1/2、II 前半、VII Conclusions。残りの algebra と Appendices A–D は未読。',
  't-doped stabilizer state の Pauli characteristic distribution と有限解像度を利用して poly(n,2^t) で厳密に学習する。学習した表現から効率的な準備回路を合成する問題は残る。',
  '学習・圧縮可能というだけでは安い可逆回路が得られない。今回必要なのは実命令列と入力・位相契約まで伴う合成である。'),
 (54, 'ref_54.md', 'https://arxiv.org/pdf/2306.00083', 'selected_sections',
  'Abstract、Introduction、Bell sampling 定義、Computational complexity と classical circuit shadows の導入。残る本文と S1–S5 は未読。',
  '同じ状態の2コピーへ transversal Bell measurements を行い、回路の忠実度・深さ・magic を推定する。Bell 分布自体の計算困難性も分析する。',
  '独立した統計診断には参考になるが、2コピー・H・測定を伴い、既存単一入力のcoherent loaderをそのまま置き換える操作ではない。'),
 (55, 'ref_55.md', 'https://arxiv.org/pdf/2212.11337', 'main_text_complete',
  'letter の抽出本文全体、全節・数式・図説明。外部Supplemental Materialは未読。一般化の詳証は参考文献56側。',
  'tが制限された quasichaotic scrambler から指定部分系の情報を Clifford decoder で回復する。学習費用や成功率・忠実度は n,t とアクセス領域に依存する。',
  '部分系の復号とユニタリ全体の逆演算は異なる。Toffoliを全てCliffordへ置換できるという結果ではない。'),
 (56, 'ref_56.md', 'https://arxiv.org/pdf/2212.11338', 'selected_sections',
  'Abstract・I、II 冒頭、VI Conclusions 冒頭。詳細アルゴリズム、全証明・付録は未読。',
  't-doped Clifford unitary の非Clifford部分を高々t量子ビットへ集約する構造を利用し、quasichaotic scrambler の効率的decoderを学習する。',
  '集約後も非Clifford資源は残る。限定した復号タスクの成功と、任意入力に対する元のユニタリ全体の置換を区別する。'),
 (57, '2304.10481.md', 'https://arxiv.org/pdf/2304.10481', 'selected_sections',
  'Abstract・Introduction と I Model 前半。II–V の残部、Supplement A–M は未読。',
  'Clifford encoding、coherent single-qubit rotations、decode、syndrome measurements という模型で、回転強度や符号率に対する magic の相転移を調べる。',
  '測定を追加すると出力channel自体が変わる。相転移を理由に固定oracleの中間量を自由に測定・消去することはできない。'),
 (58, 'ref_58.md', 'https://arxiv.org/pdf/2312.00132', 'selected_sections',
  'Abstract・I 冒頭、VII Discussion。stabilizer purification と magic fragmentation の動機・適用条件を確認。詳細証明、Appendices A–H は未読。取得テキストはAppendix E.3.2途中で終了し、E.4・F–H・参考文献本文は未取得。後続の共同補完読解は別台帳に記録。',
  '監視された Clifford+T 回路の stabilizer purification と magic fragmentation を解析。簡略模型の定理と、より一般の模型の数値結果を分けている。',
  '測定による状態変化を含む計算相の分類であり、現在の厳密な可逆ローダーへ任意の測定を挿入する規則ではない。'),
 (59, '2407.03929.md', 'https://arxiv.org/pdf/2407.03929', 'selected_sections',
  'Abstract・I 冒頭、VI Discussion、VII Conclusions と Methods 冒頭。Methods の残り、補足証明は未読。',
  'ランダム回路の magic spreading を generalized stabilizer entropy、replica/tensor-network法で解析し、entanglement spreading と異なる時空間尺度を示す。',
  '平均的状態資源量の成長と厳密なゲート再合成は別。entropy指標の測定に対する単調性も定義ごとの条件を確認する必要がある。'),
 (60, '2410.09001.md', 'https://arxiv.org/pdf/2410.09001', 'selected_sections',
  '最新版の題名は Disentangling magic states with classically simulable quantum circuits。Abstract、setup、Theorem 1と証明、Results冒頭、Discussion全体。後半Results・Applications・End Matterは未読。',
  'Clifford符号化された状態の未使用|0>自由度へ Pauli rotation のmagicを移し、entanglementを抑えた表現を構成する。magicそのものを消去する操作ではない。',
  '初期状態制約と自由量子ビットを使うシミュレーション表現。任意32ビット標的入力を含むローダーのゲート数削減には、別途具体的な回路と清浄化が必要。'),
 (61, '2412.17209.md', 'https://arxiv.org/pdf/2412.17209', 'selected_sections',
  'Abstract・I、II 冒頭、III.1 Theorem 1と証明/OFD、VII Conclusions。III残部–VIとAppendices A–Iは未読。',
  'Clifford-augmented MPS において自由|0>量子ビットと Pauli string の構造を用いて magic とentanglementを分離する。GF(2)行列のrankはdisentangle可能性を分類する。',
  'このrankは固定truth tableの双線形tensor rankとは異なる。小bond dimensionとT-count削減を同一視せず、振幅・sampling処理の費用も含める。'),
 ('v1-only-55', '2404.14493.md', 'https://arxiv.org/pdf/2404.14493', 'selected_sections',
  'v1参考文献55、v2では削除。取得した2026-08-24改訂版のAbstract・I、IIIの数値結果、IV Future directions。全証明は未読。',
  'peaked random circuit sampling による検証可能な量子優位性を提案し、peaking深さの下界・数値的生成を調べる。効率的生成と安全性には未解決点がある。',
  '旧版に載るため調査対象に保持したが、最新版主論文の結論を強める証明とは扱わない。固定oracleの回路合成との直接の接点は薄い。'),
]

def main():
    refs = []
    for number, filename, url, status, scope, result, use in ROWS:
        citation = (BIB['references'][number-1]['citation'] if isinstance(number,int)
                    else BIB['version_difference']['v1_removed_reference']['citation'])
        p = BASE / 'root_refs' / filename
        refs.append(dict(number=number,citation_exact=citation,primary_fulltext_url=url,
                         review_status=status,reviewer='root',reviewed_scope_ja=scope,
                         result_ja=result,applicability_ja=use,full_text_retrieved=(number!=58),
                         main_text_retrieved=True,
                         retrieval_status=('main_text_complete_appendices_truncated' if number==58 else 'retrieved_text_available'),
                         local_cache=str(p),cache_sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
    data = dict(numbering='Published/v2 44–61 plus v1-only55',review_date='2026-11-15',
                retrieval_is_not_reading=True,references=refs)
    (BASE/'refs_44_61_and_v1_only.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    lines=['# 主論文参考文献44–61と旧版のみの55：実読台帳','',
           '全文取得と全文読了を区別する。以下はroot自身が読んだ範囲であり、追加の共同調査は別項に記録する。', '']
    for r in refs:
        lines += [f"## [{r['number']}] {r['citation_exact']}",'',
                  f"一次資料: {r['primary_fulltext_url']}",'',
                  f"**読解範囲 ({r['review_status']})**: {r['reviewed_scope_ja']}",'',
                  f"**内容**: {r['result_ja']}",'',f"**実装への判断**: {r['applicability_ja']}",'']
    (BASE/'refs_44_61_and_v1_only.md').write_text('\n'.join(lines))

if __name__ == '__main__':
    main()
