# 主論文参考文献44–61と旧版のみの55：実読台帳

全文取得と全文読了を区別する。以下はroot自身が読んだ範囲であり、追加の共同調査は別項に記録する。

## [44] R. Raussendorf, D. E. Browne, and H. J. Briegel, Measurement-based quantum computation on cluster states, Physical review A 68 , 022312 (2003).

一次資料: https://arxiv.org/pdf/quant-ph/0301052

**読解範囲 (selected_sections)**: Abstract・I、II A の cluster preparation/correlation、II D のゲート連結と byproduct。32頁全体・残りの証明は未読。

**内容**: Cluster state を準備し、適応的な1量子ビット測定で計算する。論理ゲートは測定結果依存の Pauli byproduct を伴い、後続測定基底へ反映する。

**実装への判断**: 測定分岐を含む等価性の確認には参考になる。H、任意測定基底、cluster preparation を現在の命令へ実装する費用が必要で、既存ローダーの直接置換ではない。

## [45] S. Aaronson, Quantum computing, postselection, and probabilistic polynomial-time, Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences 461 , 3473 (2005).

一次資料: https://www.scottaaronson.com/papers/pp.pdf

**読解範囲 (full_extracted_text_complete)**: 著者公開PDF全9頁。PostBQP=PP の証明、閉包性、関連する非線形・postselection議論まで。

**内容**: PostBQP=PP を示し、確率が指数的に小さい非零分岐でも条件付けできる計算モデルの強さを特徴づける。

**実装への判断**: 望ましい測定結果だけを残すことと、全測定分岐を補正して同じ coherent oracle を得ることを混同しないための根拠。

## [46] F. Arute, K. Arya, R. Babbush, D. Bacon, J. C. Bardin, R. Barends, R. Biswas, S. Boixo, F. G. Brandao, D. A. Buell, et al. , Quantum supremacy using a programmable superconducting processor, Nature 574 , 505 (2019).

一次資料: https://www.nature.com/articles/s41586-019-1666-5

**読解範囲 (main_text_complete)**: 出版社の本文 Main から The future まで。classical computational cost・digital error model・図説明を含む。別ファイルの Supplementary Information は未読。

**内容**: 53量子ビットの超伝導プロセッサで random circuit sampling と XEB を実施。古典費用は2019年時点のアルゴリズム・計算機に対する外挿である。

**実装への判断**: XEB とハードウェア忠実度は全入力の厳密一致証明ではない。歴史的な古典時間見積もりを現在の性能や論理ゲート費用に流用しない。

## [47] M.-H. Yung and B. Cheng, Anti-forging quantum data: Cryptographic verification of quantum computational power, arXiv preprint arXiv:2005.01510 (2020).

一次資料: https://arxiv.org/html/2005.01510

**読解範囲 (full_extracted_text_complete)**: 本文 I–III と Appendices A–C。IQP 相関推定、secret strings、GF(2) scrambling、乱択解析を含む抽出全文。

**内容**: IQP の秘密相関に基づく認証案。theta=pi/8 では Pauli 相関計算が Clifford に帰着し、一般角には加法誤差の推定を使う。厳密な安全性証明は未完と明記される。

**実装への判断**: GF(2) 基底変換に伴う秘密ベクトルの逆変換、位相相関の検査に参考。サンプリング認証を全アドレス・任意標的・位相の一致の代用にはしない。

## [48] S. Bravyi, D. Gosset, and Y. Liu, How to simulate quantum measurement without computing marginals, Physical Review Letters 128 , 220503 (2022).

一次資料: https://arxiv.org/pdf/2112.08499

**読解範囲 (selected_sections)**: Abstract・Introduction、Section I（Algorithms 1/2 と帰納的正当性）、Section II Eq.11まで、Appendix B冒頭。残部は未読。

**内容**: 出力 marginal を全計算せず、振幅問い合わせからゲートごとの更新でサンプリングする。対角ゲート・置換ゲートの特別扱いと近似誤差の累積を解析する。

**実装への判断**: 古典シミュレータの省力化には有用だが、対角ゲートを sampling で省けることは coherent oracle から位相を削除できる意味ではない。

## [49] C.-Y. Lai and H.-C. Cheng, Learning quantum circuits of some t gates, IEEE Transactions on Information Theory 68 , 3951 (2022).

一次資料: https://arxiv.org/pdf/2106.12524

**読解範囲 (selected_sections)**: Abstract・I の定理と計算量、Lemma 15 付近の Bell 測定、VI Discussions。II–V 全体の証明は未読。

**内容**: 未知 Clifford を多項式問い合わせで学習し、条件を満たす T-depth-one 回路では計算基底入力の出力を学習できる。任意入力のユニタリ再構成は別の高い計算量を持つ。

**実装への判断**: 計算基底で得た出力状態の位相自由度が残ると、重ね合わせや任意標的入力上の一致は保証できない。単なる真理値表検査の不足を明確化する。

## [50] S. Grewal, V. Iyer, W. Kretschmer, and D. Liang, Low-stabilizer-complexity quantum states are not pseudorandom, arXiv preprint arXiv:2209.14530 (2022).

一次資料: https://arxiv.org/pdf/2209.14530

**読解範囲 (selected_sections)**: Abstract・I、Theorem 1.1/Corollary 1.2、Section 4 Algorithm 1 と Theorem 4.1 の冒頭証明。残りの証明・付録は未読。

**内容**: 安定化子忠実度が無視できない状態を Haar random と区別する Bell-difference-sampling 法を与え、擬似乱数状態の non-Clifford 資源下界を導く。

**実装への判断**: 状態アンサンブルの識別困難性の下界であり、固定の75語ローダーの4170境界や最小 Toffoli 数を与えない。

## [51] S. Grewal, V. Iyer, W. Kretschmer, and D. Liang, Efficient learning of quantum states prepared with few non-clifford gates, arXiv preprint arXiv:2305.13409 (2023).

一次資料: https://arxiv.org/pdf/2305.13409

**読解範囲 (selected_sections)**: Abstract・I と main theorem、Section 7 Algorithm 3/Theorem 7.1 の証明、Corollary 7.2 冒頭。その他の長い証明・付録は未読。

**内容**: 少数 non-Clifford ゲートで準備した状態を、stabilizer dimension と Bell/single-copy measurements を用いて poly(n,2^t,1/epsilon) の資源で学習する。

**実装への判断**: 近似状態 tomography の効率化であり、既知の厳密な多出力Boolean写像に最少回路を与える結果ではない。

## [52] S. Grewal, V. Iyer, W. Kretschmer, and D. Liang, Improved stabilizer estimation via bell difference sampling, in Proceedings of the 56th Annual ACM Symposium on Theory of Computing (2024) pp. 1352–1363.

一次資料: https://arxiv.org/pdf/2304.13915

**読解範囲 (selected_sections)**: Abstract・I の Theorems 1.1/1.2 と Section 8 discussion/open questions。詳細な証明・付録は未読。

**内容**: Bell difference sampling による stabilizer fidelity 推定を改善し、擬似乱数状態に必要な T/non-Clifford ゲート数の下界を強める。

**実装への判断**: 固定 oracle の最小 Toffoli 問題とは異なる資源・入力・誤差の設定。一般的な magic 下界を今回の数値下界とは扱わない。

## [53] L. Leone, S. F. Oliviero, and A. Hamma, Learning t-doped stabilizer states, Quantum 8 , 1361 (2024a).

一次資料: https://arxiv.org/pdf/2305.15398

**読解範囲 (selected_sections)**: Abstract・I、Algorithms 1/2、II 前半、VII Conclusions。残りの algebra と Appendices A–D は未読。

**内容**: t-doped stabilizer state の Pauli characteristic distribution と有限解像度を利用して poly(n,2^t) で厳密に学習する。学習した表現から効率的な準備回路を合成する問題は残る。

**実装への判断**: 学習・圧縮可能というだけでは安い可逆回路が得られない。今回必要なのは実命令列と入力・位相契約まで伴う合成である。

## [54] D. Hangleiter and M. J. Gullans, Bell sampling from quantum circuits, Physical Review Letters 133 , 020601 (2024).

一次資料: https://arxiv.org/pdf/2306.00083

**読解範囲 (selected_sections)**: Abstract、Introduction、Bell sampling 定義、Computational complexity と classical circuit shadows の導入。残る本文と S1–S5 は未読。

**内容**: 同じ状態の2コピーへ transversal Bell measurements を行い、回路の忠実度・深さ・magic を推定する。Bell 分布自体の計算困難性も分析する。

**実装への判断**: 独立した統計診断には参考になるが、2コピー・H・測定を伴い、既存単一入力のcoherent loaderをそのまま置き換える操作ではない。

## [55] S. F. Oliviero, L. Leone, S. Lloyd, and A. Hamma, Unscrambling quantum information with clifford decoders, Physical Review Letters 132 , 080402 (2024).

一次資料: https://arxiv.org/pdf/2212.11337

**読解範囲 (main_text_complete)**: letter の抽出本文全体、全節・数式・図説明。外部Supplemental Materialは未読。一般化の詳証は参考文献56側。

**内容**: tが制限された quasichaotic scrambler から指定部分系の情報を Clifford decoder で回復する。学習費用や成功率・忠実度は n,t とアクセス領域に依存する。

**実装への判断**: 部分系の復号とユニタリ全体の逆演算は異なる。Toffoliを全てCliffordへ置換できるという結果ではない。

## [56] L. Leone, S. F. Oliviero, S. Lloyd, and A. Hamma, Learning efficient decoders for quasichaotic quantum scramblers, Physical Review A 109 , 022429 (2024b).

一次資料: https://arxiv.org/pdf/2212.11338

**読解範囲 (selected_sections)**: Abstract・I、II 冒頭、VI Conclusions 冒頭。詳細アルゴリズム、全証明・付録は未読。

**内容**: t-doped Clifford unitary の非Clifford部分を高々t量子ビットへ集約する構造を利用し、quasichaotic scrambler の効率的decoderを学習する。

**実装への判断**: 集約後も非Clifford資源は残る。限定した復号タスクの成功と、任意入力に対する元のユニタリ全体の置換を区別する。

## [57] P. Niroula, C. D. White, Q. Wang, S. Johri, D. Zhu, C. Monroe, C. Noel, and M. J. Gullans, Phase transition in magic with random quantum circuits, arXiv preprint arXiv:2304.10481 (2023).

一次資料: https://arxiv.org/pdf/2304.10481

**読解範囲 (selected_sections)**: Abstract・Introduction と I Model 前半。II–V の残部、Supplement A–M は未読。

**内容**: Clifford encoding、coherent single-qubit rotations、decode、syndrome measurements という模型で、回転強度や符号率に対する magic の相転移を調べる。

**実装への判断**: 測定を追加すると出力channel自体が変わる。相転移を理由に固定oracleの中間量を自由に測定・消去することはできない。

## [58] M. Bejan, C. McLauchlan, and B. Béri, Dynamical magic transitions in monitored clifford+ t circuits, PRX Quantum 5 , 030332 (2024).

一次資料: https://arxiv.org/pdf/2312.00132

**読解範囲 (selected_sections)**: Abstract・I 冒頭、VII Discussion。stabilizer purification と magic fragmentation の動機・適用条件を確認。詳細証明、Appendices A–H は未読。取得テキストはAppendix E.3.2途中で終了し、E.4・F–H・参考文献本文は未取得。後続の共同補完読解は別台帳に記録。

**内容**: 監視された Clifford+T 回路の stabilizer purification と magic fragmentation を解析。簡略模型の定理と、より一般の模型の数値結果を分けている。

**実装への判断**: 測定による状態変化を含む計算相の分類であり、現在の厳密な可逆ローダーへ任意の測定を挿入する規則ではない。

## [59] X. Turkeshi, E. Tirrito, and P. Sierant, Magic spreading in random quantum circuits (2024), arXiv:2407.03929 [quant-ph] .

一次資料: https://arxiv.org/pdf/2407.03929

**読解範囲 (selected_sections)**: Abstract・I 冒頭、VI Discussion、VII Conclusions と Methods 冒頭。Methods の残り、補足証明は未読。

**内容**: ランダム回路の magic spreading を generalized stabilizer entropy、replica/tensor-network法で解析し、entanglement spreading と異なる時空間尺度を示す。

**実装への判断**: 平均的状態資源量の成長と厳密なゲート再合成は別。entropy指標の測定に対する単調性も定義ごとの条件を確認する必要がある。

## [60] G. E. Fux, B. Béri, R. Fazio, and E. Tirrito, Disentangling unitary dynamics with classically simulable quantum circuits, arXiv preprint arXiv:2410.09001 (2024).

一次資料: https://arxiv.org/pdf/2410.09001

**読解範囲 (selected_sections)**: 最新版の題名は Disentangling magic states with classically simulable quantum circuits。Abstract、setup、Theorem 1と証明、Results冒頭、Discussion全体。後半Results・Applications・End Matterは未読。

**内容**: Clifford符号化された状態の未使用|0>自由度へ Pauli rotation のmagicを移し、entanglementを抑えた表現を構成する。magicそのものを消去する操作ではない。

**実装への判断**: 初期状態制約と自由量子ビットを使うシミュレーション表現。任意32ビット標的入力を含むローダーのゲート数削減には、別途具体的な回路と清浄化が必要。

## [61] Z. Liu and B. K. Clark, Classical simulability of clifford+ t circuits with clifford-augmented matrix product states, arXiv preprint arXiv:2412.17209 (2024).

一次資料: https://arxiv.org/pdf/2412.17209

**読解範囲 (selected_sections)**: Abstract・I、II 冒頭、III.1 Theorem 1と証明/OFD、VII Conclusions。III残部–VIとAppendices A–Iは未読。

**内容**: Clifford-augmented MPS において自由|0>量子ビットと Pauli string の構造を用いて magic とentanglementを分離する。GF(2)行列のrankはdisentangle可能性を分類する。

**実装への判断**: このrankは固定truth tableの双線形tensor rankとは異なる。小bond dimensionとT-count削減を同一視せず、振幅・sampling処理の費用も含める。

## [v1-only-55] S. Aaronson and Y. Zhang, On verifiable quantum advantage with peaked circuit sampling, arXiv preprint arXiv:2404.14493 (2024).

一次資料: https://arxiv.org/pdf/2404.14493

**読解範囲 (selected_sections)**: v1参考文献55、v2では削除。取得した2026-08-24改訂版のAbstract・I、IIIの数値結果、IV Future directions。全証明は未読。

**内容**: peaked random circuit sampling による検証可能な量子優位性を提案し、peaking深さの下界・数値的生成を調べる。効率的生成と安全性には未解決点がある。

**実装への判断**: 旧版に載るため調査対象に保持したが、最新版主論文の結論を強める証明とは扱わない。固定oracleの回路合成との直接の接点は薄い。
