# 主論文の引用：本文残部の追加読解

11件の補完記録です。root担当の既読範囲と今回の追加読解を合わせて、11件は本文の全節を確認しました。残る本文・付録・参考文献の未読部分は下に個別記録しており、全PDF読了とはしません。新しい回路実装・Toffoli削減は行っていません。

数式・擬似コード・抽出された図説明を読みました。全図のピクセル視認や、全定理の独立再証明ではありません。版が後年更新された[60][61]は、親論文が引用した初版と区別します。

|番号|統合した本文の範囲|未読部分|
|---|---|---|
|50|全節|Appendix A (state-preparation-unitary access); Appendix B (tightness); Reference list|
|51|全節|Appendix A (one-round adaptivity); Appendix B (mixed states); Reference list|
|52|全節|Appendix A (squared Weyl expectation estimation); Reference list|
|53|全節|Appendices A–D; Reference list|
|54|全節|Supplementary Material S1–S5; Acknowledgments and reference lists|
|56|全節|Appendix A (notation); Appendix B (subroutines); Appendix C (proof of Theorem 1); Appendix D (finite resolution lemma); Reference list|
|57|全節|Supplement D–M; Reference list|
|58|全節|Appendices A–H (A–D and E.1–part of E.3.2 are cached but not read as substantive supplementary review); Appendix E.3.2 remainder, E.4 and F–H are absent from this truncated cache; Reference list is absent from this cache|
|59|全節|Supplemental Material sections 1–6; Reference list; Remaining acknowledgment/funding/data statements after character 67418|
|60|全節|Reference list|
|61|全節|Appendix A; Appendices D–I; Reference list|


## [50] Low-Stabilizer-Complexity Quantum States Are Not Pseudorandom

Sabee Grewal; Vishnu Iyer; William Kretschmer; Daniel Liang。 arXiv:2209.14530v1, 2022-09-29。

[一次本文](https://arxiv.org/html/2209.14530v1)

**今回の実読範囲:** [[14574, 51241]]（Unicode文字、半開区間）。

**読んだ節:** 2 Preliminaries (complete); 3 Certificate of Low Stabilizer Complexity, including all proofs (complete); 4 Algorithm and Sample Complexity Analysis, including all proofs (complete); 5 Open Problems (complete); Acknowledgments。

**この補完前のroot範囲:** Abstract・I、Theorem 1.1/Corollary 1.2、Section 4 Algorithm 1 と Theorem 4.1 の冒頭証明。残りの証明・付録は未読。

**未読:** Appendix A (state-preparation-unitary access); Appendix B (tightness); Reference list。

**追加の要点・条件:**

- Algorithm 1は4コピーのBell difference samplingと追加2コピーのPauli測定を各反復で使う。未知pure stateがHaarまたはstabilizer fidelity≥1/kというpromiseの下で区別する手順である。
- Theorem 4.1のv1条件はn≥33、k≤(4/5)2^(n/12)。標本数O(k^12 log(1/δ))、時間O(n k^12 log(1/δ))で、有限失敗確率とHaar ensembleに関する平均を伴う。
- Corollary 4.3は擬似乱数状態ensembleに必要なT数ω(log n)を導く。固定した決定的なtruth tableや任意入力unitaryに対する数値下界ではない。
- Section 5は低stabilizer rankとfidelityの関係、学習、より強いT下界を未解決問題として区別する。低extent、低rank、低実ゲート数を同一視できない。

**今回への適用:** 検証に使うなら状態の統計的診断であり、全アドレス・任意ターゲット・HMR相対位相の厳密同値検証には置き換えない。6コピー測定を128Q回路の無料操作と扱わない。

**根拠箇所:** Lemma 2.5; Lemma 3.1; Algorithm 1 and Theorem 4.1; Corollary 4.3; Section 5。

## [51] Efficient Learning of Quantum States Prepared With Few Non-Clifford Gates

Sabee Grewal; Vishnu Iyer; William Kretschmer; Daniel Liang。 arXiv:2305.13409v5, 2025-11-04 (parent cites 2023 preprint)。

[一次本文](https://arxiv.org/html/2305.13409v5)

**今回の実読範囲:** [[29796, 130797]]（Unicode文字、半開区間）。

**読んだ節:** 2–10 complete, including all extracted proofs, algorithms 1–4, and open problems; Acknowledgments。

**この補完前のroot範囲:** Abstract・I と main theorem、Section 7 Algorithm 3/Theorem 7.1 の証明、Corollary 7.2 冒頭。その他の長い証明・付録は未読。

**未読:** Appendix A (one-round adaptivity); Appendix B (mixed states); Reference list。

**追加の要点・条件:**

- 一般single-qubit non-Clifford t個でstabilizer dimension≥n−2t。論文後半のn−tはstabilizer dimensionのpromiseであり、一般gate数のtと無条件に一致しない。
- Lemma 3.2はisotropic subspaceをPauli Z標準形へ写すCliffordをH・S・CNOTで構成する。古典的な行操作はbasis表現の変更であって、実回路の非Clifford積を無料に消す操作ではない。
- Algorithms 2–4は大きなPauli probability massをもつ部分空間を学習し、C|ψ>を少数qubit状態と既知basis stateに近似分離してtomographyする。測定によるpostselection、state trace-distance誤差ε、失敗率δを伴う。
- Bell measurements版の部分空間学習はO(n/ε²)標本だが、残ったt-qubit状態の一般tomographyにはpoly(2^t)の資源が残る。Single-copy版はrandom Cliffordを使い2^tにも依存する。
- Section 10は本手法がproper learnerではないと明記する。少数non-Cliffordで準備された状態を学習できても、その少数ゲート数を保った準備回路の効率的合成はQuestion 10.1として未解決である。
- Section 3の行列図と証明の一部は一次HTML抽出で文字が結合している。抽出された全文は読んだが、全行列図の別PDF照合や全式の独立再証明はしていない。

**今回への適用:** 状態記述の圧縮をToffoli数の改善と扱えない理由が本文自身に明示されている。任意32ターゲットは既知の|0>や観測済みbasis stateに置き換えられず、位相を捨てたunsigned Pauli groupだけではcontrolled演算の厳密監査が足りない。

**根拠箇所:** Definition 2.22 and Lemma 2.23; Lemma 3.2; Lemmas 4.5–4.6; Algorithms 2–4 / Theorems 6.4, 7.1, 9.6; Section 10, Question 10.1。

## [52] Improved Stabilizer Estimation via Bell Difference Sampling

Sabee Grewal; Vishnu Iyer; William Kretschmer; Daniel Liang。 arXiv:2304.13915v3, 2024-03-29 (STOC 2024 cited in parent)。

[一次本文](https://arxiv.org/html/2304.13915v3)

**今回の実読範囲:** [[2436, 115547]]（Unicode文字、半開区間）。

**読んだ節:** 1–8 complete, including all extracted proofs and algorithms 1–4; Acknowledgments。

**この補完前のroot範囲:** Abstract・I の Theorems 1.1/1.2 と Section 8 discussion/open questions。詳細な証明・付録は未読。

**未読:** Appendix A (squared Weyl expectation estimation); Reference list。

**追加の要点・条件:**

- 擬似乱数ensembleには一般single-qubit non-Clifford≥n/2、diagonal non-Clifford/Tなら≥nが必要という下界。根拠はBell difference sampleが張るPauli部分空間の次元で、任意の固定oracleのgate最適化下界ではない。
- Algorithm 2の最近傍stabilizer近似は標本数こそO((n+log(1/δ))/(ε²τ^4))だが、maximal clique列挙と各stabilizer basisの2^n候補を調べ、時間はexp(O((n+log(1/δ))/τ^4))/ε²。標本効率と計算時間効率を混同しない。
- Algorithm 3がpoly-timeになるbounded-distance条件はfidelity>cos²(π/8)≈0.8536に正のmargin γがある場合で、この条件はunique closest stabilizerを保証する。元の状態をそのstabilizerに物理的に置換してよいという意味ではない。
- Tolerant testerは全ての二閾値で使えるわけではなく、γ=α1^6−(3α2+1)/4>0というgap条件が必要。Weyl expectationの二乗は符号・相対位相の完全な情報ではない。
- 一般の近いstabilizerを求める方法やmatching-pursuitと組み合わせる応用は、classical simulation用の分解探索であり、実ゲートの削減とは目的関数が異なる。

**今回への適用:** 候補の構造分析の道具にはなるが、J=4でL≤4170を証明・達成する結果ではない。近似fidelityと統計的promise判定を、厳密なtruth-table/HMR同値検証へ読み替えない。

**根拠箇所:** Theorems 3.1–3.2; Algorithm 1 / Corollaries 4.10–4.11; Algorithm 2 / Theorem 5.10; Corollary 6.5 / Algorithm 3 / Theorem 6.7; Algorithm 4 / Theorem 7.7; Section 8。

## [53] Learning t-doped stabilizer states

Lorenzo Leone; Salvatore F. E. Oliviero; Alioscia Hamma。 arXiv:2305.15398v6, 2024-05-21; Quantum 8, 1361 (2024)。

[一次本文](https://arxiv.org/html/2305.15398v6)

**今回の実読範囲:** [[8945, 49255]]（Unicode文字、半開区間）。

**読んだ節:** II Algebraic structure (complete); III Learning from characteristic-distribution samples (complete); IV Sampling (complete); V Learning without conjugate-state access (complete); VI Concurrent work (complete); VII Conclusions (complete); Acknowledgments。

**この補完前のroot範囲:** Abstract・I、Algorithms 1/2、II 前半、VII Conclusions。残りの algebra と Appendices A–D は未読。

**未読:** Appendices A–D; Reference list。

**追加の要点・条件:**

- II–IIIのfinite resolutionによるexact learningはTゲート限定。一般O(1)-local non-Clifford gateに対する代数的分解は扱うが、同じ離散間隔とexact learningの保証は成立しないと明記する。
- Stabilizer groupとbad-generatorのcoset分解を学ぶ。m≥n−t、bad-generator数k≤4^t−1で、poly(n,2^t)はt=O(log n)のときにpoly(n)。各測定の有限標本による失敗確率は残る。
- IVの直接Bell samplingは状態とその複素共役へのquery accessを使う。Vは同じ状態の2コピーへBell測定を行い、その2回のPauli標本の積を検査する別手順で、複素共役を無料の物理演算と仮定していない。
- Vは学習したstabilizerからClifford diagonalizerを構成して、残った少数qubitの状態をtomographyする。VIIは学習した表現からClifford+T準備回路を合成する問題をopen questionとして挙げる。

**今回への適用:** 固定初期状態のtomographic descriptionを得る結果であり、任意アドレス・任意32ターゲットに同じunitary/XOR作用をする安価な回路を自動合成する定理ではない。測定標本数やstabilizer nullityを実Toffoli数へ換算しない。

**根拠箇所:** II Eqs.(1)–(5); III Eqs.(6)–(8); IV Eq.(9); V Eqs.(10)–(14); VII open questions。

## [54] Bell sampling from quantum circuits

Dominik Hangleiter; Michael J. Gullans。 arXiv:2306.00083v5, 2024-06-01; PRL 133, 020601 (2024)。

[一次本文](https://arxiv.org/html/2306.00083v5)

**今回の実読範囲:** [[9375, 27691]]（Unicode文字、半開区間）。

**読んだ節:** Bell samples as classical circuit shadows (complete); Depth test (complete); Magic test and Clifford+T learning (complete); Error Detection and Correction (complete); Discussion and outlook (complete)。

**この補完前のroot範囲:** Abstract、Introduction、Bell sampling 定義、Computational complexity と classical circuit shadows の導入。残る本文と S1–S5 は未読。

**未読:** Supplementary Material S1–S5; Acknowledgments and reference lists。

**追加の要点・条件:**

- Purityからfidelityを推定する主張にはlocal circuit-level Pauli noise、平均を取る回路ensemble、noiseless Bell measurementという条件がある。測定noiseの補正にはi.i.d.条件を追加する。任意の同じcoherent errorを2コピーに掛けた場合には対応が壊れると本文にある。
- Depth testは指定されたgate architectureの境界をまたぐgate数とsubsystem entropyから深さをlower-boundする。今回の自由配置回路のToffoli数の下界とは違う。
- Magic testはO(n/epsilon)標本で近い状態のstabilizer nullityを推定し、t-qubit部分に追加tomographyを行う。推定値が元の状態のexact T-countや最適回路費用を直接決めるわけではない。
- Antisymmetric Bell outcomeの破棄やvirtual-distillation比による誤差抑制は、測定分布・期待値の処理である。二つのコピーと測定を使い、単一のcoherent oracleを保つuncompute手順ではない。
- 後半のdepth/magic testはpurityが1に近い設定に移っており、noise-robustな一般版はoutlookに残されている。

**今回への適用:** 独立の統計的診断としては参考になるが、全1232アドレスとHMR枝の相対位相の厳密検証の代わりにはしない。二倍のqubit使用や追加のH・CNOT・測定費用も固定128Qの外に出せない。

**根拠箇所:** Bell shadows Eqs.(4)–(5); Depth test; Magic test; Error Detection and Correction; Discussion noise-robustness questions。

## [56] Learning efficient decoders for quasichaotic quantum scramblers

Lorenzo Leone; Salvatore F. E. Oliviero; Seth Lloyd; Alioscia Hamma。 arXiv:2212.11338v4, 2024-03-04; Physical Review A 109, 022429 (2024)。

[一次本文](https://arxiv.org/html/2212.11338v4)

**今回の実読範囲:** [[0, 3658], [10146, 172361]]（Unicode文字、半開区間）。

**読んだ節:** Metadata and abstract; II–VI complete, including all extracted main-text proofs, technical definitions/examples, CC algorithm, numerical conditions, conclusions and acknowledgments。

**この補完前のroot範囲:** Abstract・I、II 冒頭、VI Conclusions 冒頭。詳細アルゴリズム、全証明・付録は未読。

**未読:** Appendix A (notation); Appendix B (subroutines); Appendix C (proof of Theorem 1); Appendix D (finite resolution lemma); Reference list。

**追加の要点・条件:**

- Theorem 1はscrambler U_tに対する部分情報の復号である。EPR pair、部分系Dと既存のB′へのアクセス、追加EPR pair、DD′へのBell projectionを使い、投影成功確率と条件付きfidelityを区別する必要がある。
- 復号器生成はG_D上のPauli共役作用を符号まで合わせ、残るtableau自由度をrandom completionする。成功率の下界1−2^{−(2|C|−t)}とfidelity近似1/(1+2^{2|A|+t−2|D|})は異なる条件であり、両方を同時に満たす余白が必要。
- IV.3 Remark T4とVIは、Dを全系へ拡張するとunitary fidelityに戻り、非Clifford U_tとClifford Vのfidelityは1未満になると明記する。部分系復号を全unitary置換に使えない。
- V.2のcompression theoremはU_tをCliffordで挟んだ高々t-qubitの非Clifford核へ写すが、核には最大t個のTが残る。O(n²+t³)はH/CNOT/Tなどの全ゲート数の漸近上界で、Toffoli数が減ったという結果ではない。
- V.2はT gatesを仮定して|G(U_t)|≥2^(2n−t)などを導く。一般single-qubit非Cliffordへの拡張を脚注は述べるが、同じtの定数やfinite-resolution保証を無条件に移さない。Corollary 2のstate diagonalizerは入力のstabilizer stateに依存すると証明末尾が明記する。
- CC algorithmのworst-case資源は本文では時間O(n^5 2^(6t))、query O(n^4 2^(6t))。t=O(log n)なら多項式、tがnに比例すると指数的。実験はn=8、100 realizations、t=0…6の特定構造であり一般的な実用速度保証ではない。
- IIIの学習困難性はquery modelや既存の仮定付き結果を区別する。Metropolis探索の失敗やbest-known simulatorの指数費用は、全アルゴリズムに対する無条件下界ではない。
- V.1のEq.(31)にはHTML抽出由来の描画命令が混入する。tableauの後続説明とphase bit更新は読んだが、その図式の独立PDF照合はしていない。

**今回への適用:** 有限幅の非Clifford核を探す発想と、共役像の符号を別途追う設計は参考になる。しかし部分系復号には破棄する自由度があり、任意入力のXOR loaderとclean ancillaの全体一致を保つ無料Clifford置換にはならない。H/Sを含む全Clifford操作も公式gate alphabetと照合が必要。

**根拠箇所:** II Eqs.(1)–(4); IV.2 Eqs.(16)–(18); Theorem 1, Remarks T1–T6; V.1 tableau and phase-bit formulas; Theorem 2 / Corollaries 1–3; V.3 CC algorithm and final complexity paragraph; V.5 numerical setup; VI full-unitary-fidelity caveat。

## [57] Phase transition in magic with random quantum circuits

Pradeep Niroula; Christopher David White; Qingfeng Wang; Sonika Johri; Daiwei Zhu; Christopher Monroe; Crystal Noel; Michael J. Gullans。 arXiv:2304.10481v2, 2024-04-11 (citation in parent is 2023 preprint)。

[一次本文](https://arxiv.org/html/2304.10481v2)

**今回の実読範囲:** [[0, 2086], [8649, 36776], [40594, 48981]]（Unicode文字、半開区間）。

**読んだ節:** I Model (complete); II Quantifying magic (complete); III Vanishing rate (complete); IV Constant rate (complete); V Discussion (complete); Acknowledgments/data availability/disclaimer; Supplement A Basis-minimized entropy; Supplement B Syndrome distribution; Supplement C Decoder breakdown。

**この補完前のroot範囲:** Abstract・Introduction と I Model 前半。II–V の残部、Supplement A–M は未読。

**未読:** Supplement D–M; Reference list。

**追加の要点・条件:**

- 模型は|0>からClifford encode、全qubitへのcoherent Z rotation、inverse decode、syndrome measurementを行う。得たmagicは条件付き論理状態の性質で、元の入力に対して同じchannelを保つ変換ではない。
- Vanishing-rateの解析にはsyndromeごとのerror数の仮定がある。Constant-rateのcritical pointと指数は有限サイズfitとscaling hypothesisに敏感で、SSREとconditional entropyの転移が一致するか本文は結論していない。
- 実験のmagic推定はsyndrome classへのgrouping、tomography後の最大固有状態への射影、理想分布のsupportへの投影等の古典postprocessingを使う。これを物理回路のexact動作保証と読まない。
- Supplement Aが示すbasis-minimized entropyの性質はpure stateでのfaithfulness、Clifford不変性、subadditivity。任意の許可stabilizer操作に対する全ての資源単調性まで証明したとは扱わない。
- Supplement Cは小さい測定entropyでも情報回復を保証しないと明記する。Syndrome measurementが初期状態とは異なるpure stabilizer stateへ射影しうるためである。Syndromeごとにminimizeした平均と、全syndromeで共通basisをminimizeした値も区別する。

**今回への適用:** 測定後magicが小さいというだけでは、古い中間値を自由に測定・消去できない。HMRで正しいbyproduct correctionを全入力に適用する具体的恒等式が必要。最適Toffoli数やJ=4境界をこの相転移から導けない。

**根拠箇所:** I–V; Supplement A Eqs.(1)–(4); Supplement B two-errors-per-syndrome assumption; Supplement C Eqs.(5)–(10) and small-entropy caveat。

## [58] Dynamical Magic Transitions in Monitored Clifford+T Circuits

Mircea Bejan; Campbell McLauchlan; Benjamin Béri。 arXiv:2312.00132v3; PRX Quantum 5, 030332 (2024)。

[一次本文](https://arxiv.org/html/2312.00132v3)

**今回の実読範囲:** [[0, 186397]]（Unicode文字、半開区間）。

**読んだ節:** Table of contents, title, authors and abstract; I–VII complete, including all subsections, Theorem 1 proof, Theorem 2 statement, equations and extracted figure captions; Acknowledgments。

**この補完前のroot範囲:** Abstract・I 冒頭、VII Discussion。stabilizer purification と magic fragmentation の動機・適用条件を確認。詳細証明、Appendices A–E は未読。

**未読:** Appendices A–H (A–D and E.1–part of E.3.2 are cached but not read as substantive supplementary review); Appendix E.3.2 remainder, E.4 and F–H are absent from this truncated cache; Reference list is absent from this cache。

**取得範囲の補正:** 292,073文字のキャッシュはAppendix E.3.2の式の途中で終わる。目次にあるE.4・F（数値アルゴリズム）・G（記号表）・H（追加数値結果）と参考文献本文は保存されていない。I–VIIの本文と謝辞は揃い、全文確認した。原台帳のfull_text_retrieved=trueを論文全体取得と解釈する場合には訂正が必要で、ここではfalseとする。追加取得は今回の指示範囲外なので行っていない。

**追加の要点・条件:**

- 対象はランダムなClifford+T回路に中間Z測定を含む模型の古典シミュレーション。PBCへの変換はmagic ancilla、Pauli測定、結果に応じたClifford更新を使う。既知の安定化子入力と出力分布の再現が基礎で、任意入力に対する同じunitaryをCliffordだけで合成する定理ではない。
- III.2のCPX_PBCは、magic-state registerで重なる測定supportをまとめたブロックの大きさt_iに対するΣ_i 2^t_iというruntime proxy。多項式係数や指数内定数を省き、最終出力に関係するブロックだけを数える。実行ゲート数でも、すべての古典アルゴリズムに対する無条件下界でもない。
- VIIはCPX_PBCがCliffordで増加し得るためmagic monotoneではないこと、測定結果でPauliの符号が変わってもsupport構造とproxyは変わらないことを明記する。この符号を省く指標はHMR枝の相対位相検証に使えない。
- V.1の単一Tゲートを消す測定は、動的stabilizer codeに符号化された論理qubitのPauliを測る。Theorem 1は既知stabilizer入力について、元回路と対応PBCの出力がstabilizerであることの同値を示す。SPからmagic fragmentationへの証明は、各ブロックにO(1)個のTを置き、その終点がstabilizerという簡略模型の仮定を使う。一般回路への形式的拡張はVIIで未解決とする。
- V.3のpurification確率は、測定Pauliを所定の生成元集合から一様に選ぶ近似、共通のγや固定幅wなどを用いる。Theorem 2の生成元数とentanglementの関係の証明はAppendix Dに置かれ、今回未読。確率・時間scalingを個々の固定ローダーへの厳密保証へ移さない。
- 固定qD=O(1)の数値転移p_c=0.159±0.001と、固定qでの振舞いを区別する。V.4.2の脚注は極めて小さいqのeasy phaseを排除できないと記し、本文のhard phaseの議論も一般最悪時下界として扱えない。
- V.5は同時に未purifyのmagicがO(log n)個に留まれば、poly(n)個のstabilizer状態の重ね合わせとしてexact stateを追跡し、strong/weak simulationを効率化できると述べる。これは状態表現の古典計算費用であり、元のT/Toffoli実命令が減ったことを意味しない。
- VIのT-correlated monitoringではT直後のZ測定を増やすと、体積則entanglementのままシミュレーションが容易になる。perfect monitoringは各Tのmagicをすぐ射影で除くが、その測定を任意入力のoracleに挿入してよいことを保証しない。
- VIIはvon Neumann entropyによるarea lawからの近似MPS simulationと、Hartley entropyのarea lawを使うexact TN simulationを区別する。また独立研究とのqD一定の場合の転移の相違をNote addedで明記している。数値critical値を普遍的な回路定数として流用しない。

**今回への適用:** 測定依存を含むPauli supportグラフの分解は検証用シミュレーターの設計に参考になる。ただし入力を固定すること、magic-state準備を費用外に置くこと、Pauli符号を捨てることは現在のexact XOR loaderの要件を満たさない。全1232アドレス・任意32ターゲット・HMR枝位相を保つ具体的回路と実CCX計数が別途必要であり、本論文から削減量は得ていない。

**根拠箇所:** III.1–III.3 model, PBC and Eq.(5) runtime proxy; IV finite-size scaling; V.1 Eq.(7) logical-measurement criterion; V.2 Theorem 1 and proof; V.3 Theorem 2 and Eqs.(13)–(19); V.4.2 footnote 4; V.5 direct simulation condition; VI T-correlated monitoring; VII non-monotonicity, outcome-independent support, exact/approximate distinction and open formal link。

## [59] Magic spreading in random quantum circuits

Xhek Turkeshi; Emanuele Tirrito; Piotr Sierant。 arXiv:2407.03929v2, 2025-02-07 (parent cites 2024). HTML also prints 2026-08-24 in the author-date area; version metadata and content hash identify the text reviewed.。

[一次本文](https://arxiv.org/html/2407.03929v2)

**今回の実読範囲:** [[0, 67418]]（Unicode文字、半開区間）。

**読んだ節:** Metadata, abstract and unnumbered introduction; I–VIII complete, including Methods VIII.1.1, VIII.1.2, VIII.2, all extracted equations and captions; Acknowledgments opening。

**この補完前のroot範囲:** Abstract・I 冒頭、VI Discussion、VII Conclusions と Methods 冒頭。Methods の残り、補足証明は未読。

**未読:** Supplemental Material sections 1–6; Reference list; Remaining acknowledgment/funding/data statements after character 67418。

**追加の要点・条件:**

- 解析対象は|0>^Nからの1次元brick-wall Haar-random two-qudit circuit。一般化stabilizer entropyのensemble平均の成長であり、特定回路のT/Toffoli最小数を与えない。
- Section IはClifford不変性・faithfulness・additivityと測定下の単調性を区別し、任意GSEのPauli測定に対する単調性は保証されずqutrit反例があると明記する。SRE部分族やodd-prime manaの主張を全GSEへ一般化しない。
- 平均の対数であるannealed値と対数の平均であるquenched値を区別する。Methodsでは差が固定時刻にN比例、係数が時間とともに指数減衰するという数値scalingを調べており、両者を厳密に同一とする恒等式ではない。
- Replica/Weingarten法は平均した非unitary transfer tensorのMPS contractionを行う。qubitで有効local dimension24から14へ減らすのはClifford commutantの表現空間であり、75語truth tableの積数削減ではない。
- GSE飽和までのt∝log Nは固定の小さなtoleranceでΔM≈aN exp(−αt)という数値結果に基づく。一般のchaotic Hamiltonianへの拡張はVIでconjectureと記される。
- 大規模1024-quditの結果はbond-dimension convergenceを確認したensemble量のtensor-network計算。任意1回路の全振幅のexact simulationではない。manaはN≤14に留まり、log N飽和時間の明確な実証には不十分とMethods自身が述べる。
- Section IIIのtensor-network図はHTML抽出でSVG/TeX描画命令になる。周囲の式と説明は読んだが、全図の視認・数値再現やSupplementの証明検証はしていない。

**今回への適用:** GSEやentanglementを探索の指標として使うとしても、低い値を厳密な回路削減証明と扱わない。測定によるmagic低下からHMR消去の正しさは導けず、実CCXと全入力・位相の別検証が必要。

**根拠箇所:** I GSE definition and monotonicity caveat; II annealed/quenched definitions; III Eqs.(4)–(9); V Eq.(10); VI conjecture; VIII.1 Eqs.(12)–(15); VIII.2 finite-size mana limitation。

## [60] Disentangling magic states with classically simulable quantum circuits

Gerald E. Fux; Benjamin Béri; Rosario Fazio; Emanuele Tirrito。 arXiv:2410.09001v3, 2025-12-08; PRL 135, 260605 (2025). Parent cited 2024 title: Disentangling unitary dynamics with classically simulable quantum circuits.。

[一次本文](https://arxiv.org/html/2410.09001v3)

**今回の実読範囲:** [[8484, 34477]]（Unicode文字、半開区間）。

**読んだ節:** Results including Theorem 1 and proof (complete); Consequences for Hamiltonian dynamics; Applications; Discussion and conclusion; Acknowledgments; End Matter: Hamiltonian dynamics and matchgate disentangling (complete)。

**この補完前のroot範囲:** 最新版の題名は Disentangling magic states with classically simulable quantum circuits。Abstract、setup、Theorem 1と証明、Results冒頭、Discussion全体。後半Results・Applications・End Matterは未読。

**未読:** Reference list。

**追加の要点・条件:**

- Theorem 1はC(|phi>⊗|0>^(N−k))という符号化されたstateと、logical operatorではないPauli Pに適用する。Pがstabilizerなら位相のみ、anticommutingなら未使用|0>にmagicを移す。任意入力の全Hilbert空間上で同じoperatorという主張ではない。
- 非Clifford rotationごとにfree qubitを使うか、残ったMPSのbond dimensionを最大2倍にする。Typicalなt*≈N−1.607は深いrandom Cliffordの確率模型であり、与えられた語表回路に対する無条件保証ではない。
- Greedy sweepは二qubit Cliffordのlocal-operation quotient 20候補を調べる。実験で少数sweepが有効という結果と、常に最適disentanglerを見つける保証を区別する。
- Applicationsの量子回路圧縮はsampling taskであり、free-qubit測定のランダムな結果とClifford更新を用いる。Pauli expectationがpoly-timeでも、全qubitのjoint samplingは一般に指数的という違いを本文と結論が明記する。
- End Matterでは一般非可積分Ising dynamicsのmagic/entanglementを十分には除去できなかった。Matchgate版は特定の逆時間発展による試算であり、一般最適化手順はfuture work。

**今回への適用:** 状態表現やsampling幅の圧縮と、実命令のCCX削減は別。固定した任意32ターゲットを|0>のfree qubitと扱えず、追加magic preparationやCliffordのH/Sを公式gate alphabetの外へ無料に置けない。

**根拠箇所:** Theorem 1 and Eqs.(1)–(5); Applications sampling compression; Discussion; End Matter Eqs.(8)–(10)。

## [61] Classical simulability of Clifford+T circuits with Clifford-augmented matrix product states

Zejun Liu; Bryan K. Clark。 arXiv:2412.17209v2, 2025-08-26 (parent cited 2024 v1 preprint)。

[一次本文](https://arxiv.org/html/2412.17209v2)

**今回の実読範囲:** [[8515, 85963], [98204, 108470]]（Unicode文字、半開区間）。

**読んだ節:** II Background; III.1–III.4 including all proofs and Algorithms 1–2; IV.1–IV.2 OBD and comparison; V.1–V.2 numerical results; VI.1–VI.3 probability/sampling/amplitude/entropy and Algorithms 3–4; VII Conclusions; Acknowledgments; Appendix B complete, including Algorithm 5 and Proposition 1 proof; Appendix C complete counterexample。

**この補完前のroot範囲:** Abstract・I、II 冒頭、III.1 Theorem 1と証明/OFD、VII Conclusions。III残部–VIとAppendices A–Iは未読。

**未読:** Appendix A; Appendices D–I; Reference list。

**追加の要点・条件:**

- OFDは未使用のproduct |0> qubitにPauli stringのX/Y成分が作用するとき、同じqubitをcontrolとするcontrolled-Pauli列でmagicを局所化する。|0>という入力制約を外した任意ターゲットにはそのまま適用できない。
- III.3のGF(2)行列はtwisted Pauliを{I,Z}→0、{X,Y}→1で写したt×N行列。Rank rはOFDで処理できる独立方向の数で、未処理数t−rがbond dimensionの上界に入る。ここでは高rankが有利であり、truth-table bilinear rank低減とは別の目的である。
- 2^(t−r)はbond dimensionの上界であって厳密値でもToffoli下界でもない。単qubit作用、別領域への作用、T同士がCliffordへ結合する場合などで上界は緩む。Pauli順序は一般には交換できない。
- OBDの局所探索はOFDのlong-range controlled-Pauliを必ず発見しない。Appendix Cには5qubit・6stringsの明示反例がある。探索失敗を最適性証明として使わない。
- VIは小bond dimensionのCAMPSから全bitstring確率・sampling・振幅・entropyを求めるときにも一般に指数費用が残ることを示す。数値比較は有限precisionであり、truncationを使う大規模結果は厳密比較ではない。
- Appendix Bは任意MPS入力に対してZ stabilizerだけでは不十分とし、X/Z双方の共役像とi^sの位相を保持する。共役tableauは演算子全体のglobal phaseを同定しない点は、制御された部分演算へ移す場合に別途管理が必要。

**式を実装する場合の注意:**

- 読解からの実装上の注意: Algorithm 3/4で逐次確率を条件付き確率として掛けるなら、各射影後の正規化を明示する必要がある。印刷された擬似コードには明示のnormalize行が見当たらないため、そのままコードへ写さず正規化の規約を決める。
- 読解からの実装上の注意: VI.2は基準振幅を1にして隣接bitstringの振幅比を掛け、Eq.(30)でp0を割る。基準振幅または途中の分母が0の場合への分岐が必要で、全supportのphase verifierに無条件で流用しない。これは著者の新しい定理としてではなく、式の分母から生じる実装条件として記録する。

**今回への適用:** Pauli窓の状態シミュレーションや位相追跡の設計には参考になるが、75語表のjoint XOR loaderの実CCXを直接減らす結果ではない。現在のBoolean truth-table rankとは対象も最適化方向も異なる。

**根拠箇所:** III Theorems 1–3 and Eqs.(8)–(18); IV OBD; V truncation discussion; VI Algorithms 3–4 and Eqs.(28)–(30); Appendix B Eq.(60) and Algorithm 5; Appendix C Eq.(70)。
