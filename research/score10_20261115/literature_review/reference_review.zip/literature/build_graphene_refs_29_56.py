"""Convert the per-reference research pass to a conservatively scoped ledger."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent

def main():
    bib = json.loads((ROOT/'linked_sources/graphene_bibliography.json').read_text())
    fetched = {r['number']:r for r in json.loads((ROOT/'graphene_refs/fetch_index.json').read_text())}
    text = (ROOT/'graphene_refs_29_56_research.md').read_text()
    sections = re.split(r'^### \[(\d+)\].*$',text,flags=re.M)
    rows=[]
    for i in range(1,len(sections),2):
        n=int(sections[i]); body=sections[i+1].split('\n## 総括')[0].strip()
        def field(label):
            m=re.search(r'^- \*\*'+re.escape(label)+r'\*\*[:：](.*)$',body,re.M)
            return m.group(1).strip() if m else ''
        p=ROOT/'graphene_refs'/('ref_44_preprint.md' if n==44 else 'ref_50_author.md' if n==50 else f'ref_{n:02}.md')
        url=fetched.get(n,{}).get('url','')
        if n==44: url='https://arxiv.org/pdf/2305.13155'
        if n==50: url='https://wanglab.berkeley.edu/wp-content/uploads/2009/12/nature14364.pdf'
        row=dict(number=n,citation_exact=bib['references'][n-1]['citation_verbatim'],
                 primary_fulltext_url=url,identity_ja=field('タイトル/著者/識別子'),
                 review_status='selected_sections',reviewer='Parallel primary-source research; root identity/cost review',
                 reviewed_scope_ja=field('閲読範囲')+' 逐頁の全文読了としては集計しない。',
                 result_ja=field('主要結果'),parent_connection_ja=field('親論文との関係'),
                 applicability_ja=field('量子回路への転用'),full_text_retrieved=p.exists(),
                 local_cache=str(p),cache_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),
                 read_all_figures_independently=False)
        if n==50:
            row.update(review_status='main_text_complete',reviewer='root',
                       reviewed_scope_ja='著者大学公開PDFの抽出全文41,003文字を実読。本文、Methods、図1–4とExtended Data 1–2のキャプション。参照されるExtended Data 3は抽出に含まれず、全図画像の独立検査は行っていない。',
                       result_ja='AB/BA bilayer graphene domain wall の伝導を、同じflakeの壁なし対照、電場・温度・長さ依存で確認。約400 nmのballistic length（適合では420 nm）と4e^2/hに近い短チャネル伝導を示す。保護にはvalley混合散乱が少ない条件があり、完全に無条件の無散乱伝導ではない。',
                       applicability_ja='滑らかな結晶境界のvalley輸送の実験。今回の論理ゲート合成・可逆語ローダーへ転用できる回路恒等式は含まない。',
                       read_character_ranges=[[0,41003]])
        rows.append(row)
    assert [r['number'] for r in rows]==list(range(29,57))
    data=dict(parent_title=bib['parent_title'],review_date='2026-11-15',
              retrieval_is_not_reading=True,review_method='一次本文の主要結果・方法・指定付録を個別調査。逐頁通読と該当節確認を区別。',references=rows)
    (ROOT/'graphene_refs_29_56.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
    lines=['# グラフェン論文の参考文献29–56：読解台帳','',data['review_method'],'']
    for r in rows:
        lines += [f"## [{r['number']}] {r['citation_exact']}",'',
                  f"一次資料: {r['primary_fulltext_url']}",'',
                  f"**実読範囲**: {r['reviewed_scope_ja']}",'',
                  f"**結果**: {r['result_ja']}",'',
                  f"**親論文との関係**: {r['parent_connection_ja']}",'',
                  f"**回路への適用**: {r['applicability_ja']}",'']
    (ROOT/'graphene_refs_29_56.md').write_text('\n'.join(lines))

if __name__=='__main__':
    main()
