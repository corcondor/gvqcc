# グラフェン論文の参考文献29–56：読解台帳

一次本文の主要結果・方法・指定付録を個別調査。逐頁通読と該当節確認を区別。

## [29] C. Xu and L. Balents, Topological Superconductivity in Twisted Multilayer Graphene, Phys. Rev. Lett. **121** , 087001 (2018).

一次資料: https://arxiv.org/html/1803.08057v2

**実読範囲**: 本文確認。付録全体は未確認。 逐頁の全文読了としては集計しない。

**結果**: 谷自由度を含む最小単一バンド三角格子Hubbard模型では、スピン三重項・谷一重項のトポロジカルな d+id 超伝導が優勢になると予測する。候補状態は通常の磁束量子の半分を持つ半量子渦と、トポロジーで保護されたギャップレス端状態を支持する。

**親論文との関係**: HTG/多層グラフェンを強相関・トポロジカル相の候補として位置づけ、将来の超伝導・トポロジー研究を動機づける主張を支える。

**回路への適用**: **なし**。超伝導秩序・半量子渦の理論であり、論理ゲート合成の構成ではない。

## [30] X.-F. Zhou, Y.-W. Liu, C.-Y. Hao, C. Yan, Q. Zheng, Y.-N. Ren, Y.-X. Zhao, K. Watanabe, T. Taniguchi, and L. He, Coexistence of reconstructed and unreconstructed structures in the structural transition regime of twisted bilayer graphene, Phys Rev B **107** , 125410 (2023).

一次資料: https://arxiv.org/pdf/2209.14730

**実読範囲**: 本文確認。補足資料全体は未確認。 逐頁の全文読了としては集計しない。

**結果**: STM/STSにより、TBGは大角度の剛体構造と小角度の再構成構造の間に遷移領域を持つことを示す。その遷移領域では、再構成領域と未再構成領域が共存し、約0.90°未満では再構成、約1.80°超では剛体構造が支配的になる。

**親論文との関係**: twist角、格子再構成、局所stackingが電子構造とflat bandを左右するという主張を実験的に補強する。

**回路への適用**: **なし**。構造相転移の実験であり、ゲート合成規則はない。

## [31] C.-Y. Hao, Z. Zhan, P. A. Pantaleón, J.-Q. He, Y.-X. Zhao, K. Watanabe, T. Taniguchi, F. Guinea, and L. He, Robust flat bands in twisted trilayer graphene moiré quasicrystals, Nat. Commun. **15** , 8437 (2024).

一次資料: https://www.nature.com/articles/s41467-024-52784-7

**実読範囲**: 本文+MethodsおよびSupplementary Noteへの主要参照箇所を確認。補足全体の読了は未確認。 逐頁の全文読了としては集計しない。

**結果**: 異なる二つのtwist角を持つTTGを五試料で調べ、複数のmagic-angle pairでflat bandを直接観測した。angle pairごとに格子再構成、moiré干渉、flat-band局在の対称性が大きく異なり、局所LDOSは主にmiddle/bottom layerまたはtop/middle layerに分布した。

**親論文との関係**: 単純な「一つのmagic angle」ではなく、twist角の組合せと格子再構成がflat bandの局在・電子構造を決めるという比較対象を提供する。

**回路への適用**: **なし**。局所電子状態の測定・tight-binding計算であり、CCZ/Toffoli構成はない。

## [32] O. Aguilar-Spíndola, A. Rubio-Ponce, F. López-Urías, and F. Sánchez-Ochoa, Electronic and optical properties in helical trilayer graphene under compression, Phys Chem Chem Phys **27** , 11541 (2025).

一次資料: https://pubs.rsc.org/en/content/articlehtml/2025/cp/d5cp00337g

**実読範囲**: 本文確認。補足資料は未確認。 逐頁の全文読了としては集計しない。

**結果**: 相対回転角21.78°の三種類のhigh-angle HTG構造について、初期vertical stackingがC6またはC3対称性と異なるmoiré・回折パターンを生むことを示す。DFT計算では、圧縮により電子正孔非対称性、強いhole localization、光学伝導度と可視域吸収の増強が現れ、stackingと圧縮が電子・光学応答を制御する。

**親論文との関係**: HTGのstacking条件と層間距離が観測される電子構造を変えるという一般的な注意を支えるが、magic-angle低角度HTGの直接証拠ではない。

**回路への適用**: **なし**。光学応答の第一原理計算である。

## [33] S. Niu, J. Alicea, D. N. Sheng, and Y. Peng, Quantum Anomalous Hall Effects and Emergent SU(2) Hall Ferromagnets at Fractional Filling of Helical Trilayer Graphene, Phys Rev Lett **135** , 146505 (2025).

一次資料: https://arxiv.org/html/2505.24146v2

**実読範囲**: 本文+Appendixの主要箇所を確認。補足全体の読了は未確認。 逐頁の全文読了としては集計しない。

**結果**: 高Chern数|C|=2バンドを厳密対角化し、ν=2/3で√3×√3電荷秩序量子Hall結晶、ν=1/3でHall伝導度|σH|=2e²/3hのHalperin型fractional Chern insulatorを予測する。ν=1/2では、バンド分散があっても広範囲に縮退するSU(2) Hall ferromagnetが現れ、realisticなcorrugationでも相が安定する。

**親論文との関係**: HTGの高Chern flat bandが単なる単粒子flat bandではなく、fractional fillingで多体トポロジーを示しうるという主張を支える。

**回路への適用**: **なし**。厳密対角化・多体相の構成であり、量子回路の可逆合成ではない。

## [34] J. C. Hoke, Y. Li, Y. Hu, J. May-Mann, K. Watanabe, T. Taniguchi, T. Devakul, and B. E. Feldman, Imaging supermoiré relaxation in helical trilayer graphene, Nat. Mater. (2026). https://doi.org/10.1038/s41563-025-02423-3

一次資料: https://arxiv.org/html/2410.16269v2

**実読範囲**: 本文+MethodsおよびSupplementaryの主要箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: SET測定で、HTGが均一なmoiré周期を持つ大きなsupermoiré domainへ緩和することを実空間で示した。strainとthermal cyclingでdomain sizeを変えられ、domain boundaryの高いconductanceはcounter-propagating edge modeの存在と整合する。

**親論文との関係**: 格子緩和、domain wall、局所flat band、境界状態が実在するという親論文の実験的背景を直接支える。

**回路への適用**: **なし**。転用可能なのは「局所領域と境界を別々にモデル化する」という抽象的な設計思想だけで、CCZ分解には直結しない。

## [35] L.-Q. Xia et al., Topological bands and correlated states in helical trilayer graphene, Nat. Phys. **21** , 239 (2025).

一次資料: https://arxiv.org/html/2310.12204

**実読範囲**: 本文確認。Methods/Supplementaryの主要箇所も確認したが、補足全体の読了は未確認。 逐頁の全文読了としては集計しない。

**結果**: 同方向に連続回転したHTGでは、格子緩和によりmoiré周期の大きなdomainが形成され、各domainがvalley Chern数±(1,−2)のflat topological bandを持つ。輸送ではν=1,2,3および2/3,7/2に相関状態が現れ、ν=1,3,2/3,7/2でAHE、電場によるtopological transition、Chern domain間のgapless edge networkが観測された。

**親論文との関係**: 親論文が扱うHTGのtopological flat band、Chern mosaic、相関状態、domain-wall channelの基礎的な輸送証拠である。

**回路への適用**: **なし**。実験的物性論であり、ゲート列・位相多項式・ancilla構成はない。

## [36] T. Devakul, P. J. Ledwith, L.-Q. Xia, A. Uri, S. C. de la Barrera, P. Jarillo-Herrero, and L. Fu, Magic-angle helical trilayer graphene, Sci. Adv. **9** , eadi6063 (2023).

一次資料: https://arxiv.org/html/2305.03031

**実読範囲**: 本文+Methodsの主要箇所およびPMC掲載の補足関連箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: HTGは名目上supermoiréだが、緩和によって大きな周期的single-moiré domainへ分かれ、C2zを破るflat bandを形成する。valley Chern数は±(1,−2)、remote bandから約100 meV隔離され、integer/fractional quantum anomalous Hall相に適したnear-ideal quantum geometryを持つ。

**親論文との関係**: 親論文のHTG構造、格子緩和、flat Chern band、domain-wall networkの理論的出発点である。

**回路への適用**: **なし**。flat-band wavefunctionの構成はあっても、CCZ/Toffoliを分解する回路構成ではない。

## [37] Y. H. Kwan, P. J. Ledwith, C. F. B. Lo, and T. Devakul, Strong-coupling topological states and phase transitions in helical trilayer graphene, Phys Rev B **109** , 125141 (2024).

一次資料: https://arxiv.org/html/2308.09706

**実読範囲**: 本文+Appendix Aおよび補足的な強結合解析箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: 強結合解析とHartree–Fockにより、displacement fieldで調整できる整数充填相の相図を得て、一般化flavor ferromagnet、異常Hall相、最大|C|=6のChern数を示した。相互作用によるband dispersionの再正規化は弱く、実験的電場範囲では連続または弱い一次のtopological transitionとKekulé spiral orderが現れる。

**親論文との関係**: HTGで観測・予測される相関相が、格子緩和後も強相関理論で記述できるという主張を支える。

**回路への適用**: **なし**。強結合摂動論とHFの解析である。

## [38] A. Datta, D. Guerci, M. O. Goerbig, and C. Mora, Helical trilayer graphene in magnetic field: Chern mosaic and higher Chern number ideal flat bands, Phys Rev B **110** , 075417 (2024).

一次資料: https://arxiv.org/html/2404.15452

**実読範囲**: 本文+Appendices A–Cを確認。 逐頁の全文読了としては集計しない。

**結果**: chiral limitのHTGでは、有限磁場でもzero-energy flat bandのflatnessが保たれ、単位および半単位磁束付近でtopological transitionが起きる。解析的zero-mode wavefunctionとhidden wavefunctionを用いて、磁場によるhigher-Chern flat bandの出現とChern mosaicの変化を説明する。

**親論文との関係**: HTGのChern mosaicが磁場・corrugation・magic angleに対してどのように変化するかという理論的拡張を与える。

**回路への適用**: **なし**。wavefunctionの解析構成はあるが、量子論理ゲートの分解ではない。

## [39] Y. H. Kwan, T. Tan, and T. Devakul, Fractional Chern mosaic in supermoiré graphene, Phys Rev Res **7** , L032070 (2025).

一次資料: https://arxiv.org/html/2411.08880

**実読範囲**: 本文+Appendices A–Dの主要箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: moiré scaleで局所的にfractionalizeし、そのfractional topological orderがsupermoiré scaleで空間変調するfractional Chern mosaicを提案する。momentum-dependent tunnelingを導入するとparticle-hole asymmetryを説明でき、ν=3+1/3のfractional Chern insulatorを安定化する結果を得る。

**親論文との関係**: HTGの複数length scaleが、単なる構造模様ではなく空間依存の多体トポロジーを生みうるという将来展望を支える。

**回路への適用**: **なし**。HF・exact diagonalization・fractionalizationの構成であり、CCZ回路の合成法ではない。

## [40] D. Guerci, Y. Mao, and C. Mora, Chern mosaic and ideal flat bands in equal-twist trilayer graphene, Phys Rev Res **6** , L022025 (2024).

一次資料: https://arxiv.org/html/2305.03702

**実読範囲**: 本文+Supplementary Appendices A–Cを確認。 逐頁の全文読了としては集計しない。

**結果**: equal-twist staircase TTGのsupermoiréでは、ABA/BAB domainがvalley Chern数±1のcentral bandを持ち、AAAを結ぶgapless lineで接続される。chiral limitの約1.69°ではcentral bandが厳密にflatとなり、Chern±2のcolor-entangled stateとChern∓1のLandau-level stateの解析的重ね合わせに分解できる。

**親論文との関係**: HTGのChern domain、理想flat band、domain boundaryを説明する主要な理論的根拠である。

**回路への適用**: **なし**。解析的band分解はあるが、CCZ/Toffoliのphase-polynomial分解ではない。

## [41] Y. Mao, D. Guerci, and C. Mora, Supermoiré low-energy effective theory of twisted trilayer graphene, Phys Rev B **107** , 125423 (2023).

一次資料: https://arxiv.org/html/2210.11507

**実読範囲**: 本文+Appendices B–Fを確認。 逐頁の全文読了としては集計しない。

**結果**: supermoiré scaleの有効理論を構成し、各valleyにΓMのDirac coneとKM/K′Mの弱くgapした点を持つモデルを導出する。空間依存velocityとnon-Abelian connectionがgauge invarianceを保証し、C2zTに保護された全結合スペクトルと、2°未満でDirac-cone dipがDOS上消える挙動を示す。

**親論文との関係**: supermoiréの長距離電子構造、full connectivity、局所モデルを単純加算できない理由を支える。

**回路への適用**: **なし**。non-Abelian connectionは物性の有効Hamiltonianであり、量子回路のnon-Clifford合成ではない。

## [42] Z. Zhu, S. Carr, D. Massatt, M. Luskin, and E. Kaxiras, Twisted Trilayer Graphene: A Precisely Tunable Platform for Correlated Electrons, Phys Rev Lett **125** , 116404 (2020).

一次資料: https://arxiv.org/html/2006.00399

**実読範囲**: 本文+Supplementary Sections I–IVを確認。 逐頁の全文読了としては集計しない。

**結果**: 二つの独立twist角を持つTTGの一般低エネルギー模型を構成し、有限energy cutoffでも基底が無限次元で、一般にはBrillouin zoneを持たないことを示す。広いmagic-angle領域でVHSが融合し、DOSがcharge neutralityで鋭く増大する機構として、TBG flat bandへのincommensurate perturbationと二つのbilayer moiréのequal hybridizationを区別した。

**親論文との関係**: 多層・交互twist・helical構造を一括して単純な周期模型と扱えないという比較の基礎を与える。

**回路への適用**: **なし**。momentum-space模型の構成であり、ゲート最適化構成ではない。

## [43] C. Mora, N. Regnault, and B. A. Bernevig, Flatbands and Perfect Metal in Trilayer Moiré Graphene, Phys Rev Lett **123** , 026402 (2019).

一次資料: https://arxiv.org/html/1901.05469

**実読範囲**: 本文+Supplementaryのparticle-hole symmetry、symmetry、Dirac-point解析を確認。 逐頁の全文読了としては集計しない。

**結果**: 連続するtwist角比が有理数なら、実空間に結晶格子がなくてもquasimomentum空間に周期性が現れ、特定角度でflat bandが生じる。三層では三つのDirac coneが対でしかgapを開けないため全energyでgaplessな“perfect metal”となり、十分小さい角度では創発particle-hole symmetryがこれを保護する。

**親論文との関係**: 多層構造のband connectivityと、helical/交互twistを同一視できない理由を支える。

**回路への適用**: **なし**。Dirac coneの対称性・接続性は回路のユニタリ合成に移らない。

## [44] N. Nakatsuji, T. Kawakami, and M. Koshino, Multiscale Lattice Relaxation in General Twisted Trilayer Graphenes, Phys Rev X **13** , 041007 (2023).

一次資料: https://arxiv.org/pdf/2305.13155

**実読範囲**: 本文+Supplementary/数値・continuum計算の主要箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: 一般非対称TTGでは、二つのmoiré patternが局所的にcommensurateになるpatchwork of moiré-of-moiré domainsが形成され、moiré scaleとsupermoiré scaleの二段階緩和が現れる。chiral TTGではdomain boundaryに強く局在した一次元電子状態が異なるChern insulator間のtopological boundary stateとなり、alternating TTGではflat bandとmonolayer-like Dirac coneが共存する。

**親論文との関係**: 格子緩和がdomain、boundary channel、flat band分離を同時に作るという親論文の理論的な中核を支える。

**回路への適用**: **なし**。多尺度continuum計算であり、回路構成ではない。

## [45] Y. Liu et al., Imaging moiré flat bands and Wigner molecular crystals in twisted bilayer MoTe2, Natl. Sci. Rev. **13** , nwag014 (2026).

一次資料: https://arxiv.org/pdf/2406.19310

**実読範囲**: 本文のSTM/STS結果と主要な計算比較を確認。補足全体は未確認。 逐頁の全文読了としては集計しない。

**結果**: zero fieldではtMoTe2のflat bandがXM/MXに局在するhoneycomb latticeと非自明トポロジーを形成し、電場で二つのtrivial triangular latticeへ転移する。さらにpotential depthを変えると、MX triangular latticeからkagome latticeへのWigner molecular crystal転移が観測される。

**親論文との関係**: グラフェンではないMoTe2の結果として、helical/多層グラフェンのChern bandや局在テクスチャと混同せず、moire物質一般の比較例としてのみ支える。

**回路への適用**: **なし**。MoTe2の局在・多体相であり、CCZ/Toffoli構成ではない。

## [46] J. Jang, Effect of lattice relaxation on electronic spectra of helically twisted trilayer graphene: large-scale atomistic simulation approach, J. Korean Phys. Soc. **85** , 727 (2024).

一次資料: https://arxiv.org/pdf/2407.19143

**実読範囲**: 本文のMD・tight-binding方法と結果を確認。付録/補足は未確認。 逐頁の全文読了としては集計しない。

**結果**: 大規模molecular-dynamicsとtight-bindingを組み合わせ、HTGの格子緩和前後の電子スペクトルを比較した。緩和は特にcharge-neutrality近傍のスペクトルを大きく変え、局所DOSはmoiré stackingのdomain patternに対応する空間変化を示す。

**親論文との関係**: 格子自由度を無視した単純なunrelaxed模型では、HTGの局所flat band・DOS・domain依存性を誤るという注意を支える。

**回路への適用**: **なし**。atomistic simulationであり、回路最適化の構成はない。

## [47] A. Kerelsky et al., Moiréless correlations in ABCA graphene, Proc. Natl. Acad. Sci. **118** , e2017366118 (2021).

一次資料: https://pmc.ncbi.nlm.nih.gov/articles/PMC7848726

**実読範囲**: 本文+SI AppendixのMethods、Berry curvature、mean-field、STS計算を確認。 逐頁の全文読了としては集計しない。

**結果**: 微小角でtwistした二つのbilayerからmicron-scaleのABCA四層領域が生じ、moire potentialなしでも3–5 meV半値幅の鋭いvan Hove singularityと、charge neutralityで9.5 meVの相関gapが現れる。ABCA–ABAB境界では、電場でon/off可能なvalley-helical edge stateが観測・計算され、moiréがなくてもflat-band相関とトポロジーが成立することを示す。

**親論文との関係**: flat band・相関gap・domain-wall edge stateを、helical trilayer固有の現象と他のrhomb​​ohedral graphene現象から区別するための比較対照である。

**回路への適用**: **なし**。edge-state/Berry-curvature計算であり、回路合成構成はない。

## [48] D. Walkup, B. A. Assaf, K. L. Scipioni, R. Sankar, F. Chou, G. Chang, H. Lin, I. Zeljkovic, and V. Madhavan, Interplay of orbital effects and nanoscale strain in topological crystalline insulators, Nat. Commun. **9** , 1550 (2018).

一次資料: https://arxiv.org/pdf/1610.09337

**実読範囲**: 本文確認。補足全体は未確認。 逐頁の全文読了としては集計しない。

**結果**: SnTe薄膜のSTM・quasiparticle-interference測定と理論計算により、一方向のstrainが垂直方向のband structureを変えることを示した。効果はconduction/valence bandのorbital characterに由来し、strain模型に軌道自由度を含める必要がある。

**親論文との関係**: グラフェン論文の直接の物質証拠ではなく、strainが電子構造を変える際に局所orbital characterを考慮すべきだという一般的補助根拠である。

**回路への適用**: **なし**。SnTeのstrain効果であり、量子ゲート構成ではない。

## [49] M. J. Lawler et al., Intra-unit-cell electronic nematicity of the high-Tc copper-oxide pseudogap states, Nature **466** , 347 (2010).

一次資料: https://arxiv.org/pdf/1007.3216

**実読範囲**: 本文とSupplementary Informationへの言及箇所を確認。補足全体は未確認。 逐頁の全文読了としては集計しない。

**結果**: underdoped Bi2Sr2CaCu2O8+δのSI-STM画像を二つの独立な評価法で解析し、pseudogap energy近傍にintra-unit-cell nematicityを示す秩序パラメータを抽出した。二つの酸素siteの電子構造差が90°回転対称性の破れを直接生むことを示す。

**親論文との関係**: 局所電子テクスチャを測定して対称性破れを識別する解析手法の先行例であり、HTGの局所spectroscopyの方法論的背景を支えるが、HTGの物理を直接証明しない。

**回路への適用**: **なし**。cuprateのnematicity解析であり、ゲート合成とは無関係。

## [50] L. Ju et al., Topological valley transport at bilayer graphene domain walls, Nature **520** , 7549 (2015).

一次資料: https://wanglab.berkeley.edu/wp-content/uploads/2009/12/nature14364.pdf

**実読範囲**: 著者大学公開PDFの抽出全文41,003文字を実読。本文、Methods、図1–4とExtended Data 1–2のキャプション。参照されるExtended Data 3は抽出に含まれず、全図画像の独立検査は行っていない。

**結果**: AB/BA bilayer graphene domain wall の伝導を、同じflakeの壁なし対照、電場・温度・長さ依存で確認。約400 nmのballistic length（適合では420 nm）と4e^2/hに近い短チャネル伝導を示す。保護にはvalley混合散乱が少ない条件があり、完全に無条件の無散乱伝導ではない。

**親論文との関係**: HTGのdomain wallに現れるgapless/conducting boundary stateを理解する実験的先行例である。

**回路への適用**: 滑らかな結晶境界のvalley輸送の実験。今回の論理ゲート合成・可逆語ローダーへ転用できる回路恒等式は含まない。

## [51] H. Yoo et al., Atomic and electronic reconstruction at the van der Waals interface in twisted bilayer graphene, Nat. Mater. **18** , 448 (2019).

一次資料: https://arxiv.org/pdf/1804.03806

**実読範囲**: 本文+Supplementary Informationの主要なfabrication・transport・構造解析箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: twist角を下げると、約1°をcross-overとしてincommensurate moiréからcommensurate domainとsoliton boundaryの配列へ徐々に再構成される。臨界角以下では単純なmoiré-band記述が破綻し、電場下でdomainを囲む一次元topological channelに沿う輸送が現れる。

**親論文との関係**: 格子再構成が単なる幾何学的補正ではなく、電子構造・topological channelそのものを変えるという主張を直接支える。

**回路への適用**: **なし**。実空間再構成と輸送の研究である。

## [52] S. Huang, K. Kim, D. K. Efimkin, T. Lovorn, T. Taniguchi, K. Watanabe, A. H. MacDonald, E. Tutuc, and B. J. LeRoy, Topologically Protected Helical States in Minimally Twisted Bilayer Graphene, Phys Rev Lett **121** , 037702 (2018).

一次資料: https://arxiv.org/html/1802.02999

**実読範囲**: 本文+Supplementary Informationの主要STS・gate依存解析を確認。 逐頁の全文読了としては集計しない。

**結果**: 50 nm超のmoiré wavelengthを持つminimally twisted bilayer grapheneを作製し、AB/BA domain wallにcounter-propagating topologically protected helical stateを観測した。double-line STS profileはAB/BA regionがgapを持つ場合だけ現れ、gate-controlledなtopological-state networkの構築可能性を示す。

**親論文との関係**: domain wallのconductanceを単なる高DOSではなく、対向伝播するtopological boundary modeとして解釈する根拠を支える。

**回路への適用**: **なし**。network modelへの言及はあるが、CCZ/Toffoli回路のnetwork synthesisではない。

## [53] J. S. Alden, A. W. Tsen, P. Y. Huang, R. Hovden, L. Brown, J. Park, D. A. Muller, and P. L. McEuen, Strain solitons and topological defects in bilayer graphene, Proc. Natl. Acad. Sci. **110** , 11256 (2013).

一次資料: https://arxiv.org/pdf/1304.7549

**実読範囲**: 本文+Supplementary Materialsのsoliton幅・TEM解析箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: 電子顕微鏡により、bilayer grapheneのsoliton境界が6–11 nmにわたるatomic-scale registry shiftとして形成されることを測定した。層間移動の最小energy barrierを推定し、1000°C超のin-situ加熱でsoliton motionを観測した。

**親論文との関係**: domain wallが抽象的な境界線ではなく、有限幅の格子歪み・registry変化を持つ実体であることを支える。

**回路への適用**: **なし**。格子solitonの構造研究である。

## [54] Y. Sha, J. Zheng, K. Liu, H. Du, K. Watanabe, T. Taniguchi, J. Jia, Z. Shi, R. Zhong, and G. Chen, Observation of a Chern insulator in crystalline ABCA-tetralayer graphene with spin-orbit coupling, Science **384** , 414 (2024).

一次資料: https://arxiv.org/pdf/2310.17971

**実読範囲**: 本文+Extended Data/Supplementaryの主要輸送・相図箇所を確認。 逐頁の全文読了としては集計しない。

**結果**: WSe2近接によるspin-orbit couplingを持つABCA tetralayer grapheneで、charge neutralityにferromagnetic stateとhysteretic anomalous Hall responseを観測した。LAFとlayer-polarized insulatorの間でChern数4のquantum anomalous Hall stateを実証し、電場が磁気・トポロジーを切り替える制御軸になることを示す。

**親論文との関係**: HTGだけに固有でない、rh​​ombohedral multilayer grapheneにおける高Chern・電場制御・磁気ヒステリシスとの比較を与える。

**回路への適用**: **なし**。Chern insulatorの輸送実験であり、回路合成ではない。

## [55] T. Han et al., Signatures of chiral superconductivity in rhombohedral graphene, Nature **654** , 643(2025).

一次資料: https://arxiv.org/pdf/2408.15233

**実読範囲**: arXiv本文の主要結果・Extended Dataの記述を確認。Supplementary全体は未確認。 逐頁の全文読了としては集計しない。

**結果**: rhombohedral tetra-/pentalayer grapheneで、moiréなしのgate-induced flat conduction bandにTc最大300 mKの二つの超伝導状態を観測した。zero-field anomalous Hall signal、out-of-plane fieldでの磁気ヒステリシス、in-plane fieldへの強さ、最大1.4 Tのcritical fieldを組み合わせ、orbital time-reversal symmetry breakingを伴うchiral superconductivityを示唆する。

**親論文との関係**: HTGの将来展望にあるunconventional superconductivityを、別のrh​​ombohedral graphene系で実現した比較例として支える。ただしHTGで同じ超伝導相が実証されたことを意味しない。

**回路への適用**: **なし**。Majorana/topological quantum computingへの動機づけはあるが、実装可能なCCZ/Toffoli構成は示さない。

## [56] Z. Lu et al., Extended quantum anomalous Hall states in graphene/hBN moiré superlattices, Nature **637** , 1090 (2025).

一次資料: https://arxiv.org/pdf/2408.10203

**実読範囲**: arXiv本文とExtended Dataの主要箇所を確認。Supplementary全体は未確認。 逐頁の全文読了としては集計しない。

**結果**: rhombohedral penta-/tetralayer graphene/hBNで、従来より多いfractional quantum anomalous Hall stateを観測し、tetralayerではν=3/5と2/3のFQAHEを得た。低温・低biasではRxy=h/e²かつRxx≈0のextended QAH stateがν≈0.5–1.3に広がり、温度・電流・displacement fieldでFQAHE、Fermi liquid、composite Fermi liquidへ転移する。

**親論文との関係**: 高Chern flat band、fractional filling、異常Hall相をHTGの実験結果と比較する補助資料であるが、物質はgraphene/hBN rhombohedral moiréでHTGとは異なる。

**回路への適用**: **なし**。多体輸送相の実験であり、量子ゲート最適化の構成はない。
