# Magic 論文・参考文献53件の読解台帳

対象は [The resource cost of magic in a code block](https://arxiv.org/html/2608.29438v2) の番号付き参考文献53件。レビュー日：2026-11-15。

**一次資料の抽出本文を末尾まで実読：53/53件。** 取得だけで読了とした項目はない。共同レビューの担当は、alternative_arch 40件、cost_audit 12件、shared_synthesis 1件である。

読了には取得版の本文、含まれる付録、参考文献、抽出された図説明・表を含む。全図の画像照合、抽出で崩れた全数式の原PDF照合、各証明の独立再証明、数値実験の再実行は意味しない。最新の公開版と、実際に読んだ版を同一視せず、以下の版・範囲および JSON の SHA256 に固定する。外部の別冊補足資料は明示されたもの以外含めない。

## 今回の実装への判断

親論文は符号化した測定効果と magic の費用を扱い、強い境界には整合した recovery skeleton、挿入グラフと分岐ごとの因数分解などの前提がある。今回の75語ローダーにはその証明書がなく、4170 Toffoli の一般下界を与える論文としては使えない。

測定後の各分岐で未知入力の情報と相対位相を保持する検査は [25]–[27]、[31]、[44]、[48] が参考になる。[38] と [50] には、既知の状態や直接合成できる対角位相を利用して中間レジスターを省く着想がある。いずれも、実際のゲート列・全入力・補正・物理幅を確認して初めて今回の改善として数える。

magic-state 工場の受理率・物理時間・蒸留率、古典シミュレーターの標本数、幾何学的な保護ゲートの分類は、それぞれ異なる費用と契約を使う。実装への適用性は以下に各項目ごとに記載した。

## 書誌と版の注意

[23] は取得 PDF の表紙題名が High Rate、取得メタデータと arXiv abs が Efficient である。読了は v4 ヘッダーと取得 PDF のハッシュに固定した。[51] も取得プレプリントと引用された出版題名が異なる。[52] の親論文中の誌名・DOI は対応する著者・題名の出版記録と一致せず、正しい一次資料へ解決した。原引用は JSON の citation_verbatim に保存している。

[40] の読了版は元の planar Floquet boundary を耐故障ではないと訂正している。[50] の印刷式の独立検査と [51] の式の不整合は個別記録に残し、それらだけから論文全体を否定していない。

## 各参考文献

### [1] Universal quantum computation with ideal Clifford gates and noisy ancillas

[一次資料](https://arxiv.org/pdf/quant-ph/0403025v2) — 読んだ版：arXiv:quant-ph/0403025v2 16 Dec 2004。

**結果と条件：** 理想的 Clifford 操作と十分良い非安定化子状態を用い、蒸留から普遍量子計算へ進む構成を示す。独立な資源コピー、受理条件、復号を仮定し、原論文の T-type 状態は現在の T ゲート用状態と命名が異なる。

**今回への適用：** 資源状態を用いる候補では準備・受理・補正を費用に含める根拠になる。既製の magic ancilla が無料で与えられない今回の評価では、そのままローダーの Toffoli 数を減らせない。

**実読範囲：** Shared independent reading of all15 primary PDF pages, main I–VII, distillation derivations, Appendix A, bibliography.

**担当：** /root/cost_audit。**抽出本文：** 61,330 Unicode 文字。

### [2] Surface codes: Towards practical large-scale quantum computation

[一次資料](https://arxiv.org/pdf/1208.0928) — 読んだ版：arXiv:1208.0928, cached manuscript dated 26 October 2012, 54 pages; version suffix not exposed in retrieved text。

**結果と条件：** surface code の誤り訂正、欠陥移動、論理ゲート、magic-state 蒸留と物理資源見積りを体系的に説明する。Clifford frame の更新と非Clifford ゲートに伴う条件付き補正を明示する。

**今回への適用：** 位相を含む論理演算子の追跡と測定順序の監査に役立つ。物理面積・誤り訂正周期・理想資源を含む歴史的見積りを、今回の native Toffoli 費用へ直接換算しない。

**実読範囲：** Complete extracted manuscript: main sections I–XVIII, Appendices A–M, all 66 references, figure captions and extracted tables. All 263082 Unicode characters read; images and original matrix layout not individually audited.

**担当：** /root/alternative_arch。**抽出本文：** 263,082 Unicode 文字。

### [3] UNIQ: Communication-efficient distributed quantum computing via unified nonlinear integer programming

[一次資料](https://arxiv.org/pdf/2512.00401v1) — 読んだ版：arXiv:2512.00401v1 [quant-ph] 29 Nov 2025。

**結果と条件：** 量子プロセッサーへの配置、EPR ペアの管理、通信スケジュールを非線形整数計画とヒューリスティックで共同最適化する。目的は分散計算の通信と実行時間で、任意回路の大域最適性は保証しない。

**今回への適用：** 通信費用を数える将来の構成では参考になる。局所ゲートを省略したネットワーク目的関数は、単一 KMB 回路の積共有や Toffoli 最小化とは一致しない。

**実読範囲：** Complete arXiv v1 extracted manuscript read: Sections I–VII, both algorithms and theorem arguments, all tables/captions and 42 references. No original figure pixels or simulator/code reproduction.

**担当：** /root/alternative_arch。**抽出本文：** 55,061 Unicode 文字。

### [4] Differential privacy preserving distributed quantum computing

[一次資料](https://arxiv.org/pdf/2412.12387v2) — 読んだ版：arXiv:2412.12387v2 [quant-ph] 6 Jan 2025。

**結果と条件：** 分散量子計算で測定出力の Rényi differential privacy とノイズ機構・予算配分を扱う。有限個の入力対による推定と全入力に対する保証は区別が必要である。

**今回への適用：** ノイズを導入して出力分布を近づける手法であり、任意入力のコヒーレントな可逆作用を保つ合成手順にはならない。量子チャネル一般の距離と測定後の古典分布の距離も混同しない。

**実読範囲：** Complete arXiv v2 (6 Jan 2025) extracted manuscript read: Sections 1–8, all noise-model derivations and simulations, Appendix A/Theorems 6–8, all captions and 43 references. No figure pixels or independent proof reproduction.

**担当：** /root/alternative_arch。**抽出本文：** 70,167 Unicode 文字。

### [5] Tuning quantum computing privacy through quantum error correction

[一次資料](https://arxiv.org/pdf/2312.14521v1) — 読んだ版：arXiv:2312.14521v1 [quant-ph] 22 Dec 2023。

**結果と条件：** 誤り訂正の強さを変えることで、物理ノイズに由来するプライバシーと計算精度の関係を調整する。主な評価は独立な depolarizing noise と Steane 符号の簡略モデルに基づく。

**今回への適用：** ノイズと公開出力のプライバシーが対象である。誤りを許して出力を変える操作から、今回の完全一致するローダーの削減は導けない。

**実読範囲：** Complete arXiv v1 (22 Dec 2023) extracted manuscript read: Sections I–V, all equations, Steane syndrome table, captions and 23 references. No original circuit image pixels or device experiment reproduction.

**担当：** /root/alternative_arch。**抽出本文：** 32,179 Unicode 文字。

### [6] Differential privacy preserving quantum computing via projection operator measurements

[一次資料](https://arxiv.org/pdf/2312.08210v2) — 読んだ版：arXiv:2312.08210v2 [quant-ph] 9 Apr 2024。

**結果と条件：** 有限回の射影測定による標本変動を differential privacy に利用する。導出は中心極限定理や有限の信頼範囲に依存するため、全事象に対する厳密な pure ε-DP と同一視できない。

**今回への適用：** 測定統計の近似は、未知入力の相対位相を保つ回路同値性の証拠にはならない。サンプル誤差を許さないローダー検証には直接使わない。

**実読範囲：** Complete arXiv v2 (9 Apr 2024) extracted manuscript read: Sections I–V, all four theorem derivations, captions and 18 references; no separate appendix was present in this retrieved manuscript despite an introductory appendix mention. No figure pixels or device experiments.

**担当：** /root/alternative_arch。**抽出本文：** 30,081 Unicode 文字。

### [7] Bridging quantum computing and differential privacy: Insights into quantum computing privacy

[一次資料](https://arxiv.org/pdf/2403.09173v3) — 読んだ版：arXiv:2403.09173v3 [quant-ph] 14 Aug 2024。

**結果と条件：** 量子計算と differential privacy を、入力の隣接関係、状態準備、回路ノイズ、測定出力などの観点から整理する調査論文である。統一的な評価基準やプライバシー予算管理の課題も指摘する。

**今回への適用：** 関連研究の所在を確認する用途には有用である。近い入力を見分けにくくする要件は、入力全体をコヒーレントに保存する正確な可逆合成とは異なる。

**実読範囲：** Complete arXiv v3 (14 Aug 2024) extracted text read: Sections I–VI, all four comparison tables, all formulas/captions and 65 references. No original figure pixels.

**担当：** /root/alternative_arch。**抽出本文：** 70,764 Unicode 文字。

**書誌注記：** The parent bibliography and the retrieved v3 manuscript both use Insights into Quantum Computing Privacy. The earlier title A Survey on Quantum Computing Privacy appears in other citations, for example magic[4] reference [41]; it is not the title of the primary v3 text reviewed here.

### [8] Harnessing inherent noises for privacy preservation in quantum machine learning

[一次資料](https://arxiv.org/pdf/2312.11126v2) — 読んだ版：arXiv:2312.11126v2 [quant-ph] 7 Mar 2024。

**結果と条件：** 量子機械学習の有限ショットと物理ノイズによるプライバシーを解析し、Gaussian 近似や勾配の分散を評価する。確率的誤り軽減は期待値を回復しても標本分散を増やし得る。

**今回への適用：** 期待値推定の改善を、未知入力に対するチャネルの完全一致へ置き換えない。正確な chemistry ローダーのゲート削減案は得られない。

**実読範囲：** Complete arXiv v2 (7 Mar 2024) extracted text read: Sections I–V, Lemma 1 and Theorem 1 arguments, PEC/parameter-shift derivations, Iris experiment setup, all captions and 15 references. No original figure pixels or experiment/code rerun.

**担当：** /root/alternative_arch。**抽出本文：** 31,826 Unicode 文字。

### [9] Magic-state distillation with low overhead

[一次資料](https://arxiv.org/pdf/1209.2426v1) — 読んだ版：arXiv:1209.2426v1 [quant-ph] 11 Sep 2012。

**結果と条件：** triorthogonal な二進行列から、多数の T 資源を同時に出力する蒸留符号を構成する。理想 Clifford、独立な入力誤り、受理条件を仮定し、出力間の相関は次の蒸留段で扱う必要がある。

**今回への適用：** 列の重複度と GF(2) 制約を使う限定的な符号探索は参考になる。ただし符号の蒸留率は、任意の Boolean ローダーの AND/Toffoli 複雑さの下界ではない。

**実読範囲：** Entire11-page primary v1 extraction: sections I–IX, Appendices A–B, bibliography and table/figure captions. Missing tool-output middle was separately reread in full; no figure-pixel verification.

**担当：** /root/alternative_arch。**抽出本文：** 50,020 Unicode 文字。

### [10] Magic-state distillation with the four-qubit code

[一次資料](https://arxiv.org/pdf/1204.4221v1) — 読んだ版：arXiv:1204.4221v1 [quant-ph] 18 Apr 2012。

**結果と条件：** 4量子ビット符号を用いた 10-to-2 の Hadamard 型 magic-state 蒸留を示す。誤り率だけでなく受理率と出力間相関を含めて、後続段への接続を設計する。

**今回への適用：** 資源状態の準備費用を評価する際には有用である。準備済み状態と理想補正が別途必要なため、現在1と数える CCZ の費用をこれだけで下げられない。

**実読範囲：** Entire10-page primary v1 extraction, all main sections I–VI, exact acceptance/error polynomials, Lemma IV.1 and Corollary IV.2, bibliography, appendix and all captions. Circuit images not rendered.

**担当：** /root/alternative_arch。**抽出本文：** 40,508 Unicode 文字。

### [11] Multilevel distillation of magic states for quantum computing

[一次資料](https://arxiv.org/pdf/1210.3388v2) — 読んだ版：arXiv:1210.3388v2 [quant-ph] 27 Mar 2013。

**結果と条件：** transversal-H 符号の多段構成によって magic-state 蒸留の資源消費を抑える。高い段数では追加チェックと相関管理が必要で、漸近的な指数は一般最適性の証明ではない。

**今回への適用：** 生の magic-state 消費量と物理回路全体の費用を分ける必要がある。今回の小規模な可逆ロード回路へ、その指数だけを移して改善とは数えない。

**実読範囲：** Entire10-page primary v2 extraction, main I–V, bibliography, Appendices A–D and complete numerical Table I; figure pixels not inspected.

**担当：** /root/alternative_arch。**抽出本文：** 51,013 Unicode 文字。

### [12] Roads towards fault-tolerant universal quantum computation

[一次資料](https://arxiv.org/pdf/1612.07330v2) — 読んだ版：arXiv:1612.07330v2 [quant-ph] 12 Nov 2018。

**結果と条件：** magic-state 蒸留、color code、gauge fixing、pieceable fault tolerance などの普遍耐故障計算を比較する。各方式で符号、局所性、測定、物理資源の前提が異なる。

**今回への適用：** 候補がどの操作と物理モデルを追加しているかを点検する見取り図になる。幾何学的な no-go 定理から、全結合の有限ローダーの Toffoli 下界は得られない。

**実読範囲：** Entire9-page primary v2 extraction: main I–V, Boxes1–3, Table I, all figures through text/captions and85 references. Linked supplementary video not watched.

**担当：** /root/alternative_arch。**抽出本文：** 42,779 Unicode 文字。

### [13] The resource theory of stabilizer quantum computation

[一次資料](https://arxiv.org/pdf/1307.7171v1) — 読んだ版：arXiv:1307.7171v1 [quant-ph] 26 Jul 2013。

**結果と条件：** stabilizer 操作の資源理論を構成し、相対エントロピーや Wigner negativity・mana による変換制限を論じる。mana の主要な構成は奇素数次元に依存し、量子ビットへそのまま適用できない。

**今回への適用：** 資源単調量の前提と許可操作集合を確認するために有用である。単調量の値を特定の qubit 回路の Toffoli 数や構成法と同一視しない。

**実読範囲：** Complete primary arXiv v1 extracted text read: main Sections I–V, conclusions, Appendices A–B, all references and captions; no figure pixels or independent proof verification.

**担当：** /root/alternative_arch。**抽出本文：** 100,522 Unicode 文字。

### [14] Contextuality supplies the “magic” for quantum computation

[一次資料](https://arxiv.org/pdf/1401.4174v2) — 読んだ版：arXiv:1401.4174v2 [quant-ph] 15 Oct 2014。

**結果と条件：** 奇素数次元の安定化子測定と contextuality・離散 Wigner 表現を結び付ける。contextuality と実際の蒸留可能性の関係には、証明された部分と予想の部分がある。

**今回への適用：** 非古典性の資源を特定する理論であり、回路合成アルゴリズムではない。量子ビットの状態非依存 contextuality という例外もあるため、native CCX 数への直接換算は避ける。

**実読範囲：** Complete primary arXiv v2 extracted text read: main article, all references, Supplementary Information including Theorem 2, Lemmas 3–5 and Theorem 6 proofs; no figure pixels or independent proof verification.

**担当：** /root/alternative_arch。**抽出本文：** 48,569 Unicode 文字。

### [15] Application of a resource theory for magic states to fault-tolerant quantum computing

[一次資料](https://arxiv.org/pdf/1609.07488v2) — 読んだ版：arXiv:1609.07488v2 [quant-ph] 15 Mar 2017。

**結果と条件：** robustness of magic を線形計画で扱い、Clifford 同値な資源状態を用いた小規模な対角ゲート合成を示す。測定補助付きの決定的 CCZ 合成に4個の T 資源が必要かつ十分であることを得る。

**今回への適用：** 具体的な合成と資源下界が結び付く重要な参考文献である。ただし今回の評価では CCZ 自体を1 Toffoli 相当として扱うため、4T 実装だけでは1未満への改善にならない。

**実読範囲：** Entire10-page primary PDF extraction read including main text, bibliography, all appendix proofs and tables; diagrams read through captions/text, not pixel-rendered.

**担当：** /root/alternative_arch。**抽出本文：** 50,496 Unicode 文字。

### [16] Quantifying magic for multi-qubit operations

[一次資料](https://arxiv.org/pdf/1901.03322v2) — 読んだ版：arXiv:1901.03322v2 [quant-ph] 2 Jul 2019。

**結果と条件：** 多量子ビットのチャネルについて robustness、magic capacity、古典 Monte Carlo シミュレーションを構成する。Choi 状態の単調量とチャネル合成に対する単調量は区別される。

**今回への適用：** 演算全体の位相と資源を評価する方法として参考になる。CSP という広い自由操作集合での変換や古典標本化は、許可された KMB ゲート列を与えるものではない。

**実読範囲：** Complete primary arXiv v2 (2 Jul 2019), 40-page extracted manuscript read: Sections 1–9, all references, Appendices A–E, numerical tables, algorithms and captions. No figure pixels, source-code execution or independent proof verification.

**担当：** /root/alternative_arch。**抽出本文：** 133,015 Unicode 文字。

### [17] Improved classical simulation of quantum circuits dominated by clifford gates

[一次資料](https://arxiv.org/pdf/1601.07601v3) — 読んだ版：arXiv:1601.07601v3, 9 April 2019 (typeset 11 April 2019)。

**結果と条件：** stabilizer 分解によって Clifford+T 回路を古典計算し、確率推定と近似サンプリングの計算量を抑える。付録はアフィン支持、二次位相、内積計算などを明示する。

**今回への適用：** 位相を保持する独立検証器の構成に使える。近似した出力分布を標本化できることは、任意入力のコヒーレントな回路を同じ Toffoli 数で実装できることとは別である。

**実読範囲：** Complete 20-page extracted primary manuscript: Sections I–VI, Appendices A–F with all lemmas, proofs, algorithms, timing table, figure captions, and all 27 references/endnotes. Every character 0–104232 read; figure pixels not inspected.

**担当：** /root/alternative_arch。**抽出本文：** 104,232 Unicode 文字。

### [18] Robustness of magic and symmetries of the stabiliser polytope

[一次資料](https://arxiv.org/pdf/1807.10296v3) — 読んだ版：arXiv:1807.10296v3 [quant-ph] 4 Apr 2019。

**結果と条件：** 対称性で stabilizer polytope の線形計画を縮約し、robustness の数値計算と近似階層を構成する。有限個の数値結果や制限された分解による上界は、一般の漸近最適性とは異なる。

**今回への適用：** 正しい対称群がある場合の探索空間削減は参考になる。資源分解の効率や古典シミュレーションの指数から、今回のローダーの積共有数は直接決まらない。

**実読範囲：** Complete primary arXiv v3, 35-page extracted manuscript read: Sections 1–6, Appendices A–E including symmetry/3-design proofs, algorithm, numerical tables, captions and all 42 references. No original figure pixels, source execution, or independent proof reproduction.

**担当：** /root/alternative_arch。**抽出本文：** 107,741 Unicode 文字。

### [19] Magic state cultivation: growing T states as cheap as CNOT gates

[一次資料](https://arxiv.org/pdf/2409.17595v1) — 読んだ版：arXiv:2409.17595v1 [quant-ph] 26 Sep 2024。

**結果と条件：** 注入、検査、符号成長、脱出を組み合わせた T-state cultivation を設計する。読んだ v1 の大規模評価には S-state proxy と明示された仮定があり、符号や誤りモデルを固定して比較している。

**今回への適用：** 測定をまたぐ stabilizer flow を契約として検査する発想は有用である。受理率、準備、成長、最終消費までの費用を省略したまま native Toffoli の節減としない。

**実読範囲：** All 33 pages of extracted primary v1 PDF: main sections, references, Appendices A–C, captions and tables. Figures not rendered; published code and numerical data not rerun.

**担当：** /root/alternative_arch。**抽出本文：** 82,583 Unicode 文字。

### [20] Efficient magic state cultivation for $\sqrt{T}$ gates

[一次資料](https://arxiv.org/pdf/2606.10430v1) — 読んだ版：arXiv:2606.10430v1 [quant-ph] 9 Jun 2026。

**結果と条件：** 二重 color code と符号変換を使い、sqrt(T) など高い Clifford 階層の資源状態へ cultivation を拡張する。大規模評価の proxy、成長工程、触媒状態の初期準備が性能比較の条件になる。

**今回への適用：** 利用する回転の角度と資源準備モデルが一致する場合に検討できる。許可された回転が固定された今回の評価では、新しい資源状態を導入するだけで費用を下げられない。

**実読範囲：** Entire22-page extracted primary v1 PDF: main I–V, Appendices A–G, reference list, tables and captions. No figure pixel inspection or independent circuit/noise simulation.

**担当：** /root/alternative_arch。**抽出本文：** 101,216 Unicode 文字。

### [21] Cultivating T states on the surface code with only two-qubit gates

[一次資料](https://arxiv.org/pdf/2509.05232v2) — 読んだ版：arXiv:2509.05232v2 [quant-ph] 16 Sep 2025。

**結果と条件：** surface code の折り畳みと cat ancilla を用い、二量子ビットゲートだけで T-state cultivation を行う構成を示す。物理接続、qubit 移動、proxy による評価条件を伴う。

**今回への適用：** 三量子ビット物理ゲートを使えない装置では有用な設計比較になる。論理 CCX を既に1と数えるモデルでは、物理ゲート種の変更だけでローダー費用は下がらない。

**実読範囲：** Entire extracted primary v2 PDF: all 14 pages, main text, noise-model appendix, bibliography, captions and tables. Figure pixels not inspected.

**担当：** /root/alternative_arch。**抽出本文：** 52,305 Unicode 文字。

### [22] Fold-transversal surface code cultivation

[一次資料](https://arxiv.org/pdf/2509.05212v2) — 読んだ版：arXiv:2509.05212v2 [quant-ph] 24 Mar 2026。

**結果と条件：** surface code 内で fold-transversal な Clifford 検査と符号成長を行い、cultivation の物理費用を評価する。Appendix D の syndrome 引き継ぎは、後続が特定の Clifford 操作であることを利用する。

**今回への適用：** 古い測定値を使う際に、その後の全論理作用を確認する考え方は HMR 監査に役立つ。非局所接続、受理率、補正、成長工程を数えずに Toffoli 削減へ換算しない。

**実読範囲：** Entire extracted primary v2 PDF: all 25 pages, main sections I–IV, bibliography, Appendices A–E, all extracted table contents and figure captions. Figure pixels and supplied code not independently inspected.

**担当：** /root/alternative_arch。**抽出本文：** 96,122 Unicode 文字。

### [23] High rate magic state cultivation on the surface code

[一次資料](https://arxiv.org/pdf/2502.01743v4) — 読んだ版：arXiv:2502.01743v4, margin header 30 January 2026; cached PDF title page dated 2 February 2026; 21 pages。

**結果と条件：** 非局所な controlled fold と三量子ビットゲートを用い、surface code 上の H/HXY cultivation と erasure 検出を評価する。取得 v4 の表紙は High Rate、取得メタデータと abs は Efficient と題名が異なるため、読了は実キャッシュの版とハッシュに固定する。

**今回への適用：** Appendix I の Fredkin＝1 CCZ＋2 CX は今回の cache retirement と同じ恒等式を確認する。CX 射影の多次元受理空間や物理ノイズの前提を省略して、未知入力の無料リセットや追加の Toffoli 節減を導かない。

**実読範囲：** Entire21-page extracted primary v4 PDF, main I–VII, bibliography, Appendices A–L, all captions/tables/pseudocode; figures not rendered and external code not rerun.

**担当：** /root/alternative_arch。**抽出本文：** 87,652 Unicode 文字。

**書誌注記：** The cached primary PDF explicitly bears title High Rate Magic State Cultivation on the Surface Code, matching the parent bibliography. The fetch metadata title, and the arXiv abstract page independently opened by the root, instead say Efficient Magic State Cultivation on the Surface Code. The full-text reading claim is pinned to the cached v4 PDF/header and SHA256 below, not inferred from the current abstract-page title. No newer differently titled full text is claimed read.

### [24] A continuity theorem for Stinespring’s dilation

[一次資料](https://arxiv.org/pdf/0710.2495v1) — 読んだ版：arXiv:0710.2495v1 [quant-ph] 12 Oct 2007。

**結果と条件：** CP map の cb/diamond 型距離と、共通環境上の Stinespring dilation を最適化した距離の連続性を示す。近い dilation が存在することと、任意に固定した dilation が近いことは異なる。

**今回への適用：** 親論文の局所誤差を一つの整合した回路表現へ結合できるかを点検する根拠になる。個別に最適化した gauge を、固定された回路で同時に使えると仮定しない。

**実読範囲：** Entire18-page primary arXiv v1 extraction: sections1–5, Theorems1–2, all lemmas/propositions and proofs, Appendices A–B, references. Original publisher landing page was abstract-only and is not the reading source.

**担当：** /root/alternative_arch。**抽出本文：** 35,563 Unicode 文字。

**書誌注記：** Publisher page contains abstract/section snippets; full primary arXiv text recovered separately.

### [25] Stabilizer codes and quantum error correction

[一次資料](https://arxiv.org/pdf/quant-ph/9705052v1) — 読んだ版：arXiv:quant-ph/9705052v1, header 28 May 1997; printed text pages 1–114 plus front matter. The extracted title page displays a 2024 typeset date; this is not treated as a new arXiv revision.。

**結果と条件：** stabilizer 符号、符号化・復号、測定を使う論理ゲート、閾値の概算、符号パラメーターの境界と具体例を体系的に導く。測定による置換には既知 stabilizer と入力非依存 syndrome が必要で、Toffoli ancilla の準備には非Clifford 操作を使う。

**今回への適用：** 位相を含む GF(2) 表現と測定後補正の正当化に直接役立つ。符号空間内の恒等式を任意入力へ拡張せず、encoded zero を清浄な物理 qubit と数えず、本文の Clifford T を現代のπ/8 T と混同しない。

**実読範囲：** All 276656 Unicode characters. Chapter 5 includes every subsection, including measurement transformations (5.4), encoded Toffoli (5.7) and general Clifford network construction (5.8); Chapters 6–8 and both appendices are fully included. This supplements the narrower prior main[13] review.

**担当：** /root/alternative_arch。**抽出本文：** 276,656 Unicode 文字。

### [26] Improved simulation of stabilizer circuits

[一次資料](https://arxiv.org/pdf/quant-ph/0406196v5) — 読んだ版：arXiv:quant-ph/0406196v5, 18 June 2008。

**結果と条件：** destabilizer を併用した tableau により、stabilizer 回路の測定と更新を効率化する。Clifford の標準形と CNOT 数の漸近境界、混合状態や非Clifford 拡張も扱う。

**今回への適用：** 測定・符号・論理作用の検証器に有用である。大域位相を省く内積処理と、相対位相を必要とする HMR の契約を分け、Clifford の一般的境界をローダーの Toffoli 最適性と解釈しない。

**実読範囲：** Complete primary extracted text, Sections I–IX including every theorem/proof, the full tableau simulation algorithm, mixed/non-stabilizer extensions, open problems, all figure captions and references/endnotes (15 PDF pages). All text characters 0–70935 read; figure pixels not inspected.

**担当：** /root/alternative_arch。**抽出本文：** 70,935 Unicode 文字。

### [27] The clifford group, stabilizer states, and linear and quadratic operations over GF(2)

[一次資料](https://arxiv.org/pdf/quant-ph/0304125v1) — 読んだ版：arXiv:quant-ph/0304125v1 18 Apr 2003。

**結果と条件：** Clifford 操作と stabilizer 状態を、二進 symplectic 行列、アフィン支持、二次位相で表現する。位相補正を含む合成法と二体ゲート分解を与える。

**今回への適用：** Boolean 値だけでなく相対位相まで保つ GF(2)/HMR 検証の独立した根拠になる。Clifford ゲートの削減だけでは、現在の Toffoli 目的関数は改善しない。

**実読範囲：** Shared independent reading of all9 primary PDF pages, main I–VI, Theorems1–6 and proofs, Appendix Eq(4) proof, bibliography.

**担当：** /root/cost_audit。**抽出本文：** 37,838 Unicode 文字。

### [28] Fault-tolerant quantum computation by anyons

[一次資料](https://arxiv.org/pdf/quant-ph/9707021v1) — 読んだ版：arXiv:quant-ph/9707021v1,9 Jul1997,27pages (typeset date26 Nov2024)。

**結果と条件：** toric code と有限群の quantum double を構成し、anyon の融合・組紐を用いる耐故障計算の枠組みを示す。非可換例の普遍性や物理的な安定性には、別途必要な条件と構成がある。

**今回への適用：** topological operation の意味を確認する基礎資料である。位相の分類や局所誤りからの保護は、有限温度での自己訂正や今回の可逆算術の無料実装を意味しない。

**実読範囲：** Full introduction, Sections1–7 includingall5.1–5.4 local/ribbon-operator algebra derivations, concluding remarks, acknowledgements, all25references and figure captions. No separate appendix present.

**担当：** /root/alternative_arch。**抽出本文：** 73,328 Unicode 文字。

### [29] Models for gapped boundaries and domain walls

[一次資料](https://arxiv.org/pdf/1104.5047v4) — 読んだ版：arXiv:1104.5047v4,28 Sep2012,21pages。

**結果と条件：** Levin–Wen 型格子模型の gapped boundary と domain wall を module・bimodule category で記述する。Morita 同値と透明な壁の関係を整理する。

**今回への適用：** 壁や境界を使う構成の可逆性を確認する理論である。非可逆な壁の分類と物理ゲート費用は別なので、圏論上の同値だけで qubit や Toffoli を消去しない。

**実読範囲：** Full Sections1–7, categorical/physical dictionaryTable1, all references and figure captions; no separate appendix present. Diagrammatic formulas were read as extracted text, not inspected as pixels.

**担当：** /root/alternative_arch。**抽出本文：** 60,485 Unicode 文字。

### [30] The quantum double model with boundary: Condensations and symmetries

[一次資料](https://arxiv.org/pdf/1006.5479v5) — 読んだ版：arXiv:1006.5479v5,4 Jun2019,31pages。

**結果と条件：** 有限群の quantum double に境界を導入し、部分群と cocycle から凝縮・anyon の透過・対称性を解析する。折り畳みによる記述では組紐の向きや境界条件も追跡する。

**今回への適用：** ラベル対応があっても融合と位相の整合性が必要であることを示す。modular S/T を保存する置換を、完全な braided 同値や無料の回路置換と同一視しない。

**実読範囲：** All main Sections1–7, propositions/lemmas and included proofs, AppendicesA andB.1–B.3 includingTheoremB.1 proof steps(a)–(l), all17references and figure/table captions.

**担当：** /root/alternative_arch。**抽出本文：** 93,049 Unicode 文字。

### [31] Symmetry fractionalization, defects, and gauging of topological phases

[一次資料](https://arxiv.org/pdf/1410.4540v4) — 読んだ版：arXiv:1410.4540v4, 2019-10-15; 108 pages, 22 figures。

**結果と条件：** 対称性の分数化、欠陥の融合・組紐、gauging を G-crossed 理論で整理し、H³/H⁴ の障害と多数の例を与える。有限・オンサイト・unitary 対称性などの仮定を区別し、ラベルが固定でも −1 位相が残る例を含む。

**今回への適用：** ビット値や固定点だけでなく相対位相を検査する必要性の具体例になる。圏論上の gauge 変更や分類結果から、固定した75語の Toffoli 最小数や無料の物理変換は導けない。

**実読範囲：** Complete primary extracted text: sections I–XI (all examples A–N), Appendices A–D, references 1–174 and endnotes 175–192; 513129 Unicode characters. Not an independent PDF diagram/equation audit.

**担当：** /root/shared_synthesis。**抽出本文：** 513,129 Unicode 文字。

### [32] Topological quantum memory

[一次資料](https://arxiv.org/pdf/quant-ph/0110143v1) — 読んだ版：arXiv:quant-ph/0110143v1, 24 October 2001。

**結果と条件：** topological quantum memory の復号と閾値を、homology と格子統計模型へ結び付ける。最尤の homology class を選ぶ方法と、最小重みの単一誤り鎖を選ぶ方法は異なる。

**今回への適用：** 測定履歴、hook error、入力条件を保った論理操作の監査に役立つ。実数化や共役回路による出力統計の再現を、未知入力の完全なチャネル同値として使わない。

**実読範囲：** Complete 39-page primary manuscript extracted text, Sections I–XI including all subsections, counting/threshold derivations, fault-tolerant gates and 4D local recovery, acknowledgments, all 41 references and footnotes, and all figure captions. All 0–197812 characters read; original diagram pixels not inspected.

**担当：** /root/alternative_arch。**抽出本文：** 197,812 Unicode 文字。

### [33] Fast decoders for topological quantum codes

[一次資料](https://arxiv.org/pdf/0911.0581v2) — 読んだ版：arXiv:0911.0581v2, 5 Feb 2010, 5 pages (typeset date says 30 Oct 2018)。

**結果と条件：** renormalization と belief propagation を組み合わせ、topological code の復号を並列化する。報告された高い閾値は主に完全な syndrome を仮定した数値評価である。

**今回への適用：** 大規模な物理誤り訂正器の古典実行時間を改善する方法である。復号の計算量や並列深さは、今回の量子ローダーの Toffoli 数とは別に数える。

**実読範囲：** All main text from abstract through conclusion, equations 1–8, figure captions 1–4, acknowledgements and all18 references. No separate appendix present.

**担当：** /root/alternative_arch。**抽出本文：** 21,246 Unicode 文字。

### [34] Almost-linear time decoding algorithm for topological codes

[一次資料](https://arxiv.org/pdf/1709.06218v3) — 読んだ版：arXiv:1709.06218v3, 24 Nov 2021, 12 pages。

**結果と条件：** union-find による cluster 成長と peeling を用い、ほぼ線形時間で Pauli 誤りと erasure を復号する。距離に基づく訂正保証と数値性能を分けて提示する。

**今回への適用：** 古典的な誤り位置の管理には有用である。復号器内の virtual erasure は量子状態の消去ではないため、live qubit の無料リセットには使えない。

**実読範囲：** All introduction and Sections1–7, Algorithms1–2, Lemma1 and Theorem1 proof, AppendicesA–B, all68 references and figure/table captions.

**担当：** /root/alternative_arch。**抽出本文：** 57,397 Unicode 文字。

### [35] Surface code quantum computing by lattice surgery

[一次資料](https://arxiv.org/pdf/1111.4022v3) — 読んだ版：arXiv:1111.4022v3,21 Feb2013,29 pages。

**結果と条件：** planar surface code の merge と split により、局所性を保った論理測定や CNOT を構成する。境界測定の結果に応じた補正と、距離を確保する面積・測定周期が必要になる。

**今回への適用：** 二つの論理入力を一つへ merge する操作は一般には非unitaryである。符号空間と測定補正を省略したまま、任意入力の可逆ロードへ置き換えない。

**実読範囲：** Complete Sections1–9 and AppendicesA–B, all31 references, figure captions and extracted stabilizer-array text; stabilizer matrices have lost column spacing and image pixels were not inspected.

**担当：** /root/alternative_arch。**抽出本文：** 65,496 Unicode 文字。

### [36] Topological fault-tolerance in cluster state quantum computation

[一次資料](https://arxiv.org/pdf/quant-ph/0703143v1) — 読んだ版：arXiv:quant-ph/0703143v1, 16 Mar 2007, 20 pages (typeset date says26 Nov2024)。

**結果と条件：** 3D cluster-state 計算を2D空間と時間の構成として用い、欠陥の幾何と誤り訂正から耐故障計算を実現する。非Clifford 資源には別の準備・蒸留工程を要する。

**今回への適用：** topological な回路同値の前提となる相関と境界条件を確認できる。物理体積や特定ノイズ模型の閾値は、有限の KMB 回路の CCX 数の改善証拠にはならない。

**実読範囲：** All main Sections1–7, AppendixA state distillation and AppendixB effective error model, all33 references, figure captions and text descriptions of diagrams. Diagram-only topological equations8–13 were not inspected as image pixels.

**担当：** /root/alternative_arch。**抽出本文：** 52,351 Unicode 文字。

### [37] Lattice surgery with a twist: Simplifying clifford gates of surface codes

[一次資料](https://arxiv.org/pdf/1709.02318v2) — 読んだ版：arXiv:1709.02318v2,17 Apr2018,16 pages。

**結果と条件：** Clifford frame の古典追跡と twist を含む lattice surgery により、surface-code 操作と長距離の多標的 CNOT を整理する。測定軸、接続用面積、hook error の管理を伴う。

**今回への適用：** 後続の測定基底まで変更できる場合は、Clifford の移動・吸収が可能である。固定した出力レジスターと位相を要求するローダーでは、frame を戻す費用まで確認する。

**実読範囲：** Complete main Sections1–5, AppendixA.1/A.2 andB, all27 references and figure/table captions. Lattice/circuit diagram pixels not inspected.

**担当：** /root/alternative_arch。**抽出本文：** 54,978 Unicode 文字。

### [38] A game of surface codes: Large-scale quantum computing with lattice surgery

[一次資料](https://arxiv.org/pdf/1808.02892v3) — 読んだ版：arXiv:1808.02892v3, 3 February 2019; accepted in Quantum 1 February 2019。

**結果と条件：** surface-code patch を tile と時間段階で表し、data block と magic-state 工場の面積・時間を比較する。蒸留の spectator 消去や Clifford frame の吸収には、初期状態と終端測定の条件がある。

**今回への適用：** 既知状態の中間レジスターを省く着想は検討できる。tile の0時間はゼロゲートを意味せず、未知入力の cache 消去や固定出力へは補正と相関の確認が必要である。

**実読範囲：** Complete 37-page primary extracted text: introduction/rules, Sections 1–7, Appendices A–D, all 65 references, all figure captions, tables, and algorithms; all characters 0–146331 read. Figure pixels and matrix column alignment were not independently inspected.

**担当：** /root/alternative_arch。**抽出本文：** 146,331 Unicode 文字。

### [39] Dynamically generated logical qubits

[一次資料](https://arxiv.org/pdf/2107.02194v2) — 読んだ版：arXiv:2107.02194v2,12 Oct2021,19 pages。

**結果と条件：** 二体 Pauli 測定を周期的に並べる honeycomb Floquet code で、静的 gauge group からは見えない論理量子ビットを生成する。測定順序と instantaneous stabilizer group が保護される情報を決める。

**今回への適用：** 同じ測定集合でも順序が変わると論理情報を失い得る、という監査上の注意を与える。周期や情報の移動だけから物理 qubit の節約は導けない。

**実読範囲：** Complete Sections1–4 including1.5Majorana representation, all syndrome/threshold and boundary arguments, AppendixA toy model, all13 references and figure captions.

**担当：** /root/alternative_arch。**抽出本文：** 73,389 Unicode 文字。

### [40] Planar floquet codes

[一次資料](https://arxiv.org/pdf/2110.05348v2) — 読んだ版：arXiv:2110.05348v2, 14 Dec 2021, 16 pages。

**結果と条件：** planar な Floquet boundary を検討するが、読んだ v2 は回転する境界構成に一定重みの時空論理誤りがあり、耐故障ではないと訂正している。後の別構成の性能をこの版の結果に含めない。

**今回への適用：** 見かけの各時刻の符号距離だけでは、全測定履歴を含む安全性を保証できない例である。この境界構成を改善済みの回路候補として採用しない。

**実読範囲：** All Sections1–4 including gauge-group count, scheduleAlgorithm1, boundary construction, logical dynamics, constant-size-error correction§3.3, computation§3.5, acknowledgements, all18 references and figure/table captions.

**担当：** /root/alternative_arch。**抽出本文：** 43,403 Unicode 文字。

### [41] Quantum computation from dynamic automorphism codes

[一次資料](https://arxiv.org/pdf/2307.10353v3) — 読んだ版：arXiv:2307.10353v3, 18 August 2024; accepted in Quantum 2 August 2024; 101 pages。

**結果と条件：** 局所可逆な測定列で符号空間を移しながら論理ゲートを実行する dynamic automorphism code を構成する。効率的復号器・閾値や一部の耐故障性は未解決で、非Clifford 操作には非Pauli測定と適応補正を要する。

**今回への適用：** 測定結果を捨てられる条件と、全論理演算子を保持する検査は有用である。符号化、多層 qubit、非Pauli測定、復号と frame の費用を含む実回路なしに、今回の Toffoli 数や幅の改善とは数えない。

**実読範囲：** Complete extracted text, all 321012 Unicode characters: main sections 1–9, Appendices A–G, 76 references, footnotes, extracted measurement-sequence tables and figure captions. Diagram pixels in image-heavy detector appendices B/D/E and other figures were not independently inspected or reconstructed.

**担当：** /root/alternative_arch。**抽出本文：** 321,012 Unicode 文字。

### [42] Quantum codes on a lattice with boundary

[一次資料](https://arxiv.org/pdf/quant-ph/9811052v1) — 読んだ版：arXiv:quant-ph/9811052v1, 20 Nov 1998, 6 pages (typeset date says 26 Nov 2024)。

**結果と条件：** rough/smooth boundary を持つ格子符号を relative homology で表し、境界の配置と論理自由度の関係を示す。符号空間内の string operator が論理演算子になる。

**今回への適用：** surface-code 境界を使う提案の情報量と論理作用を数える基礎となる。一般の算術回路の ancilla 再利用法や Toffoli 削減を与えるものではない。

**実読範囲：** Complete6-page text, toric and boundary construction, explicit stabilizer example, logical-operator/homology and distance derivations, figure captions1–4, final anyon discussion, acknowledgements and all7 references.

**担当：** /root/alternative_arch。**抽出本文：** 16,412 Unicode 文字。

### [43] Optimal resources for topological 2D stabilizer codes: Comparative study

[一次資料](https://arxiv.org/pdf/quant-ph/0703272v1) — 読んだ版：arXiv:quant-ph/0703272v1, 29 Mar 2007, 6 pages。

**結果と条件：** 2D の surface code と color code を、符号距離に対する data qubit 数の比で比較する。torus と planar boundary では条件と有利な配置が異なる。

**今回への適用：** 符号化したアーキテクチャを選ぶ場合の比較である。syndrome ancilla、非Clifford 操作、耐故障の全費用を含まない比率を、今回の回路幅へ直接置き換えない。

**実読範囲：** Complete main Sections I–IV, equations1–17, figure captions1–7, acknowledgements and all20 bibliography entries.

**担当：** /root/alternative_arch。**抽出本文：** 27,890 Unicode 文字。

### [44] Theory and architecture of syndrome-resolved logical gates

[一次資料](https://arxiv.org/pdf/2510.08290v2) — 読んだ版：arXiv:2510.08290v2, 25 Jun 2026, 37頁。

**結果と条件：** 各 syndrome 分岐が入力非依存な確率で論理ユニタリを与える weak transversal gate を構成し、RUS で角度を補正する。既存 CNOT の伝播へ回転を埋め込む手法も示す。

**今回への適用：** K_s†K_s＝p_s I と補正後の論理位相を別々に証明する基準、既存パリティの再利用が参考になる。物理工場の倍率は native Toffoli の倍率ではなく、proxy の誤差指標や hook doping による距離低下を含めて評価する。

**実読範囲：** 主本文I–IV、Appendices A–H、全参考文献・全図キャプションを通読。Fig.11/12（29頁）の原PDF画像も確認。一次抽出本文中のLatexitメタデータを除いた可読コピーを保存。

**担当：** /root/cost_audit。**抽出本文：** 228,643 Unicode 文字。

**追加の条件・限界：** 一般Alg.1の最後のPauli部分は大きな支持を持ち得るので、物理局所性/定数深さを個々の符号・ハードウェアで示す必要がある。Appendix D3のsurface-code errorは単一入力のPauli期待値proxyで、一般channel diamond距離の保証ではない。hook dopingは例でfault distance7→5。数値実験を独立再現していない。

### [45] A robust phase of continuous transversal gates in quantum stabilizer codes

[一次資料](https://arxiv.org/pdf/2510.01319v2) — 読んだ版：arXiv:2510.01319v2, 2 Feb 2026, 9頁。

**結果と条件：** 奇数距離の surface code で連続角の transversal 操作を繰り返し、復号・reset を含む方策によって資源状態を準備する。主要な評価は物理 Z dephasing のモデルに基づく。

**今回への適用：** 準備される状態を指定した繰り返し手順として検討できる。状態準備中の reset を、任意の未知入力を保持する oracle の reset として使わない。

**実読範囲：** 主本文1–5頁、全参考文献5–7頁、Appendix相当のSyndrome Sampling / Logical Channel Calculation / Policy Optimization / Simulations / Fault-tolerance / Distribution Properties / Resource estimation（8–9頁）と全図キャプションを通読。

**担当：** /root/cost_audit。**抽出本文：** 49,731 Unicode 文字。

**追加の条件・限界：** 主結果はphysical Z dephasing＋coherent rotationの数値評価。phenomenological/circuit-level noiseの全面評価は著者も将来課題としている。距離を大きくすると有利な目標角の範囲も指数的に小さくなる。有限discretization・経験syndrome分布・discount factor0.99の方策を使用し、誤差と準備成功率を含む費用である。

### [46] Classification of topologically protected gates for local stabilizer codes

[一次資料](https://arxiv.org/pdf/1206.1609v1) — 読んだ版：arXiv:1206.1609v1, 7 Jun 2012, 6頁。

**結果と条件：** 幾何学的に局所な topological stabilizer code の一定深さユニタリを、空間次元に対応する Clifford 階層へ制限する。符号を保ち、伝播範囲が限定されることが重要な仮定である。

**今回への適用：** 無料の保護ゲートを仮定する提案の条件を点検できる。全結合、適応測定、任意の code deformation を含む今回の有限回路の Toffoli 下界ではない。

**実読範囲：** 全6頁の主定理・Corollary 1、toric code例、一般2D証明、D次元への帰納と有限群の証明、全参考文献・図キャプションを通読。

**担当：** /root/cost_audit。**抽出本文：** 31,140 Unicode 文字。

**追加の条件・限界：** キャッシュのarXiv識別は2012v1だが冒頭組版日付は2024年になっている。版の根拠はarXiv識別に置き、後年の全改訂状況は未調査。歴史的な物理Tの費用比較を現在のGVQCC採点へ引用しない。

### [47] Protected gates for topological quantum field theories

[一次資料](https://arxiv.org/pdf/1409.3898v3) — 読んだ版：arXiv:1409.3898v3, 2016-01-25, 50ページ。

**結果と条件：** 2D TQFT の locality-preserving な保護ゲートを、各融合基底で整合する位相付き置換として制約する。Fibonacci・Ising などの結論は曲面、荷電ラベル、mapping class group の条件に依存する。

**今回への適用：** ラベルの置換だけでなく位相と基底間の整合性を検査する根拠になる。固定2Dトポロジーと局所ユニタリの no-go を、一般の KMB 回路の4170境界へ適用しない。

**実読範囲：** 本文 §§1–7、全定理・補題の証明、Appendix A、参考文献まで、取得された全126,699文字を読了。図のラベル・キャプションは読了、全図の原画像照合は未実施。

**担当：** /root/cost_audit。**抽出本文：** 126,699 Unicode 文字。

**追加の条件・限界：** 制約は必要条件であり、その部分群の全要素が特定の微視的モデルで実装可能だとは主張しない。Fibonacci/Ising の結論は指定された曲面・荷電ラベル・TQFT 仮定に依存。欠陥線・凝縮境界は本論の対象外。

### [48] Measurement quantum cellular automata and anomalies in floquet codes

[一次資料](https://arxiv.org/pdf/2304.01277v2) — 読んだ版：arXiv:2304.01277v2, 2023-08-02（本文の最終頁番号77）。

**結果と条件：** 局所可逆な Pauli 測定列を measurement QCA として扱い、情報の流れと Floquet 境界の anomaly を分類する。補正後の論理情報保存と、境界に生じる非自明な流れを区別する。

**今回への適用：** 測定が未知入力の情報を漏らさず論理作用を保つ条件に役立つ。情報の移動や周期変更は物理 qubit の削除ではなく、ancilla 追加も含めた実回路の費用が必要である。

**実読範囲：** キャッシュ249,775文字の全テキストを順に実読。本文§§1–7、全参考文献、付録A–E（Cの1次元安定化子分類の2通りの証明、DのWPT境界、EのHH境界回路を含む）。図のキャプションと抽出された演算子表は読んだが、全図の画像を個別に視認したわけではない。

**担当：** /root/cost_audit。**抽出本文：** 249,775 Unicode 文字。

### [49] Locality-preserving logical operators in topological stabiliser codes

[一次資料](https://arxiv.org/pdf/1709.00020v3) — 読んだ版：arXiv:1709.00020v3, 2018-01-25, 24ページ。

**結果と条件：** locality-preserving logical operator を透明な domain wall と対応付け、topological stabilizer code の論理操作を分類する。空間次元、励起の次元、stack と境界条件が許される Clifford 階層を決める。

**今回への適用：** 3D 符号で CCZ が可能という構造は、現在の1 CCZ の費用を下回る置換ではない。Boolean address 変換や積共有とは別に、符号化と物理操作を全て数えて検討する。

**実読範囲：** 本文 I–VI、全定理・補題・証明、図表の全説明と参考文献まで全126,765文字を読了。原図の全画像照合は未実施。

**担当：** /root/cost_audit。**抽出本文：** 126,765 Unicode 文字。

**追加の条件・限界：** Pauli は最初から自明な LPLO として省かれており、「唯一」「none」はそれらを除いた記述。bulk の壁の分類と、特定境界の全物理実装の分類は区別が必要。STS・整数次元励起が対象で、fractal/fracton 型、non-Abelian、defect braiding は一般結果の対象外。

### [50] Adaptive constant-depth circuits for manipulating non-abelian anyons

[一次資料](https://arxiv.org/pdf/2205.01933v2) — 読んだ版：arXiv:2205.01933v2, 2022-09-28, 48ページ（arXiv現行版を再確認）。

**結果と条件：** 固定された有限 solvable group の quantum double について、適応測定と古典処理を用いる一定量子深さの状態準備・anyon 操作を示す。付録の印刷式2箇所には独立の反例・正規化不整合を記録したが、全主定理の否定とはしていない。

**今回への適用：** compute–位相–uncompute を直接の対角位相へ吸収する着想は、中間値を減らす候補になる。qudit、非局所古典処理、既知 ground state などの前提を除かず、実際の二進ゲート数と全入力作用を検証する必要がある。

**実読範囲：** 本文 §§1–7、Appendix A–C、全証明と参考文献、図の抽出説明まで全140,607文字を読了。原PDF全48頁を保存し、Appendix A p42 の原画像も目視照合。全図の画像照合・全主定理の独立再証明は未実施。

**担当：** /root/cost_audit。**抽出本文：** 140,607 Unicode 文字。

### [51] Quantifying multiqubit magic channels with completely stabilizer-preserving operations

[一次資料](https://arxiv.org/pdf/2202.07867v2) — 読んだ版：arXiv:2202.07867v2, 1 Jul 2022, 19頁（公開論文とはタイトルが異なる）。

取得本文の題名：Quantifying dynamical magic with completely stabilizer preserving operations as free。

**結果と条件：** 完全 stabilizer-preserving 操作を自由とする動的 magic の資源理論を構成し、単発の費用・蒸留境界と古典シミュレーションを扱う。読んだ公開 v2 には min-relative entropy の faithfulness と full-rank 計算の不整合がある。

**今回への適用：** 広い自由操作集合での上界は、許可された Clifford・測定回路の実装を保証しない。当該の不整合な断言や、誤差制限を外した標本数の constant runtime を、正確なローダー合成へ転用しない。

**実読範囲：** 全19頁。主本文I–VII、Theorem 1–2 / Propositions 1–4 / classical simulation algorithm、Appendices A–H、2表と全参考文献・図キャプションを通読。アルゴリズム部分は出力切詰めを避けて別途全文を再読。出版先APSのabstractと題名/DOIは照合したが、最終出版PDFの本文は取得失敗。

**担当：** /root/cost_audit。**抽出本文：** 83,464 Unicode 文字。

**書誌注記：** The parent bibliography uses the published title Quantifying multiqubit magic channels with completely stabilizer-preserving operations. The reviewed arXiv:2202.07867v2 PDF, dated 4 July 2022 on its title page and 1 July 2022 in its version header, instead has the title Quantifying dynamical magic with completely stabilizer preserving operations as free. Reading and formula cautions apply to that cached preprint version, not an uninspected corrected publication.

**追加の条件・限界：** 公開v2には注意すべき式の不整合がある。min-relative entropyの一般mixed stateに対するfaithfulness（Eq.37）は同じ論文Appendix Cのfull-rankでDmin=0という計算と両立しない。Theorem2の行列次元表記と本文証明のconvex-hull正規化にも差がある。このため当該断言を実装判定に使用しない。出版版で訂正されたかは未確認。robustnessは本文・Appendixで正規化の定義が異なる箇所があるため数値を混用しない。

### [52] The axiomatic and the operational approaches to resource theories of magic do not coincide

[一次資料](https://arxiv.org/pdf/2011.11651v3) — 読んだ版：arXiv:2011.11651v3, 18 Jan 2022, 30頁。

**結果と条件：** Clifford・安定化子準備・Pauli 測定などで作る操作 SO は、複数量子ビットでは公理的な CSP の真部分集合であると示す。単一 qudit の場合との違いと、測定の構造を明示する。

**今回への適用：** magic を増やさない写像でも、許可ゲートで無料実装できるとは限らない直接的な根拠になる。任意 Boolean 関数を測定・再準備に埋め込む例は coherence を失うため、coherent XOR ローダーの代用にならない。

**実読範囲：** 全30頁。主本文I–VII、Theorems 1–5 / Lemmata 1–16の全証明、単一quditの等価性、一般multi-quditの分離、Appendices A–C、全参考文献・図キャプションを通読。

**担当：** /root/cost_audit。**抽出本文：** 101,156 Unicode 文字。

**書誌注記：** Cited journal/DOI inconsistent with title-author primary metadata. Primary arXiv and author publication list identify J. Math. Phys. 63,112201 (2022), DOI10.1063/5.0085774; manuscript cites Quantum6,878. Raw citation preserved.

**追加の条件・限界：** 全てのCSPが無条件に効率的古典シミュレーション可能とは本論文も述べていない。効率的に標本化できる特別なPOVMなどが追加で必要。分離の証明は古典制御を非効率な任意関数まで許しても成立する。元magic参考文献のDOIは誤りであるため、実読一次資料URLは正しいarXivへ固定。

### [53] Cross-cap defects and fault-tolerant logical gates in the surface code and the honeycomb floquet code

[一次資料](https://arxiv.org/pdf/2310.06917v2) — 読んだ版：arXiv:2310.06917v2, 2024-05-21, 26ページ。

**結果と条件：** cross-cap を含む surface/Floquet code で一定深さの論理 Clifford 操作を構成する。open boundary で元の gauge fixing に戻る工程には O(d) の測定が別途必要になる。

**今回への適用：** 論理操作後に評価で要求される状態へ戻す費用も数える例になる。固有位相 e^(±iπ/4) の相対位相はπ/2なので、その操作を非Clifford T と混同しない。

**実読範囲：** 本文 I–V、Appendix A の topological invariance/quadratic property の証明、Appendix B の測定版構成、参考文献、全図表のキャプションと抽出ラベルまで全117,530文字読了。全原図画像の独立照合は未実施。

**担当：** /root/cost_audit。**抽出本文：** 117,530 Unicode 文字。

**追加の条件・限界：** open boundary を持つ非向き付け可能 surface code では U が e/m boundary を交換する。subsystem code としては論理 H だが、元の gauge fixing へ戻すには境界で O(d) 回の stabilizer 測定が必要（III.C.4）。折る前は cross-cap の O(d) 本の長距離静的接続が必要。4+1D fermionic toric code の T は discussion の将来構想で、ここに実装済みの T 回路はない。fold-transversal の threshold 欠如は著者も追加数値解析が必要とする示唆であり、一般的不可能定理として使わない。

## 再生成

`python build_magic_coverage_report.py --directory PATH --out OUTPUT` でこのレポートと詳細メモを JSON 台帳から再生成できる。ローカルに一次本文のキャッシュがある場合だけ `--verify-caches` を追加すると、全53件の SHA256 と文字数も照合する。公開・共有用の成果物は台帳、独自メモ、一次URL、再生成器であり、著作物の本文キャッシュを含める必要はない。
