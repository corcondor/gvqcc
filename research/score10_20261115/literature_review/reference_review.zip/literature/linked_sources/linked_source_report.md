# Identification and applicability of the two linked sources

## Exact identities and versions

The supplied [ResearchGate notation table](https://www.researchgate.net/figure/Notation-used-throughout_tbl1_413832096) belongs to **Jiachen Shen and Hui Zhong, The resource cost of magic in a code block**, [arXiv:2608.29438](https://arxiv.org/abs/2608.29438). The current version is v2, 1 September 2026; v1 is dated 29 August 2026. Comparison of the complete primary HTML extractions finds only the version/date heading and Zhong's affiliation/contact changed. The abstract, main sections1–5, bibliography and Appendices A–C are identical. Both versions have **53 numbered references**, despite ResearchGate displaying52. The comparison is reproducible from `magic_version_comparison.json`.

The second source is **Shudan Jiang et al., Atomic-Scale Imaging of Lattice Relaxation and Topological Flat Bands in Helical Trilayer Graphene**, [arXiv:2609.39986v1](https://arxiv.org/abs/2609.39986), 30 September 2026. Its [12-page primary manuscript](https://arxiv.org/pdf/2609.39986) has **56 numbered references**, despite ResearchGate displaying55.

## Magic paper: what was actually established

The paper studies a post-selected measurement on one encoded logical qubit. Its witness is acceptance probability times distance of the normalized effect from the stabilizer-effect octahedron. An unconditional bound charges the summed diamond distances of outcome-resolved resource cells from a free comparison. Its stronger bound requires a compatible recovery skeleton, bounded insertion degree, and transcript-wise branch factorization below a certified threshold. With a distance-linear threshold and per-cell amplitude O(1/d), accepted magic is suppressed as exp[-Omega(d log d)]. The split-readout weak-Z-rotation family supplies a threshold certificate; a logical-string example attains the exponent. Postselection, physical code distance, dilation compatibility and the recovery assumptions remain essential. The theorem is about accepted effects, not a generic algorithm for minimizing logical Toffoli gates. [Primary text](https://arxiv.org/html/2608.29438v2).

**Applicability inference:** our exact reversible loaders and inverse-square-root circuit have no supplied encoded recovery skeleton or certified insertion distance. Consequently this theorem neither establishes a4170-Toffoli loader lower bound nor supplies a cheaper loader. A physical magic-state preparation improvement would need a new evaluation model before it could change a fixed logical CCX/rotation cost. Its outcome-resolved perspective is useful when auditing measurement and phase corrections.

## Graphene paper: subject and limits

The experiment combines SNOM/AFM with low-temperature STM/STS to study lattice relaxation, honeycomb flat-band texture and domain-wall states in helical trilayer graphene. It reports a bandwidth minimum near a1.9-degree twist angle, compared with an earlier theoretical value around1.6degrees. The authors explicitly state that their measurements do not establish the topological origin of the boundary modes or Chern-number inversion. Its56 references concern moire materials, correlated phases, lattice relaxation, spectroscopy and topological electronic bands. [Primary manuscript](https://arxiv.org/pdf/2609.39986).

**Applicability inference:** “magic angle” is a band-structure condition, whereas “magic” in Clifford resource theory is a property of states/operations. This manuscript gives no reversible arithmetic, loader synthesis, Toffoli reduction or replacement for the evaluator's gate model.

## Read-scope ledger

- Both linked papers: all extracted main text, bibliography and included appendices read. All four graphene figure captions were read. Figure pixels were not separately inspected; no independent reproduction of every proof or experiment is claimed.
- Graphene supplementary figures S1–S11 are cited but absent from the retrieved12-page manuscript. They are not counted as read.
- Magic references: all53 primary extracted manuscript texts were actually read to their ends, including included appendices and references. Attribution: alternative_arch40, cost_audit12, shared_synthesis1. This is complete extracted-text reading, not a claim to have inspected every image pixel, re-proved every theorem or rerun every experiment. The exact version and detailed scope are fixed in `magic_coverage.json`, with Japanese results/application notes for every item; the readable report is `magic_coverage.md`. Retrieval never sets the fulltext-read flag.
- Graphene references: the exact56 citation strings are in `graphene_bibliography.json`/`.md`; per-reference primary-source reading is delegated to the root agent. That bibliography alone does not establish fulltext review.

## Bibliographic correction requiring care

Magic reference[52] cites Heimendahl, Heinrich and Gross under *Quantum*6,878 and DOI10.22331/q-2022-12-22-878. The matching author/title source is [arXiv:2011.11651](https://arxiv.org/abs/2011.11651), whose record and [author publication list](https://qi.uni-koeln.de/publication-list) identify *Journal of Mathematical Physics*63,112201(2022), DOI10.1063/5.0085774. The manuscript's raw citation is preserved and the mismatch recorded. This is a bibliographic discrepancy, not by itself a disproof of the parent paper.

Magic[23] has an identity detail: the cached primary PDF is explicitly headed arXiv:2502.01743v4, 30 January2026, and its title page dated2 February2026 says *High Rate Magic State Cultivation on the Surface Code*. Fetch metadata and the current arXiv abstract page instead say *Efficient Magic State Cultivation on the Surface Code*. The reading claim is pinned to the cached PDF/header/SHA256, not inferred from the abstract-page title. Magic[51] likewise has a different preprint title from its publication title, recorded in the ledger.

Magic[15], [Howard and Campbell](https://arxiv.org/pdf/1609.07488), is a directly relevant synthesis reference and has been fully read. It uses robustness-based bounds and Clifford-equivalent resource states to establish deterministic measurement-assisted CCZ synthesis with4T states as optimal, alongside other small diagonal constructions. This does not reduce an evaluator that already counts one CCZ as one CCX.

## Reproducibility

`extract_bibliographies.py` regenerates the exact numbered lists from saved primary extractions and checks contiguous numbering. `magic_coverage.json` preserves source URLs, exact original citations, text hashes, read-character ranges, honest read status and applicability notes. `magic_version_comparison.json` pins the shared full body. Primary fulltext caches are research inputs; the public deliverable should contain our notes/coverage and links, rather than copies of the papers.
