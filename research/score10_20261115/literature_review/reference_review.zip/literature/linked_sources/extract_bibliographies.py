#!/usr/bin/env python3
"""Extract the numbered reference lists without rewriting their metadata."""
import argparse, hashlib, json, re
from pathlib import Path

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent)
    a = p.parse_args()
    d = a.directory
    magic_path = d / 'magic_arxiv_1.md'
    magic_text = magic_path.read_text()
    magic = []
    for n, text in re.findall(r'^\* \[(\d+)\] (.+)$', magic_text, re.M):
        arxiv = re.search(r'\[arXiv:([^\]]+)\]', text)
        links = re.findall(r'\]\((https?://[^\s]+)\)', text)
        title = re.search(r'“(.*?)”(?:\.|\s*\()', text)
        url = 'https://arxiv.org/pdf/' + arxiv[1] if arxiv else (links[0] if links else None)
        magic.append({'number':int(n),'citation_verbatim':text,'title':title[1] if title else None,
          'arxiv_id':arxiv[1] if arxiv else None,'primary_fulltext_url':url,
          'urls_in_bibliography':links,'access_scope':'bibliography_entry_read',
          'fulltext_retrieved':False,'fulltext_read':False})
    assert [x['number'] for x in magic] == list(range(1,54))
    graph_path = d / 'graphene_arxiv.md'
    graph_text = graph_path.read_text().split('### **Reference**',1)[1].split('### **Acknowledgement**',1)[0]
    graph=[]
    chunks=list(re.finditer(r'^\[(\d+)\]\s',graph_text,re.M))
    for i,m in enumerate(chunks):
        raw = graph_text[m.end():chunks[i+1].start() if i+1<len(chunks) else len(graph_text)]
        raw = re.sub(r'^\d+\s*$', '', raw, flags=re.M)
        raw=' '.join(raw.split())
        arxiv=re.search(r'arxiv:\s*(\d{4}\.\d+)',raw,re.I)
        doi=re.search(r'https://doi\.org/\S+',raw)
        urls=([f'https://arxiv.org/abs/{arxiv[1]}'] if arxiv else [])+([doi[0]] if doi else [])
        graph.append({'number':int(m[1]),'citation_verbatim':raw,'urls_in_bibliography':urls,
          'access_scope':'bibliography_entry_read','fulltext_retrieved':False,'fulltext_read':False,
          'unresolved_primary_url':not bool(urls)})
    assert [x['number'] for x in graph] == list(range(1,57))
    for name, entries, path, title, url in [
      ('magic',magic,magic_path,'The resource cost of magic in a code block','https://arxiv.org/html/2608.29438v1'),
      ('graphene',graph,graph_path,'Atomic-Scale Imaging of Lattice Relaxation and Topological Flat Bands in Helical Trilayer Graphene','https://arxiv.org/pdf/2609.39986')]:
        result={'parent_title':title,'parent_primary_url':url,'source_file':path.name,
          'source_sha256':sha(path),'numbered_reference_count':len(entries),'references':entries}
        (d/f'{name}_bibliography.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
        lines=[f'# {title}: exact numbered bibliography','',f'Primary source: {url}', '',
          f'Numbered entries: **{len(entries)}**. Access scope at extraction: every bibliography entry read; the cited papers themselves are not implied to have been read.','']
        lines += [f"## [{x['number']}]\n\n{x['citation_verbatim']}\n" for x in entries]
        (d/f'{name}_bibliography.md').write_text('\n'.join(lines))
    print(json.dumps({'magic':len(magic),'graphene':len(graph),'output_directory':str(d)},ensure_ascii=False))

if __name__ == '__main__':
    main()
