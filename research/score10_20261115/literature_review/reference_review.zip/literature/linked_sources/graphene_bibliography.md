# Atomic-Scale Imaging of Lattice Relaxation and Topological Flat Bands in Helical Trilayer Graphene: exact numbered bibliography

Primary source: https://arxiv.org/pdf/2609.39986

Numbered entries: **56**. Access scope at extraction: every bibliography entry read; the cited papers themselves are not implied to have been read.

## [1]

R. Bistritzer and A. H. MacDonald, Moire bands in twisted double-layer graphene, Proc. Natl. Acad. Sci. **108** , 30 (2011).

## [2]

Y. Cao et al., Correlated insulator behaviour at half-filling in magic-angle graphene superlattices, Nature **556** , 7699 (2018).

## [3]

Y. Cao, V. Fatemi, S. Fang, K. Watanabe, T. Taniguchi, E. Kaxiras, and P. Jarillo-Herrero, Unconventional superconductivity in magic-angle graphene superlattices, Nature **556** , 7699 (2018).

## [4]

Y. Xie et al., Fractional Chern insulators in magic-angle twisted bilayer graphene, Nature **600** , 7889 (2021).

## [5]

E. Codecido et al., Correlated insulating and superconducting states in twisted bilayer graphene below the magic angle, Sci. Adv. **5** , eaaw9770 (2019).

## [6]

A. L. Sharpe, E. J. Fox, A. W. Barnard, J. Finney, K. Watanabe, T. Taniguchi, M. A. Kastner, and D. Goldhaber-Gordon, Emergent ferromagnetism near three-quarters filling in twisted bilayer graphene, Science **365** , 6453 (2019).

## [7]

Y.-H. Zhang, D. Mao, and T. Senthil, Twisted bilayer graphene aligned with hexagonal boron nitride: Anomalous Hall effect and a lattice model, Phys. Rev. Res. **1** , 3 (2019).

## [8]

G. Chen et al., Signatures of tunable superconductivity in a trilayer graphene moiré superlattice, Nature **572** , 7768 (2019).

## [9]

H. Kim et al., Imaging inter-valley coherent order in magic-angle twisted trilayer graphene, Nature **623** , 942 (2023).

## [10]

H. Kim, Y. Choi, C. Lewandowski, A. Thomson, Y. Zhang, R. Polski, K. Watanabe, T. Taniguchi, J. Alicea, and S. Nadj-Perge, Evidence for unconventional superconductivity in twisted trilayer graphene, Nature **606** , 7914 (2022).

## [11]

J. M. Park, Y. Cao, K. Watanabe, T. Taniguchi, and P. Jarillo-Herrero, Tunable strongly coupled superconductivity in magic-angle twisted trilayer graphene, Nature **590** , 7845 (2021).

## [12]

D. Halbertal et al., Unconventional non-local relaxation dynamics in a twisted trilayer graphene moiré superlattice, Nat. Commun. **13** , 7587 (2022).

## [13]

I. M. Craig, M. Van Winkle, C. Groschner, K. Zhang, N. Dowlatshahi, Z. Zhu, T. Taniguchi, K. Watanabe, S. M. Griffin, and D. K. Bediako, Local atomic stacking and symmetry in twisted graphene trilayers, Nat. Mater. 323 (2024).

## [14]

C. Shen, P. J. Ledwith, K. Watanabe, T. Taniguchi, E. Khalaf, A. Vishwanath, and D. K. Efetov, Dirac spectroscopy of strongly correlated phases in twisted trilayer graphene, Nat. Mater. **22** , 316 (2023).

## [15]

G. Chen et al., Evidence of a gate-tunable Mott insulator in a trilayer graphene moiré superlattice, Nat. Phys. **15** , 237 (2019).

## [16]

M. Fujimoto, N. Nakatsuji, A. Vishwanath, and P. Ledwith, Four Moiré materials at One Magic Angle in Helical Quadrilayer Graphene, arxiv:2510.02444 (2025).

## [17]

D. Guerci, Y. Mao, and C. Mora, Nature of even and odd magic angles in helical twisted trilayer graphene, arxiv: 2308.02638 (2023).

## [18]

C. Yang, J. May-Mann, Z. Zhu, and T. Devakul, Multi-moiré trilayer graphene: Lattice relaxation, electronic structure, and magic angles, Phys Rev B **110** , 115434 (2024).

## [19]

Y. Liu et al., Electronic Correlations in Rhombohedral Graphene at Atomic Scale, Phys Rev Lett **135** , 156401 (2025).

## [20]

Z. Lu, T. Han, Y. Yao, A. P. Reddy, J. Yang, J. Seo, K. Watanabe, T. Taniguchi, L. Fu, and L. Ju, Fractional quantum anomalous Hall effect in multilayer graphene, Nature **626** , 759 (2024).

## [21]

Z. Guo, X. Lu, B. Xie, and J. Liu, Fractional Chern insulator states in multilayer graphene moiré superlattices, Phys. Rev. B **110** , 075109 (2024).

## [22]

J. Dong, T. Wang, T. Wang, T. Soejima, M. P. Zaletel, A. Vishwanath, and D. E. Parker, Anomalous Hall Crystals in Rhombohedral Multilayer Graphene. I. Interaction-Driven Chern Bands and Fractional Quantum Hall States at Zero Magnetic Field, Phys. Rev. Lett. **133** , 206503 (2024).

## [23]

S. Zhang, B. Xie, Q. Wu, J. Liu, and O. V. Yazyev, Chiral Decomposition of Twisted Graphene Multilayers with Arbitrary Stacking, Nano Lett. **23** , 2921 (2023).

## [24]

Y. Park, Y. Kim, B. L. Chittari, and J. Jung, Topological flat bands in rhombohedral tetralayer and multilayer graphene on hexagonal boron nitride moiré superlattices, Phys Rev B **108** , 155406 (2023).

## [25]

Z. Dong, L. Levitov, and A. V. Chubukov, Superconductivity near spin and valley orders in graphene multilayers, Phys. Rev. B **108** , 134503 (2023).

## [26]

Y. Zhang et al., Promotion of superconductivity in magic-angle graphene multilayers, Science **377** , 6614 (2022).

## [27]

S. Zhang, X. Dai, and J. Liu, Spin-Polarized Nematic Order, Quantum Valley Hall States, and Field-Tunable Topological Transitions in Twisted Multilayer Graphene Systems, Phys Rev Lett **128** , 026403 (2022).

## [28]

J. Liu, Z. Ma, J. Gao, and X. Dai, Quantum Valley Hall Effect, Orbital Magnetism, and Anomalous Hall Effect in Twisted Multilayer Graphene Systems, Phys Rev X **9** , 031021 (2019).

## [29]

C. Xu and L. Balents, Topological Superconductivity in Twisted Multilayer Graphene, Phys. Rev. Lett. **121** , 087001 (2018).

## [30]

X.-F. Zhou, Y.-W. Liu, C.-Y. Hao, C. Yan, Q. Zheng, Y.-N. Ren, Y.-X. Zhao, K. Watanabe, T. Taniguchi, and L. He, Coexistence of reconstructed and unreconstructed structures in the structural transition regime of twisted bilayer graphene, Phys Rev B **107** , 125410 (2023).

## [31]

C.-Y. Hao, Z. Zhan, P. A. Pantaleón, J.-Q. He, Y.-X. Zhao, K. Watanabe, T. Taniguchi, F. Guinea, and L. He, Robust flat bands in twisted trilayer graphene moiré quasicrystals, Nat. Commun. **15** , 8437 (2024).

## [32]

O. Aguilar-Spíndola, A. Rubio-Ponce, F. López-Urías, and F. Sánchez-Ochoa, Electronic and optical properties in helical trilayer graphene under compression, Phys Chem Chem Phys **27** , 11541 (2025).

## [33]

S. Niu, J. Alicea, D. N. Sheng, and Y. Peng, Quantum Anomalous Hall Effects and Emergent SU(2) Hall Ferromagnets at Fractional Filling of Helical Trilayer Graphene, Phys Rev Lett **135** , 146505 (2025).

## [34]

J. C. Hoke, Y. Li, Y. Hu, J. May-Mann, K. Watanabe, T. Taniguchi, T. Devakul, and B. E. Feldman, Imaging supermoiré relaxation in helical trilayer graphene, Nat. Mater. (2026). https://doi.org/10.1038/s41563-025-02423-3

## [35]

L.-Q. Xia et al., Topological bands and correlated states in helical trilayer graphene, Nat. Phys. **21** , 239 (2025).

## [36]

T. Devakul, P. J. Ledwith, L.-Q. Xia, A. Uri, S. C. de la Barrera, P. Jarillo-Herrero, and L. Fu, Magic-angle helical trilayer graphene, Sci. Adv. **9** , eadi6063 (2023).

## [37]

Y. H. Kwan, P. J. Ledwith, C. F. B. Lo, and T. Devakul, Strong-coupling topological states and phase transitions in helical trilayer graphene, Phys Rev B **109** , 125141 (2024).

## [38]

A. Datta, D. Guerci, M. O. Goerbig, and C. Mora, Helical trilayer graphene in magnetic field: Chern mosaic and higher Chern number ideal flat bands, Phys Rev B **110** , 075417 (2024).

## [39]

Y. H. Kwan, T. Tan, and T. Devakul, Fractional Chern mosaic in supermoiré graphene, Phys Rev Res **7** , L032070 (2025).

## [40]

D. Guerci, Y. Mao, and C. Mora, Chern mosaic and ideal flat bands in equal-twist trilayer graphene, Phys Rev Res **6** , L022025 (2024).

## [41]

Y. Mao, D. Guerci, and C. Mora, Supermoiré low-energy effective theory of twisted trilayer graphene, Phys Rev B **107** , 125423 (2023).

## [42]

Z. Zhu, S. Carr, D. Massatt, M. Luskin, and E. Kaxiras, Twisted Trilayer Graphene: A Precisely Tunable Platform for Correlated Electrons, Phys Rev Lett **125** , 116404 (2020).

## [43]

C. Mora, N. Regnault, and B. A. Bernevig, Flatbands and Perfect Metal in Trilayer Moiré Graphene, Phys Rev Lett **123** , 026402 (2019).

## [44]

N. Nakatsuji, T. Kawakami, and M. Koshino, Multiscale Lattice Relaxation in General Twisted Trilayer Graphenes, Phys Rev X **13** , 041007 (2023).

## [45]

Y. Liu et al., Imaging moiré flat bands and Wigner molecular crystals in twisted bilayer MoTe2, Natl. Sci. Rev. **13** , nwag014 (2026).

## [46]

J. Jang, Effect of lattice relaxation on electronic spectra of helically twisted trilayer graphene: large-scale atomistic simulation approach, J. Korean Phys. Soc. **85** , 727 (2024).

## [47]

A. Kerelsky et al., Moiréless correlations in ABCA graphene, Proc. Natl. Acad. Sci. **118** , e2017366118 (2021).

## [48]

D. Walkup, B. A. Assaf, K. L. Scipioni, R. Sankar, F. Chou, G. Chang, H. Lin, I. Zeljkovic, and V. Madhavan, Interplay of orbital effects and nanoscale strain in topological crystalline insulators, Nat. Commun. **9** , 1550 (2018).

## [49]

M. J. Lawler et al., Intra-unit-cell electronic nematicity of the high-Tc copper-oxide pseudogap states, Nature **466** , 347 (2010).

## [50]

L. Ju et al., Topological valley transport at bilayer graphene domain walls, Nature **520** , 7549 (2015).

## [51]

H. Yoo et al., Atomic and electronic reconstruction at the van der Waals interface in twisted bilayer graphene, Nat. Mater. **18** , 448 (2019).

## [52]

S. Huang, K. Kim, D. K. Efimkin, T. Lovorn, T. Taniguchi, K. Watanabe, A. H. MacDonald, E. Tutuc, and B. J. LeRoy, Topologically Protected Helical States in Minimally Twisted Bilayer Graphene, Phys Rev Lett **121** , 037702 (2018).

## [53]

J. S. Alden, A. W. Tsen, P. Y. Huang, R. Hovden, L. Brown, J. Park, D. A. Muller, and P. L. McEuen, Strain solitons and topological defects in bilayer graphene, Proc. Natl. Acad. Sci. **110** , 11256 (2013).

## [54]

Y. Sha, J. Zheng, K. Liu, H. Du, K. Watanabe, T. Taniguchi, J. Jia, Z. Shi, R. Zhong, and G. Chen, Observation of a Chern insulator in crystalline ABCA-tetralayer graphene with spin-orbit coupling, Science **384** , 414 (2024).

## [55]

T. Han et al., Signatures of chiral superconductivity in rhombohedral graphene, Nature **654** , 643(2025).

## [56]

Z. Lu et al., Extended quantum anomalous Hall states in graphene/hBN moiré superlattices, Nature **637** , 1090 (2025).
