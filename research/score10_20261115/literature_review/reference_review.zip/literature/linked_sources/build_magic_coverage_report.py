#!/usr/bin/env python3
"""Render the reading ledger without fetching or redistributing manuscript text.

The JSON ledger records human/agent reading decisions. This renderer never
infers a reading status from a download, file size, or structural inspection.
Use --merge-notes only to merge the separately reviewed Japanese summaries.
Full-text caches are optional and are needed only for --verify-caches.
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--directory", type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument("--coverage", type=Path)
    parser.add_argument("--notes", type=Path)
    parser.add_argument("--out", type=Path, help="Output directory; defaults to --directory")
    parser.add_argument("--merge-notes", action="store_true")
    parser.add_argument("--verify-caches", action="store_true")
    args = parser.parse_args()
    directory = args.directory.resolve()
    coverage_path = args.coverage or directory / "magic_coverage.json"
    notes_path = args.notes or directory / "magic_notes_ja.json"
    out = args.out or directory
    out.mkdir(parents=True, exist_ok=True)
    ledger = load_json(coverage_path)
    refs = ledger["references"]
    assert [r["number"] for r in refs] == list(range(1, 54)), "Non-contiguous reference numbering"
    if args.merge_notes:
        summaries = load_json(notes_path)
        assert set(summaries) == {str(n) for n in range(1, 54)}
        for r in refs:
            note = summaries[str(r["number"])]
            assert set(note) == {"result_ja", "applicability_ja"}
            r.update(note)
        write_json(coverage_path, ledger)

    for r in refs:
        assert r.get("version_read"), f"Missing version scope: {r['number']}"
        assert r.get("reader"), f"Missing reader: {r['number']}"
        assert r.get("access_scope"), f"Missing access scope: {r['number']}"
        assert r.get("result_ja") and r.get("applicability_ja"), f"Missing Japanese notes: {r['number']}"
        if args.verify_caches:
            cache = directory / "magic_refs" / r["cached_fulltext"]
            content = cache.read_bytes()
            assert hashlib.sha256(content).hexdigest() == r["cached_fulltext_sha256"], cache
            assert len(content.decode("utf-8")) == r["extracted_characters"], cache

    counts = Counter(r["reader"] for r in refs if r["fulltext_read"])
    complete = sum(bool(r["fulltext_read"]) for r in refs)
    lines = [
        "# Magic 論文・参考文献53件の読解台帳",
        "",
        f"対象は [{ledger['parent_title']}]({ledger['parent_primary_url']}) の番号付き参考文献53件。レビュー日：{ledger['review_date']}。",
        "",
        f"**一次資料の抽出本文を末尾まで実読：{complete}/53件。** 取得だけで読了とした項目はない。共同レビューの担当は、alternative_arch 40件、cost_audit 12件、shared_synthesis 1件である。",
        "",
        "読了には取得版の本文、含まれる付録、参考文献、抽出された図説明・表を含む。全図の画像照合、抽出で崩れた全数式の原PDF照合、各証明の独立再証明、数値実験の再実行は意味しない。最新の公開版と、実際に読んだ版を同一視せず、以下の版・範囲および JSON の SHA256 に固定する。外部の別冊補足資料は明示されたもの以外含めない。",
        "",
        "## 今回の実装への判断",
        "",
        "親論文は符号化した測定効果と magic の費用を扱い、強い境界には整合した recovery skeleton、挿入グラフと分岐ごとの因数分解などの前提がある。今回の75語ローダーにはその証明書がなく、4170 Toffoli の一般下界を与える論文としては使えない。",
        "",
        "測定後の各分岐で未知入力の情報と相対位相を保持する検査は [25]–[27]、[31]、[44]、[48] が参考になる。[38] と [50] には、既知の状態や直接合成できる対角位相を利用して中間レジスターを省く着想がある。いずれも、実際のゲート列・全入力・補正・物理幅を確認して初めて今回の改善として数える。",
        "",
        "magic-state 工場の受理率・物理時間・蒸留率、古典シミュレーターの標本数、幾何学的な保護ゲートの分類は、それぞれ異なる費用と契約を使う。実装への適用性は以下に各項目ごとに記載した。",
        "",
        "## 書誌と版の注意",
        "",
        "[23] は取得 PDF の表紙題名が High Rate、取得メタデータと arXiv abs が Efficient である。読了は v4 ヘッダーと取得 PDF のハッシュに固定した。[51] も取得プレプリントと引用された出版題名が異なる。[52] の親論文中の誌名・DOI は対応する著者・題名の出版記録と一致せず、正しい一次資料へ解決した。原引用は JSON の citation_verbatim に保存している。",
        "",
        "[40] の読了版は元の planar Floquet boundary を耐故障ではないと訂正している。[50] の印刷式の独立検査と [51] の式の不整合は個別記録に残し、それらだけから論文全体を否定していない。",
        "",
        "## 各参考文献",
        "",
    ]
    for r in refs:
        n = r["number"]
        lines += [f"### [{n}] {r['title']}", ""]
        primary_url = r.get("versioned_fulltext_url", r["primary_fulltext_url"])
        lines += [f"[一次資料]({primary_url}) — 読んだ版：{r['version_read']}。", ""]
        if r.get("source_title_read") and r["source_title_read"].casefold() != r["title"].casefold():
            lines += [f"取得本文の題名：{r['source_title_read']}。", ""]
        lines += [f"**結果と条件：** {r['result_ja']}", "",
                  f"**今回への適用：** {r['applicability_ja']}", "",
                  f"**実読範囲：** {r.get('read_scope', r['access_scope'])}", "",
                  f"**担当：** {r['reader']}。**抽出本文：** {r['extracted_characters']:,} Unicode 文字。", ""]
        if r.get("metadata_note"):
            lines += [f"**書誌注記：** {r['metadata_note']}", ""]
        if r.get("caveats"):
            lines += [f"**追加の条件・限界：** {r['caveats']}", ""]
    lines += [
        "## 再生成",
        "",
        "`python build_magic_coverage_report.py --directory PATH --out OUTPUT` でこのレポートと詳細メモを JSON 台帳から再生成できる。ローカルに一次本文のキャッシュがある場合だけ `--verify-caches` を追加すると、全53件の SHA256 と文字数も照合する。公開・共有用の成果物は台帳、独自メモ、一次URL、再生成器であり、著作物の本文キャッシュを含める必要はない。",
        "",
    ]
    (out / "magic_coverage.md").write_text("\n".join(lines), encoding="utf-8")
    write_json(out / "magic_reference_notes.json", {str(r["number"]): r["review_note"] for r in refs})
    manifest = {
        "source_ledger_sha256": hashlib.sha256(coverage_path.read_bytes()).hexdigest(),
        "read_status_definition": ledger["read_status_definition"],
        "reference_count": len(refs),
        "fulltext_read_count": complete,
        "reader_counts": dict(counts),
        "japanese_result_count": sum(bool(r.get("result_ja")) for r in refs),
        "japanese_applicability_count": sum(bool(r.get("applicability_ja")) for r in refs),
        "cached_texts_verified": bool(args.verify_caches),
        "output_files": {},
    }
    for name in ["magic_coverage.md", "magic_reference_notes.json"]:
        blob = (out / name).read_bytes()
        manifest["output_files"][name] = {"sha256": hashlib.sha256(blob).hexdigest(), "bytes": len(blob)}
    write_json(out / "magic_coverage_manifest.json", manifest)
    print(json.dumps({k: v for k, v in manifest.items() if k != "output_files"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
