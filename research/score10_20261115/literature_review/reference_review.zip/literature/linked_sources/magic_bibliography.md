# The resource cost of magic in a code block: exact numbered bibliography

Primary source: https://arxiv.org/html/2608.29438v1

Numbered entries: **53**. Access scope at extraction: every bibliography entry read; the cited papers themselves are not implied to have been read.

## [1]

Sergei Bravyi and Alexei Kitaev. “Universal quantum computation with ideal Clifford gates and noisy ancillas”. [Physical Review A 71 , 022316](https://dx.doi.org/10.1103/PhysRevA.71.022316) (2005). [arXiv:quant-ph/0403025](http://arxiv.org/abs/quant-ph/0403025) .

## [2]

Austin G. Fowler, Matteo Mariantoni, John M. Martinis, and Andrew N. Cleland. “Surface codes: Towards practical large-scale quantum computation”. [Physical Review A 86 , 032324](https://dx.doi.org/10.1103/PhysRevA.86.032324) (2012). [arXiv:1208.0928](http://arxiv.org/abs/1208.0928) .

## [3]

Hui Zhong, Jiachen Shen, Lei Fan, Xinyue Zhang, Hao Wang, Miao Pan, and Zhu Han. “UNIQ: Communication-efficient distributed quantum computing via unified nonlinear integer programming” (2025). [arXiv:2512.00401](http://arxiv.org/abs/2512.00401) .

## [4]

Hui Zhong, Keyi Ju, Jiachen Shen, Xinyue Zhang, Xiaoqi Qin, Tomoaki Ohtsuki, Miao Pan, and Zhu Han. “Differential privacy preserving distributed quantum computing” (2024). [arXiv:2412.12387](http://arxiv.org/abs/2412.12387) .

## [5]

Hui Zhong, Keyi Ju, Manojna Sistla, Xinyue Zhang, Xiaoqi Qin, Xin Fu, and Miao Pan. “Tuning quantum computing privacy through quantum error correction” (2023). [arXiv:2312.14521](http://arxiv.org/abs/2312.14521) .

## [6]

Yuqing Li, Yusheng Zhao, Xinyue Zhang, Hui Zhong, Miao Pan, and Chi Zhang. “Differential privacy preserving quantum computing via projection operator measurements” (2023). [arXiv:2312.08210](http://arxiv.org/abs/2312.08210) .

## [7]

Yusheng Zhao, Hui Zhong, Xinyue Zhang, Yuqing Li, Chi Zhang, and Miao Pan. “Bridging quantum computing and differential privacy: Insights into quantum computing privacy” (2024). [arXiv:2403.09173](http://arxiv.org/abs/2403.09173) .

## [8]

Keyi Ju, Xiaoqi Qin, Hui Zhong, Xinyue Zhang, Miao Pan, and Baoling Liu. “Harnessing inherent noises for privacy preservation in quantum machine learning” (2023). [arXiv:2312.11126](http://arxiv.org/abs/2312.11126) .

## [9]

Sergey Bravyi and Jeongwan Haah. “Magic-state distillation with low overhead”. [Physical Review A 86 , 052329](https://dx.doi.org/10.1103/PhysRevA.86.052329) (2012). [arXiv:1209.2426](http://arxiv.org/abs/1209.2426) .

## [10]

Adam M. Meier, Bryan Eastin, and Emanuel Knill. “Magic-state distillation with the four-qubit code”. [Quantum Information and Computation 13 , 195–209](https://dx.doi.org/10.26421/QIC13.3-4-2) (2013). [arXiv:1204.4221](http://arxiv.org/abs/1204.4221) .

## [11]

Cody Jones. “Multilevel distillation of magic states for quantum computing”. [Physical Review A 87 , 042305](https://dx.doi.org/10.1103/PhysRevA.87.042305) (2013). [arXiv:1210.3388](http://arxiv.org/abs/1210.3388) .

## [12]

Earl T. Campbell, Barbara M. Terhal, and Christophe Vuillot. “Roads towards fault-tolerant universal quantum computation”. [Nature 549 , 172–179](https://dx.doi.org/10.1038/nature23460) (2017). [arXiv:1612.07330](http://arxiv.org/abs/1612.07330) .

## [13]

Victor Veitch, Seyed Ali Hamed Mousavian, Daniel Gottesman, and Joseph Emerson. “The resource theory of stabilizer quantum computation”. [New Journal of Physics 16 , 013009](https://dx.doi.org/10.1088/1367-2630/16/1/013009) (2014). [arXiv:1307.7171](http://arxiv.org/abs/1307.7171) .

## [14]

Mark Howard, Joel J. Wallman, Victor Veitch, and Joseph Emerson. “Contextuality supplies the “magic” for quantum computation”. [Nature 510 , 351–355](https://dx.doi.org/10.1038/nature13460) (2014). [arXiv:1401.4174](http://arxiv.org/abs/1401.4174) .

## [15]

Mark Howard and Earl T. Campbell. “Application of a resource theory for magic states to fault-tolerant quantum computing”. [Physical Review Letters 118 , 090501](https://dx.doi.org/10.1103/PhysRevLett.118.090501) (2017). [arXiv:1609.07488](http://arxiv.org/abs/1609.07488) .

## [16]

James R. Seddon and Earl T. Campbell. “Quantifying magic for multi-qubit operations”. [Proceedings of the Royal Society A 475 , 20190251](https://dx.doi.org/10.1098/rspa.2019.0251) (2019). [arXiv:1901.03322](http://arxiv.org/abs/1901.03322) .

## [17]

Sergey Bravyi and David Gosset. “Improved classical simulation of quantum circuits dominated by clifford gates”. [Physical Review Letters 116 , 250501](https://dx.doi.org/10.1103/PhysRevLett.116.250501) (2016). [arXiv:1601.07601](http://arxiv.org/abs/1601.07601) .

## [18]

Markus Heinrich and David Gross. “Robustness of magic and symmetries of the stabiliser polytope”. [Quantum 3 , 132](https://dx.doi.org/10.22331/q-2019-04-08-132) (2019). [arXiv:1807.10296](http://arxiv.org/abs/1807.10296) .

## [19]

Craig Gidney, Noah Shutty, and Cody Jones. “Magic state cultivation: growing T states as cheap as CNOT gates” (2024). [arXiv:2409.17595](http://arxiv.org/abs/2409.17595) .

## [20]

I-Chi Chen, Matheus da Silva Fonseca, and Andrew Sornborger. “Efficient magic state cultivation for $\sqrt{T}$ gates” (2026). [arXiv:2606.10430](http://arxiv.org/abs/2606.10430) .

## [21]

Jahan Claes. “Cultivating T states on the surface code with only two-qubit gates” (2025). [arXiv:2509.05232](http://arxiv.org/abs/2509.05232) .

## [22]

Kaavya Sahay, Pei-Kai Tsai, Kathleen Chang, Qile Su, Thomas B. Smith, Shraddha Singh, and Shruti Puri. “Fold-transversal surface code cultivation”. [PRX Quantum 7 , 033006](https://dx.doi.org/10.1103/gpvl-lg4c) (2026). [arXiv:2509.05212](http://arxiv.org/abs/2509.05212) .

## [23]

Yotam Vaknin, Shoham Jacoby, Arne Grimsmo, and Alex Retzker. “High rate magic state cultivation on the surface code”. [PRX Quantum 7 , 010353](https://dx.doi.org/10.1103/p8tw-6kq9) (2026). [arXiv:2502.01743](http://arxiv.org/abs/2502.01743) .

## [24]

Dennis Kretschmann, Dirk Schlingemann, and Reinhard F. Werner. “A continuity theorem for Stinespring’s dilation”. [Journal of Functional Analysis 255 , 1889–1904](https://dx.doi.org/10.1016/j.jfa.2008.07.023) (2008).

## [25]

Daniel Gottesman. “Stabilizer codes and quantum error correction”. [PhD thesis](https://dx.doi.org/10.7907/rzr7-dt72) . California Institute of Technology. (1997). [arXiv:quant-ph/9705052](http://arxiv.org/abs/quant-ph/9705052) .

## [26]

Scott Aaronson and Daniel Gottesman. “Improved simulation of stabilizer circuits”. [Physical Review A 70 , 052328](https://dx.doi.org/10.1103/PhysRevA.70.052328) (2004). [arXiv:quant-ph/0406196](http://arxiv.org/abs/quant-ph/0406196) .

## [27]

Jeroen Dehaene and Bart De Moor. “The clifford group, stabilizer states, and linear and quadratic operations over GF(2)”. [Physical Review A 68 , 042318](https://dx.doi.org/10.1103/PhysRevA.68.042318) (2003). [arXiv:quant-ph/0304125](http://arxiv.org/abs/quant-ph/0304125) .

## [28]

A. Yu. Kitaev. “Fault-tolerant quantum computation by anyons”. [Annals of Physics 303 , 2–30](https://dx.doi.org/10.1016/S0003-4916\(02\)00018-0) (2003). [arXiv:quant-ph/9707021](http://arxiv.org/abs/quant-ph/9707021) .

## [29]

Alexei Kitaev and Liang Kong. “Models for gapped boundaries and domain walls”. [Communications in Mathematical Physics 313 , 351–373](https://dx.doi.org/10.1007/s00220-012-1500-5) (2012). [arXiv:1104.5047](http://arxiv.org/abs/1104.5047) .

## [30]

Salman Beigi, Peter W. Shor, and Daniel Whalen. “The quantum double model with boundary: Condensations and symmetries”. [Communications in Mathematical Physics 306 , 663–694](https://dx.doi.org/10.1007/s00220-011-1294-x) (2011). [arXiv:1006.5479](http://arxiv.org/abs/1006.5479) .

## [31]

Maissam Barkeshli, Parsa Bonderson, Meng Cheng, and Zhenghan Wang. “Symmetry fractionalization, defects, and gauging of topological phases”. [Physical Review B 100 , 115147](https://dx.doi.org/10.1103/PhysRevB.100.115147) (2019). [arXiv:1410.4540](http://arxiv.org/abs/1410.4540) .

## [32]

Eric Dennis, Alexei Kitaev, Andrew Landahl, and John Preskill. “Topological quantum memory”. [Journal of Mathematical Physics 43 , 4452–4505](https://dx.doi.org/10.1063/1.1499754) (2002). [arXiv:quant-ph/0110143](http://arxiv.org/abs/quant-ph/0110143) .

## [33]

Guillaume Duclos-Cianci and David Poulin. “Fast decoders for topological quantum codes”. [Physical Review Letters 104 , 050504](https://dx.doi.org/10.1103/PhysRevLett.104.050504) (2010). [arXiv:0911.0581](http://arxiv.org/abs/0911.0581) .

## [34]

Nicolas Delfosse and Naomi H. Nickerson. “Almost-linear time decoding algorithm for topological codes”. [Quantum 5 , 595](https://dx.doi.org/10.22331/q-2021-12-02-595) (2021). [arXiv:1709.06218](http://arxiv.org/abs/1709.06218) .

## [35]

Dominic Horsman, Austin G. Fowler, Simon Devitt, and Rodney Van Meter. “Surface code quantum computing by lattice surgery”. [New Journal of Physics 14 , 123011](https://dx.doi.org/10.1088/1367-2630/14/12/123011) (2012). [arXiv:1111.4022](http://arxiv.org/abs/1111.4022) .

## [36]

Robert Raussendorf, Jim Harrington, and Kovid Goyal. “Topological fault-tolerance in cluster state quantum computation”. [New Journal of Physics 9 , 199](https://dx.doi.org/10.1088/1367-2630/9/6/199) (2007). [arXiv:quant-ph/0703143](http://arxiv.org/abs/quant-ph/0703143) .

## [37]

Daniel Litinski and Felix von Oppen. “Lattice surgery with a twist: Simplifying clifford gates of surface codes”. [Quantum 2 , 62](https://dx.doi.org/10.22331/q-2018-05-04-62) (2018). [arXiv:1709.02318](http://arxiv.org/abs/1709.02318) .

## [38]

Daniel Litinski. “A game of surface codes: Large-scale quantum computing with lattice surgery”. [Quantum 3 , 128](https://dx.doi.org/10.22331/q-2019-03-05-128) (2019). [arXiv:1808.02892](http://arxiv.org/abs/1808.02892) .

## [39]

Matthew B. Hastings and Jeongwan Haah. “Dynamically generated logical qubits”. [Quantum 5 , 564](https://dx.doi.org/10.22331/q-2021-10-19-564) (2021). [arXiv:2107.02194](http://arxiv.org/abs/2107.02194) .

## [40]

Christophe Vuillot. “Planar floquet codes” (2021). [arXiv:2110.05348](http://arxiv.org/abs/2110.05348) .

## [41]

Margarita Davydova, Nathanan Tantivasadakarn, Shankar Balasubramanian, and David Aasen. “Quantum computation from dynamic automorphism codes”. [Quantum 8 , 1448](https://dx.doi.org/10.22331/q-2024-08-27-1448) (2024). [arXiv:2307.10353](http://arxiv.org/abs/2307.10353) .

## [42]

S. B. Bravyi and A. Yu. Kitaev. “Quantum codes on a lattice with boundary” (1998). [arXiv:quant-ph/9811052](http://arxiv.org/abs/quant-ph/9811052) .

## [43]

H. Bombin and M. A. Martin-Delgado. “Optimal resources for topological 2D stabilizer codes: Comparative study”. [Physical Review A 76 , 012305](https://dx.doi.org/10.1103/PhysRevA.76.012305) (2007). [arXiv:quant-ph/0703272](http://arxiv.org/abs/quant-ph/0703272) .

## [44]

Nobuyuki Yoshioka, Alireza Seif, Peter Groszkowski, Andrew Cross, and Ali Javadi-Abhari. “Theory and architecture of syndrome-resolved logical gates” (2025). [arXiv:2510.08290](http://arxiv.org/abs/2510.08290) .

## [45]

Eric Huang, Pierre-Gabriel Rozon, Arpit Dua, Sarang Gopalakrishnan, and Michael J. Gullans. “A robust phase of continuous transversal gates in quantum stabilizer codes” (2025). [arXiv:2510.01319](http://arxiv.org/abs/2510.01319) .

## [46]

Sergey Bravyi and Robert Koenig. “Classification of topologically protected gates for local stabilizer codes”. [Physical Review Letters 110 , 170503](https://dx.doi.org/10.1103/PhysRevLett.110.170503) (2013). [arXiv:1206.1609](http://arxiv.org/abs/1206.1609) .

## [47]

Michael E. Beverland, Oliver Buerschaper, Robert Koenig, Fernando Pastawski, John Preskill, and Sumit Sijher. “Protected gates for topological quantum field theories”. [Journal of Mathematical Physics 57 , 022201](https://dx.doi.org/10.1063/1.4939783) (2016). [arXiv:1409.3898](http://arxiv.org/abs/1409.3898) .

## [48]

David Aasen, Jeongwan Haah, Zhi Li, and Roger S. K. Mong. “Measurement quantum cellular automata and anomalies in floquet codes” (2023). [arXiv:2304.01277](http://arxiv.org/abs/2304.01277) .

## [49]

Paul Webster and Stephen D. Bartlett. “Locality-preserving logical operators in topological stabiliser codes”. [Physical Review A 97 , 012330](https://dx.doi.org/10.1103/PhysRevA.97.012330) (2018). [arXiv:1709.00020](http://arxiv.org/abs/1709.00020) .

## [50]

Sergey Bravyi, Isaac Kim, Alexander Kliesch, and Robert Koenig. “Adaptive constant-depth circuits for manipulating non-abelian anyons” (2022). [arXiv:2205.01933](http://arxiv.org/abs/2205.01933) .

## [51]

Gaurav Saxena and Gilad Gour. “Quantifying multiqubit magic channels with completely stabilizer-preserving operations”. [Physical Review A 106 , 042422](https://dx.doi.org/10.1103/PhysRevA.106.042422) (2022). [arXiv:2202.07867](http://arxiv.org/abs/2202.07867) .

## [52]

Arne Heimendahl, Markus Heinrich, and David Gross. “The axiomatic and the operational approaches to resource theories of magic do not coincide”. [Quantum 6 , 878](https://dx.doi.org/10.22331/q-2022-12-22-878) (2022).

## [53]

Ryohei Kobayashi and Guanyu Zhu. “Cross-cap defects and fault-tolerant logical gates in the surface code and the honeycomb floquet code”. [PRX Quantum 5 , 020360](https://dx.doi.org/10.1103/PRXQuantum.5.020360) (2024). [arXiv:2310.06917](http://arxiv.org/abs/2310.06917) .
