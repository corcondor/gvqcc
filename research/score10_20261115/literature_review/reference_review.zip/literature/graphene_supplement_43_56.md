# グラフェン引用43–56の本文補完（50を除く）

指定13件中、記録済み13件、主本文読了12件、本文文章は全節読了したものの埋め込み資料に取得欠落があるもの1件です。本文末のMethodsを含め、別付録・補足資料の未読部分を個別に記録します。

取得と読解を区別しています。全図の画像照合、数値再現、全式の独立再証明はしていません。新しい回路実装やToffoli削減は行っていません。

|番号|本文の読解状態|実読範囲（Unicode文字、半開区間）|
|---|---|---|
|43|main_text_complete|[[0, 23437]]|
|44|main_text_complete|[[0, 58000]]|
|45|main_text_complete|[[0, 31951], [40218, 48260]]|
|46|main_text_complete|[[0, 35500]]|
|47|main_prose_complete_with_embedded_source_gaps|[[0, 44837]]|
|48|main_text_complete|[[0, 18644]]|
|49|main_text_complete|[[0, 31050]]|
|51|main_text_complete|[[0, 36216]]|
|52|main_text_complete|[[0, 22169]]|
|53|main_text_complete|[[0, 29329]]|
|54|main_text_complete|[[0, 22605], [33195, 43130]]|
|55|main_text_complete|[[0, 41066]]|
|56|main_text_complete|[[0, 31058], [42567, 47751]]|

## [43]

C. Mora, N. Regnault, and B. A. Bernevig, Flatbands and Perfect Metal in Trilayer Moiré Graphene, Phys Rev Lett **123** , 026402 (2019).

[一次本文](https://arxiv.org/html/1901.05469)

**確認した版:** arXiv:1901.05469v1, 2019-01-16; published citation PRL 123, 026402 (2019)

**今回の実読範囲:** 表題・Abstract・導入、Bloch-band coupling、equal angles、symmetries、等角・不等角での全バンド接続性の二つの証明、結論・謝辞まで全文。独立のMethods節はなく、模型導出は本文内に含む。

**従前の既読範囲:** 本文+Supplementaryのparticle-hole symmetry、symmetry、Dirac-point解析を確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- 低エネルギーDirac近似、隣接層の短距離一様トンネル、同じ方向に並ぶ運動量差、連続twist角の有理比を用いてmomentum-space moiré周期性を構成する。一般の非整合角へ同じBloch周期性を保証しない。
- magic angleでDirac速度は消えるが、全バンドが一斉に平坦になるわけではなく、特定対称線近傍での平坦化。全bandの接続性はemergent particle-hole symmetryとC2zT等の対称性に依存する。
- 等角の場合は表現multiplicityの偶奇、不等角の場合は奇数Dirac coneとwindingの議論を使う。粒子・正孔対称性を破る曲率項を無視した模型の主張で、任意の実材料に全エネルギーgaplessを無条件に保証しない。奇数多層への拡張はconjecture。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- Supplement S-I–S-IVは今回未読（従前レビューの確認範囲を別記）。参考文献全項の本文は今回の範囲外。
- 図の画素照合や全証明の独立再導出はしていない。HTMLの著者欄に後年日付があるが、ヘッダのv1と内容hashを版識別に用いる。

**SHA256:** `6983d72e8392b94c131852f64911c1556a9ed003146bf80040de7bb951e20e70`


## [44]

N. Nakatsuji, T. Kawakami, and M. Koshino, Multiscale Lattice Relaxation in General Twisted Trilayer Graphenes, Phys Rev X **13** , 041007 (2023).

[一次本文](https://arxiv.org/pdf/2305.13155)

**確認した版:** arXiv:2305.13155v2, 2023-06-06 (PDF author date June 7, 2023)

**今回の実読範囲:** Abstract、I、II A–D（構造・commensurate近似・格子緩和・電子continuum方法）、III A–B、IV A–B、V、謝辞を全文。図1–16の抽出説明を含む。参考文献冒頭も区間に含むが残りは未読。

**従前の既読範囲:** 本文+Supplementary/数値・continuum計算の主要箇所を確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- 弾性energyと隣接層の結合energyを最小化し、Fourier展開したEuler–Lagrange方程式を自己無撞着に解く。out-of-plane displacementと層1–3のremote interaction/hoppingは無視する。G=0は別パラメータとして走査して低energy解を選ぶ。
- chiralとalternatingの各3例を比較。A1/A2では二つのmoiré格子の微小な相対回転を捨てる近似commensurate構造を使い、他の例と同じexact commensurationではない。有限Fourier cutoffも指定されている。
- 中間層の緩和のfrustrationによりchiralではAA点をずらすdomain、alternatingではAA点を重ねるdomainが好まれる。chiral domain間の1D状態は局所模型のvalley Chern差で説明され、両valleyを合わせた通常のcharge Chern insulatorとは区別する。
- alternatingではmirror-odd Dirac coneとflat-band成分の混成が緩和で弱くなる。垂直電場は層間一定としたonsite potentialで導入し、混成とbandwidthを変える。観測実験や任意構造に対する厳密な最適解の証明ではない。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- 使用した一次本文は2023年6月のv2 preprint。出版版そのものの全差分照合はしていない。
- このキャッシュには独立のAppendix/Supplement節はなく、参考文献の後半は未読。抽出した行列の配置崩れを独立PDF画像で全照合したとはしない。

**SHA256:** `6d2e356a8110c2506a69b4b0183ad38ef28a21899100c23574820e2a6ebedeea`


## [45]

Y. Liu et al., Imaging moiré flat bands and Wigner molecular crystals in twisted bilayer MoTe2, Natl. Sci. Rev. **13** , nwag014 (2026).

[一次本文](https://arxiv.org/pdf/2406.19310)

**確認した版:** arXiv:2406.19310 cached PDF extract; explicit version/date absent from extracted header

**今回の実読範囲:** Abstract、導入、二つのdevice setup、K/Γ valley bands、displacement field、Wigner molecular crystals、結論・追加注記を全文。本文末Methods（fabrication、angle/strain、STM/STS、DFTとcontinuum calculation）全節を含む。

**従前の既読範囲:** 本文のSTM/STS結果と主要な計算比較を確認。補足全体は未確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- 五つのdevice、twist角約2.3–3.8度でSTM/STSとDFTを比較。二重back gateはohmic contactと測定領域のFermi levelを別々に調整し、tip距離によりK/Γ谷・上下層の感度が変わる。
- displacement fieldはback gateだけでなくtip biasと仕事関数にも依存する。XM/MXの縮退が解けるhoneycombからtriangularへの変化を観測し、topologyの解釈をDFT/continuum模型と結びつける。STS像単独でChern数を直接測った結果とはしない。
- ν_MX=3の三つのcharge-density peakとtip距離依存からWigner分子・Kagome配置を論じる。tip screeningが相互作用を変えるため、測定probeを無影響と仮定しない。Methodsのheterostrain fitは一層の一軸strainを仮定し、DFT/Gaussian broadening・二調波continuum模型には明示した近似がある。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- 参考文献、Extended Data figuresの本文末の説明、別Supplementaryは今回通読していない。
- PDF抽出ヘッダにversion番号が見当たらず、arXiv番号・cache hashで読んだ本文を同定する。出版版との差分照合や全行列の画像確認・実験再現はしていない。

**SHA256:** `11d1305917b6308a8ef50a011eaf6171d6bea0790b0a6fbabfabb5ada4679747`


## [46]

J. Jang, Effect of lattice relaxation on electronic spectra of helically twisted trilayer graphene: large-scale atomistic simulation approach, J. Korean Phys. Soc. **85** , 727 (2024).

[一次本文](https://arxiv.org/pdf/2407.19143)

**確認した版:** arXiv:2407.19143 cached PDF extract; J. Korean Phys. Soc. 85, 727 (2024) cited by parent

**今回の実読範囲:** 表題・Abstract、I、II.1–II.2 Methods、III.1–III.2 Results、IV Discussion、V Conclusion、謝辞・声明まで全文。図1–5の抽出説明と参考文献冒頭を含む。

**従前の既読範囲:** 本文のMD・tight-binding方法と結果を確認。付録/補足は未確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- 500–1000 nmの有限試料をLAMMPS、Brenner/Kolmogorov–Crespi potential、FIREで緩和し、座標をpybindingのtight-bindingへ渡す。停止条件はenergy変化0.5 ppmであり、すべての構造のglobal minimumを証明するものではない。
- 角度を増やすとatomic commensurate、moiré commensurate、supermoiréの三regimeが現れるという数値結果。低角度では初期ABA/AAA/ABC stack依存が残り、有限試料・potential選択・edge影響を無条件に消した定理ではない。
- KPM/Jackson kernelと15 meV broadeningでDOS/LDOSを求め、緩和による低energy gapとdomain-wall statesの変化を示す。out-of-plane corrugationも含む点はin-plane continuum近似と異なる。STM/SETでの観測は提案で、この論文自体の実験検出ではない。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- 参考文献の後半は未読。キャッシュに独立のSupplement/Appendixはない。
- 抽出にはhopping cutoffの単位がmm、図5のenergyが本文380 meVに対してcaption 0.38 meVとなる等の不整合があるため、これらの数値を確定実装値として引用しない。図の原画像との全照合はしていない。

**SHA256:** `29de346574b17abdadf6da9007ded2f8ccff0659f3c122731fd70776c638ddfd`


## [47]

A. Kerelsky et al., Moiréless correlations in ABCA graphene, Proc. Natl. Acad. Sci. **118** , e2017366118 (2021).

[一次本文](https://pmc.ncbi.nlm.nih.gov/articles/PMC7848726)

**確認した版:** PNAS 118(4), e2017366118 (2021), PMC7848726 archived main article

**今回の実読範囲:** PNAS/PMC本文のSignificance、Abstract、導入、Results、Discussion、Materials and Methods（Experiment、Tight Binding and DFT）を全節確認。図1–4の抽出説明を含む。

**従前の既読範囲:** 本文+SI AppendixのMethods、Berry curvature、mean-field、STS計算を確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- 微小twistのdouble bilayerからmicron-scale ABCA領域を作り、moiréの影響をdomain wallへ寄せた均一領域をSTSで測る。電場とdopingはback gateで同時に変わり、STMは主に最上層のLDOSへ感度を持つ。
- 3–5 meV半値幅とCNP近傍の9.5 meV peak-to-peak gapを観測。低電場のgapは用いた単粒子DFTと合わず、短距離・層間相互作用のmean-field模型でferrimagnetとcharge-transfer excitonic insulatorを候補に挙げる。磁気秩序の確定には追加測定が必要と本文が述べる。
- ABCA–ABAB境界でvalley Chern差に対応するsurface edge stateを論じるが、ABAB全体はmetallic。滑らかな境界でintervalley scatteringが弱い仮定とlayer polarizationにより混成が減り、他のbulk状態への散乱をtopologyが完全に禁止するわけではない。
- Methodsは5.7 K STM、gap抽出のGaussian peak位置とplateau edge、LDA/600 eV/150×150×1 DFT、有限flakeとLanczos LDOSを明示する。経験的モデルと数値手順の条件を保持する。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- SI Appendix、本文後の参考文献・関連データ、別訂正文は今回未読。ページに2021年3月のcorrectionへの告知があり、その内容の独立確認はしていない。
- PMC抽出は一部数式・パラメータが空欄になる。全節の文章は読んだが、欠落した式を読了または実装可能に検証済みとはしない。

**取得範囲:** 主本文の全節とMethodsを取得。SIはリンクのみでこのファイルに本文はなく、一部数式はHTML抽出から欠落している。


**SHA256:** `c07dd9da71c82fb907afd25db9c26f0eae694f43f7de4104f793b0ca5b3902b4`


## [48]

D. Walkup, B. A. Assaf, K. L. Scipioni, R. Sankar, F. Chou, G. Chang, H. Lin, I. Zeljkovic, and V. Madhavan, Interplay of orbital effects and nanoscale strain in topological crystalline insulators, Nat. Commun. **9** , 1550 (2018).

[一次本文](https://arxiv.org/pdf/1610.09337)

**確認した版:** arXiv:1610.09337 cached author PDF extract; Nat. Commun. 9, 1550 (2018) cited by parent

**今回の実読範囲:** 表題、Abstract、導入からstrain抽出・QPI・orbital模型の結論まで主本文を全文。謝辞、Methods、図1–5の全抽出captionを含む。

**従前の既読範囲:** 本文確認。補足全体は未確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- SnTe/PbSe(001)のmisfit dislocationを利用し、同じ領域のSTM topographとQPIを測る。Lawler–Fujita補正を2–3格子定数の尺度で使い、displacementの微分からbiaxial・uniaxial・shear・rotation成分を分ける。
- strainごとのmaskを掛けたdI/dVのFourier peakを比較し、一方向のstrainで垂直方向のDirac-node変位が強いという結果を得る。shearが小さい試料に対象を絞り、全strain tensorの独立な実験制御を行ったわけではない。
- 説明はTe由来conduction bandのpx/py軌道とtwo-center tight-binding近似での重なり変化。Methodsは約40層の薄膜、約4.5 K、10 meVのlock-in励起などの測定条件を示す。mirror保護とtime-reversal保護を区別する。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- Supplementary I–III、参考文献本文は今回未読。測定maskの詳細・軌道hoppingの展開証明を独立に再現したとはしない。
- 全figure画像のpixel照合はしていない。

**SHA256:** `8f716dcad8487924355277203f673470564741031a0589318ef5d0dd3bf04855`


## [49]

M. J. Lawler et al., Intra-unit-cell electronic nematicity of the high-Tc copper-oxide pseudogap states, Nature **466** , 347 (2010).

[一次本文](https://arxiv.org/pdf/1007.3216)

**確認した版:** arXiv:1007.3216 cached PDF extract; Nature 466, 347 (2010) cited by parent

**今回の実読範囲:** Abstract相当の導入、本文全段落と式(1)–(5)、結論、謝辞、図1–4の全説明を通読。独立の本文末Methods節はなく、本文内の観測量・registry・normalization・coarse grainingの方法を確認。

**従前の既読範囲:** 本文とSupplementary Informationへの言及箇所を確認。補足全体は未確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- Cu原点で位相をそろえたFourier変換の二つのBragg peakの実部差をnematic order parameterとする。sub-unit-cell解像度と極めて正確なCu位置registryが必要で、Cu点だけを標本化すると指標はゼロになる。
- g(r,+ω)/g(r,−ω)の比と局所pseudogapで規格化したenergyを用いて電子不均一性の影響を抑える。実空間の二つのO site差から計算した独立指標と比較し、pseudogap付近でO-site由来のC4→C2対称性破れを示す。
- nematicとsmecticの異なる波数成分・coarse-graining尺度を区別する。相関長が視野サイズへ到達する観測は無限系での厳密発散の直接測定ではない。ARPES・neutron結果と共通起源ならO-siteの弱い磁気状態という結論は条件付き解釈。

**今回の回路への適用:** この原著はSTMの格子registry補正とnematic order parameterの方法論であり、graphene本論の画像解析には関連する。Boolean出力基底の変更やHMR位相補正、Toffoli積共有へ同じFourier手順を適用する構成は与えない。

**未読範囲・限界:**

- 別Supplementary Information I–VIと動画は今回未読。本文で引用される全systematic-error検査の独立再解析はしていない。
- PDF抽出で数式の添字や分数の順序が崩れる箇所がある。定義の説明を含め読んだが、全式を画像照合した実装仕様とはしない。

**SHA256:** `fc518aa3a3620732136795749c3323cb360f4188c2101f057eebe6e1e88e8203`


## [51]

H. Yoo et al., Atomic and electronic reconstruction at the van der Waals interface in twisted bilayer graphene, Nat. Mater. **18** , 448 (2019).

[一次本文](https://arxiv.org/pdf/1804.03806)

**確認した版:** arXiv:1804.03806 cached author PDF extract; Nat. Mater. 18, 448 (2019) cited by parent

**今回の実読範囲:** Abstract相当導入、主本文全文、謝辞・著者情報、図1–3caption、本文末Methods（TEM、FEM、DFT/tight binding、transport）を全節通読。区間内の主参考文献も読んだがMethods後の追加参考文献は未読。

**従前の既読範囲:** 本文+Supplementary Informationの主要なfabrication・transport・構造解析箇所を確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- TEM dark-field像とSAED satellite intensity、有限要素計算、transportを突き合わせ、約1度を目安に滑らかなmoiréからAB/BA domain・soliton壁へのcrossoverを示す。diffraction intensityだけでは位相情報が失われ、完全構造を直接復元できないと明記する。
- FEMは非線形弾性・bending・Kolmogorov–Crespi界面energyとL-BFGSを使う。1.1度付近と0.47度付近で緩和がband構造へ及ぼす影響は異なり、rigid模型の第二magic angleをそのまま用いない。
- 垂直場でAB/BAをgappedにした1D networkの輸送像を示す。h/(4e²)の抵抗networkとの比較には頂点でのincoherentな混合を仮定する。強い場でのHofstadter feature減少は2Dからnetwork輸送への解釈で、coherent量子ゲートの実装ではない。
- MethodsではTEMとtransport用のsample構造・測定条件を分ける。一般試料は4端子、1.1度試料は2端子の測定であり同一条件の直接比較としない。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- 別Supplementary Information S1以降の全体は今回未読。Methods後の参考文献は未読。
- 抽出中のθや数式文字が二重化している箇所があり、全式・図をpixel照合していない。

**SHA256:** `007632ff2aa3be2ba7db8de4f1238f2e7f7bbb73bf7784545085698d944c63ab`


## [52]

S. Huang, K. Kim, D. K. Efimkin, T. Lovorn, T. Taniguchi, K. Watanabe, A. H. MacDonald, E. Tutuc, and B. J. LeRoy, Topologically Protected Helical States in Minimally Twisted Bilayer Graphene, Phys Rev Lett **121** , 037702 (2018).

[一次本文](https://arxiv.org/html/1802.02999)

**確認した版:** arXiv:1802.02999v2, 2018-07-17

**今回の実読範囲:** 表題・Abstractから作製・STM/STS測定方法、continuum Hamiltonian、gate依存・spatial LDOS・contrast解析、結論・謝辞まで全主本文を通読。図1–4の抽出captionを含む。独立のMethods節はない。

**従前の既読範囲:** 本文+Supplementary Informationの主要STS・gate依存解析を確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- 57.6±0.7 nmのmoiré周期（twist約0.245度）のsampleを含む、50 nm超の周期のtBLGを作製し、電場でAB/BAにgapが開いたときにdomain wallのdouble-line LDOSを観測する。
- back gateはdopingと電場を共に変え、tip biasとtip/sampleの仕事関数差がzero-field gate offsetを生む。contrastはdomain wallとABのLDOS差をAB値で規格化した測定量である。
- continuum Hamiltonianはspin/valleyのdecouplingと4重縮退を仮定。低energy network模型が要求するE_λ≪Δが実験で十分満たされず、対応するpeakは一つだけ明確と本文が認める。高energyの二つのpeakは別のsaddle-point DOSとして説明する。
- 将来のdissipationless network応用への展望と、今回の局所spectroscopyによる証拠を分ける。量子情報の論理ゲート、braiding操作またはToffoli構成の実証ではない。

**今回の回路への適用:** 今回の固定語表ローダーの回路構成・厳密等価変換・Toffoli削減を与える結果はない。物理系の低エネルギー近似やband topologyを、任意入力のXOR回路の正しさ・費用境界へ置き換えない。

**未読範囲・限界:**

- 本文が引用する別Supplementary Informationはこのcacheに含まれず、今回未読。参考文献全項の本文も対象外。
- HTML著者欄に後年日付が現れるため、arXiv headerのv2とhashで版を同定する。

**SHA256:** `cae8904dda8bf32371b5ae281ea2c836736fd229497a7fd8a10b8d1371172c63`


## [53]

J. S. Alden, A. W. Tsen, P. Y. Huang, R. Hovden, L. Brown, J. Park, D. A. Muller, and P. L. McEuen, Strain solitons and topological defects in bilayer graphene, Proc. Natl. Acad. Sci. **110** , 11256 (2013).

[一次本文](https://arxiv.org/pdf/1304.7549)

**確認した版:** arXiv:1304.7549 の取得済み著者PDF抽出。引用先はPNAS 110,11256 (2013)。抽出本文の明示的版番号は未確認。

**今回の実読範囲:** 表題・要旨から主本文全節、Figure 1–4の抽出キャプション、Methods（Growth and transfer、ADF-STEM、DF-TEM、Multislice simulations）と謝辞、主本文参考文献1–30までを連続して読んだ。Supplementary Materials開始直前まで。

**従前の既読範囲:** 本文+Supplementary Materialsのsoliton幅・TEM解析箇所を確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- AB/BA積層を層間変位の秩序変数で表し、三方向の一結合長のずれが有限幅solitonを作る。六つのdomainが会するAA coreの周りで変位が2π巻く構造欠陥を観察する。ここでの位相欠陥は結晶構造の欠陥であり、非可換anyonや量子ゲートの実証ではない。
- 原子分解能像からshear wallの幅6.2±0.6 nm、tensile wallの幅10.1±1.4 nmを得て、角度依存をFrenkel–Kontorova型モデルへ適合する。弾性率Et=340 N/mとPoisson比0.16を固定し、障壁Vsp約1.2 meV/atomとshear modulus約130 N/mを推定する。障壁はモデルを介した推定値である。
- 80 keV電子線の高い照射量でもwallは移動し、1000°C超の加熱でも運動が増える。beam-induced motionと熱的運動、wrinkle等のpinningを分けている。低い照射量で800°C未満の運動が稀という観察を、照射条件に依存しない普遍的閾値へ外挿しない。
- Methodsは60 kV ADF-STEM、80 kV DF-TEM、20秒/frame、加熱stageとmultislice散乱計算を記述する。予測されるdomain-wallの電子的1D伝導は本論文で測定した輸送特性ではない。

**今回の回路への適用:** 有限幅domain wall、変位の巻き数、構造解析を理解する資料。これをBoolean中間値の共有、HMRの位相修正、CCX数の削減へ変換する構成は提示されていない。

**未読範囲・限界:**

- 今回の通読は29329文字のSupplementary Materials開始まで。補足本文、Supplementary Figures、動画本文・映像の全体は通読・再生していない。従前の補足資料の部分確認とは区別する。
- 原子像の画素から幅を再測定しておらず、multislice計算やモデル適合の数値再現もしていない。PDF抽出で崩れた数式記号を全箇所画像照合したとはしない。

**SHA256:** `bb80b9564534beff59b378d2ea483fd958b37012f648efb929d5d51173e9ea9e`


## [54]

Y. Sha, J. Zheng, K. Liu, H. Du, K. Watanabe, T. Taniguchi, J. Jia, Z. Shi, R. Zhong, and G. Chen, Observation of a Chern insulator in crystalline ABCA-tetralayer graphene with spin-orbit coupling, Science **384** , 414 (2024).

[一次本文](https://arxiv.org/pdf/2310.17971)

**確認した版:** arXiv:2310.17971 の取得済み著者PDF抽出。Science 384,414 (2024)として引用される論文。抽出本文の明示的版番号は未確認。

**今回の実読範囲:** 表題・要旨から主本文の全段落・結論までを読んだ。後置されたFigure 1–4の全抽出キャプション、謝辞等に加え、Materials and MethodsのS1–S4（結晶成長、device fabrication、transport、symmetrization/antisymmetrization）も読んだ。Figure S1開始以降は今回の通読に含めない。

**従前の既読範囲:** 本文+Extended Data/Supplementaryの主要輸送・相図箇所を確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- WSe2近接によるspin-orbit couplingを持つABCA tetralayer grapheneで、charge neutrality付近の磁気ヒステリシスと異常Hall応答を測定する。中間displacement fieldに現れる相を、低Dのlayer-antiferromagnetと高Dのlayer-polarized insulatorの間のChern相として解釈する。
- ゼロ磁場でのHall抵抗は最大約5.0 kΩ、h/(4e²)の約78%であり、完全量子化値には達していない。他方、0.4 Tでh/(4e²)への量子化とChern数4に整合するStředa傾斜を示す。「ゼロ磁場で完全に量子化した」という読み替えを避ける。
- 電荷Hall応答は実測だが、ALL状態に期待するspin、valley、spin-valley Hall応答をすべて直接測定したわけではない。flavor秩序やlayer配置の詳細には理論的解釈が含まれ、論文自身が追加のspin/valley-sensitive測定を提案する。
- MethodsはSNOMによる積層確認、0.1 K dilution refrigeratorと1.5 K cryostat、1–10 nAの励起を述べる。主図のraw Hall信号と対称・反対称化したデータを区別し、縦抵抗の混入を扱う。parallel-plate capacitanceからの密度推定はCNPで絶縁的になると定量的に不正確になり得ると明記する。

**今回の回路への適用:** 磁気秩序とChern絶縁相の条件を示す輸送実験。Chern数やHall抵抗から、固定テーブルXORのToffoli数や測定後の位相正当性は導けない。

**未読範囲・限界:**

- 主参考文献22605–33195、Figure S1以降の補足図・captionの全体、補足参考文献は今回通読していない。S1–S4の方法本文は読了済み。
- PDF抽出の式・図を全画素照合しておらず、磁化・Hall曲線の数値再現はしていない。量子計算への言及は展望であり、ゲートの実装や誤差率を実証したものではない。

**SHA256:** `46a0351623d24afab9ede75ef9e77fea3b1549a7fcaba5b2431cd3434845480a`


## [55]

T. Han et al., Signatures of chiral superconductivity in rhombohedral graphene, Nature **654** , 643(2025).

[一次本文](https://arxiv.org/pdf/2408.15233)

**確認した版:** arXiv:2408.15233 の取得済み著者PDF抽出。元台帳はv2と同定しているが、この補完では明示的版ヘッダを独立確認していない。

**今回の実読範囲:** 表題・要旨からPhase diagram、normal-state fermiology、spin/valley polarization、temperature dependence、strong coupling、Discussion、全Methodsを連続して読んだ。主図1–5の抽出キャプション、device/transport、tight-binding、他device、fluctuations、quantum oscillations、coherence lengthの方法を含み、Author Contributions直前まで。

**従前の既読範囲:** arXiv本文の主要結果・Extended Dataの記述を確認。Supplementary全体は未確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- rhombohedral tetra-/pentalayer grapheneの五deviceで複数の超伝導領域を調べ、最大Tc約300 mKを報告する。中心的なbare T3/P1 deviceではWSe2によるSOCを仮定せず、hBNをmisalignして観測可能なmoiréを避けている。他deviceとすべて同じ近接構造ではない。
- zero-field anomalous Hall、垂直磁場での抵抗ヒステリシス、面内磁場への強さを合わせ、time-reversal symmetry breakingとspin/valley-polarized pairingを示唆する。ただしp+ipのpairing symmetry、topological superconductivity、Majorana zero modeを直接観察したわけではなく、Kerr、SQUID、Josephson、Little–Parks、熱輸送等の追加実験を提案する。
- SC1の隣のquarter-metalでは単一spin/valley pocketの解析を示すが、SC2の親状態のFermiologyには不確実性が残る。annular pocketや他valley pocketの可能性、低周波FFT成分を解像しにくいこと、未同定metalをMethodsが明記する。全超伝導領域で完全なspin/valley分極が確定したとはしない。
- 主図のnominal base temperature約7 mKと電子温度の下限約40 mKを区別する。小さいAC電流を用いる。垂直critical fieldはnormal-state抵抗の10%を基準とし、5–15%基準による不確実性を扱う。GL式からbase-temperature coherence lengthを評価し、Tc近傍でのGL fittingとは異なる。
- coherence lengthが電子間隔に近いことは強結合・BCS–BEC crossoverへの接近を示唆するが、推定はなおBCS側でありBECの直接観測ではない。8/10-band SWMcClure計算、screened displacement field、単一valleyのbandや有効質量の定義などのモデル仮定が入る。抵抗fluctuationのdomain解釈もcooldown履歴等に依存する。

**今回の回路への適用:** 将来のtopological superconductivity研究への動機はあるが、今回の128-qubit上限内のCCZ/Toffoli合成や任意target XORの実装手順は与えない。物質相の兆候からゲート資源削減を計上しない。

**未読範囲・限界:**

- 41066以降のauthor statements、Extended Data Figures、参考文献、別Supplementary全体は今回通読していない。主本文末のMethodsは全節通読した。
- 全band行列・数式のPDF画像照合、FFTやcritical-field fitの再実行、全図の独立解析は行っていない。抽出で崩れたtight-binding行列の記号を検証済みとはしない。
- 論文表題のSignaturesを、確定したpairing symmetryや利用可能なMajoranaゲートの実証へ読み替えない。

**SHA256:** `1f48bb960f10d1bad925d89ad4b76b172812ade518855257e25fd0b271a6e640`


## [56]

Z. Lu et al., Extended quantum anomalous Hall states in graphene/hBN moiré superlattices, Nature **637** , 1090 (2025).

[一次本文](https://arxiv.org/pdf/2408.10203)

**確認した版:** arXiv:2408.10203 の取得済み著者PDF抽出。Nature 637,1090 (2025)として引用される論文。抽出本文の明示的版番号は未確認。

**今回の実読範囲:** 表題・要旨、導入、fractional/extended QAHの観測、温度・電流依存、displacement-field phase transitions、Discussionまで主本文全節と主図1–4の抽出captionを読んだ。後置Methodsの全節（IR imagingとfabrication、transport、縦/Hall抵抗分離、Device 2、Device 3）も読了した。

**従前の既読範囲:** arXiv本文とExtended Dataの主要箇所を確認。Supplementary全体は未確認。 逐頁の全文読了としては集計しない。

**結果と仮定:**

- 二つのpentalayer deviceと一つのtetralayer graphene/hBN deviceを用い、fractional QAHと低温・低biasで現れるextended QAH (EQAH)を報告する。EQAHではRxy=h/e²、Rxx≈0が広い密度範囲へ広がる。最大ν≈0.5–1.3という範囲はtetralayerの結果であり、pentalayerの三領域には小さなgapが残る。すべてのdeviceで同じ連続plateauを観測したとはしない。
- mixing chamberのbase temperature 10 mKと推定電子温度約40 mKを区別する。Methodsは17.77 HzのAC、DC bias、Landau fanからのgate capacitanceを記述する。保磁力を超える正負の磁場での測定を使う対称・反対称化で縦/Hall抵抗を分離し、磁気ヒステリシスと合わせてzero-field応答を判断する。
- 低温・低biasではEQAHが一部のFQAH領域を置き換え、温度・current・Dによってfractional stateや(composite) Fermi liquidへ変わる。currentとtemperatureの依存は同一ではなく、非単調な抵抗とbreakdown thresholdを示すため、電流の全効果を単なる加熱と同一視しない。
- Discussionは二つの候補像を区別する。ひとつはtime-reversalとtranslationを破るQAH crystal、もうひとつは整数QAH液体と余剰電荷のWigner crystalからなるre-entrant類似像である。広い非整合fillingや最下moire bandでの挙動は従来RQHEと異なり、電子結晶であることを確定するにはreal-space imaging、diffraction、narrow-band noise等が必要だと述べる。
- 高throughput IR cameraはnear-field/Ramanと組み合わせて積層を確認する。中間積層が似たcontrastを示すこと、遠視野の約1 μm分解能では小domainを見逃すことをMethodsが認める。moireなしでQAH crystalを安定化できるという説明は将来の検証案であり、今回その実験を完了したものではない。

**今回の回路への適用:** 多体輸送の相と条件を与える資料である。Hall量子化やelectron-crystalの候補像は、Boolean積の共有、Clifford+measurementによる無償非Clifford生成、HMRの位相検証を与えず、Toffoli削減の実証としては扱わない。

**未読範囲・限界:**

- 31058–42567の参考文献、47751以降のauthor/data statementsおよびExtended Data Figuresの全体は今回通読していない。主本文および後置Methodsに途中切れは認めていない。
- 全図の画素照合、全抵抗データの再解析、温度の独立校正、QAH crystalの直接観察は行っていない。後者は論文自身が未確定として追加実験を求める事項である。

**SHA256:** `4226a1addd63905b9fd993d0bbe862816409680e358d97fd198b12bce93726f3`
