"""Independent checks of arXiv:2205.01933v2 Appendix A/B as printed."""
import json, math
from fractions import Fraction
from pathlib import Path

# S3 two-dimensional irreducible character: 2 at e, 0 at 3 transpositions, -1 at 2 cycles.
chi=[2,0,0,0,-1,-1]
lhs=sum(Fraction(x*x,6) for x in chi)
rhs=Fraction(2) # Eq. (68) at pi=pi_prime, g=e

# The six real matrices printed on p44, in their printed order.
s=math.sqrt(3)
G=[[[1,0],[0,1]], [[1,0],[0,-1]],
   [[-0.5,s/2],[s/2,0.5]], [[-0.5,-s/2],[s/2,-0.5]],
   [[-0.5,s/2],[-s/2,-0.5]], [[-0.5,-s/2],[-s/2,0.5]]]
# M = [[3, 3i], [0, 0]], so Tr(M Gamma) = 3 Gamma_11 + 3i Gamma_21.
traces=[3*g[0][0]+3j*g[1][0] for g in G]
# Exact: real parts 3 or -3/2, imaginary parts 0 or +/-3sqrt(3)/2; squared modulus 9.
mod_squared_exact=[Fraction(9),Fraction(9)]+[Fraction(9,4)+Fraction(27,4)]*4
out={
 'source':'https://arxiv.org/pdf/2205.01933v2',
 'eq68_S3_g_identity':{'character':chi,'lhs_exact':str(lhs),'rhs_printed_exact':str(rhs),'identity_holds':lhs==rhs, 'correct_rhs_factor':'1 / dim(pi)'},
 'lemma_B1_ii_eq71':{'M':'[[3,3i],[0,0]]','traces':[[z.real,z.imag] for z in traces],
 'mod_squared_exact':[str(x) for x in mod_squared_exact], 'all_abs_trace_equals_3':all(x==9 for x in mod_squared_exact)},
 'scope':'Checks refute those two printed algebraic claims in the arXiv v2 manuscript; no conclusion is made here that every main theorem is false or cannot be repaired.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
