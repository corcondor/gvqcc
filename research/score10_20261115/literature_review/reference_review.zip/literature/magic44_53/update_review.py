"""Truthful full-text reading ledger for the magic paper's refs 44--53."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "linked_sources"
LEDGER = HERE / "reading_ledger.json"

def update(number, version, scope, mechanisms, applicability, caveats="", status="full_text_read", primary_url=None):
    bibliography = json.loads((SOURCE / "magic_bibliography.json").read_text())
    citation = next(x for x in bibliography["references"] if x["number"] == number)
    source = SOURCE / "magic_refs" / ("ref_52_arxiv.md" if number == 52 else f"ref_{number:02d}.md")
    files = [source] + list(HERE.glob(f"ref{number}*"))
    hashes = [{"path": str(f), "bytes": f.stat().st_size,
               "sha256": hashlib.sha256(f.read_bytes()).hexdigest()} for f in files if f.is_file()]
    data = json.loads(LEDGER.read_text()) if LEDGER.exists() else {
        "parent": bibliography["parent_title"], "assigned_references": list(range(44, 54)),
        "scope_rule": "Retrieved text does not imply read. Full-text read means the available complete textual source was read, not independent reproduction of every proof, experiment, numerical estimate, or visual inspection of every figure.",
        "references": []}
    e = {"number": number, "citation": citation["citation_verbatim"],
         "primary_url": primary_url or citation["primary_fulltext_url"], "version_read": version,
         "status": status, "read_scope_ja": scope, "mechanisms_ja": mechanisms,
         "gvqcc_applicability_ja": applicability, "caveats_ja": caveats,
         "cached_files": hashes}
    data["references"] = sorted([r for r in data["references"] if r["number"] != number]+[e], key=lambda r:r["number"])
    LEDGER.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n")
    lines = ["# Magic 論文の参考文献 [44]–[53] 読書台帳", "", data["scope_rule"], ""]
    for r in data["references"]:
        lines.extend([f"## [{r['number']}] {r['citation']}", "", f"**状態・版:** {r['status']}; {r['version_read']}", "",
                      f"**実読範囲:** {r['read_scope_ja']}", "", f"**内容:** {r['mechanisms_ja']}", "",
                      f"**GVQCCへの適用:** {r['gvqcc_applicability_ja']}", "", f"**限界:** {r['caveats_ja']}", "",
                      f"**一次資料:** <{r['primary_url']}>", ""])
    (HERE/"reading_ledger_ja.md").write_text("\n".join(lines)+"\n")
