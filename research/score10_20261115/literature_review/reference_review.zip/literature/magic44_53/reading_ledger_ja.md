# Magic 論文の参考文献 [44]–[53] 読書台帳

Retrieved text does not imply read. Full-text read means the available complete textual source was read, not independent reproduction of every proof, experiment, numerical estimate, or visual inspection of every figure.

## [44] Nobuyuki Yoshioka, Alireza Seif, Peter Groszkowski, Andrew Cross, and Ali Javadi-Abhari. “Theory and architecture of syndrome-resolved logical gates” (2025). [arXiv:2510.08290](http://arxiv.org/abs/2510.08290) .

**状態・版:** full_text_read; arXiv:2510.08290v2, 25 Jun 2026, 37頁

**実読範囲:** 主本文I–IV、Appendices A–H、全参考文献・全図キャプションを通読。Fig.11/12（29頁）の原PDF画像も確認。一次抽出本文中のLatexitメタデータを除いた可読コピーを保存。

**内容:** 弱横断ゲートをsyndromeごとの入力非依存なユニタリ集合として定義。奇数Mのdisjoint support partitionは各部分積が非自明syndromeを持つよう構成し、補対なPauli積が同一syndromeへまとまる。K_s†K_s=p_s Iという入力非依存条件と論理角 tan(θbar_s)=(-1)^((M-1)/2-w)tan(θ)^(M-2w)を導出。CSSのcheck列をGF(2)消去してpartitionを作る。RUSで角度残差を補正、postselection・角度分割・MEK distillationで状態準備の誤差/物理qubitcycleを改善。既存のsyndrome CNOT伝播へ回転を挿入するhook dopingも示す。

**GVQCCへの適用:** 各測定分岐の確率が入力に依存しないことと、補正後の位相・論理作用を別々に証明する方法は現在のHMR検証に直接有用。既存CNOTが作るパリティへ回転を挿入する発想はInvsqrtの位相共用候補になる。ただし現在のZ_POWは許可された回転を直接実装し、chemistryはZ_POW不可。符号化、syndrome抽出、任意角、RUSを持ち込むだけでToffoli数が減るとはいえない。778倍/45倍はmagic工場・配置・物理時間・異なる誤差許容を含む比較であり、GVQCCのQやToffoli相当への改善証拠ではない。

**限界:** 一般Alg.1の最後のPauli部分は大きな支持を持ち得るので、物理局所性/定数深さを個々の符号・ハードウェアで示す必要がある。Appendix D3のsurface-code errorは単一入力のPauli期待値proxyで、一般channel diamond距離の保証ではない。hook dopingは例でfault distance7→5。数値実験を独立再現していない。

**一次資料:** <https://arxiv.org/pdf/2510.08290>

## [45] Eric Huang, Pierre-Gabriel Rozon, Arpit Dua, Sarang Gopalakrishnan, and Michael J. Gullans. “A robust phase of continuous transversal gates in quantum stabilizer codes” (2025). [arXiv:2510.01319](http://arxiv.org/abs/2510.01319) .

**状態・版:** full_text_read; arXiv:2510.01319v2, 2 Feb 2026, 9頁

**実読範囲:** 主本文1–5頁、全参考文献5–7頁、Appendix相当のSyndrome Sampling / Logical Channel Calculation / Policy Optimization / Simulations / Fault-tolerance / Distribution Properties / Resource estimation（8–9頁）と全図キャプションを通読。

**内容:** odd-distance surface codeの全物理Z回転後、syndromeごとの既知論理回転とdephasing率を求める。平均相対dephasing E[q_s/|φ_s|]が距離と共に指数抑制されるrobust phaseを数値で示す。Majorana Gaussian stateでsyndromeを標本化、tensor networkのChoi行列で論理channelを算出。Bellman方程式を離散化して角度と蓄積dephasingの状態空間上で適応方策を求める。resource state準備ではresetを許し、qubit-roundをcultivation＋Clifford+T synthesisと比較。

**GVQCCへの適用:** 有望な転用は期待資源を伴う適応回路の評価と入力非依存な分岐の区別。これは物理誤り・surface code・continuous rotationと古典最適化の論文で、Toffoli oracleの合成下界やnative gate削減を示していない。Invsqrtに移すなら全分岐の同一作用、許可KMB、実生存幅、回転採点を明示する別の具体的構成が必要。resource stateのresetは未知入力を持つローダーへの任意resetを正当化しない。

**限界:** 主結果はphysical Z dephasing＋coherent rotationの数値評価。phenomenological/circuit-level noiseの全面評価は著者も将来課題としている。距離を大きくすると有利な目標角の範囲も指数的に小さくなる。有限discretization・経験syndrome分布・discount factor0.99の方策を使用し、誤差と準備成功率を含む費用である。

**一次資料:** <https://arxiv.org/pdf/2510.01319>

## [46] Sergey Bravyi and Robert Koenig. “Classification of topologically protected gates for local stabilizer codes”. [Physical Review Letters 110 , 170503](https://dx.doi.org/10.1103/PhysRevLett.110.170503) (2013). [arXiv:1206.1609](http://arxiv.org/abs/1206.1609) .

**状態・版:** full_text_read; arXiv:1206.1609v1, 7 Jun 2012, 6頁

**実読範囲:** 全6頁の主定理・Corollary 1、toric code例、一般2D証明、D次元への帰納と有限群の証明、全参考文献・図キャプションを通読。

**内容:** D次元の幾何的局所stabilizer codeで、符号距離が大きく、有限range・定数depthのunitaryがcodespaceを保つなら、論理作用はClifford階層の第D層に属する。Cleaning LemmaとUnion Lemmaで論理Pauliの支持を避け、入れ子commutatorをcorrectable領域へ局所化して証明。二つの異なるtopological code間の定数depth morphismにも拡張。k固定の無限code familyではprotected gatesが生成する群も有限となり非普遍。

**GVQCCへの適用:** これは幾何的局所性・漸近code distance・codespace保存を前提とする構造上の制限。GVQCCの有限サイズall-to-all KMBローダーのToffoli下界ではない。2DでCliffordのみという結論から、測定・feedback付き構成やnative CCZを禁止・割引できない。magic44/45のweak transversalはsyndrome測定を含み、このunitary no-goと区別して読む必要がある。

**限界:** キャッシュのarXiv識別は2012v1だが冒頭組版日付は2024年になっている。版の根拠はarXiv識別に置き、後年の全改訂状況は未調査。歴史的な物理Tの費用比較を現在のGVQCC採点へ引用しない。

**一次資料:** <https://arxiv.org/pdf/1206.1609>

## [47] Michael E. Beverland, Oliver Buerschaper, Robert Koenig, Fernando Pastawski, John Preskill, and Sumit Sijher. “Protected gates for topological quantum field theories”. [Journal of Mathematical Physics 57 , 022201](https://dx.doi.org/10.1063/1.4939783) (2016). [arXiv:1409.3898](http://arxiv.org/abs/1409.3898) .

**状態・版:** full_text_read; arXiv:1409.3898v3, 2016-01-25, 50ページ

**実読範囲:** 本文 §§1–7、全定理・補題の証明、Appendix A、参考文献まで、取得された全126,699文字を読了。図のラベル・キャプションは読了、全図の原画像照合は未実施。

**内容:** 2次元 TQFT の保護されたゲートを codespace を保つ locality-preserving unitary として制約する。各閉曲線の Verlinde algebra の原始冪等元を置換するため、DAP 分解の各基底で位相付き置換行列になる。gluing の次元、F-move、mapping class group の異なる基底間の整合性が更なる制約。MCG 表現が射影ユニタリ群に稠密なら保護ゲートは大域位相のみ。Fibonacci の多穿孔球面は自明、Ising の偶数 M 穿孔球面は M/2−1 論理量子ビット上の Pauli に限定。Abelian anyon では各ループのホモロジーを保存する一般化 Clifford の部分群。Appendix A は gluing による部分空間上の稠密性へ拡張。

**GVQCCへの適用:** この no-go は固定2Dトポロジー、幾何学的局所性、一定の伝播範囲、codespace-preserving unitary が前提。全結合の有限 KMB 回路の Toffoli 数の下界にはならず、syndrome measurement、code deformation、braiding、非局所結合を許した構成の費用も算出しない。反対に、論理レベルで arbitrary protected gate を無料として数える提案には、どの前提を外すか明記させる根拠になる。Boolean loader の 4170 境界を直接改善する変換は得られない。

**限界:** 制約は必要条件であり、その部分群の全要素が特定の微視的モデルで実装可能だとは主張しない。Fibonacci/Ising の結論は指定された曲面・荷電ラベル・TQFT 仮定に依存。欠陥線・凝縮境界は本論の対象外。

**一次資料:** <https://arxiv.org/pdf/1409.3898>

## [48] David Aasen, Jeongwan Haah, Zhi Li, and Roger S. K. Mong. “Measurement quantum cellular automata and anomalies in floquet codes” (2023). [arXiv:2304.01277](http://arxiv.org/abs/2304.01277) .

**状態・版:** full_text_read; arXiv:2304.01277v2, 2023-08-02（本文の最終頁番号77）

**実読範囲:** キャッシュ249,775文字の全テキストを順に実読。本文§§1–7、全参考文献、付録A–E（Cの1次元安定化子分類の2通りの証明、DのWPT境界、EのHH境界回路を含む）。図のキャプションと抽出された演算子表は読んだが、全図の画像を個別に視認したわけではない。

**内容:** Pauli測定列の局所可逆性を、隣接する安定化子群の共通論理空間と局所的な共役生成元により定義。可逆な測定は入力情報を漏らさず、結果依存Pauli補正の下で論理情報を保持する。1次元MQCAの情報流をFredholm indexの1/2で定義し、独立な1次元局所可逆回路では整数、2次元系の境界では半整数を許し、mod ZがZ2のbulk invariantとなる。WPTと3段HH codeは非自明な1/2クラス。HHのperiod-3局所可逆境界はカイラルな情報流を持ち、period-6化や付加ancillaを用いるgapped境界を構成。付録Eでは1 ancilla/unit-cellまで減らしたperiod-6 zigzag例も示す。

**GVQCCへの適用:** HMRによる一時ビット消去を評価する際、単なる出力一致より強い、入力に依存しない測定分布と条件付き位相補正の確認が必要だという構造的指針になる。既存のANF＋測定記号での位相証明と整合する。一方、測定による論理情報の移動は物理量子ビットの除去を意味せず、論文のindexや定数深さからKMBのToffoli数・最大Qの削減は導けない。一般のBoolean非線形関数を計算・消去するための安価なKMBゲート列を提供する論文ではない。

**限界:** 仮定は幾何学的局所性、Pauli測定、局所的に可逆な安定化子群遷移。単なる可逆性は局所可逆性より弱く、長いBell teleportation鎖は反例。境界の順番を反転することと論理MQCAの逆写像は同義ではない。§7で回路雑音・thresholdは未解決として明示されており、local reversibilityからfault-toleranceを無条件に結論してはいけない。Z2 invariantが完全分類であるとは証明していない。付録E.4.1の局所可逆性確認は著者が読者に委ねており、こちらでも全図回路を独立実装して証明したものではない。

**一次資料:** <https://arxiv.org/pdf/2304.01277>

## [49] Paul Webster and Stephen D. Bartlett. “Locality-preserving logical operators in topological stabiliser codes”. [Physical Review A 97 , 012330](https://dx.doi.org/10.1103/PhysRevA.97.012330) (2018). [arXiv:1709.00020](http://arxiv.org/abs/1709.00020) .

**状態・版:** full_text_read; arXiv:1709.00020v3, 2018-01-25, 24ページ

**実読範囲:** 本文 I–VI、全定理・補題・証明、図表の全説明と参考文献まで全126,765文字を読了。原図の全画像照合は未実施。

**内容:** LPLO と gapped transparent domain wall の対応を用い、有限個の d 次元 toric/surface code に局所同値な符号の論理操作を分類する。bulk の融合・交換・braiding 統計と励起の次元を保存する壁を列挙し、境界条件で論理ゲートへ写す。二次元 stacked surface code は real Clifford、三次元の通常の stack は CNOT・CZ・CCZ により生成。colour code の境界同一視は controlled-Z 系列を R_k 系列へ変える。一般 STS 符号で最小励起次元 a のとき、階層 C_p\C_{p-1} の LPLO の支持次元 m≥p(a+1)、従って p≤d/(a+1)。非同型 stack、Abelian quantum double、Levin–Wen fermion model も検討。

**GVQCCへの適用:** CCZ が三次元符号で局所性保存に実装可能であるという構造的事実は、1 CCZ の現在の KMB 費用を下回る置換ではない。与えられたアルゴリズムと符号の相性を調べる将来の fault-tolerant architecture 設計には有用だが、符号化・全物理ゲート・ancilla を数えずに Toffoli 節減へ換算しない。Boolean address warp や複数出力の積共有とは別の階層の最適化。

**限界:** Pauli は最初から自明な LPLO として省かれており、「唯一」「none」はそれらを除いた記述。bulk の壁の分類と、特定境界の全物理実装の分類は区別が必要。STS・整数次元励起が対象で、fractal/fracton 型、non-Abelian、defect braiding は一般結果の対象外。

**一次資料:** <https://arxiv.org/pdf/1709.00020>

## [50] Sergey Bravyi, Isaac Kim, Alexander Kliesch, and Robert Koenig. “Adaptive constant-depth circuits for manipulating non-abelian anyons” (2022). [arXiv:2205.01933](http://arxiv.org/abs/2205.01933) .

**状態・版:** full_text_read; arXiv:2205.01933v2, 2022-09-28, 48ページ（arXiv現行版を再確認）

**実読範囲:** 本文 §§1–7、Appendix A–C、全証明と参考文献、図の抽出説明まで全140,607文字を読了。原PDF全48頁を保存し、Appendix A p42 の原画像も目視照合。全図の画像照合・全主定理の独立再証明は未実施。

**内容:** 固定された有限 solvable group G の quantum double について、真空状態の準備、任意距離のanyon pair/ribbon操作、領域のtopological charge測定を一定回数の測定・条件付き局所ゲートで行う構成を提示。solvable subgroup chain の cyclic quotientへ再帰し、prefix multiplication・difference・fanout を qudit Clifford のChoi状態準備とteleportationへ還元する。非可換anyonの特定ribbon作用は非適応の局所unitaryでは距離に比例する深さが必要。§4.3では compute E→diagonal correction→uncompute E を直接diagonal Vへ置換し、補助レジスターBを除去する簡約も明示。

**GVQCCへの適用:** 主要費用は一定の量子深さであり、全Toffoli数や最大qubit数の削減を証明していない。非局所の効率的古典処理、補助qudit、quditのFourier測定・任意局所unitaryを許す。KMBに移すには全ての二進符号化と位相・測定補正を合成して数える必要がある。§4.3のdiagonalへの吸収は位相生成で中間値を保持しない着想になるが、f(x)の位相を安価に直接合成できる場合だけ有効。定理6.1の決定的ribbon生成は既知のground state上の作用という定義であり、一般の非unitary Fを未知入力に決定的適用するoracleではない。

**限界:** 本文を無条件に実装仕様としては使えない。独立計算で、Appendix A Eq.(68) はS3の2次元irrep・g=eで左辺1、印刷された右辺2。原画像でもSchur直交性の1/dim(pi)が欠落し、Eq.(12)の射影正規化に影響する。またAppendix B Eq.(71)の不存在主張に対し、印刷された6つの実行列表現でM=[[3,3i],[0,0]]を取ると全て|Tr(MΓ(g))|=3となる明示反例を保存（ref50_algebra_checks.py/json）。これは当該印刷式への反例で、全主定理の否定を意味しない。v2ではord(a)と|G/H|の混同を修正した旨の謝辞があり、その修正と今回の正規化問題は別。

**一次資料:** <https://arxiv.org/pdf/2205.01933>

## [51] Gaurav Saxena and Gilad Gour. “Quantifying multiqubit magic channels with completely stabilizer-preserving operations”. [Physical Review A 106 , 042422](https://dx.doi.org/10.1103/PhysRevA.106.042422) (2022). [arXiv:2202.07867](http://arxiv.org/abs/2202.07867) .

**状態・版:** full_text_read; arXiv:2202.07867v2, 1 Jul 2022, 19頁（公開論文とはタイトルが異なる）

**実読範囲:** 全19頁。主本文I–VII、Theorem 1–2 / Propositions 1–4 / classical simulation algorithm、Appendices A–H、2表と全参考文献・図キャプションを通読。アルゴリズム部分は出力切詰めを避けて別途全文を再読。出版先APSのabstractと題名/DOIは照合したが、最終出版PDFの本文は取得失敗。

**内容:** CSPOを正規化Choi状態がstabilizer polytopeにあるCPTP mapとして特徴付け、CSPO-preservingとcompletely CSPO-preserving superchannelsを定義。後者も正規化Choi状態がstabilizerという条件になる。generalized robustness / min-relative entropyからsingle-shot costとdistillationの上下界を導く。単一qubit変換は元状態の24Clifford像と6stabilizer状態のconvex hullの問題。古典constrained-path simulatorは一部channelをscaled CSPOへ置換し、許容additive errorに応じて標本数を減らす。

**GVQCCへの適用:** 大きい自由操作集合下の単調量は、より狭い許可回路への必要条件・下界に使えるが、CSPO下の変換上界だけでKMB実装が得られるとはいえない。CCZ resource-stateのT-state cost4という表も、そのままToffoli0.25等の新しい換算を与えない。constant runtimeは誤差制限を外した標本数についての議論で、最適decompositionの前処理や回路読出しまで無料という意味ではない。正確なcoherent loaderの候補にはならない。

**限界:** 公開v2には注意すべき式の不整合がある。min-relative entropyの一般mixed stateに対するfaithfulness（Eq.37）は同じ論文Appendix Cのfull-rankでDmin=0という計算と両立しない。Theorem2の行列次元表記と本文証明のconvex-hull正規化にも差がある。このため当該断言を実装判定に使用しない。出版版で訂正されたかは未確認。robustnessは本文・Appendixで正規化の定義が異なる箇所があるため数値を混用しない。

**一次資料:** <https://arxiv.org/pdf/2202.07867>

## [52] Arne Heimendahl, Markus Heinrich, and David Gross. “The axiomatic and the operational approaches to resource theories of magic do not coincide”. [Quantum 6 , 878](https://dx.doi.org/10.22331/q-2022-12-22-878) (2022).

**状態・版:** full_text_read; arXiv:2011.11651v3, 18 Jan 2022, 30頁

**実読範囲:** 全30頁。主本文I–VII、Theorems 1–5 / Lemmata 1–16の全証明、単一quditの等価性、一般multi-quditの分離、Appendices A–C、全参考文献・図キャプションを通読。

**内容:** 操作的SO（Clifford・stabilizer準備・Pauli測定・適応古典制御・discard）と公理的CSPを区別し、n>=2のprime-dimensional quditではSOがCSPの真部分集合、n=1では等しいと証明。2qubit反例は|00>を|++>へ、他基底は保持し、その非対角成分を半減するchannel。Choiはstabilizer混合だがSOのextremal構造を満たさない。SOのnormal formはorthogonal stabilizer code projector測定＋条件Clifford、任意SOは最大n interactive rounds。CSPはより広い非直交stabilizer POVMを許す。

**GVQCCへの適用:** この文献は「古典的に記述/シミュレートできるfree map」と「許可されたClifford回路で実装できる操作」を区別する直接的根拠。CSP下でmagicが増えない/安く変換できることはKMBの合成手順にならない。Remark1のE(|x><y|)=δ_xy |O(x)><O(x)|は任意Boolean Oをclassical制御に隠せるが、測定でcoherenceを消すので量子ローダーのcoherent XORとは異なる。候補に使うなら入力/測定/phaseの契約と実ゲート列が要る。

**限界:** 全てのCSPが無条件に効率的古典シミュレーション可能とは本論文も述べていない。効率的に標本化できる特別なPOVMなどが追加で必要。分離の証明は古典制御を非効率な任意関数まで許しても成立する。元magic参考文献のDOIは誤りであるため、実読一次資料URLは正しいarXivへ固定。

**一次資料:** <https://arxiv.org/pdf/2011.11651v3>

## [53] Ryohei Kobayashi and Guanyu Zhu. “Cross-cap defects and fault-tolerant logical gates in the surface code and the honeycomb floquet code”. [PRX Quantum 5 , 020360](https://dx.doi.org/10.1103/PRXQuantum.5.020360) (2024). [arXiv:2310.06917](http://arxiv.org/abs/2310.06917) .

**状態・版:** full_text_read; arXiv:2310.06917v2, 2024-05-21, 26ページ

**実読範囲:** 本文 I–V、Appendix A の topological invariance/quadratic property の証明、Appendix B の測定版構成、参考文献、全図表のキャプションと抽出ラベルまで全117,530文字読了。全原図画像の独立照合は未実施。

**内容:** cross-cap により論理 X と Z が同じホモロジー経路に載り、e↔m 交換を一定深さの局所回路で論理 HZ として実装する。薄い slit を折れば bilayer の layer-exchange twist と gapped boundary になり、Clifford 全群を構成できる。honeycomb Floquet の XX→YY→ZZ 測定周期を fermion loop の condensation operator として展開し、二次形式の Gauss sum/Arf–Brown–Kervaire invariant から cross-cap 量子ビット上の exp(−iπY/4)=HZ を導出。Appendix B は Klein bottle 上の Wen plaquette-translation を四回の局所測定で実装。

**GVQCCへの適用:** 主要ゲートは Clifford であり、T/CCZ を減らす新しい非Clifford分解ではない。e^{±iπ/4} という固有位相が出ても相対位相は π/2 なので、それだけを T ゲートと誤認しない。Boolean loader の 4,170 Toffoli 境界や Invsqrt の全回路45qubit化への直接変換はなし。位相の二次形式をシンボリックに追跡する設計思想は既存 HMR 位相監査と整合する。

**限界:** open boundary を持つ非向き付け可能 surface code では U が e/m boundary を交換する。subsystem code としては論理 H だが、元の gauge fixing へ戻すには境界で O(d) 回の stabilizer 測定が必要（III.C.4）。折る前は cross-cap の O(d) 本の長距離静的接続が必要。4+1D fermionic toric code の T は discussion の将来構想で、ここに実装済みの T 回路はない。fold-transversal の threshold 欠如は著者も追加数値解析が必要とする示唆であり、一般的不可能定理として使わない。

**一次資料:** <https://arxiv.org/pdf/2310.06917>

