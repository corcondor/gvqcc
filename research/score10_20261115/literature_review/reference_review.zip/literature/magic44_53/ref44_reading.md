**Theory and Architecture of Syndrome-Resolved Logical Gates**

Nobuyuki Yoshioka, 1, _∗_ Alireza Seif, ² Peter Groszkowski, ³ Andrew Cross, ² and Ali Javadi-Abhari ²

1 _International Center for Elementary Particle Physics,_

_The University of Tokyo, 7-3-1 Hongo, Bunkyo-ku, Tokyo 113-0033, Japan_

2 _IBM Quantum, IBM T.J. Watson Research Center, Yorktown Heights, NY, USA_

3 _National Center for Computational Sciences, Oak Ridge National Laboratory, Oak Ridge, Tennessee 37831, USA_

We introduce a general framework for weak transversal gates—syndrome-resolved implementation

of logical unitaries realized by local physical unitaries—and demonstrate its wide impact in three

applications: partial fault-tolerant architecture, short-depth state preparation, and magic state

distillation. Our theoretical contribution is to prove a sufficient condition for a general Calderbank-

Shor-Steane code to admit weak transversal gates, and to present an efficient algorithm to determine

the physical multiqubit Pauli rotations. To demonstrate the practicality of weak transversal gates

in the near future, we propose a partially fault-tolerant Clifford+ _ϕ_ architecture that implements

in-place Pauli rotations via a repeat-until-success strategy. Numerical simulations indicate that a

rotation of 0 _._ 001 attains a logical error of 9 _._ 6 _×_ 10 _−_ ⁵ on a surface code with _d_ = 7 at a physical

error rate of _p_ phys = 10 _−_ ⁴ , while avoiding the spacetime overheads of magic state factories, small

angle synthesis, and routing. Resource estimates on surface and [[144,12,12]] bivariate bicycle codes

for a Trotter-like circuit with _N_ = 108 logical qubits indicate runtime reductions of factors of

778 and 45, respectively, relative to the conventional Clifford+T execution, due to the natural

parallelism of rotation gates. Looking further ahead, we consider state-preparation tasks allowing

postselection. We show that weak transversal gadgets prepare high-level equatorial magic states with

a substantially improved cost-accuracy tradeoff, achieving up to a 10 ³ \-fold reduction in spacetime

cost for a magic state at the 11th level of the Clifford hierarchy on a surface code of _d_ = 11.

Furthermore, we integrate weak transversal gates into magic state distillation pipelines, reducing

the logical error rate of level-2 distillation of the

_√_

_T_ state by up to a factor of 94 with a small

increase in spacetime cost.

This work opens a novel paradigm for non-Clifford operations beyond

conventional transversal and factory-based approaches.

**I.**

**INTRODUCTION**

Transversal gates, the logical gates that can be implemented with only local operations on physical qubits, play a

central role in fault-tolerant quantum computation (FTQC). Beyond their direct use as fault-tolerant gate operations,

they are also fundamental in protocols such as distillation of quantum resources [ 1 , 2 ]. However, systematic methods

to identify transversal gates in the conventional sense remain limited: a naive approach requires exponential-time

computation [ 3 , 4 ], and consequently, most known constructions have been derived on a case-by-case basis [ 5 – 8 ].

Considering that practical architectures of FTQC require resilience to qubit dropout [ 9 – 13 ] or the use of dynamically

changing error correcting codes (QECCs) [ 14 , 15 ], a more flexible and efficient framework for determining the feasibility

of gate implementations is desired. In particular, in the earliest realizations of FTQC, combinations of fault-tolerant

and non-fault-tolerant gates are envisioned to outperform full-fledged FTQC [ 16 – 19 ], and hence it is essential to

develop methodologies that reduce the burden on quantum computers.

An emerging question is whether there exist transversal yet non-fault-tolerant gates. Indeed, it has been found in the

context of error correcting memory [ 20 , 21 , 23 , 24 ] and randomness generation [ 22 ] that weaker versions of transversal

gates exist. We refer to these as _weak transversal gates_ , which implement a set of gates in a probabilistic manner

depending on the syndrome, instead of a deterministic manner (Fig. 1 ). Both works consider surface codes of odd

code distance, with the assumption that identical physical unitaries are applied to all the data qubits. Extending this

framework to quantum error correcting codes with multiple logical qubits, including quantum low-density parity check

(qLDPC) codes, has been an open question, as noted recently by Cheng et al. [ 22 ]. Additionally, when considering

inhomogeneous application of physical unitaries, it remains entirely unknown which weak transversal gates are allowed.

An outstanding question to be answered in this context is as follows: _Are Pauli rotations weakly transversal in general_

_codes, and what does this enable computationally?_ We address this question by establishing a general construction of

weak transversal Pauli rotation gates in general Calderbank–Shor–Steane (CSS) codes, including high-rate quantum

_∗_ ny.nobuyoshioka@gmail.com

arXiv:2510.08290v2 [quant-ph] 25 Jun 2026

2

Local unitaries

Syndrome meas.

Recovery

 ¯ _U_ **_s_** ¯ _ω_ ¯ _U_ _†_

**_s_**

with Prob( **_s_** )

⊗ _i_ _u_ _i_

QECC

Physical

unitary

Ref. [20,21]

Rz or Rx

Surface

odd- _d_

Refs. [22-24]

SU(2)

Surface

odd- _d_

**This work**

\-body Pauli rot

_O_ (1)

Logical unitary

Rz or Rx

SU(2)

**multi-Pauli**

**rotation**

**General CSS**

(+ numerics for non-CSS)

Target

Implemented

(a)

(b)

_C_ **_s_**

Π **_s_**

(c)

Near-term

 _|_ _ω_ _→_

**Prep**

(FT)

**Gate**

(FT)

non-FT

**Meas**

(FT)

**Pauli Rot**

 _|_ Stab _→_

**Sec.III A,B**

**Sec. III C**

**Sec. III D**

Short-depth state preparation

Magic state distillation

Factory-free, Clifford+ architecture

_ϕ_

Mid-term

Long term

FIG. 1.

(a) Concept of a weak transversal gate. If a set of given local unitaries followed by syndrome measurement with result

**_s_** and correction operation _C_ **_s_** results in a logical unitary operation ¯ _U_ **_s_** that is _independent of the input state_ , then we call such

an operation weakly transversal. (b) Comparison with existing works that study weak transversal gates [ 20 – 24 ]. Our main

contribution in Sec. II is to establish a general condition for CSS codes to admit weak transversal implementation of multi-

body Pauli rotation gates. (c) Applications considered in this work: partially fault-tolerant architecture (Secs. III A , III B ),

short-depth state preparation (Sec. III C ), and magic state distillation (Sec. III D ), which we expect to be relevant in the near-,

mid-, and long-term FTQC, respectively.

low-density parity-check (qLDPC) codes [ 25 – 29 ] and topological codes such as the surface code [ 30 , 31 ] and color

codes [ 32 , 33 ] (Sec. II ). We further demonstrate the impact of weak transversal gates for quantum computing in three

settings: factory-free Clifford+ _ϕ_ architecture, postselected short-depth state preparation, and enhanced magic state

distillation:

• **Factory-free, Clifford+** _ϕ_ **architecture (Sec.** **III A** **,** **III B** **).** We propose a partially-fault tolerant architecture

that augments the instruction set with _in-place_ Pauli rotations implemented via a repeat-until-success (RUS)

strategy. As detailed in Sec. III A , estimate from circuit-level simulations show that a rotation of 0 _._ 001 achieves a

logical error rate of 9 _._ 6 _×_ 10 _−_ ⁵ within 30 rounds of syndrome extraction on a _d_ = 7 surface code at _p_ phys = 10 _−_ ⁴ _._

Compared to synthesizing the same rotation from fault-tolerant primitives, this reduces the number of code

cycles by a factor of ten, and also evades the space overhead of magic state factories as well as the overhead

of distilling and routing, which is in sharp contrast to existing partial FTQC architectures [ 16 – 19 ]. We further

find in Sec. III B that resource estimates for Trotter-like circuits with _N_ = 108 logical qubits assuming a surface

code and a [[144, 12, 12]] bivariate bicycle code [ 29 ] show improvements by factors of 778 and 45, respectively,

in the runtime over a conventional Clifford+T architecture, enabled by the natural parallelism of rotation gates.

• **Short-depth state preparation (Sec.** **III C** **).** Looking ahead to regimes requiring much lower logical error

rates, we study shallow-depth state preparation, which underlies primitives in quantum learning, quantum

simulation, and phase estimation. By utilizing postselection, weak-transversal rotation gadgets prepare high-

level equatorial magic states with a markedly improved cost-accuracy tradeoff; for example, we find that a magic

state at the 11th level of the Clifford hierarchy can be prepared with up to a 10 ³ \-fold reduction in spacetime cost

3

on a _d_ = 11 surface code at _p_ phys = 10 _−_ ⁴ . We also introduce a beyond-state-of-the-art protocol for preparing

the phase gradient state, a catalytic resource for the phase estimation algorithm.

• **Magic state distillation (Sec.** **III D** **).** We next turn to ultra-high-precision regimes where magic state dis-

tillation is indispensable. Postselected weak transversal gates exhibit nonlinear error suppression, which can be

further enhanced by segmenting the target rotation angle at the cost of increased spacetime overhead. While

segmentation is expensive as a stand-alone state preparation method, it becomes advantageous within a distil-

lation pipeline, where initial noisy state injections are the bottleneck in terms of error but contribute only a

small fraction of the total spacetime cost. For the Meier–Eastin–Knill protocol [ 34 ], we numerically find that

integrating segmented weak transversal gates reduces the output logical error of the

_√_

_T_ state by a factor of 94

with only a modest increase in spacetime cost, which compounds even more when we perform multiple rounds

of distillation.

**II.**

**THEORY OF WEAK TRANSVERSAL OPERATION**

**A.**

**Preliminaries and setup**

A logical quantum operation ¯ _U_ is usually said to be _transversal_ if it can be implemented by applying the same

physical gate to each physical qubit in the code blocks. In the following, we introduce the notion of _strong_ and _weak_

transversality. The former coincides with the standard definition, while the latter differs in the sense that it admits

probabilistic implementation of a gate set, and hence the fault distance is usually lower than that of strong transversal

gates. For the sake of simplicity, we assume that operations are done within a single code block of an [[ _n, k, d_ ]] QECC,

while the notion can be straightforwardly extended to involve multiple code blocks. We first provide the definition of

a strong transversal gate on a single QECC patch. Note that we hereafter distinguish logical and physical operations

by the presence or absence of the bar above the symbols, e.g., ¯ _U_ and _U_ .

**Definition 1.** _(Strong transversality.)_

_Let_ ¯ _U_ _be a unitary that acts on one or more code blocks, each consisting of_

_n_ _physical qubits. A physical unitary_ _V_ _is called a strongly transversal implementation of_ ¯ _U_ _if_ _V_ =  _n_

_i_ =1 _v_ _i_ _,_ _where_ _v_ _i_

_acts only on the_ _i_ _\-th physical qubit(s) of the code block(s) involved._

One of the most prominent examples of strong transversal operations is the logical Pauli operators of qubit stabilizer

codes; they can all be implemented with single-qubit Pauli gates.

Other examples include the CNOT gate for

Calderbank-Shor-Steane (CSS) codes [ 35 ] and the T gate for triorthogonal codes [ 5 ]. In these cases, the physical

operation _V_ is a product of local unitaries; syndrome extraction and recovery operations are performed to correct

errors, but do not play a crucial role in the implementation of the logical gate. We contrast this with weak transversal

gates, in which the action of physical operations themselves is not closed within the individual symmetric space defined

by stabilizers. We further discuss this point after providing the definition:

**Definition 2.** _(Weak transversality.)_

_Let_ _E_ = _{_ ( _p_ _x_ _,_ ¯ _U_ _x_ ) _}_ _x_ _be an ensemble of probabilities_ _{_ _p_ _x_ _|_ 

_x_ _p_ _x_ = 1 _, p_ _x_ _>_ ⁰ _}_

_and unitaries_ _{_ ¯ _U_ _x_ _}_ _that act on logical qubits of a QECC patch consisting of_ _n_ _qubits. Assume that the following_

_conditions are satisfied by the physical operation_ _V_ _:_

_•_ _V_ _is a constant-depth sequence of physically available local operations on_ _n_ _qubits that implements_ ¯ _U_ _x_ _with_

_probability_ _p_ _x_ _._

_•_ _The outcome does not depend on the input logical state._

_Then,_ _V_ _is a weak transversal gate. Here we do not require the ability to choose from the set_ _{_ ¯ _U_ _x_ _}_ _; it can be a random_

_realization._

The notion of weak transversality is relevant to the projected ensembles, which are ensembles of pure quantum states

generated by projective measurements on a subspace of a Hilbert space (usually a subset of qubits for a multiqubit

system) [ 36 , 37 ]. Here we instead consider an ensemble of logical unitaries realized via a sequence of physical unitaries

followed by projective measurements and feedback operations (see Fig. 1 ). Note that it is crucial to require that

the ensemble of unitaries _E_ does not rely on an input state _ρ_ , as long as _ρ_ lives in the code space. Otherwise, we

must simulate the quantum circuit in order to deduce the implemented quantum operation, which quickly becomes

intractable when _n_ is large.

Due to the celebrated Eastin-Knill theorem [ 38 , 39 ], there is no QECC that admits a strong transversal implemen-

tation of universal gate sets, leading to the need to rely on gate teleportation [ 40 ] or code switching [ 41 – 43 ] to attain

universality. Meanwhile, the Eastin-Knill theorem does not rule out _weak_ transversal implementation. We therefore

4

aim to make a first attempt to derive general conditions for a QECC to admit weak transversal implementation of

Pauli rotation gates. It is useful to refer to the entire continuous gate set of _e_ _i_ ¯

_P θ_ as follows.

**Definition 3.** _(Weak transversal Pauli rotation gate.) Let_ ¯ _P_ _be a nontrivial logical Pauli operator on a single QECC_

_patch. If_ _V_ Φ _is a constant-depth sequence of physically available local operations with parameter set of_ Φ _such that,_

_for any_ _θ_ _there exists_ Φ _that implements_ _e_ _i_ ¯

_P θ_ _with nonzero probability, then_ _V_ Φ _is a weak transversal_ ¯ _P_ _rotation gate._

As we see in the remainder of this section, _V_ Φ consists of local unitaries, syndrome measurements, and a recovery

map. With a slight abuse of terminology, we also refer to the local unitaries as weak transversal Pauli rotation gates.

Our main theoretical result regarding the weak transversal Pauli rotation gate is Theorem 2 , which provides a

sufficient condition for arbitrary CSS codes. To prove this, we start in Sec. II B by assuming that (i) physical unitaries

are single-qubit operations, and (ii) we aim to implement single-qubit Z rotation. As detailed in Sec. II C , we prove

Theorem 2 by gradually lifting the conditions. Namely, we consider physical unitaries acting on multiple physical

qubits, and also aim to provide a method for weak transversal gates for general Pauli rotations. While we restrict our

discussion to CSS codes, we also briefly mention the applicability to non-CSS codes in Sec. II D .

**B.**

**Weak transversal Z rotation for odd distance**

Our first result is the sufficient condition to admit weak transversal Z rotation on a multiqubit code block, which

also applies to X and Y rotations. After stating the theorem, we provide a proof sketch, with its full derivation

deferred to Appendix A .

**Theorem 1.** _(Weak transversal Z rotation gate on odd-distance code) Let a logical QECC patch be an_ [[ _n, k, d_ _x_ _, d_ _z_ ]]

_CSS code. Assume that the following conditions are satisfied:_

_1\. The code distance for the logical Z operator,_ _d_ _z_ _, is odd._

_2\. The logical Z operator of interest,_ ¯ _Z_ target _, is weight_ _d_ _z_ _._

_Then,_ _U_ := 

_j_ _∈_ supp( ¯

_Z_ target ) _e_ _iθZ_ _j_ _is a weak transversal Z rotation gate._

_Proof sketch._ The core of the theorem is to prove (i) input agnosticity of the logical operation and (ii) the ability to

implement an arbitrary logical angle by tuning the physical angle. These properties ensure weak transversality and a

nontrivial logical operation, respectively. In the following, we outline the proof in order.

For input agnosticity, let Π 0 be the projector onto the code space and _{_ Π **_s_** _}_ **_s_** := _{_  _n_ _−_ _k_

_i_ =1

1+( _−_ 1) _si_ _g_ _i_

2

_}_ **_s_** the projectors

corresponding to a syndrome measurement result **_s_** , where _g_ _i_ is the _i_ \-th stabilizer generator. After applying _U_ =



_j_ _∈_ supp( ¯

_Z_ target ) _e_ _iθZ_ _j_ and measuring the syndrome, the Kraus operator associated with outcome **_s_** is _K_ **_s_** := Π **_s_** _U_ .

Then, it suffices to show that the outcome probability _p_ **_s_** (¯ _ρ_ ) = Tr[ _K_ **_s_** ¯ _ρK_ _†_

**_s_** ] is independent of the input logical state ¯ _ρ_ .

It is convenient to expand a given logical state in terms of logical Pauli operators as

¯ _ρ_ = Π **0**







¯

_Q_ _∈{_ ¯ _I,_ ¯

_X,_ ¯ _Y ,_ ¯

_Z_ _}_

_c_ ¯

_Q_ ¯ _Q_



 Π **0** = ¹

2 _k_ Π **0** \+



¯

_Q_ _∈{_ ¯ _I,_ ¯

_X,_ ¯ _Y ,_ ¯

_Z_ _}_ _⊗_ _k_ _\\_ ¯ _I_

_c_ ¯

_Q_ Π ⁰ ¯ _Q._

(1)

Then

_p_ **_s_** (¯ _ρ_ ) = ¹

2 _k_ Tr[Π **_s_** _U_ Π ⁰ _U_ _†_ ] +



¯

_Q_ _̸_ = ¯ _I_

_c_ ¯

_Q_ Tr[Π **_s_** _U_ Π ⁰ ¯ _QU_ _†_ ] _._

(2)

Since Π **_s_** and Π 0 are linear combinations of stabilizers, it suffices to show that

Tr[ _S_ 1 _US_ 2 ¯ _QU_ _†_ ] = 0

(3)

for all _S_ 1 _, S_ 2 _∈ S_ and all nontrivial logical Paulis ¯ _Q_ .

If ¯ _Q_ contains any logical _X_ component, then _S_ 1 _S_ 2 ¯ _Q_ has nonzero _X_ \-support. Since the conjugation of _S_ 2 ¯ _Q_ by _U_

can only append _Z_ ’s on the overlapping sites (it never removes _X_ support), the term remains traceless. Next, if ¯ _Q_ is

purely logical _Z_ , i.e., do not contain any X or Y component, conjugation by _U_ can only create additional _Z_ operators

supported on supp( ¯ _Z_ target ) _∩_ supp _X_ ( _S_ 2 ). Because _d_ _z_ is odd and _S_ 2 commutes with ¯ _Z_ target , this overlap is even and

strictly smaller than _d_ _z_ . Therefore it cannot cancel a nontrivial logical- _Z_ component, whose minimum weight is _d_ _z_

by assumption. Thus, Tr[ _S_ 1 _US_ 2 ¯ _QU_ _†_ ] = 0 in all cases, implying that _p_ **_s_** is input-agnostic.

5

In order to show the second part, namely the capability of implementing arbitrary logical angle, we identify ¯ _U_ **_s_** as

a ¯ _Z_ target \-rotation up to a Pauli recovery operation. We first expand the unitary as

_U_ =



_j_ _∈_ supp( ¯

_Z_ target )

(cos _θ I_ \+ _i_ sin _θ Z_ _j_ ) =



**_b_** _∈{_ 0 _,_ 1 _}_ _dz_

(cos _θ_ ) _d_ _z_ _−|_ **_b_** _|_ ( _i_ sin _θ_ ) _|_ **_b_** _|_



_j_ _∈_ supp( ¯

_Z_ target )

_Z_ _b_ _j_

_j_ _._

(4)

Each Z term determines a syndrome **_s_** , which is uniquely related to a minimum-weight _Z_ error _E_ **_s_** with supp( _E_ **_s_** ) _⊆_

supp( ¯ _Z_ target ) and _w_ := _|_ _E_ **_s_** _| ≤_ ( _d_ _z_ _−_ 1) _/_ 2\. Moreover, _E_ **_s_** and _E_ **_s_** ¯ _Z_ target have the same syndrome. Projecting onto the

_s_ \-syndrome subspace therefore yields, on the code space,

_K_ **_s_** _∝_ _E_ **_s_**



(cos _θ_ ) _d_ _z_ _−_ _w_ ( _i_ sin _θ_ ) _w_ ¯ _I_ \+ (cos _θ_ ) _w_ ( _i_ sin _θ_ ) _d_ _z_ _−_ _w_ ¯ _Z_ target



Π 0 = _√_ _p_ **_s_** _E_ **_s_** _e_ _i_ ¯ _θ_ _s_ ¯

_Z_ target Π 0 _,_

(5)

with

_p_ **_s_** =

 (cos _θ_ ) _d_ _z_ _−_ _w_ (sin _θ_ ) _w_  2 \+

 (sin _θ_ ) _d_ _z_ _−_ _w_ (cos _θ_ ) _w_  2 _,_

tan ¯ _θ_ _s_ = ( _−_ 1)

_dz_ _−_ 1

2

_−_ _w_ tan _d_ _z_ _−_ 2 _w_ _θ._

(6)

Because _d_ _z_ is odd, varying _θ_ makes ¯ _θ_ _s_ attain any target angle modulo a global phase, with _p_ **_s_** _>_ 0\.

**C.**

**General Pauli rotation**

While we have assumed only single-qubit unitary for each physical qubit in Theorem 2 , weak transversal operation

can be even more versatile if we allow multiqubit operations. Deferring the detailed proof to Appendix B , here we

state the Theorem and then provide a sketch of proof.

**Theorem 2.** _(Weak transversal implementation of general Pauli rotation gate)_

_Let_ _C_ _be an_ [[ _n, k, d_ ]] _CSS code,_

_and let_ _M_ _≤_ _d_ _be an odd integer. Then, for any logical Pauli operator_ ¯ _P_ _of the code_ _C_ _, there exists a set of Pauli_

_operators_ _{_ _P_ _m_ _}_ _M_

_m_ =1 ( _P_ _m_ _∈ {_ _I, X, Y, Z_ _}_ _⊗_ _n_ ) _such that a unitary_  _M_

_m_ =1 _e_ _iθP_ _m_ _followed by syndrome extraction yields_

_weak transversal implementation of_ ¯ _P_ _\-rotation gate._

_Proof sketch._ Similarly to Theorem 1 , we prove the theorem in two steps; first the input agnosticity, and second the

capability of implementing arbitrary logical angle.

For the first step, it is crucial to construct the actual unitary operation for the weak transversal gate. To accomplish

this, first recall that once we choose _U_ as a product of Pauli rotations, every operator appearing in the Pauli expansion

of _U_ is a _subproduct_ of the rotated Paulis. Consequently, when we evaluate expressions of the form Tr[ _S_ 1 _US_ 2 ¯ _QU_ _†_ ], the

only potentially dangerous terms are those subproducts that have a nonzero action on the code space. If some proper

subproduct acts as a logical Pauli operator (up to stabilizers), it can interfere with the logical degrees of freedom and

spoil the input-agnosticity. Thus, a natural sufficient condition for extending Eq. ( 3 ) is to demand that _no proper_

_subproduct survives on the code space_ .

Toward this goal, we introduce a notion called _disjoint support partition_ . For a given target logical operator ¯ _P_ , a

set of physical Pauli operators _{_ _P_ _m_ _}_ _M_

_m_ =1 is a disjoint support partition if (i) ¯ _P_ =  _M_

_m_ =1 _P_ _m_ , (ii) _M_ is an odd number,

and (iii) for any nonempty subset _R_ ⊊ [ _M_ ], it holds that Π 0

 

_m_ _∈_ _R_ _P_ _m_



Π 0 = 0 where Π 0 is a projection operator

onto the code space. As we detail in Appendix B , we have constructed an efficient algorithm to find such a partition

of _M_ _≤_ _d_ for arbitrary logical operators. Thanks to the property (iii), a unitary defined as

_U_ =

_M_



_m_ =1

_e_ _iθP_ _m_

(7)

can only multiply 

_m_ _∈_ _R_ ⊊ [ _M_ ] _P_ _m_ upon conjugating a stabilizer _S_ as _USU_ _†_ , and hence it holds that Tr[ _S_ ¹ _US_ ² ¯ _QU_ _†_ ] = 0

for any stabilizers _S_ 1 and _S_ 2 and logical Pauli operator ¯ _Q_ . This indicates that _U_ followed by the syndrome extraction

yields an input-agnostic logical operation, and hence _U_ is a weakly transversal gate in the sense of Definition 2 .

For the second step, we first find that any product of Pauli operators from subset of disjoint support partition

 _M_

_m_ =1 _P_ _b_ _m_

_m_

( _b_ _m_ _∈ {_ 0 _,_ 1 _}_ ) can be uniquely related to a Pauli correction operation _E_ **_s_** ( **_b_** ) where **_s_** ( **_b_** ) indicates the

syndrome invoked by the Pauli operator. Because _M_ is odd, every **_b_** has a unique complement **_b_** _c_ = **1** _⊕_ **_b_** with

_|_ **_b_** _c_ _|_ = _M_ _− |_ **_b_** _|_ . Using (i), we have  _M_

_m_ =1 _P_ _b_ _m_

_m_ _P_ _b_ _c_

_m_

_m_ = ¯ _P_ target and _E_ **_s_** ( **_b_** ) = _E_ **_s_** ( **_b_** _c_ ) up to global phase, thus

Π 0 _E_ **_s_** ( **_b_** ) _E_ **_s_** ( **_b_** ) Π 0 = Π 0 _E_ **_s_** ( **_b_** ) _E_ **_s_** ( **_b_** _c_ ) Π 0 = Π 0 _._

(8)

6

Next, for any pair of **_b_** and **_b_** _′_ satisfying **_s_** ( **_b_** ) _̸_ = **_s_** ( **_b_** _′_ ), their symmetric difference corresponds to a nonempty proper

subset _R_ ⊊ [ _M_ ], hence using (iii) we have

Π 0 _E_ **_s_** ( **_b_** ) _E_ **_s_** ( **_b_** _′_ ) Π 0 = 0 _,_

(9)

Combining Eqs.

( 8 ) and ( 9 ), the set _{_ _E_ **_s_** ( **_b_** ) _}_ **_b_** satisfies a Knill–Laflamme-type orthogonality on the code space.

Therefore stabilizer syndrome measurement can discriminate errors _E_ **_s_** , which in principle does not discriminate the

terms 

_m_ _P_ _b_ _m_

_m_

and its complement 

_m_ _P_ _b_ _c_

_m_

_m_ = ¯ _P_ target _·_ 

_m_ _P_ _b_ _m_

_m_ .

The above argument shows that, for a given syndrome **_s_** , only the Pauli operators  _M_

_m_ =1 _P_ _b_ _m_

_m_

corresponding to

bitstrings **_b_** with **_s_** = **_s_** ( **_b_** ) _,_ _|_ **_b_** _| ≤_ ( _M_ _−_ 1) _/_ 2 and its complement contribute to the logical operation. Concretely, the

Kraus operator can be written using _w_ := _|_ **_b_** _|_ as

_K_ **_s_** _∝_ _E_ **_s_**



(cos _θ_ ) _M_ _−_ _w_ ( _i_ sin _θ_ ) _w_ ¯ _I_ \+ (cos _θ_ ) _w_ ( _i_ sin _θ_ ) _M_ _−_ _w_ ¯ _P_ target



= _√_ _p_ **_s_** _E_ **_s_** _e_ _i_ ¯ _θ_ **_s_** ¯

_P_ target _,_

(10)

with

_p_ **_s_** =

 (cos _θ_ ) _M_ _−_ _w_ (sin _θ_ ) _w_  2 \+

 (sin _θ_ ) _M_ _−_ _w_ (cos _θ_ ) _w_  2 _,_

tan ¯ _θ_ **_s_** = ( _−_ 1)

_M_ _−_ 1

2

_−_ _w_ tan _M_ _−_ 2 _w_ _θ._

(11)

Since _M_ is odd, varying _θ_ makes ¯ _θ_ **_s_** attain any target angle modulo a global phase with _p_ **_s_** _>_ 0\. Combining first and

second steps proves that the circuit yields a weak transversal implementation of the ¯ _P_ target \-rotation gate.

**D.**

**General Pauli rotation in non-CSS codes**

In Section II C , we have proved for CSS codes that logical Pauli rotation gates can be implemented probabilistically

under some condition. We cannot straightforwardly extend our results to non-CSS code since we have exploited the

CSS property to construct disjoint support partition of logical operators; we leave it as an interesting future problem

to investigate general non-CSS codes.

For future reference, here we report numerical results for small instances of non-CSS codes that are taken from

Ref. [ 44 ]. As shown in Fig. 2 , we have confirmed that all non-CSS codes with _d_ _≥_ 3 within our numerics admit weak

transversal implementation of arbitrary Pauli rotation _e_ _iθ_ ¯

_P_ where ¯ _P_ _∈ {_ ¯ _I,_ ¯ _X,_ ¯ _Y ,_ ¯ _Z_ _}_ _⊗_ _k_ using physical unitary with

_M_ = 3 partitions. Due to the current implementation for the calculation, we are limited to small number of logical

qubits as _k_ _≤_ 5, and also number of physical qubits as _n_ _≤_ 17\.

: # Physical qubits

_n_

: # Logical qubits

_k_

Code distance

FIG. 2. Numerical verification of weak transversal gates in non-CSS codes. The stabilizers are all taken from Ref. [ 44 ]. The

color of the cells (and the inset integers) indicate the code distance. For all the non-CSS codes shown in this figure, weak

transversal implementation of arbitrary Pauli rotation _e_ _iθ_ ¯

_P_ ( ¯ _P_ _∈ {_ ¯ _I,_ ¯

_X,_ ¯ _Y ,_ ¯ _Z_ _}_ _⊗_ _k_ ) with _M_ _≤_ _d_ is found. The missing cells are

either CSS codes or invalid code parameters without logical operator.

7

**III.**

**APPLICATIONS OF WEAK TRANSVERSAL GATES**

We now demonstrate that weak transversal gates have versatile applications ranging from early- to long-term

FTQC. We first target the early-FTQC regime, where reducing the resource bottleneck of large Clifford+T circuits

is more urgent than realizing an extremely low-error universal instruction set. After introducing the repeat-until-

success protocol to implement in-place Pauli rotation gate in Sec. III A , we incorporate it into a factory-free, partially

fault-tolerant architecture in Sec. III B and benchmark it against Clifford+T compilation with magic-state factories

for a Trotter-like circuit.

The remaining subsections address higher-precision regimes in which state preparation

becomes a central primitive. In Sec. III C , we study short-depth preparation of high-level equatorial magic states

and, in particular, the phase-gradient state, which is a catalytic resource for quantum Fourier transforms and phase-

estimation routines.

We show that weak transversal gates with postselection improve the cost-accuracy tradeoff

relative to state-of-the-art teleportation- or synthesis-based baselines. In Sec. III D , we further show that segmented

weak transversal rotations can substantially improve the output accuracy of magic state distillation with only a modest

increase in circuit volume.

**A.**

**Repeat-until-success protocol for in-place, addressable Pauli rotation gate**

Here, we aim to utilize weak transversal gates for non-fault-tolerant implementation of Pauli rotation gates. Since

the logical angles are realized randomly according to the syndrome measurement result, we consider a repeat-until-

success strategy; at each step, we choose physical angles _θ_ so that ¯ _θ_ is realized under some given syndrome **_s_** . If we

obtain the desired syndrome, we terminate the iteration. If not, we again implement local unitaries, with updated

physical angles so that the undesired logical angle is compensated. See Fig. 3 (a) for a graphical description.

Notable features of the current schemes are as follows.

• _In-place implementation._

All the operations are closed within the logical patches and, importantly, do not

require magic state factories. This implies that we can parallelize the non-Clifford gates, which are usually

bottlenecked by the limited number of magic state factories.

• _Addressability._ The physical unitary is applied only to the chosen support of the target logical Pauli operator

and is then followed by ordinary syndrome extraction. Therefore, even when a logical patch contains many

physical qubits, the protocol can address a selected logical Pauli rotation without driving the entire patch by a

strong transversal pattern.

• _Generality._ As discussed in Sec. II , the in-place Pauli rotation can be applied to a broad class of quantum error

correcting codes. This includes many families of codes such as surface codes, color codes, and qLDPC codes

that are considered to be leading candidates for fault-tolerant quantum computers.

• _On-the-fly protocol._ If the physical angles are homogeneously taken as _θ_ , then there is an analytical expression

for one-to-one correspondence between the physical angle _θ_ and the logical angle ¯ _θ,_ as summarized in Lemma 1 .

This is extremely helpful for the electronics, since we can calculate physical angles on-the-fly.

Since the physical angles are updated according to the syndromes, the proposed scheme is non-fault-tolerant.

However, as we demonstrate in Sec. III B , in-place Pauli rotations are effective in the megaquop regime, i.e., where

circuits require millions of gates under Clifford+T architecture, for two reasons. First, in such a regime, the logical

error rate is moderate so that the overhead of some fault-tolerant instructions may exceed that of non-fault-tolerant

ones.

Second, the number of magic state factories are limited and hence parallelization by in-place, addressable

operation plays a significant role.

It is useful to introduce a convenient formula connecting the syndrome measurement result and the realized logical

angle. While we defer the proof to Appendix B , we state the result here.

**Lemma 1.** _Let_ _C_ _be an_ [[ _n, k, d_ ]] _CSS code, and let_ _M_ _≤_ _d_ _be an odd integer. Let the following be a unitary that is_

_constructed to be a disjoint support partition of_ ¯ _P_ target _,_

_U_ =

_M_



_m_ =1

_e_ _iθX_ **_A_** _m_ _Z_ **_B_** _m_ _._

_Then, the logical operation of the unitary followed by the syndrome measurement_ _M_ _and recovery map_ _C_ _is given as_

_C ◦ M ◦ U_ (¯ _ρ_ ) =

_M_ _−_ 1

2



_χ_ =0

_p_ _χ_ ¯ _R_ ¯ _θ_ _χ_ (¯ _ρ_ ) _,_

8

rotations

_M_ = 3

effective error

Target angle ¯ _θ_

Target angle ¯ _θ_

Desired **_s_** ?

Yes

Terminate

No

Unitary

Meas

Recovery

(b)

(a)

Update _θ_

rotations

_M_ = 5

FIG. 3. Repeat-until-success implementation of in-place Pauli rotations. (a) Schematic of the protocol. Physical Pauli rotations

are applied on the support of the target logical Pauli operator, syndrome extraction identifies the realized logical branch, and

the physical angle for the next attempt is updated unless the target angle has already been reached. (b) Numerical evaluation

of the effective error induced by the protocol when _M_ = 3 and _M_ = 5 physical rotation gates are used, with _p_ phys = 10 _−_ ⁴ .

We show ordinary RUS and diluted RUS data for the code-capacity simulation (CC) and for circuit-level simulations based

on repetition and rotated surface codes. The insets show the history of first-success and cumulative-success probabilities at

¯ _θ_ = 10 _−_ ² . The dotted surface curve in the _M_ = 5 panel is an estimate obtained by multiplying the data of _d_ = _M_ = 5 repetition

code simulation data following the error rate ratio between _d_ = _M_ = 3 repetition and surface codes. The faint and thick shaded

band indicates the memory error of _d_ = 3 and 5 surface codes under accumulation over maximal count of iterations.

_where_ ¯ _R_ ¯ _θ_ ( _·_ ) := _e_ _i_ ¯ _θ_ ¯

_P_ ( _·_ ) _e_ _−_ _i_ ¯ _θ_ ¯

_P_ _is a logical rotation channel and_ _χ_ _is the weight of correction operation_ _C_ **_s_** _given a_

_syndrome_ **_s_** _. The probabilities and angles are given as_

_p_ _χ_ =



_M_

_χ_

 

_|_ cos _M_ _−_ _χ_ _θ_ sin _χ_ _θ_ _|_ ² \+ _|_ cos _χ_ _θ_ sin _M_ _−_ _χ_ _θ_ _|_ ² 

_,_

(12)

¯ _θ_ _χ_ = arctan



( _−_ 1)

_M_ _−_ 1

2

_−_ _χ_ tan _M_ _−_ 2 _χ_ _θ_



_._

(13)

Now we are ready to describe the repeat-until-success strategy. Assume that one aims to implement _e_ _i_ ¯ _θ_ target ¯

_P_ target _,_

and one has performed its weak transversal implementation that resulted in logical angle of ¯ _θ._ If ¯ _θ_ = ¯ _θ_ target , then one

has succeeded in the implementation, so one can simply proceed to the next gate. If not, one must compensate for

the deviation in the next step; compute the physical angle _θ_ using Lemma 1 so that ¯ _θ_ target _−_ ¯ _θ_ is realized in the next

step with as high a probability as possible. More concretely, the steps can be summarized as follows.

0\. Initialize the cumulative logical angle as ¯ _φ_ ( _l_ =0) = 0 _,_ where _l_ denotes the count of iteration.

1\. Set the target logical angle as ¯ _θ_ target _−_ ¯ _φ_ ( _l_ _−_ 1) _,_ and calculate the physical angle for the _l_ \-th step, _θ_ ( _l_ ) , from

Eq. ( 13 ), such that the target rotation’s probability is maximized.

2\. For each **_s_** ( _l_ ) , compute the realized angle ¯ _θ_ **_s_** ( _l_ ) . If ¯ _φ_ ( _l_ ) := ¯ _φ_ ( _l_ _−_ 1) \+ ¯ _θ_ ( _l_ )

**_s_** ( _l_ ) satisfies ¯ _φ_ ( _l_ ) = ¯ _θ_ target , then terminate the

iteration. Otherwise, record the syndrome **_s_** ( _l_ ) and the cumulative logical angle ¯ _φ_ ( _l_ ) for each syndrome.

3\. If terminated, compute the accumulation of Pauli operation during the protocol, and either apply the correction

or record as Pauli frame to keep the state in the code space. If not terminated, update the iteration count as

_l_ _←_ _l_ \+ 1, and return to Step 1.

If there is no hardware error, the RUS strategy systematically improves the precision as the number of attempts

increases, in analogy with RUS protocols based on gate teleportation [ 45 , 46 ]. The relevant question is therefore how

much error is induced by syndrome-extraction faults during the protocol. We first study this for _M_ = 3 case using

the code-capacity noise model where the syndrome extraction measurement result is flipped by _p_ phys = 10 _−_ ⁴ . For

a target angle ¯ _θ_ = 10 _−_ ² , about 90% of branches terminate in the first round, more than 99% terminate within 10

rounds, and more than 99 _._ 9% terminate within 20 rounds. At this truncation depth, the induced logical operation

has diamond distance below 10 _−_ ⁴ from the target rotation.

9

We then compare this code-capacity estimate with circuit-level simulations using a _d_ = 3 bitflip code and a _d_ = 3

rotated surface code, as shown in Fig. 3 (b). At ¯ _θ_ = 10 _−_ ² , the circuit-level estimates are larger than the code-capacity

value by roughly factors of two and four, respectively. The dominant mechanism is syndrome misclassification caused

by faults in the extraction circuit: a single fault can change the inferred value of _χ_ in Eq. ( 13 ), and hence select the

wrong compensation angle in the next RUS attempt. Especially for small angles ¯ _θ_ _≪_ 1, the no-syndrome branch is

misclassified into finite syndrome with probability _p_ phys _M_ , and results in unnecessary ¯ _θ_ correction by further RUS.

Although this simple argument may lead to scaling of _O_ ( _p_ phys _M_ ¯ _θ_ ), the additional error during the preceding RUS

protocol seems to yield sublinear scaling with ¯ _θ_ in the plotted region. Details of the numerical implementation and

decoder choices are also given in Appendix D .

One way to improve the logical error rate is to use mixed synthesis [ 47 – 49 ].

Mixed synthesis probabilistically

combines implementable unitary channels whose coherent mismatch from the desired target cancels to higher order.

In the present setting, we mix a noisy RUS implementation at a larger angle with an almost noiseless identity channel

to synthesize a smaller target angle. Because the weight of the larger-angle channel is proportional to the desired

target angle, the stochastic contribution from RUS faults is also suppressed linearly in ¯ _θ_ . The residual mismatch

caused by mixing channels with different angles is much smaller than this stochastic contribution in the parameter

regime considered here, so the diluted RUS protocol achieves the scaling _O_ ( _p_ phys ¯ _θ_ ); see Appendix C . For ¯ _θ_ = 10 _−_ ³ ,

the _M_ = 3 data give ordinary-RUS effective errors of 1 _._ 2 _×_ 10 _−_ ⁴ , 1 _._ 2 _×_ 10 _−_ ⁴ , and 1 _._ 3 _×_ 10 _−_ ⁴ for the code-capacity

simulation and circuit-level simulations of repetition and surface codes, respectively.

After dilution, these values

become 1 _._ 8 _×_ 10 _−_ ⁵ , 2 _._ 8 _×_ 10 _−_ ⁵ , and 6 _._ 0 _×_ 10 _−_ ⁵ . Note that this is comparable with memory error of _d_ = 3 surface code

( _∼_ 5 _×_ 10 _−_ ⁵ ), while that for _d_ = 5 ( _∼_ 5 _×_ 10 _−_ ⁷ ) is significantly lower. Repeating the diluted comparison for _M_ = 5

gives 3 _._ 3 _×_ 10 _−_ ⁵ , 4 _._ 5 _×_ 10 _−_ ⁵ , and 9 _._ 6 _×_ 10 _−_ ⁵ , where the last value is estimated from the ratio between repetition and

surface codes in _M_ = 3.

It is natural to expect that the error in RUS protocol is governed by the number of physical rotations _M_ , rather

than the code distance alone. Namely, the protocol is limited by faults that corrupt the syndrome information used to

identify the realized branch, rather than by the memory distance of the underlying code. As explained in Appendix E ,

the CNOT schedule of syndrome extraction can be intentionally modified so that inserting a single-qubit Pauli rotation

in the middle of the extraction circuit realizes an effective multiqubit rotation, which makes it possible to use the

same value of _M_ even in larger-distance surface-code patches. The modified schedule intentionally lowers the fault

distance for memory errors and therefore allows memory errors to accumulate more easily, but for the rotation angles

considered in Fig. 3 (b), the RUS-induced error is still the dominant contribution. In the remainder of this work, we

use the estimated error for further numerical evaluation.

(b)

 ...

 ...

 ...

 ...

 ...

system

ancilla

(d)

system

adapter

LPU

 ...

(c)

factory

adapter’

(e)

system

LPU

 ...

(a)

 ...

 ...

 ...

 ...

 ...

 ...

factory

 ...

 ...

 ...

 ...

 ...

 ...

 ...

 ...

 ...

 ...

 ...

FIG. 4. (a) Benchmarked quantum circuit of _N_ = 108 logical qubits. In each unit of gates, qubits individually undergo a _Z_

rotation with angle 0 _._ 001 followed by two layers of CNOT gates on even and odd edges. Such a unit is repeated 100 times. For

architectures, we consider (b) surface code using Clifford+T compilation with 1 to 64 magic-state factories, (c) surface code

using in-place Pauli rotation, (d) [[144,12,12]] bivariate bicycle code (known as gross code) using Clifford+T compilation, and

(e) gross code using in-place Pauli rotation. The code distance for the surface code is _d_ = 7, and that for magic state factories

is _d_ = 7 for both surface and gross codes.

10

(a)

(b)

x1/805

x1/53

x1/45

x1/778

FIG. 5. Resource estimation of (a) timesteps and active physical qubits and (b) the circuit volume for the circuit shown in

Fig. 4 (a). Compared to the Clifford+T architecture with a single magic state factory, the timesteps are reduced by factors

of 780 and 45 for surface ( _d_ = 7) and gross code, respectively, and the circuit volume is reduced by factors of 805 and 53.

The faint circles indicate optimistic Clifford+T estimates with 2, 4, 8, 16, 32, and 64 magic-state factories, assuming that

the runtime of synthesis can be reduced linearly with the number of factories. The data points for Clifford+ _ϕ_ architecture in

gross code indicate that we use 10, 20, 30, and 40 modules, which enables distributed allocation of system qubits and hence

more parallelized execution of CNOT gates. For both codes, the number of physical rotations for the weak transversal gates is

_M_ = 5, and the physical error rate is assumed to be _p_ phys = 10 _−_ ⁴ .

**B.**

**Megaquop regime: partially fault-tolerant architecture**

Early fault-tolerant quantum computers are unlikely to support the full overhead of high-throughput magic-state

factories and long Clifford+T synthesis pipelines.

Therefore, partially fault-tolerant architectures offer a natural

route toward early practical quantum advantage by combining reliable Clifford operations with carefully controlled

non-fault-tolerant primitives. Here we consider Trotterized quantum dynamics as a benchmark, because (i) quantum

dynamics is considered as the primary candidate for practical quantum advantage [ 50 – 52 ], and (ii) it contains many

small-angle Pauli rotations and hence directly exposes the resource bottleneck that in-place weak-transversal rotations

are designed to remove. The performance of each architecture is quantified by the following figures of merit:

• _Timesteps_ _τ_ _._ Assuming that every physical operation takes the same amount of time, we call one such unit a

timestep [ 53 ]. The total number of timesteps _τ_ estimates the wall-clock time of circuit execution. Physical _R_ Z

gates are implemented as virtual gates and hence are assumed to take no timestep [ 54 ].

• _Active Physical Qubits_ _N_ phys _._ If a qubit is idling during the entire execution of the circuit, we regard such a

qubit to be not active. Otherwise, the qubit is active. We count the number of active physical qubits _N_ phys to

quantify the spatial cost of the circuit.

• _Circuit volume_ _V_ _._ The circuit volume is defined as _V_ := _τ_ _·_ _N_ phys .

• _Total logical error rate_ ¯ _p_ tot _._ When the logical error rate of the _i_ \-th operation is ¯ _p_ _i_ , we estimate the total logical

error rate by the first-order sum ¯ _p_ tot := 

_i_ ¯ _p_ _i_ _._

We evaluate these quantities for the four architectures shown in Fig. 4 . Throughout the estimates, we assume

superconducting physical qubits and take the physical error rate of each operation to be _p_ phys = 10 _−_ ⁴ . Each Pauli

rotation has angle 0 _._ 001 and is assumed to be implemented using _M_ = 5 physical rotations with a logical error rate of

9 _._ 6 _×_ 10 _−_ ⁵ , following the numerical results from the previous subsection. We choose parameters for circuit synthesis

and distillation protocols so that the total error rate satisfies ¯ _p_ tot _∼_ 1, reflecting that error mitigation techniques

11

remain available on top of error correction [ 55 – 57 ].

The detailed formulas are deferred to Appendix F ; here we

summarize the architectural differences.

**Surface code, Clifford+T.** (Fig. 4 (b)) Clifford gates are implemented using standard surface-code operations:

CNOT by lattice surgery [ 58 ], Hadamard by a transversal Hadamard followed by logical patch rotation [ 59 , 60 ],

and S by lattice surgery [ 60 ]. Non-Clifford rotations are synthesized into Clifford+T circuits, and each T gate

is implemented by magic-state teleportation. We assume one level of magic-state distillation [ 61 ].

**Surface code, Clifford+** _ϕ_ **.** (Fig. 4 (c)) Clifford gates are implemented as above, while logical ¯ _R_ Z gates are

executed directly as in-place Pauli rotations. Each in-place rotation uses the _M_ = 5 gadget composed of two

_R_ ZZ gates and three _R_ Z gates. Since each rotated surface-code patch encodes a single logical qubit, these logical

_Z_ rotations can be applied in parallel over all patches.

**Gross code, Pauli-based computation.** (Fig. 4 (d)) We compile the Clifford+T circuit into Pauli-based

computation, where Clifford operations are absorbed by propagating Pauli operators through the Clifford cir-

cuit [ 53 , 60 , 62 ]. The resulting instructions are scheduled using the bicycle-code ISA, consisting of idle operations,

shift automorphisms, and in-module/inter-module Pauli measurements. Each non-Clifford operation appears

as a T-type Pauli rotation _e_ _−_ _iπP/_ ⁸ , equivalently _R_ _P_ ( _π/_ 4) up to phase convention, for a possibly multi-body

Pauli operator _P_ , and is implemented by T-state injection consuming one magic state. We assume one level

of distillation in a distance-7 surface-code magic-state factory, connected to the gross-code module through an

adapter.

**Gross code, Clifford+** _ϕ_ **.** (Fig. 4 (e)) Logical ¯ _R_ Z gates are executed directly as in-place weak-transversal Pauli

rotations using three _R_ ZZ gates and two _R_ ZZZ gates. CNOT gates are implemented by measurement-based

Clifford operations. For in-module CNOTs, Pauli-product measurements are mediated by a pivot logical qubit;

for CNOTs between different modules, the same measurement-based pattern is realized using inter-module Pauli

measurements through the gross-code adapters.

The resulting resource estimates, for the circuit shown in Fig. 4 (a), are shown in Fig. 5 and Table I . We find that

a drastic resource reduction is achieved in both surface and gross codes. By replacing synthesized rotations with

in-place rotations, the total timestep _τ_ is reduced by a factor of 778 for the surface code and by a factor of 45 for the

gross code.

For the surface code, the dominant bottleneck of Clifford+T execution is the limited supply of magic states for

synthesized rotation gates. The Clifford+ _ϕ_ architecture resolves such a limitation, and hence reduces the number

of timesteps by a factor of 778. We also estimate an optimistic multi factory model in which the contribution of

unitary synthesis for Pauli rotation decreases linearly with the number of magic-state factories. Even under this

assumption, the additional factory footprint keeps the Clifford+T estimates far above the Clifford+ _ϕ_ architecture in

circuit volume.

For the gross code, the runtime improvement from single-factory architecture to factory-free architecture is factor of

45, which is less pronounced because the CNOT layers are comparatively expensive. This overhead originates from the

fact that logical operators are not completely disjoint within one gross-code module and that in-module CNOTs are

mediated by pivot logical qubits. Consequently, not all in-place rotations or pivot-mediated CNOTs can be performed

simultaneously, and we schedule only mutually compatible groups in parallel. We find that such an overhead can be

reduced by distributing the _N_ = 108 system qubits over larger number of gross-code modules. In Table I , the 10-, 20-,

30-, and 40-module Clifford+ _ϕ_ estimates restrict the maximum number of system logical qubits per module to 11, 6,

4, and 3, respectively, which increases the parallelism of the CNOT layers. Since the standard gross-code Clifford+T

estimate is based on Pauli-based computation, we only report the single-factory estimate; increasing the number of

factories does not translate into the same simple parallelization model as in the surface-code Clifford+T estimate.

Further improvements may be possible by using additional pivot qubits or more optimized schedules. We leave such

an investigation as a future work.

**C.**

**Gigaquop regime: short-depth state preparation circuits**

Short-depth state preparation is a heavily used subroutine in high-accuracy quantum algorithms. Representative

examples include GHZ/cat-like entangled states for quantum-enhanced learning [ 63 – 65 ], tensor-network states for

many-body simulation [ 66 – 68 ], and phase-gradient states used for coherent phase rotations in quantum arithmetic

and phase estimation [ 69 ]. Here we use phase-gradient-state preparation as a benchmark, because it is built from a

sequence of small-angle non-Clifford rotations, possibly interleaved with Clifford operations.

12

Architecture

Code

\# module # factory Timestep _τ_ Active physical qubits _N_ phys Total error rate ¯ _p_ tot

Clifford+T

Surface

108

1

124 _,_ 216 _,_ 320

24 _,_ 624

1 _._ 12191

Clifford+T

108

2

62 _,_ 124 _,_ 960

25 _,_ 434

1 _._ 12191

Clifford+T

108

4

31 _,_ 079 _,_ 280

27 _,_ 054

1 _._ 12191

Clifford+T

108

8

15 _,_ 556 _,_ 440

30 _,_ 294

1 _._ 12191

Clifford+T

108

16

7 _,_ 795 _,_ 020

36 _,_ 774

1 _._ 12191

Clifford+T

108

32

3 _,_ 914 _,_ 310

49 _,_ 734

1 _._ 12191

Clifford+T

108

64

1 _,_ 973 _,_ 955

75 _,_ 654

1 _._ 12191

Clifford+T

Gross

10

1

194 _,_ 998 _,_ 776

4 _,_ 801

0 _._ 83833

Clifford+ _ϕ_

Surface

108

0

159 _,_ 600

23 _,_ 814

1 _._ 03742

Clifford+ _ϕ_

Gross

10

0

4 _,_ 426 _,_ 800

3 _,_ 991

1 _._ 03714

Clifford+ _ϕ_

20

0

1 _,_ 531 _,_ 200

7 _,_ 991

1 _._ 03707

Clifford+ _ϕ_

30

0

1 _,_ 070 _,_ 400

11 _,_ 991

1 _._ 03713

Clifford+ _ϕ_

40

0

746 _,_ 400

15 _,_ 991

1 _._ 03713

TABLE I.

Total resource estimates for the benchmark circuit of Fig. 4 (a), with _N_ = 108 logical qubits, 100 circuit layers,

¯ _θ_ = 0 _._ 001, and _p_ phys = 10 _−_ ⁴ . For surface-code Clifford+T compilation, the table sweeps 1 _,_ 2 _,_ 4 _,_ 8 _,_ 16 _,_ 32 _,_ 64 distance-7 magic-

state factories at synthesis precision _ε_ syn = 10 _−_ ⁴ , assuming that the rotation-synthesis contribution to the timestep is parallelized

by the number of factories while the first-order logical error is set by the same gate count. For gross-code Clifford+T compilation,

we only report the single-factory estimate, since increasing the number of factories does not directly translate into the same

simple parallelization model. The gross-code Clifford+T row uses _⌈_ _N/_ 11 _⌉_ = 10 gross modules plus one factory, because one

logical slot per module is reserved as a pivot/mediator slot in this comparison. The 10-module gross-code Clifford+ _ϕ_ row

uses the same number of gross modules without a factory. For gross-code Clifford+ _ϕ_ compilation, the listed variants use the

locked-pivot estimates for the indicated number of gross modules. The total error rate is the first-order sum ¯ _p_ tot = 

_i_ ¯ _p_ _i_ .

We compare two conceptually different routes to small-angle rotations: teleportation-based and weak transversal

methods. Teleportation-based methods first prepare an equatorial magic state, either by angle-agnostic injection [ 70 ],

angle-agnostic injection followed by MEK distillation [ 34 , 46 ], or angle-dependent injection [ 16 , 19 ], and then consume

it through a teleportation gadget. These methods inherit a fallback recursion: an unfavorable measurement outcome

at level _l_ requires a corrective rotation at level _l_ _−_ 1, so the total gate error can be dominated by lower hierarchy levels,

as in partial FTQC architectures. Weak transversal gates take a more direct route. Syndrome-detected attempts can

simply be discarded, so postselection removes the fallback recursion and preserves the superlinear small-angle error

scaling of the weak transversal gadget. This scaling can be further improved by segmenting the target rotation into

smaller angles, at the cost of additional attempts.

In the following, for the sake of comparison with prior work, we assume that logical qubits are encoded in rotated

surface code. We measure spacetime cost in what we refer to as _logical qubitcycles_ , denoted by _V_ _L_ . When a logical

patch has fixed size, _V_ _L_ is simply the sum of active logical-patch code cycles. When the size of logical patches changes

during a protocol, on the other hand, we convert the physical qubitcycles _V_ as _V_ _L_ = _V/_ (2 _d_ ² ), where _d_ is the final

code distance.

To isolate the basic mechanism, we first consider a single Pauli rotation gate _R_ Z ( _π/_ 2 _l_ ) with _l_ _≥_ 3\.

Table II

summarizes the asymptotic scaling of the relevant small-angle subroutines (see Appendix G for details), which is

numerically demonstrated in Fig. 6 for _p_ phys = 10 _−_ ⁴ on a _d_ = 11 rotated surface code. Indeed, the angle-agnostic

teleportation approach (MEK) is competitive for the lowest levels of the Clifford hierarchy, while weak transversal

gates become increasingly favorable for smaller angles. For _l_ = 10, a weak transversal gate with _r_ = 10 segments

Method

Logical Error Rate

Logical qubitcycle _V_ _L_

Teleport, Li [ 70 ]

_O_ ( _p_ )

_O_ ( _d_ )

Teleport, Li+MEK [ 34 , 46 ]

_O_ ( _p_ ² )

_O_ ( _dl_ )

Teleport, transversal injection [ 16 , 19 ]

_O_ ( _p_ 2 _−_ _l_ )

14 _d_ \+ _O_ ( _d_ ² 2 _−_ ² _l/d_ )

Weak transversal gate

(general, with postselection)

_O_ ( _p_ 2 _−_ ² _l_ (1 _−_ ¹ _/M_ ) _r_ ² _/M_ _−_ ¹ ) _rd_ \+ _O_ ( _dMr_ ² _−_ ² _/M_ 2 _−_ ² _l/M_ )

TABLE II. Asymptotic scaling of logical error rate and logical qubitcycle for small-angle gadget of _l_ ( _≫_ 1)-th level of Clifford

hierarchy. We assume that logical qubit is of distance _d_ . The weak transversal row assumes _r_ segments and postselection.

13

reaches an error rate comparable to MEK-distilled teleportation with roughly a 10 ² \-fold smaller logical qubitcycle

cost. For _l_ = 11, the weak transversal gate with _r_ = 1 reaches a similar error scale with approximately a 10 ³ \-fold

smaller cost. In this small-angle regime, the postselection failure probability is only a few percent, so the cost is close

to the baseline value _rd_ .

Logical error rate

Logical qubit cycle / _P_ success

Cli ff ord hierarchy level

Cli ff ord hierarchy level

(a)

(b)

FIG. 6.

Resource estimates for implementing _R_ Z ( _π/_ 2 _k_ ) on a distance-11 rotated surface code with _p_ phys = 10 _−_ ⁴ . Panel (a)

compares logical error rates, and panel (b) compares logical qubitcycles per successful preparation. For the weak transversal

gate, we assume _M_ = 3 physical rotations.

The single-rotation benchmark is useful, but many state-preparation tasks require a collection of small rotations

rather than one isolated gate. We therefore next apply the same comparison to circuits of the form

_K_



_k_ =1

_R_ Z ( _θ_ _k_ ) _|_ _G_ _⟩_ _,_

(14)

where _|_ _G_ _⟩_ is a _K_ \-qubit graph state.

This form includes Trotterized Hamiltonian simulation circuits [ 71 ], partial

execution of instantaneous quantum polynomial circuits [ 72 ], and phase-gradient state preparation. We focus on the

_K_ \-qubit phase-gradient state [ 69 , 73 ],

_|_ PG _K_ _⟩_ :=

 _K_



_k_ =1

_R_ Z

 _π_

2 _k_

 

_|_ \+ _⟩_ _⊗_ _K_ _,_

(15)

which can catalyze phase rotations and reduce the _T_ count of quantum Fourier transforms from _O_ ( _n_ ² log 1 _/ϵ_ ) to

_O_ ( _n_ ² ).

This formulation makes the phase-gradient state a direct test of whether small-angle components should be prepared,

neglected, or handled by weak transversal gates. We compare protocols that either prepare the required equatorial

magic states by MEK distillation, discard high-level components, or use a hybrid strategy. In the hybrid strategy,

MEK distillation is used up to level _K_ _′_ , while the remaining smaller rotations are prepared using segmented weak

transversal gates with postselection.

Figure 7 shows the resulting tradeoff for _K_ = 15. The data show that increasing the number of weak-transversal

segments is not uniformly optimal. For larger angles, segmentation can be costly because the lower success probability

increases the expected volume; for smaller angles, the same mechanism gives a favorable error-volume tradeoff. The

hybrid protocol also improves over the simple strategy of neglecting the highest-level phase-gradient components [ 69 ]:

weak transversal gates make those small-angle components inexpensive enough to include, improving accuracy without

the full cost of MEK distillation.

14

Logical error rate

 _|_ \+ _→_

 _R_ Z ( _ω_ _/_ 2)

 _|_ \+ _→_

 ...

 _|_ _M_ 1 _→_

 ...

 _|_ _M_ 15 _→_

 ...

Mlv+gY8Z3qZNEWM5l9X56tTpViSZmQcRbgRyCJMLIWbEbFHEACxrKMBhwiOsQ4FLbRcyGzi9uAT5xASwT5HFVHSlimLU4ZC7AmNR7TaDVmT1o2abqDW6BSdukPKOFLsid2yOntk9+yFfxayw9qNLyc0qw2tdwuDZ6Prb/qzJo9nD8p

_R_ Z ( _ω_ _/_ 2 ¹⁵ )

All MEK

Negl. _l_ = 15

Negl. _l_ ≥ 14

Switch at _l_ = 11

Switch at _l_ = 12

⋮

⋮

preparation

aB6QDzKzGKw7GWhLDhAXAXUqMKgaXDVYafDZ4ITBaoOXBn9wmlUNgPklkognQTRm1oQz98lEfydoK5cIF3CkIHQhdfNJQxpDBZgt2YC3V4AFgH5Ihmiv6xq+udgqyDVajWDRQavge5fa

_→_ ¹⁵

_l_ =1 _|_ _M_ _l_ _↑_

Logical qubit cycle / _P_ success

FIG. 7.

Logical error and spacetime tradeoff for preparing the phase-gradient state _|_ PG _K_ _⟩_ with _K_ = 15, assuming _p_ phys = 10 _−_ ⁴

and a distance-13 surface code. Orange points use MEK distillation up to a cutoff and neglect the remaining higher-level

components. Green points use hybrid protocols that combine MEK distillation for lower levels with weak transversal gates for

higher levels.

**D.**

**Teraquop regime: accuracy-enhanced magic state distillation**

Weak transversal gates play a significant role even in the ultra high precision regime that tolerates a trillion gate

count in terms of Clifford+T gate set.

One of the most practical examples is the magic state distillation.

The

success in the state preparation, as shown in Sec. III C , naturally implies that weak transversal gates can be used to

Ratio (%)

**Prep**

(a)

(c)

Logical error rate

**Pivot rot**

**T gate**

**Cli** **ff** **ord**

**Pivot rot**

**Pivot**

**T gate**

**Cli** **ff** **ord**

**T gate** **Cli** **ff** **ord**

(d)

(b)

Logical qubit cycle

Error rate breakdown

Spacetime cost breakdown

Ratio (%)

**Prep**

**Prep**

**Prep**

FIG. 8.

Breakdown of logical error rate and spacetime cost for magic state distillation of _|_ _M_ _l_ =4 _⟩_ . Here, we assume that

T gates and the pivot rotation gate (which is a T gate) are already distilled [ 74 ]. The physical error rate is assumed to be

_p_ phys = 10 _−_ ⁴ , and logical qubits are individually encoded via surface code of code distance _d_ = 11.

15

improve the accuracy of magic state injection. Furthermore, we may benefit from the segmenting the rotation angles,

especially when the bottleneck in the precision is in the rotation gate while the spacetime cost is dominated by a

different process.

One representative situation is indicated in Fig. 8 where we show the breakdown of contribution to the spacetime

cost and logical error rate to the MEK distillation protocol. Here, we aim to distill an equatorial magic state from

the _l_ = 4-th level of the Clifford hierarchy, which is known to nearly halve the non-Clifford gate count in synthesizing

a single-qubit gate, compared to the case when only T gates are used [ 76 ]. The contributions are classified into four

categories: the magic state injection, pivot rotation gate, T gate, and Clifford gates. As we can see from results for

_r_ = 1 in panels (a) and (c), the magic state injection dominates the error of the output state, while panels (b) and (d)

indicate that the spacetime cost is only a few percent of the entire protocol. By segmenting the rotation angle into

_r_ = 16 steps, we can achieve a 6-fold reduction of logical error rate from 1 _._ 2 _×_ 10 _−_ ⁹ to 1 _._ 9 _×_ 10 _−_ ¹⁰ , with a moderate

increase in spacetime cost from 2011 to 2827 in terms of the logical qubit cycle.

We gain even more by performing more rounds of distillation (see Fig. 9 ). Specifically, we find that the aforemen-

tioned bottleneck structure is also present when we perform two rounds of magic state distillation, and hence, by

segmenting weak transversal gates into _r_ = 32 steps, we can achieve a 94-fold reduction of logical error rate from

1 _._ 4 _×_ 10 _−_ ¹⁸ to 1 _._ 5 _×_ 10 _−_ ²⁰ , with an increase in the spacetime cost from 1 _._ 4 _×_ 10 ⁴ to 1 _._ 9 _×_ 10 ⁴ in terms of logical qubit

cycle. We remark that such a preparation protocol is far more efficient than naively synthesizing the magic state.

(a)

(b)

(c)

Logical error rate

Logical error rate

Logical error rate

Logical qubit cycle

Logical qubit cycle

 

 

 

 

 

+-

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 



,

,

,

,

,

,

,

$-$ 

$-$ 

 

 .  

 

 

 

 

 .  

 .  

+-

 

 

 

 

 

$

, -

 

 

 

 

 

+-

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 

 



,

,

,

,

,

,

,

$-$ 

$-$ 

 

 .  

 

 

 

 

 .  

 .  

+-

 

 

 

 

 

$

, -

 

 

 

 

 

 $,+/$

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 1

 $+

-$

-$

-$

-$

-$

-$

-$

/+.+

/+.

 

 0  

 1

 1

 1

 

 0  

 0  

 $,+/$

 1

 1

 1

 1

 1

 +++$$+

$-$/

FIG. 9.

Tradeoff between spacetime cost in units of logical qubit cycle and the logical error rate for distillation of

_√_

_T_ state.

Compared with the Clifford+T-synthesis-based preparation using state-of-the-art T-state distillation protocol [ 61 , 74 , 75 ], our

proposal achieves orders of magnitude more precise magic state preparation. When we prepare the initial state, we take the

number of segmentation as _r_ = 1 _,_ 2 _,_ 4 _,_ 8 _,_ 16 _,_ 32 _._ The number of distillation rounds by the MEK protocol is indicated by colors

of blue (raw), orange (1 round), and green (2 rounds). Physical error rate is assumed to be _p_ phys = 10 _−_ ⁴ for all data.

16

As shown in Fig. 9 (a), synthesizing the T gates consumes nearly 10 times the spacetime cost even when we rely on

state-of-the-art T-state preparation methods [ 61 , 74 ] using a nearly optimal synthesis algorithm [ 75 ]. For instance,

4 _×_ 10 ³ logical qubit cycles are required in order to achieve a logical error rate of 10 _−_ ¹⁰ using one round of the MEK

protocol, while synthesis consumes 3 _×_ 10 ⁴ logical qubit cycles. With a similar spacetime cost, our protocol can distill

down to a logical error rate of 10 _−_ ²⁰ _._

**IV.**

**DISCUSSION**

In this work, we have developed a general theory of weak transversal gates—logical operations implemented by

local physical unitaries for probabilistic implementation of a set of logical unitaries rather than deterministic one—

and shown how they expand the scope of transversal techniques for quantum computation on logical qubits. Our

theoretical contribution is to show the sufficient condition to admit weak transversal implementation of multiqubit

Pauli rotation gates, together with a constructive method to realize them in CSS codes. To provide quantitative

validation, we have considered three tasks: factory-free, partially fault-tolerant architecture (Sec. III A , III B ), short-

depth state preparation (Sec. III C ), and enhanced magic state distillation (Sec. III D ). Collectively, these results

position weak transversality as a practical, scalable complement to deterministic transversal gates, well-suited to

early FTQC settings that must tolerate qubit dropout and dynamically changing codes.

Beyond the in-place implementation of Pauli rotation, the application of weak transversal gates are envisioned as

follows.

• **Scrambling in logical qubits.** Our work directly solves the open question cast in Ref. [ 22 ] regarding the

many-body generalization of emergent randomness generation.

• **Dynamical phase transition.** Recent findings show that dynamics of quantum circuit fosters rich physics

in terms of competition between measurement, entanglement, and magic [ 77 – 79 ].

The framework of weak

transversal gates provides an excellent platform to simulate such emergent phenomena.

• **Resource distillation.** Beyond magic state, numerous quantum resource preparation including entanglement

and coherence leverage distillation protocols. Our scheme is directly applicable to such tasks which is indispens-

able for quantum communication or distributed quantum computation.

• **Teleportation-free architecture in flying qubits.** The in-place Pauli rotation gates opens a possibility to

completely eliminate logical ancilla qubits for encoded flying qubits which can perform entangling operations in

a transversal manner. Furthermore, combined with code concatenation, we may flexibly tune the achieved error

scaling for both the transversal and weak transversal operations.

We finally remark on future problems. First, it is interesting to investigate whether Theorem 2 can be extended

to non-CSS stabilizer codes, an open problem also mentioned in Sec. II . Second, it is important to evaluate the

performance of in-place Pauli rotation based on circuit-level noise simulation beyond the currently executed size.

The major bottleneck is the coexistence of non-Clifford gates and stochastic noise with multiple syndrome extraction.

Large-scale simulation remains challenging even with current classical simulation techniques [ 80 , 81 ], and hence further

development is required. Third, it is intriguing to explore whether one can gain from inhomogeneous physical rotation

angles. It has been found in the context of strong transversal gates that some non-Clifford gates are implemented

via inhomogeneous local gates [ 82 , 83 ], and we foresee that flexibility of weak transversal gates can be leveraged in a

similar way.

**ACKNOWLEDGMENTS**

The authors wish to thank Sergey Bravyi, Michael Gullans, Ying Li, Patrick Rall, Shiro Tamiya for fruitful

discussions. We are grateful to Yutaka Hirano for his generosity for sharing numerical data on (0+1)-level distillation.

N.Y. is supported by JST Grant Number JPMJPF2221, JST CREST Grant Number JPMJCR23I4, IBM Quantum,

Google Quantum AI, JST ASPIRE Grant Number JPMJAP2316, JST ERATO Grant Number JPMJER2302, and

JST [Moonshot R&D] [Grant Number JPMJMS256J]. We acknowledge the use of large language models to improve

the clarity of original text. This research used resources of the Oak Ridge Leadership Computing Facility, which is a

DOE Office of Science User Facility supported under Contract DE-AC05-00OR22725.

_Note added.—_ Upon preparation of the manuscript, an independent work [ 84 ] appeared on arXiv that proposed to

adaptively implement in-place Pauli rotation on a rotated surface code. Physical rotations are applied to the entire

17

code patch in Ref. [ 84 ] and hence it cannot be generalized to multiqubit logical patch, while our scheme is capable of

general CSS codes.

18

**Appendix A: Proof of Theorem 1**

In this Appendix, we provide a detailed proof for Theorem 1 . For the sake of convenience, we restate the theorem.

**Theorem 1.** _(Weak transversal Z rotation gate on odd-distance code) Let a logical QECC patch be an_ [[ _n, k, d_ _x_ _, d_ _z_ ]]

_CSS code. Assume that the following conditions are satisfied:_

_1\. The code distance for the logical Z operator,_ _d_ _z_ _, is odd._

_2\. The logical Z operator of interest,_ ¯ _Z_ target _, is weight_ _d_ _z_ _._

_Then,_ _U_ := 

_j_ _∈_ supp( ¯

_Z_ target ) _e_ _iθZ_ _j_ _is a weak transversal Z rotation gate._

To prove Theorem 1 , it is important to keep in mind that if a quantum operation corresponds to a quantum channel

on the logical space, then the action on the logical space should not depend on the input state. As noted in Ref. [ 22 ],

the following well-known fact is crucial:

**Lemma 2.** _Let a quantum channel_ _M_ ( _·_ ) = 

_x_ _K_ _x_ _·_ _K_ _†_

_x_ _be specified by a set of Kraus operators_ _{_ _K_ _x_ _}_ _. The probability_

_distribution_ _p_ _x_ = Tr[ _K_ _x_ _ρK_ _†_

_x_ ] _is independent of the input state_ _ρ_ _if and only if_ _K_ _x_ = _√_ _p_ _x_ _U_ _x_ _._

In the context of weak transversal gate, the set of Kraus operators are _{_ _√_ _p_ **_s_** Π **_s_** _U_ _}_ **_s_** , where _p_ **_s_** is the probability

of obtaining the syndrome **_s_** and Π **_s_** :=  _n_ _−_ _k_

_i_ =1

1+( _−_ 1) _si_ _g_ _i_

2

is the projection operator defined by the set of stabilizer

generators _{_ _g_ _i_ _}_ _n_ _−_ _k_

_i_ =1 . In order to bridge Lemma ² and Theorem ¹ , we first prove the following useful lemma.

**Lemma 3.** _Let_ _S_ _be a stabilizer group that specifies the code space of an_ [[ _n, k, d_ _x_ _, d_ _z_ ]] _CSS code._

_Assume that_

_conditions in Theorem_ _1_ _are satisfied._

_Then, for any_ _S_ 1 _, S_ 2 _∈ S_ _, and_ ¯ _Q_ _∈ {_ ¯ _I,_ ¯ _X,_ ¯ _Y ,_ ¯ _Z_ _}_ _⊗_ _k_ _\\{_ ¯ _I_ _}_ _, a unitary_ _U_ =



_j_ _∈_ supp( ¯

_Z_ target ) _e_ _iθ_ _j_ _Z_ _j_ _satisfies_

Tr[ _S_ 1 _US_ 2 ¯ _QU_ _†_ ] = 0 _._

(A1)

_Proof._ We first prove Eq. ( A1 ) for logical operators that include at least one logical X operator, and then consider

those without any logical X operator. For the sake of description, we utilize the symplectic representation of Pauli

operators, while global phase is neglected since it does not affect the discussion after all. We denote a stabilizer as

_S_ _m_ = _X_ **_a_** _m_ _Z_ **_b_** _m_ ( **_a_** _m_ _,_ **_b_** _m_ _∈_ F _n_

2 ), and a single logical operator as ¯ _X_ _i_ = _X_ **_α_** _i_ ( **_α_** _i_ _∈_ F _n_

2 ) and ¯ _Z_ _i_ = _Z_ **_β_** _i_ ( **_β_** _i_ _∈_ F _n_

2 ). For a

product of logical operators, we indicate them as ¯ _Q_ = ¯ _X_ **_µ_** ¯ _Z_ **_ν_** = _X_



_i_ _µ_ _i_ **_α_** _i_ _Z_



_i_ _ν_ _i_ **_β_** _i_ ( **_µ_** _,_ **_ν_** _∈_ F _k_

2 ) _._

First, assume that the nontrivial logical X operator is present in ¯ _Q_ , i.e., **_µ_** _̸_ = **0** . It is illustrative to first assume

**_ν_** = **0** . Here, the product of stabilizers and a logical operator is written as

_S_ 1 _S_ 2 ¯ _Q_ = _S_ 1 _S_ 2 ¯ _X_ **_µ_** = _X_ **_a_** ¹ \+ **_a_** ² \+ 

_i_ _µ_ _i_ **_α_** _i_ _Z_ **_b_** ¹ \+ **_b_** ² _._

(A2)

Since any nontrivial logical operator is a centralizer of _S_ , we have Tr[ _S_ ¯ _X_ **_µ_** _̸_ = **0** ] = 0 for any _S_ _∈ S_ . To prove Eq. ( A1 ),

we inspect how Eq. ( A2 ) is modified under the conjugation by _U_ . Note that for single-qubit Pauli operators we have

_e_ _iθZ_ _XZ_ _b_ _e_ _−_ _iθZ_ = cos(2 _θ_ ) _XZ_ _b_ _−_ _i_ sin(2 _θ_ ) _XZ_ _b_ \+1

=



_w_ =0 _,_ 1

_c_ _w_ _XZ_ _b_ \+ _w_ _,_

(A3)

where _c_ _w_ _∈_ C is a coefficient. We can easily derive a multiqubit version by noting that the conjugation acts nontrivially

only for the overlapping supports between _U_ and _X_ **_a_** :







_j_ _∈_ supp( ¯

_Z_ target )

_e_ _iθ_ _j_ _Z_ _j_



 _X_ **_a_** _Z_ **_b_**







_j_ _∈_ supp( ¯

_Z_ target )

_e_ _−_ _iθ_ _j_ _Z_ _j_



 =



**_w_** _∈_ _W_ (supp( ¯

_Z_ target ) _∩_ supp( _X_ **_a_** ))

_c_ **_w_** _X_ **_a_** _Z_ **_b_** \+ **_w_** _∧_ **_a_** _,_

(A4)

where _W_ (Λ) = _{_ 

_j_ _∈_ Λ _f_ _j_ **_e_** _j_ _|_ _f_ _j_ _∈ {_ ⁰ _,_ ¹ _}}_ with _e_ _j_ _∈_ F _n_

2 indicating a vector with only the _j_ \-th element being unity.

Here, we have introduced _∧_ for the bit-wise AND operation. This allows us to compute the conjugation of Eq. ( A2 )

as

_S_ 1 _US_ 2 ¯ _X_ **_µ_** _U_ _†_ = _X_ **_a_** ¹ _Z_ **_b_** ¹ _·_ _U_ _·_ _X_ **_a_** ² _Z_ **_b_** ² _·_ _X_



_i_ _µ_ _i_ **_α_** _i_ _·_ _U_ _†_

(A5)

= _X_ **_a_** ¹ _Z_ **_b_** ¹ _·_ _Z_ **_b_** ² _·_



**_w_** _∈_ _W_ Λ _′_

_c_ **_w_** _X_ **_a_** ² \+ 

_i_ _µ_ _i_ **_α_** _i_ _Z_ **_w_** _∧_ ( **_a_** ² \+ 

_i_ _µ_ _i_ **_α_** _i_ )

(A6)

= _X_ **_a_** ¹ \+ **_a_** ² \+ 

_i_ _µ_ _i_ **_α_** _i_



**_w_** _∈_ _W_ Λ _′_

_c_ **_w_** _Z_ **_b_** ¹ \+ **_b_** ² \+ **_w_** _∧_ ( **_a_** ² \+ 

_i_ _µ_ _i_ **_α_** _i_ ) _,_

(A7)

19

where we have introduced Λ _′_ := supp( _U_ ) _∩_ supp( _X_ **_a_** ² \+ 

_i_ _µ_ _i_ **_α_** _i_ ). Since **_µ_** _̸_ = **0** , it holds that **_a_** 1 \+ **_a_** 2 \+ 

_i_ _µ_ _i_ **_α_** _i_ _̸_ = **0** ,

and thus the trace of Eq. ( A7 ) must be zero as

Tr[ _S_ 1 _US_ 2 ¯ _X_ **_µ_** _U_ _†_ ] = 0 _._

(A8)

Since Eq. ( A8 ) follows from the argument regarding the support of X operators, Eq. ( A8 ) holds for **_ν_** _̸_ = **0** as long as

**_µ_** _̸_ = **0** .

Next, we consider the case when ¯ _Q_ is composed only of logical Z operators, i.e., **_µ_** = **0** and **_ν_** _̸_ = **0** . Similar to

Eq. ( A7 ), the conjugation of stabilizer operators can be written as

_S_ 1 _US_ 2 ¯ _Z_ **_ν_** _U_ _†_ = _X_ **_a_** ¹ \+ **_a_** ²



**_w_** _∈_ _W_ (supp _Z_ ( _U_ ) _∩_ supp _X_ ( _S_ 2 ))

_c_ _w_ _Z_ **_b_** ¹ \+ **_b_** ² \+ **_w_** _∧_ **_a_** ² \+ 

_i_ _ν_ _i_ **_β_** _i_ _,_

(A9)

where we have introduced supp _X_ and supp _Z_ to denote the support of X and Z components, respectively. Using _| · |_

to denote the Hamming weight, it holds that

max

**_w_** _|_ **_w_** _∧_ **_a_** ² _|_ = max

**_w_** _|_ **_w_** _|_ = _|_ supp _Z_ ( ¯ _Z_ target ) _∩_ supp _X_ ( _S_ ² ) _| ≤ |_ supp _Z_ ( ¯ _Z_ target ) _|_ = _d_ _z_ _,_

(A10)

while the equality in _|_ supp _Z_ ( ¯ _Z_ target ) _∩_ supp _X_ ( _S_ 2 ) _| ≤ |_ supp _Z_ ( ¯ _Z_ target ) _|_ cannot be satisfied when _d_ _z_ is odd. This follows

from the fact that _|_ supp _Z_ ( ¯ _Z_ target ) _∩_ supp _X_ ( _S_ 2 ) _|_ is an even number when [ ¯ _Z_ target _, S_ 2 ] = 0 holds. On the other hand,

since _S_ 1 _S_ 2 ¯ _Z_ **_ν_** is a nontrivial logical Z operator for any _S_ 1 _, S_ 2 _∈ S_ , the Hamming weight satisfies

min

**_b_** 1 _,_ **_b_** 2 _∈_ _G_ _Z_ wt( **_b_** ¹ \+ **_b_** ² \+



_i_

_ν_ _i_ **_β_** _i_ ) _≥_ _d_ _z_ _,_

(A11)

where _G_ _Z_ is the generator matrix for Z stabilizers. Due to Eqs. ( A10 ), ( A11 ), we find that _Z_ **_w_** _∧_ **_a_** ² and _Z_ **_b_** ¹ \+ **_b_** ² \+ 

_i_ _ν_ _i_ **_β_** _i_

do not cancel out with each other; their product always yields a nontrivial Pauli Z operator, and hence its trace is

zero. Therefore, for any _S_ 1 _, S_ 2 _∈ S_ _,_

Tr



_S_ 1 _US_ 2 ¯ _Z_ **_ν_** _U_ _†_ 

= 0 _._

(A12)

Combining the arguments, we conclude that the following holds for any nontrivial logical operator

¯ _P_

_∈_

_{_ ¯ _I,_ ¯ _X,_ ¯ _Y ,_ ¯ _Z_ _}_ _⊗_ _k_ _\\ {_ ¯ _I_ _}_ ,

Tr[ _S_ 1 _US_ 2 ¯ _PU_ _†_ ] = 0 _._

(A13)

We further proceed by noting that any Kraus operator for stabilizer measurement can be decomposed into sum of

stabilizer operators as

Π **_s_** =

_n_ _−_ _k_



_i_ =1

_I_ \+ ( _−_ 1) _s_ _i_ _g_ _i_

2

=



_S_ _∈S_

_f_ _S_ _S._

(A14)

By straightforwardly combining this expression with Lemma 3 , we obtain the following:

**Lemma 4.** _Assume that a CSS code satisfies the conditions given in Theorem_ _1_ _. Then, for all_ ¯ _Q_ _∈ {_ ¯ _I,_ ¯ _X,_ ¯ _Y ,_ ¯ _Z_ _}_ _⊗_ _k_ _\\_

_{_ ¯ _I_ _}_ _, a unitary_ _U_ = 

_j_ _∈_ supp( ¯

_Z_ target ) _e_ _iθZ_ _j_ _satisfies_

Tr[Π **_s_** _U_ Π **0** ¯ _QU_ _†_ ] = 0 _._

(A15)

Building on top of Lemma 4 , we show that the stabilizer measurement results do not depend on the input logical

state. Note that any logical state ¯ _ρ_ can be decomposed into sum of logical Pauli operator as

¯ _ρ_ = Π **0**







¯

_Q_ _∈{_ ¯ _I,_ ¯

_X,_ ¯ _Y ,_ ¯

_Z_ _}_ _⊗_ _k_

_c_ ¯

_Q_ ¯ _Q_



 Π **0** = ¹

2 _k_ Π **0** \+



¯

_Q_ _∈{_ ¯ _I,_ ¯

_X,_ ¯ _Y ,_ ¯

_Z_ _}_ _⊗_ _k_ _\\{_ ¯ _I_ _}_

_c_ ¯

_Q_ Π **0** ¯ _Q,_

(A16)

20

where _c_ ¯

_Q_ _∈_ R is the Pauli coefficient that encodes the logical information of the state. Then, the measurement

probability distribution _p_ **_s_** can be computed using Lemma 4 as

_p_ **_s_** = Tr[Π **_s_** _U_ ¯ _ρU_ _†_ ] =

1

2 _k_ Tr[Π **_s_** _U_ Π **0** _U_ _†_ ] +



¯

_Q_ _∈{_ ¯ _I,_ ¯

_X,_ ¯ _Y ,_ ¯

_Z_ _}_ _⊗_ _k_ _\\{_ ¯ _I_ _}_

_c_ ¯

_Q_ Tr[Π **_s_** _U_ Π **0** ¯ _QU_ _†_ ]

(A17)

=

1

2 _k_ Tr[Π **_s_** _U_ Π **0** _U_ _†_ ] _,_

(A18)

which is indeed independent of the logical state ¯ _ρ_ . Therefore, by Lemma 2 , _U_ yields a weak transversal operation.

In order to complete the proof of Theorem 1 , we must assure that any logical rotation angle ¯ _θ_ can be implemented,

as follows.

**Lemma 5.** _Assume that a CSS code satisfies the conditions given in Theorem_ _1_ _, and let_ _U_ _be a unitary defined as_

_U_ = 

_j_ _∈_ supp( ¯

_Z_ target ) _e_ _iθZ_ _j_ _. Then, by applying_ _U_ _on an arbitrary logical state_ ¯ _ρ_ _, followed by syndrome measurement_

_M_ _, the gate operation can be written as_

_M ◦ U_ (¯ _ρ_ ) =



**_s_** _∈{_ 0 _,_ 1 _}_ _M_ _−_ ¹

_E_ **_s_** ( _p_ **_s_** ¯ _V_ **_s_** ¯ _ρ_ ¯ _V_ _†_

**_s_** ) _,_

(A19)

_where_ _E_ **_s_** ( _·_ ) = _E_ **_s_** _·_ _E_ _†_

**_s_** _is a map for_ _E_ **_s_** _, a minimum-weight Pauli error that invokes syndrome_ **_s_** _,_ _p_ **_s_** _is the probability_

_of obtaining the syndrome_ **_s_** _, and_ ¯ _V_ **_s_** = _e_ _i_ ¯ _θ_ **_s_** ¯

_Z_ target _is a logical rotation unitary. The probabilities and angles are given_

_by_

_p_ **_s_** = _|_ cos _d_ _z_ _−_ _w_ _θ_ sin _w_ _θ_ _|_ ² \+ _|_ sin _d_ _z_ _−_ _w_ _θ_ cos _w_ _θ_ _|_ ² _,_

¯ _θ_ **_s_** = arctan



( _−_ 1)

_dz_ _−_ 1

2

_−_ _w_ tan _d_ _z_ _−_ 2 _w_ _θ_



_,_

(A20)

_where_ _w_ := _|_ _E_ **_s_** _|_ _indicates the Pauli weight of_ _E_ **_s_** _._

_Proof._ There are _d_ _z_ _−_ 1 X-type stabilizer generators that can be related with individual entry of a syndrome **_s_** =

( _s_ 1 _, ..., s_ _d_ _z_ _−_ 1 ). Since the Z code distance of the target QECC is _d_ _z_ , any Pauli Z error _E_ with wt( _E_ ) _≤_ _d_ _z_ _−_ ¹

2

must be

discriminated by the syndrome measurement. Considering that the number of combinations of such Pauli errors is

_dz_ _−_ 1

2



_l_ =0



_d_ _z_

_l_



= ¹

2

_d_ _z_



_l_ =0



_d_ _z_

_l_



= 2 _d_ _z_ _−_ ¹ _,_

we can see that there exists a set of stabilizer generators _{_ _g_ _i_ _}_ _d_ _z_ _−_ ¹

_i_ =1

for correcting the error on supp _Z_ ( ¯ _Z_ target ). In other

words, we can uniquely relate a syndrome **_s_** with a Pauli Z error _E_ with wt( _E_ ) _≤_ _d_ _z_ _−_ ¹

2

, which is denoted as _E_ **_s_** in

the following.

We remark that _E_ **_s_** can be estimated with an optimal decoding algorithm for a _classical_ code with _d_ _z_ bits. Namely,

instead of considering the stabilizer generator _g_ =  _n_

_i_ =1 _Q_ _i_ ( _Q_ _i_ _∈ {_ _I, X, Y, Z_ _}_ ), one may define a punctured stabilizer

generator as

ˆ _g_ :=



_i_ _∈_ supp _Z_ ( ¯

_Z_ target )

_Q_ _i_ _,_

and construct a classical code whose check matrices are given by _H_ =



ˆ _a_ _T_

_i_

 _T_

where the binary vectors ˆ _a_ _i_ are

defined from ˆ _g_ _i_ = _X_ ˆ _a_ _i_ _._ Thus, the computational cost for computing _E_ **_s_** is drastically reduced compared to decoding

the original QECC. For a moderate _d_ _z_ , one may prepare a lookup table for it.

Now we decompose the unitary as

_U_ =



_j_ _∈_ supp _Z_ ( ¯

_Z_ target )

_e_ _iθZ_ _j_ =



_j_ _∈_ supp _Z_ ( ¯

_Z_ target )

(cos _θ_ _·_ _I_ \+ _i_ sin _θ_ _·_ _Z_ _j_ )

(A21)

=



**_b_** _∈{_ 0 _,_ 1 _}_ _dz_

(cos _θ_ ) _d_ _z_ _−|_ **_b_** _|_ ( _i_ sin _θ_ ) _|_ **_b_** _|_ _Z_ **_b_**

(A22)

=



**_b_** _∈{_ 0 _,_ 1 _}_ _dz_

_|_ **_b_** _|≤_ _dz_ _−_ ¹

2

(cos _θ_ ) _d_ _z_ _−|_ **_b_** _|_ ( _i_ sin _θ_ ) _|_ **_b_** _|_ _Z_ **_b_** \+ (cos _θ_ ) _|_ **_b_** _|_ ( _i_ sin _θ_ ) _d_ _z_ _−|_ **_b_** _|_ _Z_

¯ **_β_** \+ **_b_** _,_

(A23)

(A24)

21

where ¯ _Z_ target = _Z_ **_β_** _._ As we have noted above, _Z_ **_b_** with _|_ **_b_** _| ≤_ _d_ _z_ _−_ ¹

2

can be uniquely identified with a syndrome **_s_** . Thus,

we can further rewrite the unitary using projector Π **_s_** := _E_ **_s_** Π **0** _E_ **_s_** and _w_ := _|_ _E_ **_s_** _|_ as

_U_ =



**_s_**

Π **_s_** _U_ =



**_s_**

_U_ **_s_** _,_

(A25)

_U_ **_s_** = _E_ **_s_** _·_ (cos _θ_ ) wt( _E_ **_s_** ) ( _i_ sin _θ_ ) wt( _E_ **_s_** ) (cos _d_ _z_ _−_ 2wt( _E_ **_s_** ) _θ_ _·_ _I_ \+ ( _i_ sin _θ_ ) _d_ _z_ _−_ 2wt( _E_ **_s_** ) _·_ ¯ _Z_ target )

_≃_ _√_ _p_ **_s_** _E_ **_s_** ¯ _V_ **_s_** _,_

(A26)

where we have neglected the global phase in the second line, and _p_ **_s_** and ¯ _V_ **_s_** are defined as in Eq. ( A20 ).

Finally, by using the fact that _M_ (Π **_s_** _·_ Π **_s_** _′_ ) = _δ_ **_s_** _,_ **_s_** _′_ _M_ (Π **_s_** _·_ Π **_s_** ) holds for the syndrome measurement _M_ of the

QECC, we obtain

_M ◦ U_ (¯ _ρ_ ) = _M_ ( _U_ ¯ _ρU_ _†_ ) =



**_s_** _,_ **_s_** _′_

_M_ (Π **_s_** _U_ ¯ _ρU_ _†_ Π **_s_** _′_ ) =



**_s_**

_M_ (Π **_s_** _U_ ¯ _ρU_ _†_ Π **_s_** )

=



**_s_**

_M ◦ E_ **_s_** ( _p_ **_s_** ¯ _V_ **_s_** ¯ _ρ_ ¯ _V_ _†_

**_s_** )

=



**_s_**

_E_ **_s_** ( _p_ **_s_** ¯ _V_ **_s_** ¯ _ρ_ ¯ _V_ _†_

**_s_** ) _,_

(A27)

where we have used _M ◦ E_ **_s_** = _E_ **_s_** _◦ M_ and _M_ ( ¯ _V_ **_s_** ¯ _ρ_ ¯ _V_ _†_

**_s_** ) = ¯ _V_ **_s_** ¯ _ρ_ ¯ _V_ _†_

**_s_** in the last line.

Note that _M_ in Lemma 5 can be in principle replaced by syndrome measurement for the punctured stabilizer

generators _{_ ˆ _g_ _i_ _}_ _i_ if we are only interested in the weak transversal gate. However, in practice we desire to suppress

the hardware error on the physical qubits, and hence perform the syndrome measurement for the entire QECC. By

combining Lemma 5 with the fact that _U_ is a weak transversal gate, we complete the proof of Theorem 1 .

We note that Theorem 1 also implies weak transversal X rotations after exchanging X and Z. If the assumptions

in Theorem 1 are satisfied for both X and Z operators, a weak transversal Y rotation can also be obtained by a

constant-size composition of weak transversal X and Z rotations, for example using _e_ _iθY_ = _e_ _−_ _iπZ/_ ⁴ _e_ _iθX_ _e_ _iπZ/_ ⁴ . This

composition uses multiple syndrome-extraction gadgets. In contrast, the disjoint-support construction in Appendix B

gives a single-gadget implementation of general logical Pauli rotations when its conditions are satisfied.

**Appendix B: Proof of Theorem 2**

In this Appendix, we provide a detailed proof for Theorem 2 , which we restate here for convenience.

**Theorem 2.** _(Weak transversal implementation of general Pauli rotation gate)_

_Let_ _C_ _be an_ [[ _n, k, d_ ]] _CSS code,_

_and let_ _M_ _≤_ _d_ _be an odd integer. Then, for any logical Pauli operator_ ¯ _P_ _of the code_ _C_ _, there exists a set of Pauli_

_operators_ _{_ _P_ _m_ _}_ _M_

_m_ =1 ( _P_ _m_ _∈ {_ _I, X, Y, Z_ _}_ _⊗_ _n_ ) _such that a unitary_  _M_

_m_ =1 _e_ _iθP_ _m_ _followed by syndrome extraction yields_

_weak transversal implementation of_ ¯ _P_ _\-rotation gate._

The proof proceeds as follows. In Appendix B 1 we claim that, once a partition of logical Pauli operator ¯ _P_ called

_disjoint support partition_ is obtained, we can implement ¯ _P_ \-rotation gate in weak transversal manner for arbitrary log-

ical angle. Motivated by actually constructing the disjoint support partition, in Appendix B 2 we provide Algorithm 1

for finding the disjoint support partition.

**1\.**

**Disjoint support partition for weak transversal Pauli rotation**

In order to ensure the input-agnosticity, it is important that we perform physical Pauli rotations with appropriate

support. Here, we consider a specific partition of logical operator as follows.

**Definition 4.** _(Disjoint support partition) Let_ ¯ _P_ _be a nontrivial Pauli operator of an_ [[ _n, k, d_ ]] _CSS code. A set_

_of Pauli operators_ _{_ _P_ _m_ _}_ _M_

_m_ =1 ( _P_ _m_ _∈ {_ _I, X, Y, Z_ _}_ _⊗_ _n_ ) _is said to be a disjoint support partition of_ ¯ _P_ _if the following_

_conditions are satisfied:_

_•_ ¯ _P_ =  _M_

_m_ =1 _P_ _m_ _with odd_ _M_ _._

_•_ supp( _P_ _m_ ) _∩_ supp( _P_ _m_ _′_ ) = _∅_ _for all_ _m_ _̸_ = _m_ _′_ _._

22

_•_ _For any nonempty subset_ _R_ ⊊ [ _M_ ] _, it holds that_ Π **0**



_m_ _∈_ _R_ _P_ _m_ Π **0** = 0 _where_ Π **0** _is a projection operator onto_

_the code space._

_In particular, the third condition assures that any nonempty proper subset of the operators yield nontrivial syndrome._

Assuming that _{_ _P_ _m_ _}_ _m_ is a disjoint support partition, we can show that _U_ =  _M_

_m_ =1 _e_ _iθP_ _m_ is a weak transversal

Pauli rotation gate.

**Lemma 6.** _Let_ _U_ =  _M_

_m_ =1 _e_ _iθP_ _m_ _with_ _{_ _P_ _m_ _}_ _M_

_m_ =1 _being a disjoint support partition of the target Pauli operator_ ¯ _P_ target _._

_Then,_ _U_ _followed by syndrome measurement is a weak transversal_ ¯ _P_ target _rotation gate._

_Proof._ First, let us decompose the unitary into sum of Pauli operators as

_U_ =

_M_



_m_ =1

_e_ _iθP_ _m_ =



**_b_** _∈{_ 0 _,_ 1 _}_ _M_

_α_ **_b_**

_M_



_m_ =1

_P_ _b_ _m_

_m_

(B1)

where _α_ **_b_** _∈_ C is a coefficient of product of Pauli operators. Since _{_ _P_ _m_ _}_ _m_ is a disjoint support partition, for a given

proper subset _R_ ⊊ [ _M_ ], only _R_ _c_ = [ _M_ ] _\\_ _R_ _̸_ = _R_ is a proper subset that satisfies ( 

_m_ _∈_ _R_ _P_ _m_ ) _·_ ( 

_m_ _∈_ _R_ _c_ _P_ _m_ ) = ¯ _P_ target _∈_

_{_ ¯ _I,_ ¯ _X,_ ¯ _Y ,_ ¯ _Z_ _}_ _⊗_ _k_ . Therefore,

Π 0 (



_m_ _∈_ _R_

_P_ _m_ ) _·_ (



_m_ _∈_ _R_ _′_

_P_ _m_ )Π 0 =











Π 0

if _R_ _′_ = _R_

Π 0 ¯ _P_ target

if _R_ _′_ = _R_ _c_

0

otherwise _._

(B2)

Note that 

_m_ _P_ **_b_** _m_

_m_

can be uniquely related to a correction operation _E_ **_s_** ( **_b_** ) where **_s_** ( **_b_** ) indicates the syndrome invoked

by the Pauli operator. Combining **_s_** ( **_b_** ) = **_s_** ( **1** _−_ **_b_** ) with Eq. ( B2 ), it follows that

Π **0** _E_ **_s_** _E_ **_s_** _′_ Π **0** = _δ_ **_s_** _,_ **_s_** _′_ Π **0** _,_

(B3)

which satisfies the Knill-Laflamme error correcting condition [ 85 ]. This indicates that we can discriminate the elements

of _{_ _E_ **_s_** _}_ from each other via syndrome measurement.

Observe that, since _M_ is odd due to the condition of disjoint support partition, we can decompose the unitary as

_U_ =



**_s_**

_U_ **_s_**

(B4)

where

_U_ **_s_** = _E_ **_s_** (cos _θ_ ) _w_ ( _i_ sin _θ_ ) _w_ (cos _M_ _−_ ² _w_ _θ_ \+ ( _i_ sin _θ_ ) _M_ _−_ ² _w_ ¯ _P_ target )

(B5)

_≃_ _√_ _p_ **_s_** _E_ **_s_** ¯ _V_ **_s_** _,_

(B6)

where _w_ := _|_ _E_ **_s_** _|_ . This is not even a unitary operator if _M_ is an even number. Note that we have neglected the global

phase in the second line. Here, _p_ **_s_** _∈_ R is the normalization factor, and ¯ _V_ **_s_** = _e_ _i_ ¯ _θ_ **_s_** ¯

_P_ target is the logical rotation unitary

that are explicitly given as

_p_ **_s_** = _|_ cos _M_ _−_ _w_ _θ_ sin _w_ _θ_ _|_ ² \+ _|_ sin _M_ _−_ _w_ _θ_ cos _w_ _θ_ _|_ ² _,_

(B7)

¯ _θ_ **_s_** = arctan



( _−_ 1)

_M_ _−_ 1

2

_−_ _w_ tan _M_ _−_ 2 _w_ _θ_



_._

(B8)

Now, let us confirm that we indeed obtain ¯ _V_ **_s_** with probability **_s_** when the syndrome measurement result is **_s_** . Let

Π **_s_** = _E_ **_s_** Π 0 _E_ **_s_** be the Kraus operator corresponding to the measurement with syndrome **_s_** . Due to Eq. ( B3 ), it holds

that Π **_s_** _U_ Π 0 = Π **_s_** _U_ **_s_** Π 0 . Then, it follows that, for any logical operator ¯ _Q_ _∈ {_ ¯ _I,_ ¯ _X,_ ¯ _Y ,_ ¯ _Z_ _}_ _⊗_ _k_ ,

Tr[Π **_s_** _U_ Π 0 ¯ _QU_ _†_ ] = Tr[Π **_s_** _U_ **_s_** Π 0 ¯ _QU_ _†_

**_s_** ]

= _p_ **_s_** Tr[Π **_s_** _E_ **_s_** ¯ _V_ **_s_** Π 0 ¯ _QE_ **_s_** ¯ _V_ _†_

**_s_** ]

= _p_ **_s_** Tr[Π 0 ¯ _Q_ ]

=



_p_ **_s_** _·_ 2 _k_

if ¯ _Q_ = ¯ _I_

0

otherwise _._

(B9)

23

From the second to third line, we have used the fact that operators consisting of logical operators ( ¯ _Q_ and ¯ _V_ **_s_** ) and

those consisting only of stabilizers and/or destabilizers ( _E_ **_s_** and Π **_s_** ) commute with each other. Now decompose a

logical state as

¯ _ρ_ = Π **0**



 _I_

2 _k_ \+



¯

_Q_ _∈{_ ¯ _I,_ ¯

_X,_ ¯ _Y ,_ ¯

_Z_ _}_ _⊗_ _k_

_c_ ¯

_Q_ ¯ _Q_



 _,_

(B10)

where _c_ ¯

_Q_ is the coefficient that encodes the logical information of the state. By combining Eqs. ( B9 ), ( B10 ) we

find that the probability of obtaining the syndrome _s_ is independent of the logical state, since Tr[Π **_s_** _U_ ¯ _ρU_ _†_ ] = _p_ **_s_** _._

Concretely, by denoting syndrome measurement channel as _M_ and the unitary channel as _U_ , we find that

_M ◦ U_ (¯ _ρ_ ) = _M_ ( _U_ ¯ _ρU_ _†_ ) =



**_s_**

_p_ **_s_** _E_ **_s_** ( ¯ _V_ **_s_** ¯ _ρ_ ¯ _V_ _†_

**_s_** ) _,_

(B11)

where we have defined _E_ **_s_** ( _·_ ) := _E_ **_s_** _·_ _E_ **_s_** . This indicates that unitary _U_ followed by syndrome measurement results in

implementing logical unitary ¯ _V_ **_s_** with probability _p_ **_s_** , associated with Pauli error _E_ **_s_** .

**2\.**

**Construction of disjoint support partition**

The argument in the previous section motivates us to construct an algorithm to compute disjoint support partition.

Here, we provide an efficient algorithm to determine the disjoint support partition of arbitrary logical operator into

partition number of an integer _M_ _≤_ _d_ .

Let _H_ _X_ and _H_ _Z_ be the X- and Z-check matrices of an [[ _n, k, d_ ]] code, and let a syndrome vector for any Pauli

operator _P_ = _X_ **_a_** _Z_ **_b_** be defined as

**_s_** ( **_a_** _,_ **_b_** ) := ( _H_ _Z_ **_a_** _⊤_ _, H_ _X_ **_b_** _⊤_ ) _._

(B12)

Let ¯ _P_ target = _X_ **_α_** _Z_ **_β_** be a physical Pauli operator representation of a nontrivial logical Pauli operator, and let

_S_ := supp( **_α_** ) _∪_ supp( **_β_** ) _⊆_ [ _n_ ]

(B13)

be its support. For each _j_ _∈_ _S_ , we define its syndrome column vector in F _r_ _Z_ \+ _r_ _X_

2

by

**_h_** _j_ := **_s_** ( _α_ _j_ **_e_** _j_ _, β_ _j_ **_e_** _j_ ) =



_α_ _j_ _H_ _Z_ (: _, j_ ) _, β_ _j_ _H_ _X_ (: _, j_ )



_,_

(B14)

=



















 _H_ _Z_ **_e_** _j_

0



_∈_ F _r_ _Z_ \+ _r_ _X_

2

if ( _α_ _j_ _, β_ _j_ ) = (1 _,_ 0) (syndrome vector for _X_ _j_ ) _,_



0

_H_ _X_ **_e_** _j_



_∈_ F _r_ _Z_ \+ _r_ _X_

2

if ( _α_ _j_ _, β_ _j_ ) = (0 _,_ 1) (syndrome vector for _Z_ _j_ ) _,_

 _H_ _Z_ **_e_** _j_

_H_ _X_ **_e_** _j_



_∈_ F _r_ _Z_ \+ _r_ _X_

2

if ( _α_ _j_ _, β_ _j_ ) = (1 _,_ 1) (syndrome vector for _Y_ _j_ ) _,_

(B15)

where _H_ (: _, j_ ) denotes the _j_ \-th column and **_e_** _j_ is the _j_ \-th standard basis vector. Note that **_s_** ( **_α_** _,_ **_β_** ) = 

_j_ _∈_ _S_ **_h_** _j_ .

As discussed in the previous section, if _{_ _P_ _m_ _}_ _M_

_m_ =1 is a disjoint support partition of the logical operator ¯ _P_ target , for

any proper subset _R_ ⊊ [ _M_ ], the product 

_m_ _∈_ _R_ _P_ _m_ invokes a different syndrome. This can be formally stated as the

following Lemma.

**Lemma 7** (Rank of restricted check matrix) **.** _Let_ _C_ _be an_ [[ _n, k, d_ ]] _CSS code with check matrices_ _H_ _X_ _∈_ F _r_ _X_ _×_ _n_

2

_and_

_H_ _Z_ _∈_ F _r_ _Z_ _×_ _n_

2

_. Let_ ¯ _P_ target = _X_ **_α_** _Z_ **_β_** _be a nontrivial logical Pauli operator, and define its support as_ _S_ := supp( **_α_** ) _∪_

supp( **_β_** ) _. Let_ _H_ _S_ _be the_ ( _r_ _Z_ \+ _r_ _X_ ) _× |_ _S_ _|_ _matrix whose columns are_ _{_ **_h_** _j_ _}_ _j_ _∈_ _S_ _. Then, the rank of the restricted check_

_matrix can be bounded from below as_

rank( _H_ _S_ ) _≥_ _d_ _−_ 1 _._

(B16)

_Proof._ Because ¯ _P_ target is a logical operator, it commutes with all stabilizer generators, hence it has trivial syndrome.

For CSS codes, this means _H_ _Z_ **_α_** _⊤_ = **0** and _H_ _X_ **_β_** _⊤_ = **0** . Equivalently,



_j_ _∈_ _S_

**_h_** _j_ = 0 _,_

implying that the column set _{_ **_h_** _j_ _}_ _j_ _∈_ _S_ is linearly dependent.

24

We show Eq. ( B16 ) by contradiction. Assume for contradiction that rank( _H_ _S_ ) _≤_ _d_ _−_ 2\. Since the columns are

dependent, there exists a minimal dependent subset _D_ _⊆_ _S_ that satisfies 

_j_ _∈_ _D_ **_h_** _j_ = 0 and every nonempty proper

subset of _{_ **_h_** _j_ _}_ _j_ _∈_ _D_ is linearly independent. For such a _D_ , we have rank( _H_ _D_ ) = _|_ _D_ _| −_ 1 where _H_ _D_ is the restriction of

_H_ _S_ to the columns indexed by _D_ . Therefore,

_|_ _D_ _| −_ 1 = rank( _H_ _D_ ) _≤_ rank( _H_ _S_ ) _≤_ _d_ _−_ 2

_⇒_

_|_ _D_ _| ≤_ _d_ _−_ 1 _._

Let ¯ _P_ target _|_ _D_ be the restriction of ¯ _P_ target to the qubits in _D_ . By construction, 

_j_ _∈_ _D_ **_h_** _j_ = 0 holds, hence _P_ _D_ has

trivial syndrome and thus lies in the normalizer. Its weight is wt( _P_ _D_ ) = _|_ _D_ _| ≤_ _d_ _−_ 1 _< d_ . By the definition of the

code distance _d_ , no nontrivial logical operator can have weight _< d_ . Hence _P_ _D_ must be a stabilizer (up to a phase).

Now multiply _P_ target by this stabilizer _P_ _D_ ; this removes the factors on _D_ while keeping the syndrome trivial.

Repeating the same argument on the remaining support, we can decompose _P_ target as a product of stabilizers,

implying that it itself is a stabilizer, contradicting the nontriviality. Therefore, rank( _H_ _S_ ) _≥_ _d_ _−_ 1\.

Using this Lemma, we can prove the following Proposition.

**Proposition 1** (Construction of disjoint support partition) **.** _Let_ _C_ _be an_ [[ _n, k, d_ ]] _CSS code, and_ _M_ _be an odd number_

_satisfying_ _M_ _≤_ _d_ _. Then, Algorithm_ _1_ _outputs binary vectors_ _{_ ( **_A_** _m_ _,_ **_B_** _m_ ) _}_ _M_

_m_ =1 _such that_ _{_ _X_ **_A_** _m_ _Z_ **_B_** _m_ _}_ _M_

_m_ =1 _is a disjoint_

_support partition of_ ¯ _P_ target _in the sense of Definition_ _4_ _._

_Proof._ Algorithm 1 chooses _S_ _′_ ⊊ _S_ with _|_ _S_ _′_ _|_ = _M_ _−_ 1 such that _{_ **_h_** _j_ _}_ _j_ _∈_ _S_ _′_ are linearly independent, which exists by

Lemma 7 . Define

_P_ _m_ := _X_ **_A_** _m_ _Z_ **_B_** _m_ _._

Because any _P_ _m_ with 1 _≤_ _m_ _≤_ _M_ _−_ 1 act on distinct single qubits and _P_ _M_ acts on the remaining qubits, the supports

are pairwise disjoint and ¯ _Z_ target =  _M_

_m_ =1 _P_ _m_ .

For the condition where there is no proper subproduct on code space, note that **_s_** ( ¯ _P_ target ) = 0 and syndromes that

add up under multiplication of operators. Due to the independence of syndromes, for every nonempty proper subset

_R_ ⊊ [ _M_ ], it also holds that **_s_** ( 

_m_ _∈_ _R_ _P_ _m_ ) _̸_ = 0, which implies Π ⁰ ( 

_m_ _∈_ _R_ _P_ _m_ )Π ⁰ = 0 for every such _R_ . Together with

the above argument, _{_ _P_ _m_ _}_ _M_

_m_ =1 is a disjoint support partition of ¯ _P_ target .

**Algorithm 1:** Disjoint support partition for a general logical Pauli operator

**Input:** CSS check matrices _H_ _X_ _∈_ F _r_ _X_ _×_ _n_

2

, _H_ _Z_ _∈_ F _r_ _Z_ _×_ _n_

2

;

Target logical operator _P_ target = ¯

_X_ **_µ_** ¯ _Z_ **_ν_** = _X_ **_α_** _Z_ **_β_** .

**Output:** Disjoint support partition _{_ _X_ **_A_** _m_ _Z_ **_B_** _m_ _}_ _M_

_m_ =1 for _P_ target .

**1** _S_ _←_ supp( **_α_** ) _∪_ supp( **_β_** );

**2** **for** _j_ _∈_ _S_ **do**

**3**

**_h_** _j_ _←_ ( _α_ _j_ _H_ _Z_ (: _, j_ ) _, β_ _j_ _H_ _X_ (: _, j_ )) _∈_ F _r_ _Z_ \+ _r_ _X_

2

;

**4** Find _S_ _′_ ⊊ _S_ such that _|_ _S_ _′_ _|_ = _M_ _−_ 1 and _{_ **_h_** _j_ _}_ _j_ _∈_ _S_ _′_ are linearly independent, e.g., via Gaussian elimination;

**5** **for** _j_ _m_ _∈_ _S_ _′_ **do**

**6**

_X_ **_A_** _m_ _Z_ **_B_** _m_ _←_ ¯ _P_ target _|_ _j_ _m_ ;

**7** **_A_** _M_ _←_ **_α_** _−_  _M_ _−_ ¹

_m_ =1 **_A_** _m_ _,_

**_B_** _M_ _←_ **_β_** _−_  _M_ _−_ ¹

_m_ =1 **_B_** _m_ ;

**8** **return** _{_ ( **_A_** _m_ _,_ **_B_** _m_ ) _}_ _M_

_m_ =1 ;

With Lemma 6 and Proposition 1 , we complete the proof of Theorem 2 .

**Appendix C: Coherent error suppression in probabilistic implementation**

Let _H_ be the target Hilbert space of interest, and _L_ ( _H_ ) and _B_ ( _H_ ) be the set of linear operator and bounded linear

operators acting on _H_ . Let the diamond distance between two quantum maps Φ : _L_ ( _H_ ) _→ L_ ( _H_ ) and Ψ : _L_ ( _H_ ) _→ L_ ( _H_ )

be defined as follows,

_d_ _⋄_ (Φ _,_ Ψ) := _∥_ Φ _−_ Ψ _∥_ _⋄_ _/_ 2 _,_

(C1)

25

where the diamond norm for a map is defined using the trace norm _∥ · ∥_ 1 := Tr[

_√_

_··_ _†_ ] as

_∥_ Φ _∥_ _⋄_ =

max

_X_ _∈B_ ( _H_ )

_∥_ (Φ _⊗_ 1 )( _X_ ) _∥_ 1

_∥_ _X_ _∥_ 1

_._

(C2)

Now let us consider a Pauli Z rotation channel _R_ _θ_ = _e_ _iθZ_ _·_ _e_ _−_ _iθZ_ _._ It can be shown that the diamond distance from

the identity channel is

_d_ _⋄_ ( _R_ _θ_ _,_ _I_ ) = _d_ _⋄_ ( _R_ _−_ _θ_ _,_ _I_ ) = _|_ sin _θ_ _|_ _._

(C3)

Next, assume that we cannot implement the identity channel itself (or the noiseless target unitary channel), but we

have access to channels that deviate by _R_ _θ_ and _R_ _−_ _θ_ . Then, by simply taking the average over the channels, we can

quadratically suppress the error [ 47 ]:

_d_ _⋄_

 _R_ _θ_ \+ _R_ _−_ _θ_

2

_,_ _I_



= sin ² _θ._

(C4)

Furthermore, assume that the angles of the accessible channels _R_ _θ_ 1 _>_ 0 and _R_ _θ_ 2 _<_ 0 do not sum up to zero, i.e.,

_θ_ 1 \+ _θ_ 2 _̸_ = 0. Even in such a case, it can be shown that optimal mixture of two channels achieve quadratic improvement,

as follows [ 49 , 86 ]:

**Lemma 8.** _Let_ _R_ _θ_ 1 _and_ _R_ _θ_ 2 _be Z-rotation channels with_ _θ_ 1 _>_ 0 _and_ _θ_ 2 _<_ 0 _,_ _and let_ _p_ 1 _, p_ 2 _∈_ [0 _,_ 1] _satisfy_ _p_ 1 \+ _p_ 2 = 1 _._

_Then, it holds that_

min

_p_ 1 _,p_ 2 _d_ _⋄_ ( _p_ ¹ _R_ _θ_ ¹ \+ _p_ ² _R_ _θ_ ² _,_ _I_ ) _≤_ _ϵ_ ² _,_

(C5)

_where_ _ϵ_ = max _{_ _d_ _⋄_ ( _R_ _θ_ 1 _,_ _I_ ) _, d_ _⋄_ ( _R_ _θ_ 2 _,_ _I_ ) _}_ _._

**Appendix D: Details on numerics for repeat-until-success protocol**

**1\.**

**Decoders for repeat-until-success**

In the circuit-level repeat-until-success (RUS) simulations, the syndrome record contains two qualitatively different

contributions. The first is the usual signal caused by physical faults during syndrome extraction, and the second is

induced by weak transversal gadget. When only a single round of RUS is performed, as in the small angle regimes or

postselected case, we numerically found that it suffices to treat with an _one-step decoder_ which does not discriminate

two errors. Meanwhile, in the case when we perform multiple rounds of RUS, the failure in earlier rounds applies

physical Pauli operations to some physical qubits, and hence one must discriminate two errors so that memory

decoder would not harmfully introduce additional error. We refer to the RUS-aware decoder that separates these

two contributions before applying the ordinary memory decoder as the _two-step decoder_ , and describe how it is

implemented in the following.

Let _s_ ( _r_ )

raw be the raw syndrome obtained from the _r_ \-th round of RUS branch, and the syndromes stored in the

memory be given as _s_ ( _r_ _−_ 1)

mem and _s_ ( _r_ _−_ 1)

RUS

for the memory and RUS protocol, respectively. We first construct a detector

∆ _s_ ( _r_ ) = _s_ ( _r_ )

raw _⊕_ _s_ ( _r_ _−_ 1)

raw

. Then, one use a pre-computed lookup table that considers the entire neighboring check detector

pattern to decide whether this increment is attributed to error supported on the weak transversal gadget or not. This

enable us to split the detector as _d_ ( _r_ )

RUS _⊕_ _d_ ( _r_ )

mem = ∆ _s_ ( _r_ ) . The RUS detector _d_ ( _r_ )

RUS determines the physical operation

_E_ **_s_** applied to the logical support, and hence related with the logical angle applied to the system. This is used to

decide whether or not to terminate the RUS protocol. The memory detector _d_ ( _r_ )

mem is used to compute the memory

syndrome _s_ ( _r_ )

mem = _s_ ( _r_ _−_ 1)

mem _⊕_ _d_ ( _r_ )

mem , which is stored on a classical register. If the RUS protocol finishes in _R_ rounds, one

can perform decoding for the entire set of memory detector _{_ _d_ ( _r_ )

mem _}_ _R_

_r_ =1 _._

For the numerical simulation of weak transversal gadget, we have initialized the system so that no nontrivial

syndrome exists at the beginning of the RUS protocol, as _s_ (0)

raw = _s_ (0)

mem = _s_ (0)

RUS = 0. Also, after the RUS protocol,

we have performed transversal Pauli measurement on the data qubits, and thus the decoding graph for the memory

is similar to the ordinary memory experiment. We leave the extension to window decoding as an interesting future

work.

26

**2\.**

**Optimization of implementation policy**

The RUS protocol for weak transversal gadget is not unique, in the sense that we have degrees of freedom to choose

physical angles and termination condition. Here, we discuss how to optimize the protocol in two stages. First, we

use inexpensive repetition-code simulations, and, when appropriate, code-capacity branch-policy searches, to identify

promising termination policies and physical-angle rules. Second, we evaluate the resulting candidates in the circuit-

level surface-code simulation (using matrix product state, or MPS) and selected the best point after scanning the

maximum number of RUS rounds. This separation is useful because the latter is too expensive to optimize directly

over both the branch policy and the continuous physical angles.

For the one-step decoder, we optimized the physical angles by minimizing the trace distance between the output

logical state ¯ _ρ_ out and the ideal state ¯ _ρ_ ideal in the repetition-code density-matrix simulation:

_D_ tr ( _ρ_ out _, ρ_ ideal ) := ¹

2 _∥_ _ρ_ out _−_ _ρ_ ideal _∥_ ¹ _._

(D1)

The one-step decoder does not apply a Pauli-frame correction before the final maximum-likelihood decoding, so the

dominant effect of the angle optimization is to make the averaged logical output channel close to the target logical

rotation. As briefly mentioned in the privious subsection, for the small-angle regime considered in the surface-code

simulations, the best repetition-code strategy was obtained with a single RUS round, _R_ = 1, using the optimized

physical angle. As a representative example, for ¯ _θ_ target = 10 _−_ ⁴ , the unoptimized physical angle makes the trivial-

syndrome branch close to the target angle, but the rare nontrivial-syndrome branches produce a large opposite

rotation. The optimized physical angle shifts the trivial branch slightly away from the target so that the average

logical channel is much closer to the desired unitary. The same optimized _R_ = 1 one-step strategy was then used

in the circuit-level simulation for surface code, where it remained the best low-angle candidate among the strategies

tested.

For the two-step decoder, we considered a broader class of policies because the Pauli-frame correction makes the

result sensitive to the history of observed syndromes. We first tested fixed termination schedules, specified by a target

value of the Pauli correction weight _χ_ in each round. For instance, we denote _χ_ target = [0 _,_ 0 _,_ 1] to indicate that the

RUS protocol terminates if _χ_ = 0 for the first and second round, and _χ_ = 1 for larger number of rounds. For these

fixed schedules, we compared analytic, unoptimized physical angles against physical angles optimized in the density-

matrix simulation for repetition code. While we did not exhaustively explore in this work, the policy family can be

even more diverse; we may perform a search over history-dependent branch policies based on the code-capacity noise

model. Namely, the target termination value of _χ_ can be chosen from the current branch history: the first round uses

a root target, the next two failed rounds use maps depending on the last recorded _χ_ , and later failed rounds use a tail

map. It is interesting direction how to efficiently optimize over such policies, and to investigate what is the potential

room of further improvement.

**3\.**

**Error metric**

In the code-capacity simulations in the main text, we evaluate the logical channel itself and report the diamond

distance _d_ _⋄_ from the target logical unitary. This channel-level metric is natural for comparing coherent logical errors,

but it becomes numerically expensive in the circuit-level simulations. In particular, reconstructing the full logical

channel for a surface-code repeat-until-success circuit would require simulating the logical process for multiple input

states while resolving the measurement-feedback branches. We therefore use state-based error metrics for the circuit-

level simulations.

For the circuit-level data, we initialize the logical qubit in _|_ 0 _L_ _⟩_ and compare the decoded output state _ρ_ out with

the ideal output state _ρ_ id for the same target angle ¯ _θ_ target . When direct density-matrix simulation is available, we

compute the trace distance between the output logical state ¯ _ρ_ out and the ideal state ¯ _ρ_ ideal as

_D_ tr ( _ρ_ out _, ρ_ ideal ) := ¹

2 _∥_ _ρ_ out _−_ _ρ_ ideal _∥_ ¹ _._

(D2)

For circuit-level simulation for the surface code, we instead estimate an effective error from the logical Pauli expectation

value. For the logical _X_ \-rotation instances considered in the circuit-level simulations, the ideal output from _|_ ¯ 0 _⟩_ satisfies

_⟨_ ¯ _Z_ _⟩_ ideal = cos



2 ¯ _θ_ target



_,_

_⟨_ ¯ _Y_ _⟩_ ideal = sin



2 ¯ _θ_ target



_,_

(D3)

up to the sign convention for the rotation direction. We define

_ϵ_ _Z_ := ¹

2

 _⟨_ ¯ _Z_ _⟩_ out _− ⟨_ ¯ _Z_ _⟩_ ideal

 _,_

_ϵ_ _Y_ := ¹

2

 _⟨_ ¯ _Y_ _⟩_ out _− ⟨_ ¯ _Y_ _⟩_ ideal

 _._

(D4)

27

10

5

10

4

10

3

10

2

target angle

10

9

10

8

10

7

10

6

10

5

10

4

error

Repetition exact-DM components for adopted strategies

TD, 1-step

TD, 2-step

Z , 1-step

Z , 2-step

Y , 1-step

Y , 2-step

FIG. 10.

Validation of the circuit-level error metric using exact density-matrix simulations of the bit-flip repetition code. We

compare the trace distance from the ideal logical output state with the effective errors inferred from logical Pauli expectation

values, _ϵ_ _Z_ and _ϵ_ _Y_ , for the same class of repeat-until-success strategies used in the surface-code simulations. In both the optimized

one-step-decoder regime and the two-step-decoder regime, _ϵ_ _Z_ closely tracks the trace distance, whereas _ϵ_ _Y_ is subdominant.

In general, such expectation-value deviations are only lower bounds on the trace distance: for any observable _O_ with

_∥_ _O_ _∥_ _∞_ _≤_ 1, since ¹

2 _|_ Tr [ _O_ ( _ρ_ _−_ _σ_ )] _| ≤_ _D_ tr ( _ρ, σ_ ). In this sense, although _ϵ_ _Z_ and _ϵ_ _Y_ are not guaranteed to reproduce the

full error for an arbitrary logical noise channel, we find that the proxy _ϵ_ _Z_ is in particular faithful for simulations in

this work.

In Fig. 10 , we show the numerical results of exact density-matrix circuit-level simulations for the bit-flip repetition

code. The _Z_ \-expectation-based estimate _ϵ_ _Z_ reproduces the trace distance over the relevant range of target angles and

for both decoder choices. The _Y_ \-expectation contribution is much smaller in the optimized one-step-decoder regime

and remains below the dominant _Z_ component in the two-step-decoder regime. This indicates that the trace distance

is dominated by the component visible in _⟨_ _Z_ _L_ _⟩_ for the RUS strategies considered here.

The circuit-level simulation of the surface code does not give the full logical channel at comparable cost, but their

error curves follow the same qualitative envelope as the circuit-level simulation of the bitflip code. Moreover, the

memory-only checks show that the independent memory contribution is suppressed below the RUS-induced error in

the relevant parameter regime. We therefore use _ϵ_ _Z_ as the reported effective circuit-level error rate for surface code

as well.

**4\.**

**Error scaling for small angles**

Here, we briefly explain the error scaling of code-capacity simulation quoted in the main text. In the small-angle

regime, the ordinary RUS envelope is governed by first-order support faults that cause the decoder to assign a

neighboring RUS branch. The probability of such a branch-misclassification event is _O_ ( _p_ phys ). Expanding Eq. ( 13 )

around the branch selected by the optimized policy and using the small-angle relation _θ_ = _O_ ( ¯ _θ_ ¹ _/M_ ), the residual

logical-angle error associated with one such misclassified branch scales as _O_ ( ¯ _θ_ ¹ _−_ ¹ _/M_ ) for the code-capacity policy used

in Fig. 3 (b). The induced diamond distance therefore scales as

_d_ RUS

_⋄_

= _O_



_p_ phys ¯ _θ_ ¹ _−_ ¹ _/M_ 

\+ _O_ ( _p_ ²

phys ) _,_

(D5)

up to constants depending on the selected branch policy. This estimate is intended for the ordinary RUS envelope; the

diluted protocol changes the angle dependence by probabilistically mixing this larger-angle channel with the identity

channel, as discussed in Appendix C .

28

Target ¯ _θ_

Logical error ¯ _p_ eff

_Z_

Decoder Best _R_

Policy

5 _×_ 10 _−_ ⁵

(3 _._ 00 _±_ 1 _._ 73) _×_ 10 _−_ ⁶

1-step

1

_χ_ target = [0]; optimized

1 _×_ 10 _−_ ⁴

(3 _._ 99 _±_ 2 _._ 00) _×_ 10 _−_ ⁶

1-step

1

_χ_ target = [0]; optimized

2 _×_ 10 _−_ ⁴

(1 _._ 50 _±_ 0 _._ 39) _×_ 10 _−_ ⁵

1-step

1

_χ_ target = [0]; optimized

3 _×_ 10 _−_ ⁴

(2 _._ 39 _±_ 0 _._ 49) _×_ 10 _−_ ⁵

1-step

1

_χ_ target = [0]; optimized

5 _×_ 10 _−_ ⁴

(5 _._ 48 _±_ 0 _._ 74) _×_ 10 _−_ ⁵

1-step

1

_χ_ target = [0]; optimized

1 _×_ 10 _−_ ³

(1 _._ 30 _±_ 0 _._ 11) _×_ 10 _−_ ⁴

1-step

1

_χ_ target = [0]; optimized

2 _×_ 10 _−_ ³

(3 _._ 52 _±_ 0 _._ 19) _×_ 10 _−_ ⁴

2-step

15

_χ_ target = [0 _,_ 0 _,_ 1]; unoptimized

5 _×_ 10 _−_ ³

(4 _._ 48 _±_ 0 _._ 22) _×_ 10 _−_ ⁴

2-step

28

_χ_ target = [0 _,_ 1]; unoptimized

1 _×_ 10 _−_ ²

(5 _._ 06 _±_ 0 _._ 25) _×_ 10 _−_ ⁴

2-step

21

_χ_ target = [0 _,_ 0 _,_ 1];unoptimized

1 _._ 5 _×_ 10 _−_ ² (6 _._ 37 _±_ 0 _._ 29) _×_ 10 _−_ ⁴

2-step

15

_χ_ target = [0 _,_ 1]; unoptimized

2 _×_ 10 _−_ ²

(5 _._ 65 _±_ 0 _._ 31) _×_ 10 _−_ ⁴

2-step

20

_χ_ target = [0 _,_ 1]; unoptimized

3 _×_ 10 _−_ ²

(7 _._ 22 _±_ 0 _._ 40) _×_ 10 _−_ ⁴

2-step

20

_χ_ target = [0 _,_ 1]; unoptimized

TABLE III. Implemented protocols used for the rotated surface-code circuit-level simulations with _d_ = _M_ = 3. The logical error

is the _Z_ \-based effective logical error from the hook-aware circuit level simulation for surface code using MPS at _p_ phys = 10 _−_ ⁴

with depolarizing physical noise; the uncertainty denotes one standard error from the 10 ⁶ \-shot estimates. _χ_ target indicates the

target value of _χ_ used at _r_ \-th round. The “optimized” policy indicates that physical angles are optimized to minimize the

diamond distance for circuit-level density matrix simulation using _d_ = 3 repetition code.

**5\.**

**Implemented protocol**

For the rotated surface-code circuit-level simulations with _d_ = _M_ = 3, we used the protocols summarized in

Table III . The reported logical error is the _Z_ \-based effective logical error estimated by the circuit level simulation of

surface code using MPS.

**Appendix E: CNOT scheduling during syndrome extraction**

As described in the main text, a weak transversal Pauli rotation can be implemented by first applying _M_ physical

Pauli rotations and subsequently performing syndrome extraction. When _M_ equals the physical Pauli weight of the

target logical operator, the physical rotations can be chosen to be single-qubit rotations, so the additional circuit

overhead is essentially negligible.

In contrast, when _M_ is strictly smaller than the weight of the target logical

operator, at least some of the physical rotations are multiqubit Pauli rotations. Because most hardware platforms

do not natively support arbitrary multiqubit Pauli rotations, a direct implementation would require decomposing

them into single-qubit Pauli rotations sandwiched by entangling gates, thereby introducing additional opportunities

for noise.

In this Appendix, we show how this additional overhead can be suppressed by embedding the required multiqubit

rotations into the syndrome-extraction circuit. The mechanism uses the same error-propagation structure that gives

rise to hook errors; we refer to the deliberate use of this structure as _hook doping_ . We illustrate the construction for

the _d_ = 7 rotated surface code with _M_ = 5 in Fig. 11 . The basic idea is to push physical rotation gates inside the

syndrome-extraction circuit with modified CNOT ordering so that conjugation by the surrounding CNOTs maps the

rotations to the desired physical Pauli rotations. Although the resulting hook-doped schedule reduces the memory

fault distance, we find that such a reduction does not affect the overall logical error rate in the parameter regime

where the intrinsic error of the weak transversal protocol is the dominant contribution.

To implement a weak transversal gate using _M < d_ physical rotations, we intentionally introduce the corresponding

hook propagation. As an example, Fig. 11 (c) shows a partial modification of the CNOT-layer ordering for _Z_ \-type

stabilizers. This schedule has three useful properties:

• The CNOT depth is unchanged; no additional CNOT layer is required.

• _X_ \-type syndrome extraction is unaffected, so the fault distance for the logical _X_ operator remains _d_ = 7.

• Although the fault distance for the logical _Z_ operator is reduced to 5, the effect on the overall performance is

small.

29

(a)

(b)

 _|_ \+ _→_

Z

X

X

Z

X

Z

X

Z

2

3

4

1

=

_M_ _X_

Z

X X

Z 3

4

1

_M_ _Z_

 _|_ 0 _→_

X

Z

X

Z

2

=

**X stabilizer**

**Z stabilizer**

**No harmful hooks**

(c)

**Partial hook-doped**

(d)

**Full hook-doped**

FIG. 11. (a) Graphical notation for CNOT orderings for _X_ \- and _Z_ \-type stabilizer measurements. (b) An ordinary syndrome-

extraction schedule that preserves the code distance of 7 at the circuit level. (c) A hook-doped schedule. The blue strokes

indicate the modified parts of the schedule, which intentionally invokes harmful hooks for the sake of implementing ZZ rotation

gate. Here the fault distance is 5. (d) Fully hook-doped schedule. Here the fault distance is 4.

_R_ _Z_

_R_ _Z_

_R_ _Z_

_R_ _Z_

_R_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _Z_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _X_

_M_ _Z_

_M_ _Z_

_M_ _Z_

**Measure**

**Initialize**

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ 0 _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ 0 _→_

 _|_ 0 _→_

**Layer 1**

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

X

Z

X

Z

Z

X

Z

X

Z

X

X

Z

X

Z

X

Z

**Layer 2**

**Layer 3**

**Layer 4**

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

X

Z

Z

X

Z

X

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

X

Z

Z

X

Z

X

Z

X

Z

X

Z

X

X

Z

**gate**

_R_ _z_

_R_ _ZZ_

_R_ _Z_

_R_ _Z_

_R_ _Z_

_R_ _ZZ_

**Pauli rotation +**

**syndrome extraction**

**=**

FIG. 12. Full circuit description of weak transversal Z rotation for surface code of _d_ = 7 with _M_ = 5 rotation gates.

For the first point, Fig. 12 shows that the schedule indeed contains no additional CNOT layers beyond the original

four. The only extra layer is an _R_ Z layer, which is much faster than entangling gates on most platforms and can be

virtual on superconducting devices. To verify the second and third points, we performed numerical simulations; see

Fig. 13 . Because _X_ \-type syndrome extraction is unchanged, the logical-error-rate scaling _O_ ( _p_ ⁴ ) for the _Z_ \-memory

circuit remains consistent with fault distance 7. By contrast, in the partially hook-doped circuit, the fault distance

for logical _Z_ errors is reduced to 5, consistent with an _O_ ( _p_ ³ ) scaling. We also simulated a fully hook-doped schedule

obtained by reversing the CNOT ordering for all _Z_ \-type stabilizers. In this case the fault distance drops to _⌈_ _d/_ 2 _⌉_ = 4,

giving an _O_ ( _p_ ² ) logical-error-rate scaling.

Although the drop of fault distance is undesirable from the viewpoint of quantum memory, its quantitative impact

is limited in the regime of interest. For instance, at _p_ phys = 10 _−_ ⁴ , the memory logical error rate remains below 10 _−_ ⁷ .

This value is comparable to the logical error rate of in-place Pauli rotations only when the target logical angle is as

small as ¯ _θ_ ≲ 10 _−_ ⁵ . By contrast, for practical computations using a distance-7 surface code, we expect the relevant

regime to be ¯ _θ_ ≳ 10 _−_ ⁴ , in which the intrinsic error of the weak-transversal rotation dominates over the additional

memory error introduced by hook doping. Thus, in this regime, hook doping does not degrade the overall performance.

In summary, this example shows that a modified syndrome-extraction schedule can be used to implement multiqubit

Pauli rotations required for weak transversal gates without adding CNOT depth. Although the discussion here focused

on a single rotated-surface-code patch, the same idea can in principle be applied to more general codes, provided

that the relevant Pauli rotations can be embedded into their syndrome-extraction circuits through controlled error

30

Logical Error Rate

Physical Error Rate

FIG. 13. Logical error rate in memory experiments for the _d_ = 7 rotated surface code after _d_ rounds of syndrome extraction.

The red and green data points show the results of _X_ \- and _Z_ \-type memory experiments, respectively. Circle, square, and triangle

markers correspond to the harmful-hook-free schedule, the partially hook-doped schedule shown in Fig. 11 (c), and the fully

hook-doped schedule, respectively.

propagation.

**Appendix F: Resource estimation details for the megaquop benchmark**

In this appendix, we give the formulas used to compute the timestep _τ_ , the number of active physical qubits _N_ phys ,

and the total logical error rate ¯ _p_ tot for the megaquop benchmark in Sec. III B .

**1\.**

**Surface code**

_a._

_Clifford+T compilation_

In general, when we consider Clifford+T compilation of a quantum circuit, all the non-Clifford gates are first

synthesized so that all gates are given as a sequence of Clifford and T gates. Regarding the benchmarked circuit, this

can be done by simply performing the single-qubit gate synthesis of the rotation gate. Here we employ the ancilla-free

near-optimal synthesis algorithm proposed in Ref. [ 75 ], which requires approximately 3 log 2 (1 _/ε_ ) + _O_ (1) T gates to

implement a single rotation gate up to accuracy of _ε._ These T gates are implemented via gate teleportation consuming

a single magic state that is distilled once [ 60 ]. For Clifford gates, we implement CNOT using lattice surgery [ 58 ],

Hadamard gate by transversal gate followed by logical patch rotation [ 59 , 60 ], and S gate via lattice surgery [ 60 ].

That said, the total error can be estimated as follows,

¯ _p_ tot = ¯ _p_ dec \+ ¯ _p_ dis \+ ¯ _p_ syn _,_

(F1)

where ¯ _p_ dec _,_ ¯ _p_ dis _,_ ¯ _p_ syn are decoding error, distillation error, and synthesis error, respectively [ 86 ]. Explicitly broken

down, the individual expression of errors are given as follows:

¯ _p_ dec = _N_ CNOT _·_ ¯ _p_ CNOT \+ _N_ H _·_ ¯ _p_ H \+ _N_ S _·_ ¯ _p_ S _,_

(F2)

¯ _p_ dis = _N_ T _·_ ¯ _p_ _T_ _,_

(F3)

¯ _p_ syn = _N_ rot _·_ _ε_ syn _,_

(F4)

31

Instruction Cycles _t_ _i_ Timestep _τ_ _i_ Logical Error ¯ _p_ _i_

CNOT

14

84

1 _._ 4 _×_ 10 _−_ ⁸

Hadamard

21

126

2 _._ 1 _×_ 10 _−_ ⁸

S

7

42

7 _._ 0 _×_ 10 _−_ ⁹

T

18\.1

109

6 _._ 2 _×_ 10 _−_ ⁸

TABLE IV. Cost for elementary instructions in Clifford+T compilation using surface code of code distance _d_ = 7 on 2d planar

architecture. Here, logical error rates for Clifford gates are computed as ¯ _p_ _·_ _t_ _i_ where ¯ _p_ = 0 _._ 1( _p_ phys _/p_ th )

_d_ \+1

2

is the logical error

rate per code cycle under threshold error rate of _p_ th = 0 _._ 01\. For physical error rate of _p_ phys = 10 _−_ ⁴ and code distance of _d_ = 7,

the logical error rate per cycle is ¯ _p_ = 1 _._ 0 _×_ 10 _−_ ⁹ . The number of code cycles, _t_ CNOT _/_ H _/_ S are 2 _d_ , 3 _d_ , and _d_ for CNOT, H, and S

gates, respectively [ 60 ].

Instruction

Cycles _t_ _i_ Timestep _τ_ _i_ Logical Error ¯ _p_ _i_

CNOT

14

84

1 _._ 4 _×_ 10 _−_ ⁸

In-place rotation

( _θ_ = 0 _._ 001)

\-

180

9 _._ 6 _×_ 10 _−_ ⁵

TABLE V. Cost for elementary instructions of Clifford+ _ϕ_ compilation in surface code of code distance _d_ = 7 on 2d planar

architecture.

where _N_ CNOT _/_ S _/_ H _/_ T _/_ rot is the number of each gate in the circuit, ¯ _p_ CNOT _/_ S _/_ H _/_ T is the logical error rate per gate that

is estimated as given in Table IV . The gate synthesis error per each rotation gate, _ε_ syn , is homogeneously taken to be

10 _−_ ⁴ .

The total timesteps are estimated as follows,

_τ_ =

\#gates



_i_ =1

_τ_ _i_ _,_

(F5)

where _τ_ _i_ indicates the timestep for the _i_ \-th gate operation. Each _τ_ for the instruction set architecture (ISA) is given

in Table IV .

Finally the number of active physical qubits is computed assuming the qubit plane layout as shown in Fig. 4 (b) as

_N_ phys = 1 _._ 5 ² _N_ _·_ 2 _d_ ² \+ _n_ _F_ _A_ _F_ _,_

(F6)

where _n_ _F_ is the number of magic state factories and _A_ _F_ is the number of physical qubits per magic state factory. For

the sake of comparison with the bicycle architecture (Sec. F 2 a ), here we take _n_ _F_ = 1, and use _A_ _F_ = 810 following

Ref. [ 61 ].

_b._

_Clifford+_ _ϕ_ _compilation_

When we use in-place Pauli rotation, the total error rate can be estimated as follows,

¯ _p_ tot = ¯ _p_ dec \+ ¯ _p_ rot _,_

(F7)

where ¯ _p_ dec is the decoding error as introduced in the previous section, and ¯ _p_ rot is the error of in-place rotation. Using

the phenomenological simulation presented in Sec. III A , we assume that the logical error rate per logical Z rotation

is 9 _._ 6 _×_ 10 _−_ ⁵ _._ As we summarize in Table V , the costs for Clifford gates are taken to be the same as in Clifford+T

compilation.

For the timesteps, we estimate as

_τ_ tot =



_i_

_τ_ _i_ _,_

(F8)

where _τ_ _i_ is the timestep required to execute the _i_ \-th instruction. As summarized in Table V , the timesteps for Clifford

gates are taken to be the same as in Section F 1 a . For the in-place Pauli rotation, we fix the number of iterations

to 30 to give a conservative estimate, while in reality it may finish in fewer iterations. We foresee that dynamical

32

Instruction

Timestep _τ_ _i_ Logical Error ¯ _p_ _i_

idle

8

1 _._ 4 _×_ 10 _−_ ¹⁵

shift automorphism

12

6 _._ 1 _×_ 10 _−_ ¹⁴

in-module meas.

120

1 _._ 0 _×_ 10 _−_ ⁹

inter-module meas.

120

4 _._ 8 _×_ 10 _−_ ⁸

T injection

73+120

8 _._ 8 _×_ 10 _−_ ⁷

TABLE VI. Cost for elementary instructions of Pauli-based computation in gross code [ 53 ].

recompilation of circuits [ 87 ] can further reduce the runtime. At each iteration, we assume _d_ rounds of syndrome

extraction, with the first round preceded by the Pauli rotation as discussed in Sec. E . While such an additional

operation may naively seem to increase the number of timesteps, we find that there is no overhead to perform in-place

Z rotation (See Appendix E ) in this case. Therefore, the number of timesteps is obtained by multiplying the number

of code cycles by 6.

The number of active physical qubits is computed assuming the qubit plane layout shown in Fig. 4 (c) as

_N_ phys = 1 _._ 5 ² _N_ _·_ 2 _d_ ² _._

(F9)

**2\.**

**Gross code**

_a._

_Pauli-based computation_

Pauli-based computation is a way of compiling a quantum circuit into one composed entirely of Pauli rotation

and Pauli measurements (allowing multiqubit Paulis) [ 60 , 62 ]. Pauli operators are conjugated so that Clifford gates

no longer appear explicitly in the circuit. As a result, the circuit can be expressed by the instructions indicated in

Table VI .

The timesteps are calculated by a public code available in Ref. [ 88 ].

The number of active physical qubits is provided as

_N_ phys = _N_ patch _·_ ( _c_ \+ _u_ \+ _a_ ) _−_ _a_ \+ _a_ _′_ \+ _n_ _F_ _A_ _F_ _,_

(F10)

where _N_ patch is the number of gross code modules, _c_ = 288 is the number of physical qubits within each gross code

module, _u_ = 90 indicates the contribution from the logical processing unit, _a_ = 22 is required for adapter between

gross codes, and _a_ _′_ = 13 is for adapter between a gross code and magic state factory. We assume that the magic

states are prepared by level-1 distillation for a surface code of distance 7, and hence _A_ _F_ = 810. Since we consider the

Pauli-based computation, we take _n_ _F_ = 1.

_b._

_Clifford+_ _ϕ_ _compilation_

In Clifford+ _ϕ_ compilation, we rather aim to implement the Clifford gates using the in-module and inter-module

measurements interleaved by shift automorphisms. For instance, a CNOT gate can be decomposed into XX and ZZ

measurements followed by Pauli correction. In order to perform resource estimation of the benchmarked circuit, we

first calculate the cost for performing CNOT for all neighbors as 

_i_ :odd CNOT _i,i_ \+1



_i_ :even CNOT _i,i_ \+1 , whose results

are shown in Table VII . For the in-place Pauli rotation, we assume the scheme uses _M_ = 5 physical rotations, and

fix the number of iterations to 30, as in the surface-code case. However, unlike the surface code, the logical support

provided in Ref. [ 53 ] does not allow us to implement all multi-Z rotations mediated by Z-check ancilla qubits; instead,

we must use X-check ancilla qubits. This forces us to switch the basis between X and Z, and hence imposes 2 additional

physical CNOT layers. Since the number of timesteps is 8 for a single round of syndrome extraction, we need 10

timesteps when we introduce physical rotation gates.

The number of active physical qubits is provided as

_N_ phys = _N_ patch _·_ ( _c_ \+ _u_ \+ _a_ ) _−_ _a._

(F11)

Note that there is no need for a magic state factory or the adapter between a gross code patch and a magic state

factory.

33

Instruction

Max. logical per patch Timestep _τ_ _i_ Logical Error ¯ _p_ _i_

idle

Any

8

1 _._ 44 _×_ 10 _−_ ¹⁵

CNOT for all neighbors

11

42768

3 _._ 4 _×_ 10 _−_ ⁶

6

17976

3 _._ 2 _×_ 10 _−_ ⁶

4

10200

3 _._ 0 _×_ 10 _−_ ⁶

3

6864

3 _._ 3 _×_ 10 _−_ ⁶

Simultaneous in-place _Z_ rot.

11

1500

1 _._ 0 _×_ 10 _−_ ²

6

600

1 _._ 0 _×_ 10 _−_ ²

4

600

1 _._ 0 _×_ 10 _−_ ²

3

600

1 _._ 0 _×_ 10 _−_ ²

TABLE VII. Cost of instructions in the Clifford+ _ϕ_ formalism for the gross code. The logical rotation angles are homogeneously

taken as ¯ _θ_ = 0 _._ 001\.

**Appendix G: Analysis of small angle rotation gate cost under postselection**

Here, we explain the scaling shown in Table II in the main text. As mentioned, we assume here that logical qubits

are encoded into surface code of distance _d_ . Therefore, the fallback recursion of teleportation-based rotation gates

terminates at the fault-tolerant _S_ gate.

With angle-agnostic injection, an arbitrary single-qubit state can be injected into the surface code with a logical

error rate of ²

5 _p_ and logical qubitcycle cost of _O_ ( _d_ ) [ ⁷⁰ ]. The injected states may also be distilled using the Meier-

Eastin-Knill (MEK) protocol [ 34 , 46 ], which uses the [[4 _,_ 2 _,_ 2]] code to obtain quadratic error suppression. Writing

the cost of an _R_ _l_ gate as C _R_ _l_ and the nonrecursive MEK overhead as C MEK _l_ , the fallback recursion gives

C _R_ _l_ = C _|_ _M_ _l_ _⟩_ \+ 0 _._ 5 C _R_ _l_ _−_ 1 = C _R_ _l_ _−_ 1 \+ 0 _._ 5 C MEK _l_ _._

(G1)

For angle-agnostic injection, C MEK _l_ = _O_ ( _d_ ) is independent of _l_ , giving C _R_ _l_ = _O_ ( _dl_ ).

Angle-dependent injection improves the error of the injected magic state to _O_ ( _p_ phys ¯ _θ_ _α_ ) with _α_ = 2(1 _−_ 1 _/M_ ).

However, after the fallback recursion, the logical error of the implemented gate scales only as _O_ ( _p_ phys ¯ _θ_ ) [ 19 ], unless

one relies on unitary synthesis [ 89 ]. The lower-level fallback rotations dominate because the fallback probability is

reduced by a factor of two per level, whereas the angle-dependent error grows by a factor 2 _α_ _>_ 2 when moving down

one level. The numerical data in Fig. 6 (a) confirm this behavior, and the circuit volume approaches

14 _d_ \+ _O_ ( _d_ ² 2 _−_ ² _l/d_ ) _,_

(G2)

which is the sum of state preparation with cost _V_ _L_ _∼_ _d_ \+ _O_ ( _d_ ² 2 _−_ ² _l/d_ ), a CNOT gate with _V_ _L_ _∼_ 4 _d_ , and measurement

feedback with cost _V_ _L_ _∼_ 2 _d_ . Since the expected number of fallback steps is two, we obtain the above expression.

For the weak transversal gates, the relevant acceptance event is the absence of a syndrome. For an _M_ \-rotation

weak transversal gadget realizing a logical angle ¯ _θ_ , the no-syndrome probability is

_P_ success = _p_ _χ_ =0 = _|_ cos _θ_ _|_ ² _M_ \+ _|_ sin _θ_ _|_ ² _M_ _≈_ 1 _−_ _M_ ¯ _θ_ ² _/M_ _._

(G3)

The dominant contribution to the logical error is the _χ_ = 1 event being misclassified as _χ_ = 0. This occurs with

probability of _p_ _χ_ =1 _·_ ( _Mp_ phys ) = _O_ ( _p_ phys _Mθ_ ² ), and results in diamond norm error of _O_ ( _θ_ ² _M_ _−_ ⁴ ), and hence the overall

error is _O_ ( _p_ phys _Mθ_ ² _M_ _−_ ² ) = _O_ ( _p_ phys _M_ ¯ _θ_ 2(1 _−_ ¹ _/M_ ) ). Due to the superlinear scaling with the angle, the logical error can

be reduced by segmenting the desired rotation into _r_ rotations of angle ¯ _θ/r_ :

(Diamond norm error) = _O_



_r_ _·_ _p_ phys _M_

 ¯ _θ/r_

 2(1 _−_ 1 _/M_ ) 

= _O_ ( _p_ phys _M_ ¯ _θ_ 2(1 _−_ ¹ _/M_ ) _r_ ² _/M_ _−_ ¹ ) _._

(G4)

The corresponding success probability is

_P_ success _≈_



1 _−_ _M_

 ¯ _θ_

_r_

 2 _/M_  _r_

_,_

(G5)

so the expected spacetime cost is estimated as

C _R_ _l_ = _rd/P_ success = _rd_ \+ _O_ ( _dMr_ ² _−_ ² _/M_ 2 _−_ ² _l/M_ ) _,_

(G6)

for _l_ _≫_ 1\. Note that this cost analysis assumes that the spacetime cost of the gate preceding the weak transversal gate

is negligibly small, such as graph state preparation. The segmentation parameter therefore controls the error-volume

tradeoff: larger _r_ improves the logical error but also increases the baseline volume _rd_ .

34

**Appendix H: Meier-Eastin-Knill protocol for distillation of equatorial magic states**

Here, we provide a brief review on the distillation protocol for equatorial states proposed by Meier-Eastin-Knill [ 34 ]

and later improved by Campbell and O’Gorman [ 46 ]. We hereby refer to the protocol as the MEK protocol. We denote

by _|_ _M_ _k_ _⟩_ = _R_ _k_ _|_ \+ _⟩_ = _R_ Z

 _π_

2 _k_



_|_ \+ _⟩_ the magic state for Pauli rotation gate from the _k_ \-th level of Clifford hierarchy, and

also denote by _H_ _k_ = _R_ _k_ _XR_ _†_

_k_ the unitary and Hermitian operator that stabilizes _|_ _M_ _k_ _⟩_ . In short, the MEK protocol

performs a parity check on _|_ _M_ _k_ _⟩_ regarding _H_ _l_ , using the four qubit code which is also known as the _C_ 4 code (see

Fig. 14 ).

Thanks to the [[4, 2, 2]] code, the errors of non-Clifford _R_ 3 gates can be suppressed up to quadratic factor. On the

other hand, the non-Clifford _R_ _†_

_l_ _−_ 1 is not encoded, and hence contributes linearly to the total error rate. By performing

numerical analysis neglecting the correlations of noise, we find that the total error rate per distilled magic state _ϵ_ _′_

_l_

can be written as

_ϵ_ _′_

_l_ = 8 _ϵ_ ²

3 \+ _ϵ_ ²

_l_ \+ _ϵ_ ²

2 \+ 1

4 _η_ _l_ _−_ ¹ \+ 3

20 _η_ _F_ \+ 1

16 _η_ CNOT _,_

(H1)

where _ϵ_ _l_ and _ϵ_ CNOT are the error rate per magic state for the _l_ \-th level of Clifford hierarchy and CNOT gate, _η_ _l_ _−_ 1

is the error rate of the _R_ _l_ _−_ 1 gate, _η_ _F_ is the error rate of the encoding circuit into the four qubit code, and _η_ CNOT is

the error rate of the CNOT layer. Note that _ϵ_ and _η_ indicate whether the error is quadratically suppressed or not.

For instance, the input magic state infidelity and T gate error can be suppressed quadratically, while the error in the

mid-circuit _R_ _l_ _−_ 1 cannot be. Due to the fact that the _R_ _l_ _−_ 1 gate is not protected by the [[4,2,2]] code, we must ensure

that the gate is implemented with high accuracy, and hence it is called the “pivot gate.” This has motivated us to

perform an additional round of distillation for the magic state corresponding to _R_ _l_ _−_ 1 .

[1] S. Bravyi and A. Kitaev, Universal quantum computation with ideal clifford gates and noisy ancillas, Physical Review A

**71** , 022316 (2005) .

[2] E. Knill, Fault-tolerant postselected quantum computation: Schemes, arXiv:quant-ph (2004), quant-ph/0402171 .

[3] L. Babai, P. Codenotti, J. A. Grochow, and Y. Qiao, Code equivalence and group isomorphism, in _Proceedings of the_

_Twenty-Second Annual ACM-SIAM Symposium on Discrete Algorithms_ , SODA ’11 (Society for Industrial and Applied

Mathematics, USA, 2011) p. 1395–1408.

[4] M. A. Webster, A. O. Quintavalle, and S. D. Bartlett, Transversal diagonal logical operators for stabiliser codes, New

Journal of Physics **25** , 103018 (2023).

[5] S. Bravyi and J. Haah, Magic state distillation with low overhead, Physical Review A **86** , 052329 (2012) .

[6] H. Bomb´ın, Gauge color codes: Optimal transversal gates and gauge fixing in topological stabilizer codes, New Journal of

Physics **17** , 083002 (2015) .

[7] A. Paetznick and B. W. Reichardt, Universal fault-tolerant quantum computation with only transversal gates and error

correction, Phys. Rev. Lett. **111** , 090505 (2013) .

[8] M. Vasmer and D. E. Browne, Three-dimensional surface codes: Transversal gates and fault-tolerant architectures, Phys.

Rev. A **100** , 012312 (2019) .

[9] S. Nagayama, A. G. Fowler, D. Horsman, S. J. Devitt, and R. Van Meter, Surface code error correction on a defective

lattice, New Journal of Physics **19** , 023050 (2017).

[10] J. M. Auger, H. Anwar, M. Gimeno-Segovia, T. M. Stace, and D. E. Browne, Fault-tolerance thresholds for the surface

code with fabrication errors, Phys. Rev. A **96** , 042316 (2017) .

[11] A. Strikis, S. C. Benjamin, and B. J. Brown, Quantum computing is scalable on a planar array of qubits with fabrication

defects, Physical Review Applied **19** , 064081 (2023).

[12] D. M. Debroy, M. McEwen, C. Gidney, N. Shutty, and A. Zalcman, Luci in the surface code with dropouts, arXiv preprint

arXiv:2410.14891 (2024).

[13] C. Leroux, S. F. Lin, P. Bienias, K. R. Sankar, A. Benhemou, A. Kubica, and J. K. Iverson, Snakes and ladders: Adapting

the surface code to defects, arXiv preprint arXiv:2412.11504 (2024).

[14] M. B. Hastings and J. Haah, Dynamically generated logical qubits, Quantum **5** , 564 (2021).

[15] A. Eickbusch, M. McEwen, V. Sivak, A. Bourassa, J. Atalaya, J. Claes, D. Kafri, C. Gidney, C. W. Warren, J. Gross,

_et al._ , Demonstrating dynamic surface codes, arXiv preprint arXiv:2412.14360 (2024).

[16] H. Choi, F. T. Chong, D. Englund, and Y. Ding, Fault tolerant non-clifford state preparation for arbitrary rotations, arXiv

preprint arXiv:2303.17380 (2023).

[17] J. Gavriel, D. Herr, A. Shaw, M. J. Bremner, A. Paler, and S. J. Devitt, Transversal injection for direct encoding of ancilla

states for non-clifford gates using stabilizer codes, Phys. Rev. Res. **5** , 033019 (2023) .

[18] Y. Akahoshi, K. Maruyama, H. Oshima, S. Sato, and K. Fujii, Partially fault-tolerant quantum computing architecture

with error-corrected clifford gates and space-time efficient analog rotations, PRX Quantum **5** , 010337 (2024) .

35

 _|_ \+ _→_

 _ω_ _l_

 _ω_ _l_

_F_

_F_ †

_F_

_F_ †

 _|_ \+ _→_

 _|_ 0 _→_

 _|_ 0 _→_

 _X_

(b)

(c)

 _H_

 _H_

=

_E_

8X7Amu6MbWLVX7SrLc6eI0gfI35/7JyjMpOR0Kp2dTS4uhV/RjTFMYJrew6LWEGeTrXxDHOcB5lkakMWm8l

_Q_ _†_

8X7Amu6MbWLVX7SrLc6eI0gfI35/7JyjMpOR0Kp2dTS4uhV/RjTFMYJrew6LWEGeTrXxDHOcB5lkakMWm8l

_Q_ _†_

 _Q_

 _Q_

 _Q_

_F_

=

0kq4pgqiN7M7WnlIuc3c3nmQpFkTiJ5BDkEQYGTt+jS3swYaGKkxwWBCEDSjwqG1CBoND3DYaxLmE9GCf4xBR0lYpi1OGQmyFxjKtNkPWorVf0wvUGp1iUHdJmcAke2A37IXds1v2yN5/rdUIavhe6jSrLS13dmNHo6tv/6pMmgX

_Q_ _†_

0kq4pgqiN7M7WnlIuc3c3nmQpFkTiJ5BDkEQYGTt+jS3swYaGKkxwWBCEDSjwqG1CBoND3DYaxLmE9GCf4xBR0lYpi1OGQmyFxjKtNkPWorVf0wvUGp1iUHdJmcAke2A37IXds1v2yN5/rdUIavhe6jSrLS13dmNHo6tv/6pMmgX

_Q_ _†_

 _Q_

 _Q_

 _Q_

(a)

 _|_ \+ _→_

 _ω_ _l_

 _ω_ _l_

 _H_ _l_

 _H_ _l_

 _H_ _l_

 _|_ \+ _→_

 _|_ \+ _→_

 _H_ _l_

 _|_ \+ _→_

=

bR6ahCaKcixbrFsL6tnB/qFWKnGvKCsyYKIdwM1BArCSDvyDfZxCAcGqiAw4YgbEGDT98eVDC4xBVQJ84jZAb7HGeIkrZKWZwyNGL9C/Rai9kbVq3a/qB2qBTLBoeKeNIsEd2y1rsgd2xZ/bxa616UKPt5YRmvaPlbjF2PrX

_R_ _†_

_l_ _→_ 1

 _T_

Z/F+yNrunG+iN/k6w7NnCNAHJH4+dy/YXIwnkvFkZimaWvO+wo8w5rBA72MFDaQRoHO1XCc1z4XoRpISzMd

_T_ _†_

 _T_

Z/F+yNrunG+iN/k6w7NnCNAHJH4+dy/YXIwnkvFkZimaWvO+wo8w5rBA72MFDaQRoHO1XCc1z4XoRpISzMd

_T_ _†_

J/wV7ZHd0A7v2pl3leEUCfoA+edzN4OVqYw8k5nJT6ezC9FXxJHCGCbpvWeRxRJyKNG5Fo5xhvPYizQkpaSR

_S_ _†_

 _T_

1paLIokPUVn53e1+sVrm1F4qyOHMj0gsSHojCi7QRusE29mFARh0aOHQ4hFWIsKmVkQCDSdwOWsRZhBR3n+MIAdLWKYtThkhsjcYqrcoeq9O6U9N21TKdolK3SBlBjD2yW/bKHtgde2Ifv9ZquTU6Xpo0S10tN/eCxzO5939VGs0

_T_ _†_

 _T_

1paLIokPUVn53e1+sVrm1F4qyOHMj0gsSHojCi7QRusE29mFARh0aOHQ4hFWIsKmVkQCDSdwOWsRZhBR3n+MIAdLWKYtThkhsjcYqrcoeq9O6U9N21TKdolK3SBlBjD2yW/bKHtgde2Ifv9ZquTU6Xpo0S10tN/eCxzO5939VGs0

_T_ _†_

bRsXQFEHUenF7c0fRde6Vk2mWYWGMNgM5AmlEkXOS19jEDhxoqMIChw1B2IQCn9oGZDC4xG2hTpxHyAj3OQ6RIG2VsjhlKMTu0ajTaiNibVoHNf1QrdEpJnWPlKMYZw/shr2ye3bLntjHr7XqY3Ayz7NakPL3XLf0XDx/V+VRbP

_S_ _†_

FIG. 14.

(a) Hadamard test regarding a unitary and Hermitian operator _H_ _l_ = _R_ _l_ _XR_ _†_

_l_ , which stabilizes _|_ _M_ _l_ _⟩_ , over two noisy

magic states _ρ_ _l_ . (b) The Hadamard test with code concatenation into [[4,2,2]] code, in which the transversal implementation

of Hadamard gate realizes a logical SWAP gate. Note that some rotation gates can be canceled out [ 46 ], which results in

consuming eight T gates and one _R_ _l_ _−_ 1 gate. The blue region corresponds to the controlled SWAP gate as indicated in panel

(a). The operator is rewritten using the identity _H_ _l_ = _R_ _l_ _XR_ _†_

_l_ = _XR_ _†_

_l_ _−_ 1 . (c) Detailed circuit structure of the encoding circuit

_F_ . Here, we have introduced a unitary _Q_ that conjugates Pauli _Y_ and _Z_ as _QY Q_ _†_ = _Z_ and hence also _QR_ Y ( _θ_ ) _Q_ _†_ = _R_ Z ( _θ_ ).

[19] R. Toshio, Y. Akahoshi, J. Fujisaki, H. Oshima, S. Sato, and K. Fujii, Practical quantum advantage on partially fault-

tolerant quantum computer, Phys. Rev. X **15** , 021057 (2025) .

[20] S. Bravyi, M. Englbrecht, R. K¨onig, and N. Peard, Correcting coherent errors with surface codes, npj Quantum Information

**4** , 55 (2018).

[21] Y. Suzuki, K. Fujii, and M. Koashi, Efficient simulation of quantum error correction under coherent error based on the

nonunitary free-fermionic formalism, Physical review letters **119** , 190503 (2017).

[22] Z. Cheng, E. Huang, V. Khemani, M. J. Gullans, and M. Ippoliti, Emergent unitary designs for encoded qubits from

coherent errors and syndrome measurements, PRX Quantum **6** , 030333 (2025) .

[23] F. Venn, J. Behrends, and B. B´eri, Coherent-error threshold for surface codes from majorana delocalization, Phys. Rev.

Lett. **131** , 060603 (2023) .

[24] J. Behrends and B. B´eri, Statistical mechanical mapping and maximum-likelihood thresholds for the surface code under

generic single-qubit coherent errors, arXiv preprint arXiv:2410.22436 (2024).

[25] A. A. Kovalev and L. P. Pryadko, Improved quantum hypergraph-product ldpc codes, in _2012 IEEE International Sym-_

_posium on Information Theory Proceedings_ (2012) pp. 348–352.

[26] J.-P. Tillich and G. Z´emor, Quantum ldpc codes with positive rate and minimum distance proportional to the square root

of the blocklength, IEEE Transactions on Information Theory **60** , 1193 (2014) .

[27] W. Zeng and L. P. Pryadko, Higher-dimensional quantum hypergraph-product codes with finite rates, Phys. Rev. Lett.

**122** , 230501 (2019) .

[28] N. P. Breuckmann and J. N. Eberhardt, Quantum low-density parity-check codes, PRX Quantum **2** , 040101 (2021) .

36

[29] S. Bravyi, A. W. Cross, J. M. Gambetta, D. Maslov, P. Rall, and T. J. Yoder, High-threshold and low-overhead fault-

tolerant quantum memory, Nature **627** , 778 (2024) .

[30] A. Y. Kitaev, Fault-tolerant quantum computation by anyons, Annals of physics **303** , 2 (2003).

[31] A. G. Fowler, M. Mariantoni, J. M. Martinis, and A. N. Cleland, Surface codes: Towards practical large-scale quantum

computation, Phys. Rev. A **86** , 032324 (2012) .

[32] H. Bombin and M. A. Martin-Delgado, Topological quantum distillation, Phys. Rev. Lett. **97** , 180501 (2006) .

[33] A. J. Landahl, J. T. Anderson, and P. R. Rice, Fault-tolerant quantum computing with color codes, arXiv preprint

arXiv:1108.5738 (2011).

[34] A. M. Meier, B. Eastin, and E. Knill, Magic-state distillation with the four-qubit code, arXiv preprint arXiv:1204.4221

(2012).

[35] P. W. Shor, Fault-tolerant quantum computation, in _Proceedings of 37th conference on foundations of computer science_

(IEEE, 1996) pp. 56–65.

[36] J. Choi, A. L. Shaw, I. S. Madjarov, X. Xie, R. Finkelstein, J. P. Covey, J. S. Cotler, D. K. Mark, H.-Y. Huang, A. Kale,

_et al._ , Preparing random states and benchmarking with many-body quantum chaos, Nature **613** , 468 (2023).

[37] J. S. Cotler, D. K. Mark, H.-Y. Huang, F. Hern´andez, J. Choi, A. L. Shaw, M. Endres, and S. Choi, Emergent quantum

state designs from individual many-body wave functions, PRX Quantum **4** , 010311 (2023) .

[38] B. Eastin and E. Knill, Restrictions on transversal encoded quantum gate sets, Phys. Rev. Lett. **102** , 110502 (2009) .

[39] B. Zeng, A. Cross, and I. L. Chuang, Transversality versus universality for additive quantum codes, IEEE Transactions on

Information Theory **57** , 6272 (2011) .

[40] D. Gottesman and I. L. Chuang, Demonstrating the viability of universal quantum computation using teleportation and

single-qubit operations, Nature **402** , 390 (1999) .

[41] A. Kubica and M. E. Beverland, Universal transversal gates with color codes: A simplified approach, Phys. Rev. A **91** ,

032330 (2015) .

[42] J. T. Anderson, G. Duclos-Cianci, and D. Poulin, Fault-tolerant conversion between the steane and reed-muller quantum

codes, Phys. Rev. Lett. **113** , 080501 (2014) .

[43] F. Butt, S. Heußen, M. Rispler, and M. M¨uller, Fault-tolerant code-switching protocols for near-term quantum processors,

PRX Quantum **5** , 020345 (2024) .

[44] M. Grassl, Bounds on the minimum distance of linear codes and quantum codes, Online available at http://www.

codetables.de (2007), accessed on 2025-09-11.

[45] G. Duclos-Cianci and D. Poulin, Reducing the quantum-computing overhead with complex gate distillation, Phys. Rev. A

**91** , 042315 (2015) .

[46] E. T. Campbell and J. O’Gorman, An efficient magic state approach to small angle rotations, Quantum Science and

Technology **1** , 015007 (2016) .

[47] M. B. Hastings, Turning gate synthesis errors into incoherent errors, arXiv preprint arXiv:1612.01011 (2016).

[48] N. Yoshioka, T. Okubo, Y. Suzuki, Y. Koizumi, and W. Mizukami, Hunting for quantum-classical crossover in condensed

matter problems, npj Quantum Information **10** , 45 (2024) .

[49] S. Akibue, G. Kato, and S. Tani, Probabilistic unitary synthesis with optimal accuracy, ACM Transactions on Quantum

Computing **5** , 1 (2024).

[50] E. T. Campbell, Early fault-tolerant simulations of the hubbard model, Quantum Science & Technology **7** , 015007 (2022).

[51] M. E. Beverland, P. Murali, M. Troyer, K. M. Svore, T. Hoeffler, V. Kliuchnikov, G. H. Low, M. Soeken, A. Sundaram, and

A. Vaschillo, Assessing requirements to scale to practical quantum advantage, arXiv preprint arXiv:2211.07629 (2022).

[52] Y. Akahoshi, R. Toshio, J. Fujisaki, H. Oshima, S. Sato, and K. Fujii, Compilation of trotter-based time evolution for

partially fault-tolerant quantum computing architecture, PRX Quantum **6** , 040319 (2025).

[53] T. J. Yoder, E. Schoute, P. Rall, E. Pritchett, J. M. Gambetta, A. W. Cross, M. Carroll, and M. E. Beverland, Tour de

gross: A modular quantum computer based on bivariate bicycle codes, arXiv preprint arXiv:2506.03094 (2025).

[54] D. C. McKay, C. J. Wood, S. Sheldon, J. M. Chow, and J. M. Gambetta, Efficient z gates for quantum computing, Physical

Review A **96** , 022330 (2017).

[55] K. Tsubouchi, T. Sagawa, and N. Yoshioka, Universal Cost Bound of Quantum Error Mitigation Based on Quantum

Estimation Theory, Physical Review Letters **131** , 210601 (2023) , publisher: American Physical Society.

[56] R. Takagi, H. Tajima, and M. Gu, Universal sampling lower bounds for quantum error mitigation, Phys. Rev. Lett. **131** ,

210602 (2023) .

[57] Y. Quek, D. S. Fran¸ca, S. Khatri, J. J. Meyer, and J. Eisert, Exponentially tighter bounds on limitations of quantum error

mitigation, arXiv preprint arXiv:2210.11505 (2022).

[58] D. Horsman, A. G. Fowler, S. Devitt, and R. Van Meter, Surface code quantum computing by lattice surgery, New Journal

of Physics **14** , 123011 (2012).

[59] A. G. Fowler and C. Gidney, Low overhead quantum computation using lattice surgery, arXiv preprint arXiv:1808.06709

(2018).

[60] D. Litinski, A game of surface codes: Large-scale quantum computing with lattice surgery, Quantum **3** , 128 (2019).

[61] D. Litinski, Magic state distillation: Not as costly as you think, Quantum **3** , 205 (2019).

[62] S. Bravyi, G. Smith, and J. A. Smolin, Trading classical and quantum computational resources, Physical Review X **6** ,

021043 (2016).

[63] D. Leibfried, M. D. Barrett, T. Schaetz, J. Britton, J. Chiaverini, W. M. Itano, J. D. Jost, C. Langer, and

D. J. Wineland, Toward heisenberg-limited spectroscopy with multiparticle entangled states, Science **304** , 1476 (2004) ,

https://www.science.org/doi/pdf/10.1126/science.1097576 .

37

[64] V. Giovannetti, S. Lloyd, and L. Maccone, Quantum metrology, Phys. Rev. Lett. **96** , 010401 (2006) .

[65] M. Ma, S. T. Flammia, J. Preskill, and Y. Tong, Learning _k_ \-body hamiltonians via compressed sensing, arXiv preprint

arXiv:2410.18928 (2024).

[66] D. Malz, G. Styliaris, Z.-Y. Wei, and J. I. Cirac, Preparation of matrix product states with log-depth quantum circuits,

Phys. Rev. Lett. **132** , 040404 (2024) .

[67] K. C. Smith, A. Khan, B. K. Clark, S. M. Girvin, and T.-C. Wei, Constant-depth preparation of matrix product states

with adaptive quantum circuits, PRX Quantum **5** , 030344 (2024) .

[68] K. C. Smith, E. Crane, N. Wiebe, and S. M. Girvin, Deterministic constant-depth preparation of the aklt state on a

quantum processor using fusion measurements, PRX Quantum **4** , 020315 (2023) .

[69] C. Gidney, Halving the cost of quantum addition, Quantum **2** , 74 (2018) .

[70] Y. Li, A magic state’s fidelity can be superior to the operations that created it, New Journal of Physics **17** , 023037 (2015).

[71] M. Suzuki, General correction theorems on decomposition formulae of exponential operators and extrapolation methods

for quantum monte carlo simulations, Physics Letters A **113** , 299 (1985), publisher: Elsevier.

[72] M. J. Bremner, R. Jozsa, and D. J. Shepherd, Classical simulation of commuting quantum computations implies collapse

of the polynomial hierarchy, Proceedings of the Royal Society A: Mathematical, Physical and Engineering Sciences **467** ,

459 (2011).

[73] C. Gidney, Turning gradients into additions into QFTs, https://algassert.com/post/1620 (2016), blog post, published

31 Jul 2016. Licensed under CC BY 4.0. Accessed 2025-11-16.

[74] Y. Hirano, T. Itogawa, and K. Fujii, Leveraging zero-level distillation to generate high-fidelity magic states, in _2024 IEEE_

_International Conference on Quantum Computing and Engineering (QCE)_ , Vol. 1 (IEEE, 2024) pp. 843–853.

[75] N. J. Ross and P. Selinger, Optimal ancilla-free clifford+ t approximation of z-rotations, arXiv preprint arXiv:1403.2975

(2014).

[76] V. Kliuchnikov, K. Lauter, R. Minko, A. Paetznick, and C. Petit, Shorter quantum circuits via single-qubit gate approxi-

mation, Quantum **7** , 1208 (2023) .

[77] B. Skinner, J. Ruhman, and A. Nahum, Measurement-induced phase transitions in the dynamics of entanglement, Phys.

Rev. X **9** , 031009 (2019) .

[78] Y. Li, X. Chen, and M. P. A. Fisher, Measurement-driven entanglement transition in hybrid quantum circuits, Phys. Rev.

B **100** , 134306 (2019) .

[79] M. Bejan, C. McLauchlan, and B. B´eri, Dynamical magic transitions in monitored clifford+ _t_ circuits, PRX Quantum **5** ,

030332 (2024) .

[80] A. S. Darmawan and D. Poulin, Tensor-network simulations of the surface code under realistic noise, Phys. Rev. Lett. **119** ,

040502 (2017) .

[81] A. Miller, C. Ostrove, J. Hines, R. Blume-Kohout, K. Young, and T. Proctor, Efficient simulation of clifford circuits with

small markovian errors, arXiv preprint arXiv:2504.15128 (2025).

[82] E.

T.

Campbell,

The

smallest

interesting

colour

code,

https://earltcampbell.com/2016/09/26/

the-smallest-interesting-colour-code/ (2016), blog post.

[83] L. Garvie and R. Duncan, Verifying the smallest interesting colour code with quantomatic, in _Proceedings of the 14th_

_International Conference on Quantum Physics and Logic (QPL 2017)_ , Electronic Proceedings in Theoretical Computer

Science, Vol. 266 (2018) pp. 147–163.

[84] E. Huang, P.-G. Rozon, A. Dua, S. Gopalakrishnan, and M. J. Gullans, A robust phase of continuous transversal gates in

quantum stabilizer codes, arXiv preprint arXiv:2510.01319 (2025).

[85] E. Knill and R. Laflamme, Theory of quantum error-correcting codes, Phys. Rev. A **55** , 900 (1997) .

[86] N. Yoshioka, S. Akibue, H. Morisaki, K. Tsubouchi, and Y. Suzuki, Error crafting in mixed quantum gate synthesis, npj

Quantum Information **11** , 95 (2025).

[87] S. Sethi and J. M. Baker, Rescq: Realtime scheduling for continuous angle quantum error correction architectures, in

_Proceedings of the 30th ACM International Conference on Architectural Support for Programming Languages and Operating_

_Systems, Volume 2_ (2025) pp. 1028–1043.

[88] qiskit-community/bicycle-architecture-compiler: A compiler prototype targeting a bicycle architecture from pbc circuits,

https://github.com/qiskit-community/bicycle-architecture-compiler/ (2025), gitHub repository, accessed on 2025-

09-10.

[89] R. Toshio, S. Kanasugi, J. Fujisaki, H. Oshima, S. Sato, and K. Fujii, Star-magic mutation: Even more efficient analog

rotation gates for early fault-tolerant quantum computer, arXiv preprint arXiv:2603.22891 (2026).
