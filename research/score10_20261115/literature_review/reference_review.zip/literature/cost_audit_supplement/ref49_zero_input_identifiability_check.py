"""Independent limited check of data used by arXiv:2106.12524v3 Algorithm 2.

This does not address algorithms with arbitrary-input queries or U-dagger access.
The printed Algorithm 2 prepares only copies of U|0^n>. Such data cannot
identify a fixed implementation of U on all other basis states. It also cannot
identify relative phases between computational-basis columns.
"""
from __future__ import annotations

import cmath
import json
import math
from pathlib import Path


def mm(a, b):
    return [[sum(a[i][k] * b[k][j] for k in range(len(b)))
             for j in range(len(b[0]))] for i in range(len(a))]


def adj(a):
    return [[a[j][i].conjugate() for j in range(len(a))]
            for i in range(len(a[0]))]


def kron(a, b):
    return [[x * y for x in row_a for y in row_b]
            for row_a in a for row_b in b]


def column(a, j):
    return [row[j] for row in a]


def overlap(a, b):
    return sum(x.conjugate() * y for x, y in zip(a, b))


def norm_difference(a, b):
    return math.sqrt(sum(abs(x - y)**2 for x, y in zip(a, b)))


def matrix_difference(a, b):
    return max(abs(x - y) for aa, bb in zip(a, b) for x, y in zip(aa, bb))


def main():
    h = [[complex(1 / math.sqrt(2)), complex(1 / math.sqrt(2))],
         [complex(1 / math.sqrt(2)), complex(-1 / math.sqrt(2))]]
    t = [[1 + 0j, 0j], [0j, cmath.exp(1j * math.pi / 4)]]
    eye = [[1 + 0j, 0j], [0j, 1 + 0j]]
    x = [[0j, 1 + 0j], [1 + 0j, 0j]]
    z = [[1 + 0j, 0j], [0j, -1 + 0j]]
    cx = [[complex(int(i == (j ^ (j >> 1)))) for j in range(4)]
          for i in range(4)]
    c1_u = kron(h, h)
    c1_v = mm(c1_u, cx)
    u = mm(kron(t, t), c1_u)
    v = mm(kron(t, t), c1_v)
    w = mm(u, kron(z, eye))
    # Both input Cliffords prepare |++> and have full X-rank on both T sites.
    generators_u = [kron(x, eye), kron(eye, x)]
    generators_v = [kron(x, eye), kron(x, x)]
    generators_z = [kron(z, eye), kron(eye, z)]
    for c1, expected in [(c1_u, generators_u), (c1_v, generators_v)]:
        for zz, ee in zip(generators_z, expected):
            assert matrix_difference(mm(mm(c1, zz), adj(c1)), ee) < 1e-12
    zero_equal = norm_difference(column(u, 0), column(v, 0))
    ten_overlap_squared = abs(overlap(column(u, 2), column(v, 2)))**2
    assert zero_equal < 1e-12
    assert ten_overlap_squared < 1e-12
    # Separate phase-only example: identical basis output states as rays,
    # but distinguishable output states on a coherent input.
    phase_basis_overlaps = [abs(overlap(column(u, j), column(w, j)))**2
                            for j in range(4)]
    plus_zero_u = [(row[0] + row[2]) / math.sqrt(2) for row in u]
    plus_zero_w = [(row[0] + row[2]) / math.sqrt(2) for row in w]
    coherent_overlap_squared = abs(overlap(plus_zero_u, plus_zero_w))**2
    assert all(abs(a - 1) < 1e-12 for a in phase_basis_overlaps)
    assert coherent_overlap_squared < 1e-12
    report = {
        "source": "https://arxiv.org/html/2106.12524v3",
        "scope": "Printed Algorithm 2 steps (1)-(7), given only copies of U|00>; not a lower bound for algorithms using other input queries or U-dagger",
        "basis_order": ["00", "01", "10", "11"],
        "U": "(T tensor T)(H tensor H)",
        "V": "U CNOT(control first qubit, target second)",
        "T_depth": 1,
        "T_count_each": 2,
        "X_rank_U": 2,
        "X_rank_V": 2,
        "input_Clifford_stabilizer_generators_U": ["XI", "IX"],
        "input_Clifford_stabilizer_generators_V": ["XI", "XX"],
        "zero_input_vector_distance": zero_equal,
        "ten_input_output_overlap_squared": ten_overlap_squared,
        "phase_only_example_W": "U(Z tensor I)",
        "all_basis_output_overlap_squared_U_W": phase_basis_overlaps,
        "plus_zero_input_output_overlap_squared_U_W": coherent_overlap_squared,
        "conclusion": "U|00> data do not identify the action of a single fixed circuit on all basis states. Even all basis output rays alone do not identify coherent relative phases.",
        "not_claimed": "This does not refute target-state learning on |0^n>, all possible algorithms using general oracle access, or the whole paper. Relearning separately for each input is a different task.",
        "passed": True,
    }
    path = Path(__file__).with_suffix('.json')
    path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
