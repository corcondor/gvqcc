"""Record actual additional reading, without modifying the parent-owned ledger."""
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/fd9d1fc36baf/literature')


def source(n):
    p = BASE / 'root_refs' / f'ref_{n}.md'
    return {
        'source_path': str(p),
        'source_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
        'source_characters': len(p.read_text()),
    }


references = [
    {
        'number': 44,
        'title': 'Measurement-based quantum computation on cluster states',
        'primary_url': 'https://arxiv.org/pdf/quant-ph/0301052v2',
        'version': 'arXiv:quant-ph/0301052v2, 2003-01-14',
        'status': 'main_results_reviewed',
        'additional_read_intervals': [[20907, 32340], [48911, 78166], [98840, 169650]],
        'additional_read_characters': 111498,
        'read_scope_ja': 'II B–C、II E–F（Theorem 1の証明全体を含む）、II H–I、III全体、IV A–H全体、V・VI・Acknowledgementsを実読。親のAbstract/I/II A/II D既読分を補完した。II Gの個別ゲート相関の詳細導出、Appendix Aのcluster decomposition証明は通読していない。図のキャプション・抽出ラベルは読んだが全画像を個別視認していない。取得済み177,425文字の全読を意味しない。',
        'results_and_assumptions_ja': 'CNOTは15-qubit clusterのPauli測定、任意SU(2)は5-qubit chainの適応的測定で実現し、結果依存Pauli byproductを伴う。不要なcluster siteのZ測定は隣接siteのstabilizer符号を変えるため、その記録を後続基底へ反映する。Cliffordを通るbyproductはPauliを更新し、非Clifford回転を通る場合は角度の符号を適応的に変える。測定依存のforward coneが時間順序を決める。Theorem 1は入出力の2n個のX/Z相関から任意入力のunitary作用を証明する。計算基底での一致だけでは残る入力依存位相Dを、|+>^n入力の相関と同じ枝の正規化を用いてglobal phaseまで固定する。',
        'algorithms_and_resources_ja': '全Pauli測定を初回へ集め、残る適応測定を順序付ける。既知入力の計算ではClifford部分をalgorithm-specific graph stateと古典information-flow vector（2n bit）へ吸収できるが、graph stateの生成は必要。ここでSはcluster site数、Oは1-qubit測定数、Tは測定ラウンド数。一般上界T≤3T_qln、S≤24 S_qln² T_qln、S,O≤24 O_qln S_qlnは見積りではなく上界と明記する。IVはswap、Pauli-product回転、非隣接CNOT、controlled phase、QFT、Toffoli phase、CARRY、加算を構成する。Toffoli phaseはEq174の7個の一般化Z回転（φ=πならT型のπ/4回転）であり、Pauli測定後の1回の適応測定ラウンドにまとめる。CARRYのtilted-basis測定によるbyproductはZ型で対角gateと可換なので同時化できる。加算は回路の幾何配置を折り返し、clusterの幅38・高さ8n−5、主要項S=O=304n、T=nにする。Vでは中間出力を未測定のまま保持し、測定済みqubitだけ再準備・再エンタングルして有限clusterを再利用する。',
        'gvqcc_applicability_ja': '直接参考になるのは、測定分岐のbyproductと後続角度依存の追跡、既知に消去済みの領域だけ再利用する条件、計算基底とcoherent入力の検証を区別する証明方法である。phase-cache退役の検証では同様に全measurement symbolを残した位相一致を確認している。7個の位相回転を同時化しても現在のnative CCZ=1 Toffoliに対する費用削減にはならない。cluster siteの幾何学的幅38は現在のinvsqrtのnum_qubits=45という主張ではない。一般H・|+>準備・任意測定基底・graph entanglingを現在のKMB命令へ実現する費用と可否を別途示す必要がある。',
        'limitations_ja': '測定ラウンドTと今回のToffoli countを混同しない。既知入力＋最終古典readoutの議論で量子registerを省けても、未知入力を保つcoherent loaderの入出力を省けるわけではない。graph stateへのClifford吸収は量子回路全体の無料化ではない。IIIのモデル論・Vのdecoherence管理は2003年時点の構成と条件であり、この資料だけから現在のfault-tolerance thresholdを保証しない。全証明の独立再現やKMBへの新規実装は行っていない。公式chemistry契約の到達可能部分空間での正確性を否定する記述ではない。',
        **source(44),
    },
    {
        'number': 48,
        'title': 'How to simulate quantum measurement without computing marginals',
        'primary_url': 'https://arxiv.org/html/2112.08499v2',
        'version': 'arXiv:2112.08499v2, 2022-01-06',
        'status': 'main_text_read_with_selected_appendices',
        'additional_read_intervals': [[8721, 31262], [40016, 47515], [75371, 81170]],
        'additional_read_characters': 35839,
        'read_scope_ja': 'IおよびIIの全文、IIのDirichlet-form混合時間証明、Appendix A（A.1を含む）・D・Eの全証明を実読。Iは親既読分も再確認し、振幅問い合わせの意味と対角gateの扱いを確認した。親のAbstract/Introduction/Algorithms 1–2既読分と合わせ主要本文はすべて確認。Appendix Bの数値実験詳細、Appendix Cのsurface-code MBQC・#P-hard marginalの長い証明は今回未通読（親はB冒頭既読）。全82,989文字を読了したという意味ではない。',
        'results_and_assumptions_ja': 'm個のk-local unitaryからなる回路の出力分布を、各prefix回路の振幅を合計≤m 2^k回問い合わせてexact samplingする。現サンプルのgate作用外bitを固定し、作用するbitだけ更新する。局所unitaryは作用外marginalを保つので帰納的に正しい。CNOT等の基底置換はサンプルを直接更新し、対角gateではその時点の更新を省ける。後のprefix振幅には以前の対角gateの位相を含める必要がある。中間測定・古典制御への拡張では、測定済みqubitに後続gateが作用しないというモデル化を使う。一般のkで振幅計算が無料という主張ではなく、強シミュレーションからsamplingへの還元である。',
        'algorithms_and_resources_ja': 'Appendix Aの頑健性は、各prefix状態ψ_tに対し既知の近似ベクトルφ_tが状態2-normでε_t以内であり、その振幅を正確に計算できるという仮定。R_t=|<x|U_t φ_{t-1}>|²/||φ_{t-1}||²を使い、最終分布のl1誤差を≤16Σ_{t=1}^{m−1}ε_tとする。任意に独立な各確率の加算誤差を仮定する定理ではない。sum-over-CliffordsのcostはO(n²)/δ²(Σ_t η_t^(1/3))³、η_t=Π_{s≤t}ξ(U_s)。末尾項だけで近似する簡略式はそれらが支配する場合に限る。本文IIはunique ground state、k-bit flip locality、Hamiltonian gap γ、amplitude sensitivity s、非ゼロの初期π(x_in)、振幅比問い合わせを仮定するlazy Metropolis-Hastingsで、gap≥γ/(2Ns)、N=Σ_{j≤k}binom(n,j)を証明。query数はO(n^k s/γ log(1/(π(x_in)ε)))。stoquasticならs≤max_x H_xx−E0。Appendix Eのfrustration-free magic-ratio Hamiltonianは、各projectorのrank-one成分が互いに素な計算基底supportを持つ条件で局所比を計算でき、s≤m。',
        'gvqcc_applicability_ja': '古典的な独立検証で、振幅計算がmarginal計算より安い場合にsampling費用を下げる候補。exact stabilizer-rank分解ではrankへの依存を二乗から一次へ改善するが、rank自体はnon-Clifford数に対して指数的に大きくなり得る。全アドレスのloader一致や任意ターゲットのANF・HMR位相証明を、有限回のoutput samplingだけで置き換える根拠にはならない。対角gateで古典sample更新を省けることを、KMBから位相gateを削除できると解釈してはいけない。',
        'limitations_ja': '49-qubit depth16 tensor-network比較のFLOP数は実縮約の実行時間ではなくCoTenGraによる推定と本文に明記する。planar surface-code stateの任意測定順samplingと2D cluster stateの普遍MBQCは別のresource state。Appendix Cの詳細証明は未読なので独立検証済みとはしない。ground-state MCMCの多項式性は1/γ・s・振幅比計算の費用などの条件付きであり、任意Hamiltonianを効率よくsamplingできる定理ではない。',
        **source(48),
    },
    {
        'number': 49,
        'title': 'Learning quantum circuits of some T gates',
        'primary_url': 'https://arxiv.org/html/2106.12524v3',
        'version': 'arXiv:2106.12524v3, 2022-06-28',
        'status': 'full_main_text_read',
        'additional_read_intervals': [[0, 90681]],
        'additional_read_characters': 90681,
        'read_scope_ja': '表題・Abstract・I–VI・Acknowledgementまで本文全体を実読。II–Vの全証明、Algorithms 1/2、関連する全Lemma、Theorems 9/18、Corollary 19、Examples 1–9を含む。参考文献表の再読はしていない。図の画像は個別に開いておらず、本文・table・captionで読める範囲。既読だった親のI/VI等も再確認した。',
        'results_and_assumptions_ja': 'Clifford学習ではU|0^n>とU|+^n>のBell samplingからstabilizer基底を求め、さらに単一bitを変えた基底入力やX基底入力で生成子のラベルと符号を特定し、Clifford synthesisする。Algorithm 1/Theorem 9は2n²+10n+4 query、O(n³)時間、成功確率≥1−2^{-n+1}。T-depth1ではC2 T^v C1、Tのsupport上でC1|0^n>のX-rankがfullである条件を要求する。3^kの符号付きstabilizer pseudomixtureの代わりにn−k isotropic生成子と2k primary symplectic生成子の構造を利用する。Bell samplingでそのspanを求め、Pauli測定の確率1、(2+√2)/4、(1+2^{-m/2})/2、1/2を区別してprimary生成子を選ぶ。Algorithm 2が掲げるquery/時間はO(3^k n)/O(n³+3^k n)で、T-depth1という条件だけで多項式にはならずk=O(log n)が必要。',
        'algorithms_and_resources_ja': '通常のClifford学習ではinputを変えてlabelled Pauli actionを得る点が重要。T部分のBell samplingはψ*を生成せず、ψ⊗ψのoutcomeが固定Pauliだけshiftする構造を使う。magic-state injectionでn+k qubitのClifford回路に変換するProposition 11は、magic statesとpostselectionを資源として仮定しており、無料のClifford-only実装ではない。Corollary 19は任意入力unitaryの回路表現についてO(4^{3n})古典計算を記述するが、VIでは固定all-zero inputのstate再構成を主要結果とし、任意入力回路表現を得る方法を未解決問題として述べる。',
        'gvqcc_applicability_ja': 'state preparationの学習と、未知入力にcoherentに作用するoracleの合成を区別するために有用。今回の既知ソースKMBにはブラックボックス量子query学習をそのまま行う必要はない。T-depth低下やstabilizer生成子の数の減少を、実Toffoli数の減少として採点できない。学習したU|0^n>を再準備できることだけでは、提出loaderやinvsqrtの全入力作用・相対位相・測定補正の一致を保証しない。',
        'quantifier_caution_ja': '厳密な限定: arXiv v3 Algorithm 2の印刷された手順(1)–(7)が使うデータはU|0^n>のcopiesである一方、Theorem 18の末尾には固定した同じhat Uについて全vへの一致が記される。この強い量化は、そのデータだけからは同定できない。U=(T⊗T)(H⊗H)、V=U CNOT_{1→2}は両方T-depth1/full T-rank2でU|00>=V|00>だが、U|10>とV|10>は直交する。独立4×4行列チェックを保存した。各vごとの再学習や他の入力・U†への追加queryを使う別手続きはこの反例の対象外。本文全体が誤りであるという結論ではなく、今回の任意入力oracle置換の根拠としてこの強い読みに依存しない。',
        'limitations_ja': '全計算基底について出力状態をphaseを捨てて学習しても、基底間のrelative phaseは未確定。別の簡単な例W=U(Z⊗I)では各基底の出力rayは同じでも|+0>入力の出力は直交する。3^kのpseudomixtureは負の係数を含み、物理的な確率混合や無料な直交枝としては扱わない。noisy circuit学習のLPNへの関連は計算量仮定に依存し、実証された一般不可能性ではない。原論文の全定理を独立に検証したわけではない。',
        'independent_check_paths': [
            str(BASE / 'cost_audit_supplement/ref49_zero_input_identifiability_check.py'),
            str(BASE / 'cost_audit_supplement/ref49_zero_input_identifiability_check.json'),
        ],
        **source(49),
    },
]

data = {
    'owner': 'cost_audit',
    'review_date': '2026-11-15',
    'main_numbering': 'arXiv:2409.13809v2 bibliography',
    'scope_rule': 'Cached primary full text, actual reading, and independent proof/code checks are recorded separately. No claim of recursively reading every bibliography of these references.',
    'references': references,
}

json_path = BASE / 'root_reference_supplement_cost.json'
json_path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')

lines = ['# 主論文 [44]・[48]・[49] の本文補完', '',
         '取得、実読、独立検証を区別する。本文の結果・条件を優先し、未読の詳細証明は各項目に明示した。', '']
fields = [('read_scope_ja', '実際に読んだ範囲'),
          ('results_and_assumptions_ja', '結果と仮定'),
          ('algorithms_and_resources_ja', 'アルゴリズムと資源'),
          ('gvqcc_applicability_ja', 'GVQCCへの適用'),
          ('quantifier_caution_ja', '量化・入力accessの注意'),
          ('limitations_ja', '限界')]
for ref in references:
    lines += [f"## [{ref['number']}] {ref['title']}", '',
              f"**状態:** {ref['status']}  ",
              f"**版:** {ref['version']}  ",
              f"**一次資料:** <{ref['primary_url']}>", '']
    for key, label in fields:
        if key in ref:
            lines += [f"### {label}", '', ref[key], '']
    lines += [f"**証拠ファイル:** `{ref['source_path']}`  ",
              f"**SHA256:** `{ref['source_sha256']}`", '']
(BASE / 'root_reference_supplement_cost.md').write_text('\n'.join(lines) + '\n')
print(json.dumps({'saved': str(json_path), 'references': [r['number'] for r in references]}, ensure_ascii=False))
