"""Incrementally record actual final-pass main-text reading."""
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/fd9d1fc36baf/literature')
JSON_PATH = BASE / 'shallow_final_supplement.json'
MD_PATH = BASE / 'shallow_final_supplement.md'
ASSIGNED = [1, 2, 6, 18, 39, 44, 'v1-only-55']


def update(number, source_path, primary_url, ranges, scope, results, applicability,
           limitations, status='main_text_complete', **extra):
    p = Path(source_path)
    s = p.read_text()
    assert all(0 <= a < b <= len(s) for a, b in ranges)
    item = {
        'number': number,
        'primary_url': primary_url,
        'source_path': str(p),
        'source_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
        'source_characters': len(s),
        'read_character_ranges': ranges,
        'read_scope_ja': scope,
        'combined_review_status': status,
        'results_and_assumptions_ja': results,
        'applicability_ja': applicability,
        'limitations_ja': limitations,
        **extra,
    }
    data = json.loads(JSON_PATH.read_text()) if JSON_PATH.exists() else {
        'reviewer': '/root/cost_audit',
        'assigned_numbers': ASSIGNED,
        'scope_rule': 'Ranges in this ledger are the additional actually read primary-text ranges; combined status includes explicitly identified earlier reads. Main-text completion does not imply all appendices, image pixels, or independent proof reproduction.',
        'references': [],
    }
    data['references'] = [x for x in data['references'] if x['number'] != number] + [item]
    data['references'].sort(key=lambda x: str(x['number']).zfill(3))
    data['recorded_count'] = len(data['references'])
    JSON_PATH.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    lines = ['# 主論文参考文献の最終本文補完', '',
             'この台帳の区間は今回実読した追加区間。本文完了は既読区間との合算であり、付録・画像・独立再証明を含むという意味ではない。', '']
    for x in data['references']:
        lines += [f"## [{x['number']}] {x['combined_review_status']}", '',
                  f"**一次資料:** <{x['primary_url']}>", '',
                  f"**追加読解範囲:** {x['read_scope_ja']}", '',
                  f"**結果と仮定:** {x['results_and_assumptions_ja']}", '',
                  f"**実装への適用:** {x['applicability_ja']}", '',
                  f"**限界:** {x['limitations_ja']}", '',
                  f"**SHA256:** `{x['source_sha256']}`", '']
    MD_PATH.write_text('\n'.join(lines) + '\n')
    print(f'Recorded {number}; {len(data["references"])}/{len(ASSIGNED)} assigned references')
