"""Record Aaronson--Chen reading and Shor PDF visual review; no paper text copied."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent


def main():
    source = ROOT / 'cache_01_25/ref_04.md'
    raw = source.read_bytes()
    text = raw.decode()
    assert len(text) == 203939
    root_ranges = [[0, 5500], [12500, 69723], [86521, len(text)]]
    earlier_ranges = [[0, 12500], [69723, 86521]]
    merged = []
    for a, b in sorted(root_ranges + earlier_ranges):
        if merged and a <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], b)
        else:
            merged.append([a, b])
    assert merged == [[0, len(text)]]
    r = {
        'number': 4,
        'reviewer': 'root, combined with shared_synthesis initial reading',
        'primary_url': 'https://arxiv.org/pdf/1612.05903v2',
        'version': 'arXiv:1612.05903v2, 2016-12-26, 65-page extracted manuscript',
        'source_sha256': hashlib.sha256(raw).hexdigest(),
        'source_characters': len(text),
        'read_character_ranges': root_ranges,
        'earlier_read_character_ranges': earlier_ranges,
        'combined_read_character_ranges': merged,
        'combined_review_status': 'full_extracted_text_complete',
        'read_scope_ja': '先行読解のAbstract・序論冒頭と§4に、rootの残る序論、§§2–3・5–9、謝辞・参考文献、Appendices A–Eの全抽出テキストを統合。取得テキスト0–203939文字を共同で全読した。図は抽出説明を読み、全画像の独立確認は行っていない。',
        'results_and_assumptions_ja': 'HOG（高確率出力の生成）の困難性をQUATH仮定から導き、検査を通過する出力の生成と分布全体の近似サンプリングを区別する。一般回路の振幅を多項式空間・d^{O(n)}時間で評価する再帰と時間・空間交換、格子局所性を使う改善を示す。近似サンプリングとPH崩壊を結ぶ強い一般定理には非相対化が必要と示し、Fourier Samplingの1量子問い合わせ対Ω(2^n)古典問い合わせの分離を十分小さい固定誤差で証明する。P/polyオラクルの分離にはone-way function等の計算量仮定を明示する。',
        'applicability_ja': '回路検証のメモリ削減には深さ分割・小さい切断を持つ窓の収縮が候補になるが、実量子回路のCCX数を減らす定理ではない。HOGを通過することは任意入力・位相・作業領域が一致する証明にはならない。オラクルへのアクセスを1回と数える問い合わせ下界や近似置換を、既知の1220アドレス表の合成費用4170の境界へ流用しない。',
        'additional_points_ja': [
            '§3の主たる困難性はQUATHを仮定し、ランダム回路の出力非一様性を高確率で保証するConjecture 1は本文では予想のまま。Appendix Eの有限サイズ数値実験はその証明ではない。',
            '§§5・8のオラクル置換は初期状態と到達分布に関する誤差評価であり、全入力の厳密な演算子恒等式ではない。',
            'Appendix Aの古典/量子one-way functionの仮定、Appendices B–Dの補助証明、Appendix Eの実験設定まで確認した。2016年の実験規模・計算機見積りは現時点の性能情報として用いない。'
        ],
        'limitations_ja': '抽出テキストには数式の改行・上付き下付きの崩れがある。図の全画素確認、全証明の独立再導出、Appendix Eのシミュレーション再実行は行っていない。参考文献の再帰的な全原著調査には広げていない。',
        'demonstrated_gate_saving': False,
    }
    pdf = ROOT / 'cache_01_25/ref_06_author.pdf'
    r6 = {
        'number': 6,
        'reviewer': 'root, PDF page images; cost_audit, extracted text',
        'primary_url': 'https://math.mit.edu/~shor/papers/algsfqc-dlf.pdf',
        'version': 'FOCS 1994 author-hosted version with minor corrections and Figure 1, as identified by the author publication list',
        'source_sha256': hashlib.sha256(pdf.read_bytes()).hexdigest(),
        'source_bytes': pdf.stat().st_size,
        'read_pdf_logical_pages': list(range(1, 12)),
        'pdf_physical_page_order_zero_based': list(range(10, -1, -1)),
        'visual_inspection': 'Poppler 125-dpi PNG rendering; all 11 page images read in logical page order',
        'combined_review_status': 'full_extracted_text_complete',
        'read_scope_ja': 'cost_auditの本文テキスト読解に、rootの著者公開PDF全11頁の実画像読解を統合。PDF自体の頁順が逆なので物理頁10→0（0始まり）で論理頁1→11を読んだ。Abstract、§§1–7、式(2.1)–(7.41)、Figure 1、謝辞、全33参考文献を確認し、数式OCR欠損を元画像で補完した。',
        'results_and_assumptions_ja': '因数分解を位数発見へ帰着し、可逆なmodular exponentiation、Fourier変換、測定、連分数による周期回復を組み合わせる。離散対数はp−1がsmoothな場合から一般の場合へ拡張し、確率解析と再試行・古典検算を含む。初期稿のsmooth q構成とCoppersmithの2^k Fourier変換への言及、有限精度で成功確率を保つ議論を区別して確認した。',
        'applicability_ja': '§2のFact 1は、入力を残してfを計算できることと、入力を消してfへ置き換えられることを分ける。後者には単射性とf^{-1}の効率的実装が必要で、前バッチの語を破壊的に上書きしてよい根拠にはならない。位数・Fourier構造を持たない固定75語lookupへそのまま適用できるゲート削減は示されていない。',
        'additional_points_ja': [
            '§2の式(2.2)–(2.5)は、同じ基底測定確率を持つ状態でも相対位相によって後続ユニタリの結果が異なる例。全アドレスの出力値だけでなくHMR位相を追う今回の検証方針に直接関係する。',
            'Figure 1はq=240、r=13の出力確率で、240/13の整数倍付近にピークがある。例示図を1220アドレスの厳密ローダー検証へ置き換えるものではない。',
            '有限精度のFourier変換で成功確率を保つ議論は、今回のBoolean語写像の完全一致要件を緩める許可ではない。'
        ],
        'limitations_ja': '著者サイトはこのPDFに小修正と図の追加があると明記している。1994年会議録の版そのものと完全同一とはしない。本文・数式・図は読んだが、全数論証明の独立再導出や実機再現は行っていない。',
        'demonstrated_gate_saving': False,
    }
    s11 = ROOT / 'cache_01_25/ref_11.md'
    r11 = {
        'number': 11,
        'reviewer': 'root',
        'primary_url': 'https://pure.strath.ac.uk/ws/portalfiles/portal/139863900/Daley_etal_2022_Practical_quantum_advantage_in_quantum_simulation.pdf',
        'version': 'Author accepted manuscript dated 2022-08-31; not the Version of Record',
        'source_sha256': hashlib.sha256(s11.read_bytes()).hexdigest(),
        'read_character_ranges': [[0, 105000]],
        'combined_review_status': 'main_text_complete',
        'read_scope_ja': 'Abstract、I–VIの全本文、Boxes 1–3、Figures 1–2の抽出説明、Table I、謝辞・著者貢献・利益相反まで読解。参考文献の途中まで含む0–105000文字の範囲を確認した。Box 3等に混入した20個のLaTeXiTシリアライズ文字列は非本文メタデータとして出力から除外した。別ファイルSupplementary Informationと残る参考文献欄は未読。',
        'results_and_assumptions_ja': '多体系の動力学について、古典計算の圧縮・サンプリング限界と、アナログ、誤り訂正デジタル、両者を併用する量子シミュレーションを比較する。Hubbard模型の例で較正誤差、Trotter誤差、論理ゲート合成、物理誤り訂正の費用を分ける。検証として異なる装置の比較と局所Hamiltonian learningを説明し、後者は多項式個の局所項からなるモデルAnsatzを前提とする。',
        'applicability_ja': '資源評価では目標精度と実装層を固定して比較する、という点が今回に有用。Hamiltonianの少数パラメータを学習できても、任意入力のローダーの位相を含む全作用が一致したことにはならない。アナログ装置の一括時間発展を今回の許可ゲート1個として換算できず、T-depthや物理量子ビットの改善をnative Toffoli数の改善とはしない。',
        'additional_points_ja': [
            '§IV BとBox 3は、全量子状態のtomographyと局所Hamiltonianのパラメータ推定を明確に分けている。未知の非局所項を無条件に排除する証明にはならない。',
            '本文・Table Iの「today」「next 2–3 years」は2022年の状況・展望。現在の装置規模や計算能力についての記述として流用しない。',
            '近似数値計算が難しい科学問題を解く有用性と、固定Boolean oracleのゲート最小化は異なる課題である。'
        ],
        'limitations_ja': '図・Box内の数式は抽出されたテキストと説明を読んだ範囲で、画像全体の独立確認は行っていない。別ファイル補足にある詳細な誤差予算・ゲートカウント計算は未読で、再現済みとはしない。',
        'demonstrated_gate_saving': False,
    }
    data = {'review_date': '2026-11-15', 'references': [r, r6, r11]}
    (ROOT / 'shallow_root_final_supplement.json').write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n')
    lines = ['# 主論文参考文献[4]の本文・付録補完', '', r['primary_url'], '',
             '## 実読範囲', '', r['read_scope_ja'], '', '## 結果と仮定', '',
             r['results_and_assumptions_ja'], '', '## 実装への判断', '',
             r['applicability_ja'], '', '## 追加確認', '']
    lines += ['- ' + point for point in r['additional_points_ja']]
    lines += ['', '## 留保', '', r['limitations_ja'], '',
              'SHA256: ' + r['source_sha256'], '']
    lines += ['# 主論文参考文献[6]のPDF画像による数式補完', '', r6['primary_url'], '',
              '## 実読範囲', '', r6['read_scope_ja'], '', '## 結果と仮定', '',
              r6['results_and_assumptions_ja'], '', '## 実装への判断', '',
              r6['applicability_ja'], '']
    lines += ['- ' + point for point in r6['additional_points_ja']]
    lines += ['', '## 留保', '', r6['limitations_ja'], '', 'PDF SHA256: ' + r6['source_sha256'], '']
    lines += ['# 主論文参考文献[11]の本文全節補完', '', r11['primary_url'], '',
              '## 実読範囲', '', r11['read_scope_ja'], '', '## 結果と仮定', '',
              r11['results_and_assumptions_ja'], '', '## 実装への判断', '',
              r11['applicability_ja'], '']
    lines += ['- ' + point for point in r11['additional_points_ja']]
    lines += ['', '## 留保', '', r11['limitations_ja'], '', 'SHA256: ' + r11['source_sha256'], '']
    (ROOT / 'shallow_root_final_supplement.md').write_text('\n'.join(lines))
    print(json.dumps({'numbers': [4, 6, 11], 'ref4_combined_characters': len(text), 'ref6_pdf_pages': 11, 'ref11_status': 'main_text_complete'}))


if __name__ == '__main__':
    main()
