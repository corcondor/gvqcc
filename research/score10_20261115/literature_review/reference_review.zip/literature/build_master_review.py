"""Merge actual reading ledgers conservatively, preserving supplemental provenance."""
from collections import Counter
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'deliverables'
LABELS={
 'full_extracted_text_complete':'取得した本文・付録の抽出テキストを全読',
 'main_text_complete':'本文の全節を読解（付録等に未読あり）',
 'main_prose_complete_with_embedded_source_gaps':'本文文章の全節を読解（埋め込み表・数式に取得欠落）',
 'main_results_reviewed':'主要結果・アルゴリズムを読解（未読節あり）',
 'selected_sections':'本文の該当節を読解（未読節あり）',
 'partial_preview_only':'公開previewのみ読解',
 'text_complete_figures_unread':'全文テキスト読解・回路画像未取得',
 'bibliography_only':'書誌のみ'}

def read(name):return json.loads((ROOT/name).read_text())
def listify(x):return x if isinstance(x,list) else ([] if not x else [x])
def std_status(s):
 return {'full_text_read':'full_extracted_text_complete',
         'full_text_read_with_shared_synthesis':'full_extracted_text_complete',
         'full_main_text_read':'main_text_complete',
         'main_text_read_with_selected_appendices':'main_text_complete',
         'partial_text_read':'text_complete_figures_unread'}.get(s,s)
def norm(r,group):
 status=r.get('review_status',r.get('status',r.get('read_scope','selected_sections')))
 if group=='magic':
  status='full_extracted_text_complete' if r.get('fulltext_read') else ('main_results_reviewed' if r.get('main_text_complete') else 'selected_sections')
  scope=r.get('access_scope','')
 else: scope=r.get('reviewed_scope_ja',r.get('read_scope_ja',r.get('reviewed_ranges','')))
 urls=listify(r.get('primary_fulltext_url',r.get('primary_url',r.get('primary_urls',[]))))
 row=dict(id=f"{group}:{r['number']}",group=group,number=r['number'],
          citation=r.get('citation_exact',r.get('citation',r.get('citation_verbatim',r.get('title','')))),
          title=r.get('title',''),primary_urls=urls,
          review_status=std_status(status),reviewed_scope=scope,
          result=r.get('result_ja',r.get('result_and_evidence_ja',r.get('mechanisms_ja',r.get('review_note','')))),
          applicability=r.get('applicability_ja',r.get('gvqcc_applicability_ja',r.get('optimization_applicability_ja',''))),
          limitations=r.get('limitations_ja',r.get('caveats_ja','')),
          retrieved_version=r.get('retrieved_version',r.get('version','')),
          source_sha256=r.get('source_sha256',r.get('cache_sha256','')),
          reading_history=[dict(reviewer=r.get('reviewer','team'),status=std_status(status),scope=scope)])
 if r.get('metadata_note'):row['metadata_note']=r['metadata_note']
 if group=='magic':
  row['limitations']=r.get('extraction_limitations','全文読解は図の全画素確認や全証明の独立再導出を意味しない。')
  row['reading_history'][0].update(fulltext_read=r.get('fulltext_read',False),ranges=r.get('read_character_ranges',[]))
  if not row['applicability']:row['applicability']=r.get('review_note','')
 return row

def apply_supplement(row,r):
 new=std_status(r.get('combined_review_status',r.get('combined_status',r.get('status','main_results_reviewed'))))
 if r.get('main_text_complete_combined'):new='main_text_complete'
 scope=r.get('read_scope_ja',r.get('reviewed_scope_ja',''))
 if not scope:
  scope='追加読解: '+ '; '.join(r.get('read_sections',[]))
  if r.get('unread_sections'):scope+='。未読: '+'; '.join(r['unread_sections'])
 row['reading_history'].append(dict(reviewer=r.get('reviewer','cost_audit'),status=new,scope=scope,
                                    ranges=r.get('read_character_ranges',r.get('read_character_intervals',[])),
                                    source_sha256=r.get('source_sha256','')))
 if new in LABELS:row['review_status']=new
 row['reviewed_scope']=scope if new=='full_extracted_text_complete' else '前回の読解範囲に補完読解を統合。'+scope
 if r.get('results_and_assumptions_ja'):row['result']=r['results_and_assumptions_ja']
 if r.get('additional_points_ja'):row['additional_points']=r['additional_points_ja']
 for k in ['applicability_ja','gvqcc_applicability_ja']:
  if r.get(k):row['applicability']=r[k]
 if r.get('limitations_ja'):row['limitations']=r['limitations_ja']
 for k in ['independent_check_ja','algorithm2_scope_check_ja','independent_counterexample_ja','quantifier_caution_ja']:
  if r.get(k):row.setdefault('additional_points',[]).append(r[k])
 if r.get('version'):row['retrieved_version']=r['version']
 if r.get('source_sha256'):row['source_sha256']=r['source_sha256']
 if r.get('primary_url'):row['primary_urls']=list(dict.fromkeys(row['primary_urls']+[r['primary_url']]))

def main():
 OUT.mkdir(exist_ok=True)
 records=[]
 for file in ['refs_01_25.json','refs26_43/reading_ledger.json','refs_44_61_and_v1_only.json']:
  records += [norm(r,'shallow') for r in read(file)['references']]
 records += [norm(r,'magic') for r in read('linked_sources/magic_coverage.json')['references']]
 for file in ['graphene_refs_01_28.json','graphene_refs_29_56.json']:
  records += [norm(r,'graphene') for r in read(file)['references']]
 byid={r['id']:r for r in records}
 assert len(records)==len(byid)==171
 for file in ['cost_audit_supplement/reading_ledger.json','root_reference_supplement.json','root_reference_supplement_cost.json','shallow_final_supplement.json','shallow_root_final_supplement.json']:
  if (ROOT/file).exists():
   d=read(file)
   for r in d.get('references',[]):apply_supplement(byid[f"shallow:{r['number']}"],r)
 for file in ['graphene_supplement_29_42.json','graphene_supplement_43_56.json']:
  if (ROOT/file).exists():
   for r in read(file).get('references',[]):apply_supplement(byid[f"graphene:{r['number']}"],r)
 overlaps=[(38,1),(19,17),(13,25),(16,26),(36,27)]
 for a,b in overlaps:
  s,m=byid[f'shallow:{a}'],byid[f'magic:{b}']
  s['same_work_as']=m['id'];m['same_work_as']=s['id']
  # Share full-document reading only when explicitly completed by a reviewer.
  if m['review_status']=='full_extracted_text_complete' and s['review_status']!='full_extracted_text_complete':
   s['reading_history'].append(dict(reviewer='shared magic-paper review',status=m['review_status'],scope=m['reviewed_scope']))
   s['review_status']=m['review_status'];s['reviewed_scope']='同一文献を記号表論文の参考文献として全文補完。'+m['reviewed_scope']
  elif a==13 and m['review_status']!='full_extracted_text_complete':
   s['reading_history'].append(dict(reviewer='shared magic-paper review',status=m['review_status'],scope=m['reviewed_scope']))
   s['reviewed_scope']+=' 追加読解: '+m['reviewed_scope']
 counts={g:dict(Counter(r['review_status'] for r in records if r['group']==g)) for g in ['shallow','magic','graphene']}
 overall=dict(Counter(r['review_status'] for r in records))
 metadata=dict(date='2026-11-15',bibliographic_entry_count=171,
               groups=dict(shallow=62,magic=53,graphene=56),
               main_versions=dict(v1=55,v2=61,union=62,v1_only='v1[55], arXiv:2404.14493'),
               known_cross_parent_duplicate_pairs=overlaps,
               counts_by_group=counts,counts_total=overall,status_definitions=LABELS,
               limits='本文取得を読了と数えない。全件を同じ深さで通読したという主張ではない。図画像・全証明・全実験の独立検算ではない。',
               public_access_gap='主論文[14] Kitaev 1997 は8頁のうち公開preview2頁のみ。主論文[43]は質問と全回答テキストを読了したが回路画像4枚は未取得。',
               known_embedded_source_gaps='graphene[31]はTable 1の表セル、[32]は画像化された数式、[47]はHTMLで欠けた数式に未取得箇所がある。文章の全節読解と区別した。',
               raw_source_distribution='原著全文の再配布を含めず、書誌、一次URL、実読範囲、独自の分析・適用判断を保存。')
 data=dict(metadata=metadata,references=records)
 (OUT/'reference_review.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 lines=['# 指定論文と参考文献全171項目の調査台帳','',
        '全項目に出典・読解範囲・内容・今回の回路への適用判断を付けた。全文通読、本文全体の読解、該当節の読解、公開previewだけの確認を区別する。',
        '',metadata['limits'],'',
        '番号は shallow=主論文の公刊版/v2、magic=記号表の出典、graphene=グラフェン論文。主論文v1のみの55は独立行で保持する。','',
        '| 系統 | 項目数 | 抽出テキスト全読 | 本文全節 | 本文文章・表数式欠落 | 主要結果・選択節 | preview等 |',
        '|---|---:|---:|---:|---:|---:|---:|']
 for g,label in [('shallow','主論文（旧版差分込み）'),('magic','記号表の出典'),('graphene','グラフェン論文')]:
  c=counts[g]
  lines += [f"| {label} | {sum(c.values())} | {c.get('full_extracted_text_complete',0)} | {c.get('main_text_complete',0)} | {c.get('main_prose_complete_with_embedded_source_gaps',0)} | {c.get('selected_sections',0)+c.get('main_results_reviewed',0)} | {c.get('partial_preview_only',0)+c.get('text_complete_figures_unread',0)+c.get('bibliography_only',0)} |"]
 lines += ['',metadata['public_access_gap'],'',metadata['known_embedded_source_gaps'],'','同一原著の5組の重複は読解情報を共有するが、文献欄上の項目数には両方を含める。','']
 for r in records:
  lines += [f"## {r['id']} — {r['citation']}",'',
            '**一次資料:** '+ ' / '.join(r['primary_urls']),'',
            '**読解状態:** '+LABELS.get(r['review_status'],r['review_status']),'',
            '**実読範囲:** '+str(r['reviewed_scope']),'',
            '**内容:** '+str(r['result']),'',
            '**今回の実装への判断:** '+str(r['applicability']),'']
  if r.get('additional_points'):lines += ['**補完読解で確認した点:** '+' / '.join(r['additional_points']),'']
  if r.get('limitations'):lines += ['**留保:** '+str(r['limitations']),'']
  if r.get('metadata_note'):lines += ['**取得版の注意:** '+str(r['metadata_note']),'']
  if r.get('same_work_as'):lines += ['同一文献: '+r['same_work_as'],'']
 (OUT/'reference_review.md').write_text('\n'.join(lines))
 (OUT/'reading_counts.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
 template=ROOT/'findings_template.md'
 if template.exists():
  table=['| 文献群 | 全項目 | 抽出テキスト全読 | 本文全節 | 本文文章・表数式欠落 | 主要結果・選択節 | preview等 |',
         '|---|---:|---:|---:|---:|---:|---:|']
  for g,label in [('shallow','主論文（旧版差分込み）'),('magic','記号表の出典'),('graphene','グラフェン論文')]:
   c=counts[g]
   table.append(f"| {label} | {sum(c.values())} | {c.get('full_extracted_text_complete',0)} | {c.get('main_text_complete',0)} | {c.get('main_prose_complete_with_embedded_source_gaps',0)} | {c.get('selected_sections',0)+c.get('main_results_reviewed',0)} | {c.get('partial_preview_only',0)+c.get('text_complete_figures_unread',0)+c.get('bibliography_only',0)} |")
  (OUT/'LITERATURE_FINDINGS_JA.md').write_text(template.read_text().replace('<!-- READING_COUNTS -->','\n'.join(table)))
 print(json.dumps(dict(counts=counts,overall=overall,total=len(records)),ensure_ascii=False))

if __name__=='__main__':main()
