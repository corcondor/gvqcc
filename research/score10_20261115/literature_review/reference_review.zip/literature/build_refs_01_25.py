from pathlib import Path
import json, hashlib, collections

ROOT = Path(__file__).resolve().parent
bib = json.loads((ROOT / 'main_references.json').read_text())
data = [
dict(n=1, title='The Computational Complexity of Linear Optics', authors='Scott Aaronson; Alex Arkhipov', year=2011,
 url='https://arxiv.org/pdf/1011.3245', version='arXiv:1011.3245v1 (2010); STOC 2011 の長編著者版',
 scope='§1の冒頭約28,000文字（モデル・exact/approximate hardness・主要予想）、Appendix 12 冒頭約5,000文字。93頁全体の証明は未読。',
 result='exact BosonSampling の効率的古典模擬から PH collapse を導く。近似版は Gaussian permanent と anti-concentration の追加仮定を伴う。Appendix 12 の加法誤差 permanent 推定は指数的に小さい振幅の相対精度を保証しない。',
 evidence='§1.3 Theorems 1, 3、Conjectures 5, 6; Appendix 12 (Gurvits algorithm).',
 apply='固定表の全アドレスで厳密な XOR を実行するローダーに、サンプリングの加法近似を代入する根拠にはならない。光学モデルの一般的困難性は J=4 の Toffoli 下界を与えない。', action='background_only'),
dict(n=2, title='BosonSampling Is Far From Uniform', authors='Scott Aaronson; Alex Arkhipov', year=2013,
 url='https://arxiv.org/pdf/1309.7460', version='arXiv:1309.7460v2, 2013-10-01',
 scope='冒頭約23,000文字（§§1–4、§5冒頭）と §9 全文。§§7–8 の詳細証明・付録は未読。',
 result='典型的な BosonSampling 分布と一様分布を、多項式時間で計算できる行ノルム統計により定数バイアスで区別する。すべての古典的模倣分布から区別できるという主張ではない。',
 evidence='主定理、row-norm estimator、§9 Summary and Open Problems.',
 apply='特定の統計的検査を通ることと、回路全体の意味が一致することを区別する。全アドレス・任意ターゲット・相対位相の既存検証を維持する根拠になる。直接のゲート削減はない。', action='verification_contract'),
dict(n=3, title='Universal computation by multiparticle quantum walk', authors='Andrew M. Childs; David Gosset; Zak Webb', year=2013,
 url='https://arxiv.org/pdf/1205.3782', version='arXiv:1205.3782v2, 2013-02-15', status='main_text_complete',
 scope='主本文の冒頭から Discussion 末尾まで（約29,200文字）を読了。付録の散乱・誤差証明は未読。',
 result='相互作用する多粒子の量子歩行を用い、静的 Hamiltonian と最大次数4の疎な平面グラフで普遍計算を構成する。厳密構成では波束長・実行時間・グラフ規模に大きい多項式 overhead がある。',
 evidence='主本文の encoded qubits、scattering gates、universality construction、Discussion.',
 apply='アナログな散乱ゲートを許可ゲートへ再コンパイルした費用は別に必要。普遍性だけから、128量子ビット以内で低 Toffoli のローダーが得られるとは判断できない。', action='architecture_not_directly_applicable'),
dict(n=4, title='Complexity-Theoretic Foundations of Quantum Supremacy Experiments', authors='Scott Aaronson; Lijie Chen', year=2016,
 url='https://arxiv.org/pdf/1612.05903', version='arXiv:1612.05903v2, 2016-12-26',
 scope='abstract・序論冒頭約12,500文字と §4 全文（Theorems 4.1–4.6 の証明を含む）。他章の hardness 証明は未読。',
 result='回路を深さ方向に分割する再帰で振幅を多項式空間で計算し、時間と空間の交換を示す。格子局所回路では幾何的分割による改善があり、一般回路への無条件適用ではない。',
 evidence='§4 Classical Simulation Algorithms, Theorems 4.1–4.6.',
 apply='小さな切断幅を持つ回路窓の検証メモリを減らす候補。量子回路に実行される Toffoli 数は減らず、ローダー全体が格子局所・低深さという前提も未証明。', action='verifier_candidate'),
dict(n=5, title='Rapid solution of problems by quantum computation', authors='David Deutsch; Richard Jozsa', year=1992,
 url='https://www.isical.ac.in/~rcbose/internship/lectures2016/rt08deutschjozsa.pdf', version='Proc. R. Soc. Lond. A 439, 553–558 (1992), 原論文の機関保管PDF', status='full_extracted_text_complete',
 scope='6頁の抽出本文を参考文献まで読了。図の独立した画素検査は行っていない。',
 result='constant/balanced の promise を用いる。1992年の原構成は Uf S Uf と oracle を2回呼び出す。任意の第二レジスタ j に対する可逆 oracle を定義し、計算・位相操作・逆計算で作業レジスタを戻す。',
 evidence='pp.554–557、oracle 定義と Uf S Uf のアルゴリズム。',
 apply='ゼロターゲットだけでなく任意 y に |a,y>→|a,y XOR f(a)> を満たすという契約を支持する。現代の1-query版と原論文を混同しない。Toffoli 削減手法は提示しない。', action='verification_contract'),
dict(n=6, title='Algorithms for Quantum Computation: Discrete Logarithms and Factoring', authors='Peter W. Shor', year=1994,
 url='https://math.mit.edu/~shor/papers/algsfqc-dlf.pdf', version='FOCS 1994, pp.124–134; 著者サイトの微修正版',
 scope='title/abstract/§1 と §3 Building unitary transformations を部分確認。PDFの頁順が逆、数式OCRに欠損があるため全論文読了とは扱わない。',
 result='周期構造を量子 Fourier 変換で読み取り、整数因数分解・離散対数を多項式時間で解く初期論文。可逆な算術構成が必要であり、oracle 呼出回数と具体的算術ゲート数は異なる。',
 evidence='著者の電子論文一覧 https://math.mit.edu/~shor/elecpubs.html; abstract; §3.',
 apply='固定75語表の lookup に、そのまま使える QROM 合成はない。長編改訂版[8]と別文献として追跡した。読み取り不良部分の定数ゲート費用は引用しない。', action='background_only'),
dict(n=7, title='On the Power of Quantum Computation', authors='Daniel R. Simon', year=1997,
 url='https://www.cs.miami.edu/home/burt/learning/csc595.251/s0097539796298637.pdf', version='SIAM J. Comput. 26, 1474–1483 (1997), 原論文の機関保管PDF', status='full_extracted_text_complete',
 scope='10頁の抽出本文・証明・参考文献を読了。',
 result='一対一または共通 XOR period を持つ二対一という promise の下で、Fourier sampling から period に直交する線形方程式を得る。oracle 相対の指数的隔たりを示す。',
 evidence='oracle promise、量子アルゴリズム、成功確率と classical lower-bound 証明。',
 apply='固定真理値表に共通 period があるかは古典的に全行検査できる。ただし一般の75語表に promise はなく、Simon を組み込むこと自体はローダー削減にならない。', action='conditional_structure_test'),
dict(n=8, title='Polynomial-Time Algorithms for Prime Factorization and Discrete Logarithms on a Quantum Computer', authors='Peter W. Shor', year=1999,
 url='https://arxiv.org/pdf/quant-ph/9508027', version='arXiv:quant-ph/9508027v2 (1996); bibliography は SIAM Review 41 (1999) を引用',
 scope='abstract・序論冒頭、§3 reversible logic と modular exponentiation 全文、§7 comments/open problems 全文。他の数論・確率証明は未読。',
 result='古典回路を入力保持・計算・コピー・逆計算で可逆化する。F と F^{-1} の両方が効率的なら、条件を満たす写像を in-place 化できる。固定定数の事前計算や作業領域再利用も区別する。',
 evidence='§3 Building unitary transformations; §7.',
 apply='再利用する前バッチ値を消去する際に、逆写像の存在と実装費用を明示する。未知ターゲットをゼロと仮定して上書きする根拠にはならない。', action='cleanup_contract'),
dict(n=9, title='Simulating Physics with Computers', authors='Richard P. Feynman', year=2018,
 url='https://www.ccsl.carleton.ca/~saran/other-papers/Feynman_SimulatingPhysicsWithComputers.pdf', version='書誌は2018年再録 pp.133–153; 読んだ本文は original IJTP 21, 467–488 (1982)', cache='ref_09_full.md',
 scope='序論冒頭、§§4–5全文、§9 discussion全文。§§2–3、6–8 は全読していない。',
 result='量子系を量子系で模擬する動機と、局所的古典確率記述が量子相関を再現する難しさを論じる。負の準確率なども扱うが、現代の具体的計算量下界を与える論文ではない。',
 evidence='original 1982 paper, §§4–5 and 9; DOI 10.1007/BF02650179.',
 apply='研究動機の背景として参照する。1982年の議論を J4 loader の最小 Toffoli 数や現在のハードウェア費用へ転用しない。再録版そのものを読んだとは主張しない。', action='background_only'),
dict(n=10, title='Toward the First Quantum Simulation with Quantum Speedup', authors='Andrew M. Childs; Dmitri Maslov; Yunseong Nam; Neil J. Ross; Yuan Su', year=2018,
 url='https://arxiv.org/pdf/1711.10980', version='arXiv:1711.10980v1, 2017-11-29; PNAS 115 (2018)', status='main_text_complete',
 scope='主論文全文、Appendix E全文、Appendix G.3 と G.4 の制御生成・最適化の証明および費用集計を確認。他の長い付録は未読。',
 result='Hamiltonian simulation の複数方式を具体回路で比較する。SELECT の二進木巡回で共通制御を使い回し、Toffoli対の恒等式・極性変更を使う。NCT制御生成構成は ≤1.5·2^w−4 Toffoli、w−1 clean ancilla。Clifford+T分解では別の相殺も行う。',
 evidence='Appendix E; G.3–G.4, Lemmas G.6–G.7, Eqs.(179)–(183).',
 apply='アドレス変数順序とprefix DAGを候補にする。既存共有bankの節約を二重計上せず、128Q以内で追加制御の準備・消去まで実測する。G.6は限定NCT制御生成モデルの下界であり、一般の多出力ローダー下界ではない。H/T/Phaseの最適化は化学の許可集合で再実装が必要。', action='synthesis_candidate'),
dict(n=11, title='Practical Quantum Advantage in Quantum Simulation', authors='Andrew J. Daley; Immanuel Bloch; Christian Kokail; Stuart Flannigan; Natalie Pearson; Matthias Troyer; Peter Zoller', year=2022,
 url='https://pure.strath.ac.uk/ws/portalfiles/portal/139863900/Daley_etal_2022_Practical_quantum_advantage_in_quantum_simulation.pdf', version='Nature 607, 667–676 (2022); 著者最終稿',
 scope='abstract・序論、§§II–III全文、§IVの大部分、§VI結論。図表・boxes・補足の全読ではない。',
 result='有用性・古典比較・制御できる誤差を含めて practical advantage を評価する。アナログ模擬の特定観測量と、汎用デジタル回路の状態精度・耐故障費用を区別する。',
 evidence='§§II–IV and VI; DOI 10.1038/s41586-022-04940-6.',
 apply='比較する誤差モデルを同じにする。観測量だけの近似が実用的という議論は、今回の厳密 lookup 置換を許すものではない。固定表の合成レシピはない。', action='cost_model_discipline'),
dict(n=12, title='Randomized Benchmarking of Quantum Gates', authors='E. Knill; D. Leibfried; R. Reichle; J. Britton; R. B. Blakestad; J. D. Jost; C. Langer; R. Ozeri; S. Seidelin; D. J. Wineland', year=2008,
 url='https://arxiv.org/pdf/0707.0963', version='arXiv:0707.0963v1 (2007); Phys. Rev. A 77, 012307 (2008)', status='full_extracted_text_complete',
 scope='§§I–VI、Appendix A、図のcaptionと参考文献を含む抽出本文を全読。',
 result='既知の最終測定を持つランダム Clifford 列の減衰から平均的ゲート誤差を推定し、SPAMと分離する。解釈には定常性・記憶なし等の仮定がある。',
 evidence='randomized benchmarking protocol、error model、Appendix A.',
 apply='ハードウェア誤差の評価法であり、コンパイラの厳密等価性を証明する検査ではない。統計的fidelityを全アドレス・任意入力・位相検証の代わりにしない。', action='verification_contract'),
dict(n=13, title='Stabilizer Codes and Quantum Error Correction', authors='Daniel Gottesman', year=1997,
 url='https://arxiv.org/pdf/quant-ph/9705052', version='Caltech PhD thesis (1997), arXiv:quant-ph/9705052v1',
 scope='目次、§§5.3–5.4全文（Clifford変換・測定・論理演算子）、§5.7全文（Toffoli注入・ancilla作製）。114頁の論文全体は未読。',
 result='Pauliの共役と符号空間の論理演算子で演算を追跡する。測定の負の分岐を正の分岐へ直すには、既知の安定化子と反可換性が必要。Toffoli注入は非Clifford ancillaの作製費を必要とする。',
 evidence='§5.4 Eq.(5.16); §5.7 Eqs.(5.21)–(5.31).',
 apply='HMR後の補正と任意ターゲットを論理X/Zまで追う検証に直接役立つ。Toffoliを注入回路に書き換えても、magic ancillaの準備を無料にはできない。', action='phase_verification'),
dict(n=14, title='Quantum Error Correction with Imperfect Gates', authors='Alexei Yu. Kitaev', year=1997,
 url='https://link.springer.com/chapter/10.1007/978-1-4615-5923-8_19', version='Quantum Communication, Computing, and Measurement, pp.181–188 (1997)', status='partial_preview_only', access='partial_preview', cache='ref_14_preview.md',
 extra_url='https://page-one.springer.com/pdf/preview/10.1007/978-1-4615-5923-8_19',
 scope='出版社のabstractとpp.181–182の2頁previewを全読。pp.183–188の6頁は取得不可。別題のKitaev論文で代用していない。',
 result='不完全ゲートの下の誤り訂正を扱い、低い一定decoherence率での耐故障保存を導入する。previewではsymplectic check operatorによる符号を説明する。全証明は確認できない。',
 evidence='Publisher abstract and preview pp.181–182; DOI 10.1007/978-1-4615-5923-8_19.',
 apply='物理的QEC overheadと今回の論理ゲート採点を区別するための背景。未取得の6頁について回路恒等式・閾値証明を検証済みとはしない。', action='access_gap'),
dict(n=15, title='The Heisenberg Representation of Quantum Computers', authors='Daniel Gottesman', year=1998,
 url='https://arxiv.org/pdf/quant-ph/9807006', version='arXiv:quant-ph/9807006v1, 1998-07-01', status='full_extracted_text_complete',
 scope='20頁の抽出本文、examples、測定節、結論・参考文献まで読了。PDF再生成日を出版年に使っていない。',
 result='Clifford演算・Pauli測定・古典条件付きCliffordをPauli生成元で追跡する。測定Aと反可換な既知安定化子Mにより分岐を補正する。任意入力は論理X/Zを保持して扱う。',
 evidence='Heisenberg generators、§7 Measurements、teleportation examples.',
 apply='局所HMR cleanupの位相込み証明に適する。ゼロ入力の状態一致のみでは未知32ビットの写像を証明できない。Toffoli部分は非Cliffordなので純粋tableauだけでは処理できない。', action='phase_verification'),
dict(n=16, title='Improved Simulation of Stabilizer Circuits', authors='Scott Aaronson; Daniel Gottesman', year=2004,
 url='https://arxiv.org/pdf/quant-ph/0406196', version='arXiv:quant-ph/0406196v5, 2008-06-18; PRA 70, 052328 (2004)',
 scope='abstract・序論・§II前半、§III全文、§§VI–VII全文（証明を含む）。§§IV–V、VIIIの全読ではない。',
 result='stabilizer/destabilizerの二重tableauで測定をO(n²)時間にし、Clifford回路のcanonical formを構成する。少数非Cliffordへの拡張はその個数に指数依存する。ユニタリの等価性は2n個のPauli像で判定する。',
 evidence='§III tableau algorithm; §VI Lemma5, Theorem8, Corollary9; §VII.',
 apply='Clifford区間の独立等価性チェックに利用できる。CNOT総数の削減だけではToffoli採点は改善せず、canonical formのH/Pをそのまま化学へ出力できない。', action='verifier_candidate'),
dict(n=17, title='Efficient Inner-product Algorithm for Stabilizer States', authors='Héctor J. García; Igor L. Markov; Andrew W. Cross', year=2012,
 url='https://arxiv.org/pdf/1210.6646', version='arXiv:1210.6646v3, 2013-08-07 (初稿2012)', status='main_text_complete',
 scope='§§I–VIIの主本文を読了。Appendix Aの1080個の3-qubit state一覧は全読していない。',
 result='canonical stabilizer matrix、H-C-CZ-P-Hのstate-normalization回路、O(n³)内積計算を構成する。stabilizer frameでは各成分の位相も必要。state synthesisと任意入力unitary synthesisは異なる。',
 evidence='Algorithms1–3; §VI Stabilizer Frames; §VII.',
 apply='小規模Clifford候補の状態比較・重複除去に使える。内積の絶対値だけでは相対位相は消えるため、複素係数を含む検証では位相を追跡する[18]の説明を併用する。', action='phase_verification'),
dict(n=18, title='On the Geometry of Stabilizer States', authors='Héctor J. García; Igor L. Markov; Andrew W. Cross', year=2014,
 url='https://www.rintonpress.com/xxqic14/qic-14-78/0683-0720.pdf', version='Quantum Information and Computation 14, 683–720 (2014), 出版社全文',
 scope='abstract・§1全文・§2冒頭、§§4–5全文、§7の主要結論。§3の全証明、§6全体、全列挙付録は未読。',
 result='nearest-neighbor構造、内積・直交化を調べる。greedy searchが最も近いstabilizer stateを保証しない反例を示す。複素内積を得るにはcanonical変換に伴うglobal phaseを各成分ごとに保存する。',
 evidence='§4.1 counterexample; §5.2 Complex-valued inner product; §5.3 Algorithm5.3.',
 apply='ヒューリスティック探索で改善がないことを最適性証明としない。多数成分を混ぜる検証では各成分の位相を保持する。stabilizer rankとGF(2)の多出力積rankを同一視しない。', action='phase_verification'),
dict(n=19, title='Improved Classical Simulation of Quantum Circuits Dominated by Clifford Gates', authors='Sergey Bravyi; David Gosset', year=2016,
 url='https://arxiv.org/pdf/1601.07601', version='arXiv:1601.07601v3, 2019-04-09; PRL 116, 250501 (2016)', status='main_text_complete',
 scope='主本文§§I–V、acknowledgmentsを読了。Appendix A冒頭のみ、Appendices B–Fは未読。',
 result='exact stabilizer decompositionで出力確率を相対誤差推定し、approximate decompositionで分布を小さいL1誤差でsampleする。postselection確率の正規化を明示し、norm estimationをrankの二乗から線形へ改善する。',
 evidence='§IV Eqs.(9)–(29), including postselection factor2^t; §V.',
 apply='少数CCXを含む局所検証の候補。全回路5197 CCXへ指数アルゴリズムを適用する実益は未確認。近似samplingと相対確率推定を、厳密なoracle等価性に取り替えない。', action='verifier_candidate'),
dict(n=20, title='Trading Classical and Quantum Computational Resources', authors='Sergey Bravyi; Graeme Smith; John A. Smolin', year=2016,
 url='https://arxiv.org/pdf/1506.01396', version='arXiv:1506.01396v1, 2015-06-03; PRX 6, 021043 (2016)', status='full_extracted_text_complete',
 scope='14頁の主本文、Appendices A–Cの証明、参考文献を含む抽出本文を全読。',
 result='sparse circuit/PBCにvirtual qubitを足す代わりに2^O(k)回の反復と古典処理を使う。Pauli測定のPBCと低stabilizer rankを構成し、6-copy magic stateの7項分解を与える。出力は古典確率の加法近似である。',
 evidence='Theorems1–4; §§III–V; AppendicesA–C.',
 apply='128Q制限を古典的なquasi-probability和で回避しても、coherentなローダー置換にはならない。7項最適という当時の予想は[23]で改良されており、探索上界を下界として扱わない。', action='cost_model_discipline'),
dict(n=21, title='Simulation of Quantum Circuits by Low-Rank Stabilizer Decompositions', authors='Sergey Bravyi; Dan Browne; Padraic Calpin; Earl Campbell; David Gosset; Mark Howard', year=2019,
 url='https://arxiv.org/pdf/1808.00128', version='arXiv:1808.00128v2, 2019-08-27; Quantum3,181 (2019)',
 scope='§§1–3全文、§§4.1–4.2全文、§4.3冒頭。§§5–6の詳細証明は未読。',
 result='stabilizer extentとsparsificationで古典模擬を拡張し、CCZを4Tへ分解するより直接CCZとして扱う方が速い例を示す。CH-formは成分のglobal phaseを保持する。Metropolisのmixing timeは一般には保証されない。',
 evidence='§2.3, Eq.(31) ξ(CCZ)=16/9; §2.4.2; §4.1 CH-form; §4.2.',
 apply='CCZ窓の位相を保持した独立検証には候補。和のClifford分解は実行可能なCliffordだけの単一回路ではない。simulation exponentの削減を実Toffoli削減として数えない。', action='verifier_candidate'),
dict(n=22, title='Improved Strong Simulation of Universal Quantum Circuits', authors='Lucas Kocia', year=2020,
 url='https://arxiv.org/pdf/2012.11739', version='arXiv:2012.11739v4, 2022-06-07 (初稿2020)', status='main_text_complete',
 scope='主本文§§I–VIIと参考文献を読了。Appendices A–Fの詳細式は未読。',
 result='12-copy magic stateで49項を47項へまとめる構成を示す。single-Pauliの制限されたGauss-sum表現では42項が得られるが、multi-Pauliへの同じ改善は未証明と明記する。これらは構成上界で最小性の証明ではない。',
 evidence='§II pair-merging construction; §III restrictions; §VI caution and open questions.',
 apply='同一項・符号項を構成後にまとめる発想は参考になるが、量子stabilizer和とGF(2)積回路は異なる。0.449を普遍的simulation exponentやJ4回路の下界にしない。[23]の後続改善とも区別する。', action='conditional_structure_test'),
dict(n=23, title='Improved Upper Bounds on the Stabilizer Rank of Magic States', authors='Hammam Qassim; Hakop Pashayan; David Gosset', year=2021,
 url='https://arxiv.org/pdf/2106.07740', version='arXiv:2106.07740v2, 2021-12-15; Quantum5,606 (2021)', status='full_extracted_text_complete',
 scope='12頁の抽出本文、全証明とAppendix Aを読了。',
 result='cat-stateの接続でexact stabilizer-rank上界をO(2^{log2(3)m/4})へ改善し、6-copyの6項分解を与える。Clifford/postselectionによる数学的構成で、既存7項の最適性予想を覆す。',
 evidence='cat-state chain construction; main upper-bound theorem; Appendix A.',
 apply='局所的な古典検証の表現を減らす可能性がある。postselectionを無料のmagic-state準備として実装費から除外しない。stabilizer rankの改善だけでは実回路Toffoli数を更新できない。', action='verifier_candidate'),
dict(n=24, title='Quantum and Classical Tradeoffs', authors='Yaoyun Shi', year=2005,
 url='https://arxiv.org/pdf/quant-ph/0312213', version='arXiv:quant-ph/0312213v2, 2003-12-30; TCS344,335–345 (2005)', status='full_extracted_text_complete',
 scope='11頁の抽出本文・証明・参考文献を全読。',
 result='basis-changing gateをquantumnessの尺度として、state-preparationのentropyと必要ゲート数、Grover queryとbasis-changing層の交換を扱う。Toffoliはこの論文ではbasis-preserving演算に含まれる。',
 evidence='quantum/classical gate definitions; state-generation theorem; Grover tradeoff.',
 apply='多くのToffoliを持つ古典的XOR回路でも基底入力の古典模擬は容易になり得る。Hadamard深さ・entropy下界は今回のToffoli数下界と異なる。浅いmagic深さを直接cost低下とみなさない。', action='cost_model_discipline'),
dict(n=25, title='Quantum Measurements and the Abelian Stabilizer Problem', authors='Alexei Yu. Kitaev', year=1995,
 url='https://arxiv.org/pdf/quant-ph/9511026', version='arXiv:quant-ph/9511026v1, 1995-11-20', status='full_extracted_text_complete',
 scope='22頁の抽出本文、全章・証明・結論・参考文献まで読了。',
 result='Abelian stabilizerは群作用の安定化群問題で、stabilizer stateのrankとは別概念。Lemma1は任意ターゲットへのXOR可逆化をcompute-copy-uncomputeで構成し、入力依存garbageがcoherenceを壊す点を説明する。',
 evidence='§2.2 Lemma1; §2.4.5; §3 controlled powers; §5 Theorem2.',
 apply='全32ターゲットビット、scratch消去、測定後位相まで検査する契約に直結する。近似copy/uncompute定理の誤差と、U|0>=|0>を仮定するcontrolled-U構成を、条件確認なしにローダーへ適用しない。', action='cleanup_contract'),
]

rows=[]
for d in data:
    n=d.pop('n')
    b=bib['references'][n-1]
    p=ROOT/'cache_01_25'/d.pop('cache',f'ref_{n:02d}.md')
    row=dict(number=n, citation_exact=b['citation'], title=d.pop('title'), authors=d.pop('authors'), publication_year=d.pop('year'), primary_fulltext_url=d.pop('url'), retrieved_version=d.pop('version'), access=d.pop('access','full_text'), review_status=d.pop('status','selected_sections'), reviewed_scope_ja=d.pop('scope'), result_ja=d.pop('result'), evidence_locator=d.pop('evidence'), applicability_ja=d.pop('apply'), action=d.pop('action'), full_text_retrieved=n!=14, local_cache=str(p), cache_sha256=hashlib.sha256(p.read_bytes()).hexdigest(), cache_characters=len(p.read_text()), source_bibliography_url=b['source_bibliography_url'], **d)
    rows.append(row)

status_counts=dict(collections.Counter(r['review_status'] for r in rows))
ledger=dict(main_paper=bib['main_paper'], main_doi=bib['doi'], numbering='Published/arXiv v2 references 1–25 inclusive; identical numbers in v1.', retrieval_and_review_are_distinct=True, full_text_retrieved=24, partial_preview_retrieved=1, review_counts=status_counts, review_date='2026-11-15', review_method='Primary author/publisher/institution PDF or arXiv full text retrieved using web extraction, then actual extracted text read in the stated ranges. Full extracted-text read does not assert independent visual inspection of all equations/figures. Cached originals are internal research material, not a redistribution deliverable.', references=rows)
(ROOT/'refs_01_25.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2)+'\n')

labels={'full_extracted_text_complete':'抽出本文全読','main_text_complete':'主本文全読・付録一部/未読','selected_sections':'章を選んで本文確認','partial_preview_only':'2頁previewのみ'}
intro='''# 主論文の引用文献 [1]–[25]：本文レビューと回路最適化への適用

対象は Zhang & Zhang, **Classical Simulability of Quantum Circuits with Shallow Magic Depth**, PRX Quantum 6, 010337 (2025) の出版版の引用番号である。[出版版](https://journals.aps.org/prxquantum/abstract/10.1103/PRXQuantum.6.010337) と [arXiv v2](https://arxiv.org/html/2409.13809v2) の対応は別台帳で確認した。

## 実際に確認できた範囲

25件すべてについて一次論文の所在を確認した。**24件の全文を取得し、[14]は8頁中2頁のpreviewを取得した。** 取得と読了を分けると、抽出本文の全読8件、主本文全読（長い付録は一部または未読）5件、章を選んだ本文確認11件、previewのみ1件である。したがって「25件の全ページを読み終えた」とは主張しない。[6]は頁順と数式OCRにも問題がある。長編の未読範囲と版の相違は各項目に明記した。

抽出本文の全読は、取得したテキストの全体を読んだという意味であり、全図・全数式を画像で独立照合したことを意味しない。以下は独自の要約と適用判断であり、全文キャッシュは再配布する成果物ではない。

## 実装判断

今回の基準は、依頼の実装文脈で確定した **27.32784222（4030ローダー版）**、J=4 の片道合計 **L≤4170**、局所 **128Q**、全1232有効アドレス・任意32ターゲットビットへのXOR・補助領域消去・HMR後の位相一致である。このレビューはその公式採点式を独立に再計算する作業ではない。

1. **制御の共有を合成候補にする。[10]** Appendix G のSELECT木では、共通接頭辞と極性の関係を使って実ゲート列を短縮する。既存の共有bankにも同じ種類の節約が含まれるため、追加の変数順序・共通部分DAGが本当に新しい節約を生むか、生成回路で比較する必要がある。論文の限定モデルの下界をローダー全体の下界に流用しない。
2. **測定を含む書換えを位相込みで検証する。[13],[15]–[19],[21],[25]** 初期化したancillaの安定化子と、未知入力の論理X/Zを両方追う。複数のstabilizer成分を扱うときは各成分のglobal phaseが相互のrelative phaseになるため、内積の絶対値だけの比較では足りない。Clifford区間にはtableau/CH-form、非Cliffordの小窓にはexact decompositionを候補にできる。
3. **古典シミュレーションの改善を実回路費用から分ける。[19]–[24]** stabilizer rank、extent、Gauss-sum項数、Hadamard層数はそれぞれ異なる量である。低rankの線形結合は、同じゲート集合による短い単一回路を意味しない。PBCのvirtual qubitやpostselectionも、coherentな任意入力oracleの幅制限を無料で回避するものではない。
4. **検証の目的を保つ。[1],[2],[5],[7],[11],[12],[25]** 加法誤差の確率推定、平均fidelity、特定統計の一致は、それぞれ有用な別の検査である。今回必要な厳密なlookup写像の一致は、それらから自動的には従わない。

この担当範囲から、数値として採用できる新しいToffoli削減はまだ得ていない。上記は次の候補を選ぶ根拠であり、合成・実回路カウント・全アドレスと位相の検証・公式検証を省略する根拠ではない。

## 文献ごとの台帳

| 番号 | 文献 | 確認状態 |
|---:|---|---|
'''
out=[intro]
for r in rows:
    out.append(f"| [{r['number']}] | [{r['title']}]({r['primary_fulltext_url']}) | {labels[r['review_status']]} |\n")
for r in rows:
    out.append(f"\n### [{r['number']}] {r['title']}\n\n**著者・年：** {r['authors']} ({r['publication_year']})  \n**取得版：** {r['retrieved_version']}  \n**一次本文：** [{r['primary_fulltext_url']}]({r['primary_fulltext_url']})\n\n**アクセスと実読範囲：** {r['reviewed_scope_ja']}\n\n**確認した結果：** {r['result_ja']}\n\n**根拠箇所：** {r['evidence_locator']}\n\n**今回への適用：** {r['applicability_ja']}\n")
    if r.get('extra_url'): out.append(f"\n[取得できたpreview]({r['extra_url']})\n")
out.append('''
## 残る読解・取得の課題

[14]の残り6頁はpublisherの全文URLがpreview/購読案内を返し、取得できなかった。[6]の完全な数式確認には、原PDFの画像と別の良質OCRが必要である。その他の長い未読章は上記の各実読範囲を参照する。版は、会議論文に対する長編著者版、2018年再録に対する1982年原論文などを明記して区別した。論文中の「最良」「最適」の歴史的表現を2026年現在の保証として扱っていない。特に[20]–[22]の小さいmagic-state rankについては、同じ引用集合内の[23]が以前の構成を改善している。

構造化データは `refs_01_25.json`。SHA-256は取得テキストの再現性確認用であり、その内容すべてを読んだという証明ではない。
''')
(ROOT/'refs_01_25.md').write_text(''.join(out))
print(json.dumps({'references':len(rows),'review_counts':status_counts,'files':['refs_01_25.json','refs_01_25.md']},ensure_ascii=False))
