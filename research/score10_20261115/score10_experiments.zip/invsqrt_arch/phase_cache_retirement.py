#!/usr/bin/env python3
"""Retire nine live swap caches in the real accepted invsqrt phase circuit.

A product t=c*(a XOR b) held in a clean qubit mediates a controlled swap.
Replace its compute/copy/uncompute/measurement correction by direct CSWAP
at both ends. The HMR remains on the now-clean cache with the same outcome
bit and order. Cost rises by one Toffoli per retired cache; no phase angle
is changed. This is a phase-region width primitive, not whole-circuit Q45.
"""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import re
import sys
import time
from collections import Counter

sys.path.append('/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages')
import kickmix as km

ROOT=Path(__file__).resolve().parent
BASE=ROOT/'accepted.kmb'
PIN='684106f101730ca193627229920a0501bef9ea10ccfb34aa453fcf63edadb50a'
TARGETS=[7696,7761,7885,7961,8074,8135,8188,8246,8292]
PHASE_START,PHASE_END=7604,8400

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def qs(line):return tuple(map(int,re.findall(r'\bq(\d+)\b',line)))

def multiply(a,b):
    out=set()
    for x in a:
        for y in b:
            z=x|y
            if z in out:out.remove(z)
            else:out.add(z)
    return out

def symbolic_run(lines):
    # These six qubits were independently measured and reset before the cut.
    clean={7,8,19,20,21,44}
    state=[set() if i in clean else {1<<i} for i in range(46)]
    bits={};stack=[];measurements=0;phase={};rotations=[];widths=[]
    def add_phase(key,poly):
        phase.setdefault(key,set()).symmetric_difference_update(poly)
    for line in lines:
        op=line.split()[0];qubits=qs(line)
        if op=='PUSH_CONDITION':
            bit=int(re.findall(r'\bb(\d+)\b',line)[0]);stack.append(bits[bit]);continue
        if op=='POP_CONDITION':stack.pop();continue
        condition=list(stack)
        if ' if ' in line:
            bit=int(re.findall(r'\bb(\d+)\b',line)[-1]);condition.append(bits[bit])
        if op in ('Z','CZ','CCZ','NEG'):
            value={0}
            for q in qubits:value=multiply(value,state[q])
            add_phase(tuple(sorted(set(condition))),value)
        else:
            assert not condition,('conditional data not supported',line)
            if op=='X':state[qubits[0]].symmetric_difference_update({0})
            elif op=='CX':state[qubits[1]].symmetric_difference_update(state[qubits[0]])
            elif op=='CCX':state[qubits[2]].symmetric_difference_update(multiply(state[qubits[0]],state[qubits[1]]))
            elif op=='SWAP':
                a,b=qubits;state[a],state[b]=state[b],state[a]
            elif op=='CSWAP':
                c,a,b=qubits;p=multiply(state[c],state[a]^state[b]);state[a]^=p;state[b]^=p
            elif op=='HMR':
                bit=int(re.findall(r'\bb(\d+)\b',line)[0]);measurements+=1;bits[bit]=measurements
                add_phase((measurements,),state[qubits[0]]);state[qubits[0]]=set()
            elif op=='R':assert not state[qubits[0]],'nonzero reset'
            elif op=='Z_POW':rotations.append((line.split()[2],frozenset(state[qubits[0]])))
            else:raise ValueError(line)
        widths.append(sum(bool(v) for v in state))
    assert not stack
    return dict(state=state,phase={k:v for k,v in phase.items() if v},rotations=rotations,
                measurements=measurements,bits=bits,max_live_nonzero=max(widths),widths=widths)

def transform(lines):
    replacements={};remove=set();rows=[]
    for number in TARGETS:
        i=number-1;c,b,t=qs(lines[i]);assert lines[i].startswith('CCX ')
        a,b0=qs(lines[i-1]);assert b==b0 and lines[i-1]==lines[i+1] and lines[i-1].startswith('CX ')
        h=next(j for j in range(i+1,len(lines)) if lines[j].startswith(f'HMR q{t} '))
        refs=[j for j in range(i+1,h) if t in qs(lines[j])]
        assert len(refs)==4
        assert all(lines[j].startswith(f'CX q{t} ') for j in refs)
        assert [qs(lines[j])[1] for j in refs[:2]]==[qs(lines[j])[1] for j in refs[2:]]
        assert set(qs(lines[j])[1] for j in refs)=={a,b}
        p=next(j for j in range(h+1,h+5) if lines[j].startswith('PUSH_CONDITION '))
        assert lines[p+3]=='POP_CONDITION'
        assert {lines[p+1],lines[p+2]}=={f'CZ q{c} q{a}',f'CZ q{c} q{b}'}
        bit=int(re.findall(r'\bb(\d+)\b',lines[h])[0]);assert lines[p]==f'PUSH_CONDITION if b{bit}'
        replacements[i-1]=[f'CSWAP q{c} q{a} q{b}']
        remove.update([i,i+1,*refs])
        replacements[p]=[f'CSWAP q{c} q{a} q{b}'];remove.update([p+1,p+2,p+3])
        rows.append(dict(original_compute_line=number,cleanup_line=h+1,cache_qubit=t,control=c,
                         data_pair=[a,b],retained_measurement_bit=bit,
                         arbitrary_target_outside_this_interval_not_claimed=True,extra_toffoli=1,
                         originally_cached_interval=[number,h+1]))
    assert not remove.intersection(replacements)
    emitted=[];origin=[]
    for i,line in enumerate(lines):
        if i in remove:continue
        for new_line in replacements.get(i,[line]):emitted.append(new_line);origin.append(i)
    return emitted,origin,rows

def main():
    start=time.monotonic();assert sha(BASE)==PIN
    source=km.Circuit.from_file(BASE);lines=str(source).splitlines()
    patched,origin,rows=transform(lines)
    a=symbolic_run(lines[PHASE_START:PHASE_END])
    b=symbolic_run([line for line,old in zip(patched,origin) if PHASE_START<=old<PHASE_END])
    assert a['state']==b['state']
    assert a['phase']==b['phase']
    assert a['rotations']==b['rotations']
    assert a['measurements']==b['measurements'] and a['bits']==b['bits']
    assert a['max_live_nonzero']==46 and b['max_live_nonzero']==45
    # Bind the clean-entry assumption to unconditional original HMR writes.
    clean_evidence={}
    depth=0
    for i,line in enumerate(lines[:PHASE_START]):
        op=line.split()[0]
        if op=='PUSH_CONDITION':depth+=1
        elif op=='POP_CONDITION':depth-=1
        q=qs(line)
        written=(q[-1:] if op in ('X','CX','CCX','HMR','R') else q if op=='SWAP' else q[1:] if op=='CSWAP' else ())
        for wire in set(written)&{7,8,19,20,21,44}:clean_evidence[wire]=(i+1,line,depth)
    assert set(clean_evidence)=={7,8,19,20,21,44}
    assert all(line.startswith('HMR ') and depth==0 and ' if ' not in line for _,line,depth in clean_evidence.values())
    candidate=km.Circuit('\n'.join(patched)+'\n')
    candidate.to_file(ROOT/'phase_retired_candidate.kmb',format='kmb')
    (ROOT/'phase_retired_candidate.kmx').write_text('\n'.join(patched)+'\n')
    old_count=int(source.operation_statistics().num_toffoli_like);new_count=int(candidate.operation_statistics().num_toffoli_like)
    assert new_count-old_count==9 and candidate.num_qubits==46
    original_angles=[l for l in lines if l.startswith('Z_POW ')]
    new_angles=[l for l in patched if l.startswith('Z_POW ')]
    assert original_angles==new_angles
    result=dict(status='EXACT_PHASE_REGION_Q46_TO45_PRIMITIVE',baseline_kmb_sha256=PIN,
                candidate_kmb_sha256=sha(ROOT/'phase_retired_candidate.kmb'),script_sha256=sha(__file__),
                baseline_static_toffoli=old_count,candidate_static_toffoli=new_count,additional_unconditional_toffoli=9,
                whole_circuit_qubits=int(candidate.num_qubits),whole_circuit_Q45=False,
                original_phase_region_peak=a['max_live_nonzero'],new_phase_region_peak=b['max_live_nonzero'],
                proof=dict(type='Exact Boolean ANF simulation of all40 arbitrary nonclean input bits and formal measurement branches',
                           old_line_interval=[PHASE_START+1,PHASE_END],clean_entry_evidence=clean_evidence,
                           final_all46_wire_polynomials_identical=True,all_generic_phase_predicates_identical=True,
                           generic_rotation_sequence_byte_identical=True,
                           all_measurement_phase_coefficients_identical=True,
                           measurement_count=a['measurements'],measurement_classical_assignment_order_identical=True),
                replacements=rows,no_score_improvement_claimed=True,official_full_verifier_run=False,
                seconds=time.monotonic()-start)
    (ROOT/'phase_cache_retirement_result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
