#!/usr/bin/env python3
"""Paired native checks of immutable min5 artifacts; no full benchmark run.

Whole-circuit variants retain all HMRs so same-seed counts couple exactly.
The real45-wire fragment drops five dead zero-HMRs. Its final phase is
branch independent; native equality there does not rely on draw coupling.
"""
from __future__ import annotations
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
import time
import numpy as np

sys.path.append('/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages')
import kickmix as km

ROOT=Path(__file__).resolve().parent
VERIFY=Path('/workspace/scratch/7f542e06b7cf/official_sources/Inzainos/verifiers/invsqrt/verify_submission_invsqrt.py')
PINS={
    'accepted.kmb':'684106f101730ca193627229920a0501bef9ea10ccfb34aa453fcf63edadb50a',
    'phase_retired5_candidate.kmb':'489c74015e0fda32b0e2f1e8bf67857898066f9079b7577b4121f0bc3e8468aa',
    'phase_fragment46_source.kmb':'d2394b8dc85cdfb3b013c7ea04ce3de166d2f54b6aab1d145a0d3732b6606490',
    'phase_fragment45.kmb':'75cd25308c5dcd23e9d95e2d0150bf2af88bbe49efc00739f7bd86754d53f1e7',
}
SEEDS=(202611150911,202611150912)

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def run(circuit, values, register_name, seed, verifier):
    reg=km.array(list(circuit.register_data[register_name]))
    sim=km.Simulator(batch_size=len(values),counting_operations=True,seed=seed)
    sim.use_same_registers_as(circuit)
    sim.write_across_shots(reg,verifier.to_bits(values,len(reg)))
    sim.do(circuit)
    allq=km.array([km.q(i) for i in range(circuit.num_qubits)])
    state=np.asarray(sim.read_across_shots(allq))
    phase=np.array([verifier.half_turns_to_units(sim.read_shot_phase(i)) for i in range(len(values))],dtype=np.uint64)
    return state,phase,int(sim.operation_statistics().num_toffoli_like)

def main():
    start=time.monotonic()
    spec=importlib.util.spec_from_file_location('native_min5_official_helpers',VERIFY)
    verifier=importlib.util.module_from_spec(spec);sys.modules[spec.name]=verifier;spec.loader.exec_module(verifier)
    circuits={}
    for name,pin in PINS.items():
        assert sha(ROOT/name)==pin,(name,'hash mismatch')
        circuits[name]=km.Circuit.from_file(ROOT/name)
    problem=verifier.ProblemSpecInvSqrt.for_n_p(10)
    rng=np.random.default_rng(20261115091)
    boundary=[(1<<k)+d for k in range(22) for d in range(-2,3) if 1<=(1<<k)+d<=problem.max_x]
    xs=np.unique(np.concatenate((np.arange(1,1025,dtype=np.uint64),
                    np.arange(problem.max_x-1023,problem.max_x+1,dtype=np.uint64),
                    rng.integers(1,problem.max_x+1,1024,dtype=np.uint64),
                    np.array(boundary,dtype=np.uint64))))
    whole=[]
    for seed in SEEDS:
        results=[]
        for name in ('accepted.kmb','phase_retired5_candidate.kmb'):
            circuit=circuits[name]
            xreg,scratch=verifier.validate_registers(circuit,problem)
            state,phase,count=run(circuit,xs,'x',seed,verifier)
            xids=[int(str(q)[1:]) for q in xreg]
            sids=[int(str(q)[1:]) for q in scratch]
            value_errors=int(np.count_nonzero(verifier.from_bits(state[xids])!=xs))
            scratch_errors=int(np.any(state[sids],axis=0).sum())
            assert value_errors==scratch_errors==0
            results.append((state,phase,count))
            whole.append(dict(file=name,seed=seed,inputs=len(xs),input_errors=value_errors,
                              scratch_errors=scratch_errors,total_toffolis=count))
        assert np.array_equal(results[0][0],results[1][0])
        assert np.array_equal(results[0][1],results[1][1])
        assert results[1][2]-results[0][2]==5*len(xs)
    # Exercise all40 unconstrained input coordinates, including parked q42/q45.
    xs40=np.unique(np.concatenate((np.array([0,(1<<40)-1]+[1<<k for k in range(40)]+[((1<<40)-1)^(1<<k) for k in range(40)],dtype=np.uint64),
                                  rng.integers(0,1<<40,4096,dtype=np.uint64))))
    fragments=[]
    for seed in SEEDS:
        results=[]
        for name in ('phase_fragment46_source.kmb','phase_fragment45.kmb'):
            state,phase,count=run(circuits[name],xs40,'phase_data',seed,verifier)
            results.append((state,phase,count))
            fragments.append(dict(file=name,seed=seed,inputs=len(xs40),qubits=int(circuits[name].num_qubits),total_toffolis=count))
        old,new=results
        assert not old[0][19].any()
        assert np.array_equal(np.delete(old[0],19,axis=0),new[0])
        assert np.array_equal(old[1],new[1])
        assert new[2]-old[2]==5*len(xs40)
    result=dict(status='PAIRED_NATIVE_WHOLE_AND_PHYSICAL45_FRAGMENT_PASS',
                script_sha256=sha(__file__),official_helper_sha256=sha(VERIFY),artifact_sha256=PINS,
                whole_circuit_rows=whole,whole_input_count=len(xs),
                whole_input_sha256=hashlib.sha256(xs.astype('<u8').tobytes()).hexdigest(),
                whole_quantum_state_identical=True,whole_phase_units_identical=True,
                whole_same_HMR_order=True,whole_extra_toffolis_every_seed=5,
                fragment_rows=fragments,fragment_input_count=len(xs40),
                fragment_input_sha256=hashlib.sha256(xs40.astype('<u8').tobytes()).hexdigest(),
                fragment_all45_retained_output_wires_identical=True,
                fragment_removed_source_wire_always_zero=True,fragment_phase_units_identical=True,
                fragment_HMR_draws_not_coupled=True,fragment_extra_toffolis_per_input=5,
                arbitrary40_input_proof_in_separate_symbolic_receipt=True,
                whole_circuit_Q45=False,full_official_verifier_run=False,seconds=time.monotonic()-start)
    (ROOT/'native_check_min5_result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
