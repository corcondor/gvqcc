#!/usr/bin/env python3
"""Five-cache version and a concrete45-qubit phase-region artifact.

This supersedes the nine-cache primitive while preserving that evidence.
All five caches use q19, so q19 is identically zero throughout the region.
Its five HMR outcomes have no remaining reads before overwrite and can be
dropped. Static relabeling then gives a real45-qubit fragment, with all40
nonclean inputs retained. The whole benchmark is still46qubits.
"""
from __future__ import annotations
import json
from pathlib import Path
import re
import time
import phase_cache_retirement as base

ROOT=Path(__file__).resolve().parent
TARGETS=[7675,7813,8012,8127,8238]

def main():
    start=time.monotonic()
    source=base.km.Circuit.from_file(base.BASE);lines=str(source).splitlines()
    assert base.sha(base.BASE)==base.PIN
    base.TARGETS=TARGETS
    patched,origin,rows=base.transform(lines)
    oldbody=lines[base.PHASE_START:base.PHASE_END]
    selected=[(l,o) for l,o in zip(patched,origin) if base.PHASE_START<=o<base.PHASE_END]
    newbody=[l for l,_ in selected]
    before=base.symbolic_run(oldbody);after=base.symbolic_run(newbody)
    for key in ('state','phase','rotations','measurements','bits'):
        assert before[key]==after[key],key
    assert before['max_live_nonzero']==46 and after['max_live_nonzero']==45
    # All phase-region references to q19 are now its five zero-HMRs.
    remaining19=[(j,l,o) for j,(l,o) in enumerate(selected) if 19 in base.qs(l)]
    assert len(remaining19)==5 and all(l.startswith('HMR q19 ') for _,l,_ in remaining19)
    dead=[]
    for j,line,old_index in remaining19:
        bit=int(re.findall(r'\bb(\d+)\b',line)[0])
        next_assignment=None
        for at in range(j+1,len(selected)):
            later=selected[at][0]
            bs=list(map(int,re.findall(r'\bb(\d+)\b',later)))
            if later.startswith('HMR ') and bs==[bit]:
                next_assignment=selected[at][1]+1;break
            assert bit not in bs,('nondead measurement',old_index+1,selected[at])
        # Every one is overwritten inside the chosen region.
        assert next_assignment is not None
        dead.append(dict(original_line=old_index+1,bit=bit,next_assignment_original_line=next_assignment))
    body45=[l for l in newbody if not l.startswith('HMR q19 ')]
    def remap(line):
        def repl(match):
            q=int(match.group(1));assert q!=19
            return f'q{q if q<19 else q-1}'
        return re.sub(r'\bq(\d+)\b',repl,line)
    # Register every retained data coordinate, including parked q42 andq45.
    clean={7,8,19,20,21,44}
    data=[q for q in range(46) if q not in clean]
    header46=[f'APPEND_TO_REGISTER q{q} r0' for q in data]+['REGISTER r0 "phase_data"']
    header45=[remap(l) for l in header46]
    source_fragment=base.km.Circuit('\n'.join(header46+oldbody)+'\n')
    fragment=base.km.Circuit('\n'.join(header45+[remap(l) for l in body45])+'\n')
    assert source_fragment.num_qubits==46 and fragment.num_qubits==45
    fragment.to_file(ROOT/'phase_fragment45.kmb',format='kmb')
    source_fragment.to_file(ROOT/'phase_fragment46_source.kmb',format='kmb')
    (ROOT/'phase_fragment45.kmx').write_text(str(fragment))
    whole=base.km.Circuit('\n'.join(patched)+'\n')
    whole.to_file(ROOT/'phase_retired5_candidate.kmb',format='kmb')
    (ROOT/'phase_retired5_candidate.kmx').write_text(str(whole))
    old_count=int(source.operation_statistics().num_toffoli_like)
    count=int(whole.operation_statistics().num_toffoli_like)
    assert count-old_count==5 and whole.num_qubits==46
    assert int(fragment.operation_statistics().num_toffoli_like)-int(source_fragment.operation_statistics().num_toffoli_like)==5
    result=dict(status='EXACT_REAL_Q45_PHASE_FRAGMENT_PLUS5_TOFFOLI',
                source_kmb_sha256=base.PIN,script_sha256=base.sha(__file__),
                whole_candidate_kmb_sha256=base.sha(ROOT/'phase_retired5_candidate.kmb'),
                fragment45_sha256=base.sha(ROOT/'phase_fragment45.kmb'),
                fragment46_source_sha256=base.sha(ROOT/'phase_fragment46_source.kmb'),
                original_phase_lines=[base.PHASE_START+1,base.PHASE_END],
                whole_original_static_toffoli=old_count,whole_candidate_static_toffoli=count,
                additional_unconditional_toffoli=5,whole_circuit_qubits=46,whole_circuit_Q45=False,
                fragment_original_qubits=46,fragment_new_qubits=45,
                fragment_original_toffoli=int(source_fragment.operation_statistics().num_toffoli_like),
                fragment_new_toffoli=int(fragment.operation_statistics().num_toffoli_like),
                all40_arbitrary_nonclean_inputs_retained=True,parked_q42_q45_retained=True,
                constant_zero_qubit_removed=19,dropped_dead_measurements=dead,
                exact_proof=dict(quantum_wire_ANF_equal=True,all_generic_phase_predicates_equal=True,
                                 all_formal_measurement_phase_coefficients_equal=True,
                                 before_dead_outcome_deletion_measurements=before['measurements'],
                                 after_dead_outcome_deletion_measurements=before['measurements']-5,
                                 discarded_results_have_no_remaining_reads_before_overwrite=True),
                replacements=rows,no_whole_score_improvement_claimed=True,full_official_verifier=False,
                seconds=time.monotonic()-start)
    (ROOT/'phase_cache_retirement_min5_result.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
