# Invsqrt architecture checkpoint: an exact 45-qubit phase fragment for five additional Toffolis

## Result and present limitation

The phase region of the accepted invsqrt circuit now has a concrete **45-qubit compiled implementation**, replacing the original 46-qubit region with **five additional Toffoli-equivalent operations**. All generic rotation angles and their Boolean predicates are unchanged. The rewrite retains every one of the 40 arbitrary data coordinates present at the region's entry, including the parked q42 and q45 values.

The complete invsqrt circuit still has **46 qubits** and its static Toffoli-like count increases from **1,550 to 1,555**. The result is a proved architecture component, not an improved benchmark submission. No new full official verifier run or portfolio score is claimed. The accepted portfolio remains the 27.32784222155277 baseline.

| Artifact | Actual qubits | Static Toffoli-like count | Purpose |
|---|---:|---:|---|
| `accepted.kmb` | 46 | 1,550 | Accepted full circuit |
| `phase_retired5_candidate.kmb` | 46 | 1,555 | Full circuit with the five exact replacements; retains dead measurements for coupled verification |
| `phase_fragment46_source.kmb` | 46 | 105 | Original phase region with all 40 data coordinates explicitly registered |
| `phase_fragment45.kmb` | 45 | 110 | Rewritten region after removing five dead measurements and the unused q19 wire |

The earlier nine-replacement result is preserved as `phase_cache_retirement.py`, `phase_retired_candidate.kmb`, and their original receipts. The five-replacement candidate supersedes it. The five-replacement builder imports the earlier module's transformation and symbolic simulator without changing the earlier files.

## What changed

The accepted circuit sometimes keeps a controlled-swap product in a clean temporary wire:

\[
t=c(a\oplus b).
\]

Copying t into both a and b exchanges the two values when c is one. The original implementation retains t across subsequent operations, later reverses the copies, measures t, and corrects the resulting phase using two conditional CZ gates. In each of the five selected intervals, replacing that cached construction by a direct CSWAP at each end eliminates the long-lived temporary product. One original CCX becomes two CSWAPs, so the cost rises by exactly one Toffoli-equivalent per interval.

The intervening arithmetic and phases were included in the proof. This is not an assertion that an arbitrary circuit between two cached swaps admits the same substitution.

All five selected intervals use q19. Their locations refer to the accepted circuit's KMX representation, with register declarations included and line numbering starting at one.

| Original CCX line | Original HMR line | Control | Data pair |
|---:|---:|---|---|
| 7,675 | 7,798 | q23 | q38, q27 |
| 7,813 | 7,998 | q23 | q3, q33 |
| 8,012 | 8,115 | q22 | q1, q30 |
| 8,127 | 8,226 | q22 | q39, q34 |
| 8,238 | 8,341 | q22 | q40, q8 |

After these replacements, q19 is identically zero over the entire phase cut, accepted lines **7,605 through 8,400**. Its only remaining uses are five HMR operations on zero. Each writes b381, which is overwritten before any subsequent read. Deleting those five measurements therefore discards only unused independent outcomes. Removing q19 and statically shifting higher wire indices down by one yields the actual 45-qubit fragment.

This distinction matters: the full candidate retaining the zero-wire measurements has a 45-wire nonzero-function peak, but is still an actual 46-wire circuit. Only the separately emitted fragment removes the physical wire. The fragment has a `phase_data` register and represents an internal region; it is not itself a valid complete invsqrt submission.

## Exact proof scope

The proof starts with six clean wires, q7, q8, q19, q20, q21, and q44. Their clean state is bound to the actual unchanged prefix: the last write to each is an unconditional HMR. The other **40 wire values are completely arbitrary**. No numerical input sample, approximate Boolean fit, or assumed relation between the parked data values is needed.

The builder propagates exact Boolean algebraic normal forms through the source region and the replacement. It compares every output wire, every generic Z_POW predicate, and the coefficients of all 41 formal measurement variables in the phase. It also checks the exact generic-angle sequence. These checks pass. The five deleted zero-wire measurements have no remaining classical use before overwrite.

An independent reviewer decoded the actual KMB binaries, implemented a separate Boolean/phase algebra, and did not import the builder. Its checks also pass:

- All 40 arbitrary input coordinates and the complete output-wire map agree.
- The 34 generic rotations have identical angles and predicates.
- Every measurement-dependent phase term cancels.
- The full candidate has an unchanged 7,604-line prefix and 15,504-line suffix.
- The physical fragment really has 45 qubits, with q42 and q45 input values retained after relabeling.
- All five deleted outcomes are overwritten before any read.

Builder evidence is in `phase_cache_retirement_min5_result.json`. Independent evidence is in `/workspace/scratch/fd9d1fc36baf/alternative_arch/score10_inv_review5.json` and `/workspace/scratch/fd9d1fc36baf/alternative_arch/score10_inv_review5_fragment.json`.

## Native validation

`native_check_min5.py` loads the pinned actual binaries and performs two separate comparisons using the native Kickmix simulator and the official verifier's exact phase-unit conversion helpers.

| Comparison | Inputs per seed | Seeds | Result |
|---|---:|---:|---|
| Accepted whole circuit vs five-replacement whole circuit | 3,129 legal boundary/random inputs | 2 | All 46 wire outputs and exact phase units agree; x restored; scratch clean; exactly +5 Toffolis per input |
| Source 46-wire fragment vs physical 45-wire fragment | 4,178 arbitrary 40-bit assignments | 2 | All 45 retained output wires and exact phase units agree; removed source wire always zero; exactly +5 Toffolis per input |

The whole-circuit variant retains all measurements, so the two simulations can couple their measurement draws by seed. The physical fragment deletes five dead measurements; its draw sequence is deliberately not assumed to match the source. Measurement-independent corrected phase is established symbolically and checked natively.

These finite native checks supplement the exact symbolic proof. They are not presented as exhaustive verification of all 3,133,452 legal invsqrt inputs or the official 200,540,928-shot workload. The result receipt is `native_check_min5_result.json`.

## Width coverage and remaining obstacle

`scan_cached_swaps.py` scans all 23,904 lines of the accepted tape for the strict structural primitive used by the builder. It finds **29 matches, all inside the phase region**, with no nonphase match. The 29 intervals cover the 88 positions at which the original phase region has all 46 wire functions nonzero. The minimum unit-cost interval cover within this particular set contains five intervals; the selected five q19 intervals achieve that bound while allowing a single physical wire to be removed across the entire region.

This is a minimum within the matched cached-swap family, not a lower bound for arbitrary phase-region synthesis or full-circuit width reduction. The absence of a nonphase structural match does not exclude other scheduling, nonlinear compression, arithmetic redesign, or measurement techniques.

Previous repository evidence already identified other full-width regions. In `outcome_invsqrt45_cover.json`, the older quadratic-retirement scan left 1,419 of 3,734 positions uncovered: 881 in the forward product/divider, 88 in phase, 412 in the inverse divider, and 38 in the tail. This new component resolves the 88 phase positions. The remaining **1,331** positions are still outside that earlier formula coverage. Earlier coverage itself is only an optimistic collection of formulas: it does not establish an executable global 45-wire allocation or compatible dependencies, and its selected formulas already cost 38 AND operations before those issues are solved.

For cost planning, the accepted invsqrt receipt reports an effective Toffoli count of 1,710.2946813836015 and cost 78,673.55534364567 at Q=46 (`score3_invsqrt_full_verification.json` in the repository). If a whole Q=45 circuit preserves the same rotation tariff and exact output phase, its additional effective Toffoli budget for strict improvement is

\[
45(1710.2946813836015+\Delta)<46\cdot1710.2946813836015,
\qquad \Delta<38.00654847519114.
\]

The new phase component uses five of that allowance, leaving **less than 33.00654847519114** for all other width changes. This is a design threshold using the accepted effective-count baseline, not a new measured candidate score. The official circuit-hash seed can change finite-shot counts, so a complete candidate would still need its own official verification.

One focused next obstacle is the long-held q45 value after accepted line 10,984 and before its next use at line 17,288. A small nonlinear reconstruction remains an unstarted next experiment at this checkpoint. `q45_held_sample_snapshots.json` contains 4,096 previously chosen witness inputs and packed states at accepted cuts 10,984, 14,888, 16,799, 17,202, and 17,287. Those are finite witnesses for candidate discovery only; any proposed reconstruction requires proof or validation across the legal domain. No new full-domain affine scan or cubic reconstruction search was run here.

## Reproduction and artifact identity

Run from this directory using a Python environment with NumPy and the existing Kickmix installation:

```sh
python scan_cached_swaps.py
python phase_cache_retirement_min5.py
python native_check_min5.py
```

The builders bind the source hash before operating. The source and candidate KMB hashes are:

| Artifact | SHA-256 |
|---|---|
| `accepted.kmb` | `684106f101730ca193627229920a0501bef9ea10ccfb34aa453fcf63edadb50a` |
| `phase_retired5_candidate.kmb` | `489c74015e0fda32b0e2f1e8bf67857898066f9079b7577b4121f0bc3e8468aa` |
| `phase_fragment46_source.kmb` | `d2394b8dc85cdfb3b013c7ea04ce3de166d2f54b6aab1d145a0d3732b6606490` |
| `phase_fragment45.kmb` | `75cd25308c5dcd23e9d95e2d0150bf2af88bbe49efc00739f7bd86754d53f1e7` |

Rerunning a script updates its timing-bearing receipt. The independent review pins the existing builder receipt hash `c752911df9f6fa33bc0879362f4b784cdbe9db12abab90097afe97d0d1a6b674`; preserve that receipt when retaining the review as archival evidence. No existing repository source, accepted submission, remote branch, or external application was modified by this subtask.
