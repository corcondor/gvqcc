#!/usr/bin/env python3
"""Reproduce strict cached-swap matches across the whole accepted KMB tape.

This is only a scan of the specific structural primitive implemented in
phase_cache_retirement.transform, not a general absence proof for other
reversible scheduling, Boolean compression, or measurement techniques.
"""
import json
from pathlib import Path
import phase_cache_retirement as b

def main():
    lines=str(b.km.Circuit.from_file(b.BASE)).splitlines()
    assert b.sha(b.BASE)==b.PIN
    rows=[]
    for i,line in enumerate(lines):
        if not line.startswith('CCX ') or i==0 or i+1==len(lines):continue
        if not lines[i-1].startswith('CX ') or lines[i-1]!=lines[i+1]:continue
        b.TARGETS=[i+1]
        try:
            _,_,found=b.transform(lines)
        except (AssertionError,StopIteration):continue
        rows.extend(found)
    phase=b.symbolic_run(lines[b.PHASE_START:b.PHASE_END])
    indices=[i+1 for i in range(b.PHASE_START,b.PHASE_END)
             if not lines[i].startswith(('PUSH_CONDITION ','POP_CONDITION'))]
    assert len(indices)==len(phase['widths'])
    peaks=[i for i,w in zip(indices,phase['widths']) if w==46]
    # Unit-cost interval cover: at earliest uncovered point, choose the
    # covering interval with latest end. Exchange argument gives optimum
    # within this finite set of cached-swap intervals only.
    selected=[];left=peaks[:]
    while left:
        options=[r for r in rows if r['original_compute_line']<=left[0]<r['cleanup_line']]
        assert options
        pick=max(options,key=lambda r:r['cleanup_line'])
        selected.append(pick['original_compute_line'])
        left=[p for p in left if p>=pick['cleanup_line']]
    all19=[r for r in rows if r['cache_qubit']==19]
    assert len(all19)==5 and all(any(r['original_compute_line']<=p<r['cleanup_line'] for r in all19) for p in peaks)
    result=dict(status='STRICT_SCAN_AND_PHASE_INTERVAL_COVER_COMPLETE',
                script_sha256=b.sha(__file__),source_kmb_sha256=b.PIN,
                scanned_tape_lines=len(lines),matches=len(rows),
                matches_outside_phase=sum(not(b.PHASE_START<r['original_compute_line']<=b.PHASE_END) for r in rows),
                phase_full_width_positions=len(peaks),phase_peak_positions_original_lines=peaks,
                minimum_interval_cover=len(selected),one_greedy_cover_original_compute_lines=selected,
                chosen_single_wire_cover=[r['original_compute_line'] for r in all19],
                chosen_single_wire=19,strict_pattern_matches=rows,
                scope='Minimum only among the29 matched cached-swap intervals, not a global circuit lower bound.')
    assert len(rows)==29 and result['matches_outside_phase']==0 and len(peaks)==88 and len(selected)==5
    out=Path(__file__).resolve().parent/'scan_cached_swaps_result.json'
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('strict_pattern_matches','phase_peak_positions_original_lines')},indent=2))

if __name__=='__main__':main()
