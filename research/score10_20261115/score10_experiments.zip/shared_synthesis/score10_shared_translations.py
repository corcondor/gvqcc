#!/usr/bin/env python3
"""Search high-row-dependent low-address translations with exact rank costs.

All 32 output bits are counted. Translations are care-independent fixed
Boolean functions of high address, so an eventual compiler uses only CNOTs
from the complete high bank to the low selection bits.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys,time
import numpy as np
sys.path.insert(0,os.environ.get('Z3_SITE_PACKAGES','/workspace/scratch/3815fb5fae06/score_invsqrt_solver_deps'))
sys.path.append(os.environ.get('KICKMIX_SITE_PACKAGES','/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages'))
try:
 import z3
except ModuleNotFoundError:
 z3=None
REPO=Path(os.environ.get('GVQCC_SOURCE_ROOT','/workspace/scratch/7f542e06b7cf/gvqcc_repo'))
sys.path.insert(0,str(REPO))
from score10_shared_boolean import factor_columns,mobius

def rank(a):
 p={}
 for x in a:
  while x and x.bit_length()-1 in p:x^=p[x.bit_length()-1]
  if x:p[x.bit_length()-1]=x
 return len(p)

def rank_cost(table,shifts):
 translated=np.stack([table[h,np.arange(16)^int(shifts[h])] for h in range(77)])
 converted=translated.copy(); converted^=(converted&64)<<1
 packed=sum(converted[:,:,j].astype(np.uint32)<<(8*j) for j in range(4))
 coeff=mobius(np.stack([mobius(row) for row in packed]))
 matrices=[[sum(((int(coeff[h,l])>>o)&1)<<(h-1) for h in range(1,77)) for l in range(1,16)] for o in range(32)]
 ranks=[rank(m) for m in matrices]
 paired=sum((r+1)//2 for r in ranks)
 shared=paired-sum(r==15 for r in ranks)//2
 return dict(ranks=ranks,paired_ccx=paired,joint_full_ccx=shared,bank_ccx=80,total_ccx=80+shared),matrices

def zx(xs):
 if not xs:return z3.BoolVal(False)
 if len(xs)==1:return xs[0]
 val=xs[0]
 for x in xs[1:]:val=z3.Xor(val,x)
 return val

def solve(table,outputs,timeout,seed):
 if z3 is None:raise ImportError('SAT search requires z3-solver; saved-plan rebuilds do not.')
 # For each selected output find a nonzero low annihilator whose parity is
 # identical on all high rows after translation. No output data is borrowed.
 encoded=table.copy();encoded^=(encoded&64)<<1
 flat=sum(encoded[:,:,j].astype(np.uint32)<<(8*j) for j in range(4))
 s=z3.Solver();s.set(timeout=timeout,random_seed=seed)
 ps=[[z3.Bool(f'p_{i}_{l}') for l in range(1,16)] for i in range(len(outputs))]
 cs=[z3.Bool(f'c_{i}') for i in range(len(outputs))]
 ts=[[z3.Bool(f't_{h}_{b}') for b in range(4)] for h in range(77)]
 for p in ps:s.add(z3.Or(*p))
 for h in range(77):
  for t in range(16):
   selector=z3.And(*[ts[h][b] if t>>b&1 else z3.Not(ts[h][b]) for b in range(4)])
   for i,o in enumerate(outputs):
    v=[ps[i][l-1] for l in range(1,16) if (int(flat[h,l^t])^int(flat[h,t]))>>o&1]
    s.add(z3.Implies(selector,zx(v)==cs[i]))
 started=time.monotonic();status=s.check();record=dict(status=str(status),seconds=time.monotonic()-started,outputs=outputs,seed=seed,timeout_ms=timeout)
 if status==z3.sat:
  m=s.model();shifts=[sum(int(z3.is_true(m.eval(t,model_completion=True)))<<b for b,t in enumerate(ts[h])) for h in range(77)]
  record.update(shifts=shifts,annihilators=[sum(int(z3.is_true(m.eval(p,model_completion=True)))<<l for l,p in enumerate(pp,1)) for pp in ps],constants=[int(z3.is_true(m.eval(c,model_completion=True))) for c in cs])
  record['cost'],_=rank_cost(table,shifts)
  for i,o in enumerate(outputs):
   assert record['cost']['ranks'][o]<15
   p=record['annihilators'][i];c=record['constants'][i]
   for h,t in enumerate(shifts):
    val=0
    for l in range(1,16):
     if p>>l&1:val^=(int(flat[h,l^t])^int(flat[h,t]))>>o&1
    assert val==c
 elif status==z3.unknown:record['reason_unknown']=s.reason_unknown()
 return record

def main():
 a=argparse.ArgumentParser();a.add_argument('--batch',type=int,default=5);a.add_argument('--outputs',type=int,nargs='+',default=[1,2,3,4]);a.add_argument('--timeout',type=int,default=45000);a.add_argument('--seed',type=int,default=20261115);a.add_argument('--out',type=Path,required=True);args=a.parse_args()
 path=REPO/'score9_rebatch_synth_source_words_1232.npy';words=np.pad(np.load(path).astype(np.uint64),((0,0),(0,1)));k=args.batch
 delta=words[:,4*k:4*k+4].copy()
 if k:delta^=words[:,4*k-4:4*k]
 table=delta.reshape(77,16,4)
 baseline,_=rank_cost(table,[0]*77)
 result=dict(batch=k,source_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),baseline=baseline,search=solve(table,args.outputs,args.timeout,args.seed),scope='Exact fixed-word truth table; all32 output cross ranks included; rank construction bound only, no circuit lower bound.')
 args.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
