#!/usr/bin/env python3
"""Compile translated J4 exact XOR loaders, counting all32 output coordinates."""
from pathlib import Path
import argparse,hashlib,json,os,subprocess,sys,time
import numpy as np
sys.path.append(os.environ.get('KICKMIX_SITE_PACKAGES','/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages'))
import kickmix as km
from score10_shared_translations import rank,rank_cost,REPO
sys.path.insert(0,str(REPO))
from score10_shared_boolean import mobius,factor_columns,packed,prove
HERE=Path(__file__).resolve().parent

def bits(x):
 while x:
  b=x&-x;yield b.bit_length()-1;x^=b

def xor_rows(mask,rows):
 r=[0]*len(rows[0])
 for i in bits(mask):r=[a^b for a,b in zip(r,rows[i])]
 return r

def output_basis(matrices,prefix):
 inp=prefix.with_suffix('.input.txt');out=prefix.with_suffix('.deficient.txt')
 tensor=[[sum(((matrices[c][l]>>h)&1)<<c for c in range(32)) for h in range(76)] for l in range(15)]
 inp.write_text('15 76 32\n'+'\n'.join(' '.join(map(str,r)) for r in tensor)+'\n')
 info=subprocess.run([str(HERE/'score10_shared_rank_basis'),str(inp),str(out)],capture_output=True,text=True,check=True)
 deficient=[int(s) for s in out.read_text().splitlines() if not s.startswith('#')]
 candidates=[]
 for w in set(deficient)|{1<<i for i in range(32)}:
  if w:
   r=rank(xor_rows(w,matrices));candidates.append(((r+1)//2,w.bit_count(),w,r))
 chosen=[];piv={};rs=[]
 for cost,_,w,r in sorted(candidates):
  v=w
  while v and v.bit_length()-1 in piv:v^=piv[v.bit_length()-1]
  if v:piv[v.bit_length()-1]=v;chosen.append(w);rs.append(r)
  if len(chosen)==32:break
 assert len(chosen)==32
 return chosen,dict(**json.loads(info.stdout),basis_ranks=rs,paired_ccx=sum((r+1)//2 for r in rs),joint_full_ccx=sum((r+1)//2 for r in rs)-sum(r==15 for r in rs)//2)

def basis_elimination(basis):
 rows=basis.copy();ops=[]
 for col in range(len(rows)):
  pivot=next(i for i in range(col,len(rows)) if rows[i]>>col&1)
  if pivot!=col:
   for s,t in ((pivot,col),(col,pivot),(pivot,col)):rows[t]^=rows[s];ops.append((s,t))
  for i in range(len(rows)):
   if i!=col and rows[i]>>col&1:rows[i]^=rows[col];ops.append((col,i))
 assert rows==[1<<i for i in range(len(rows))]
 return ops

def build(delta,shifts,basis):
 table=delta.reshape(77,16,4)
 translated=np.stack([table[h,np.arange(16)^shifts[h]] for h in range(77)]).astype(np.uint32)
 translated^=(translated&64)<<1
 flat=sum(translated[:,:,j]<<(8*j) for j in range(4))
 output=np.zeros((77,16,32),dtype=np.uint8)
 for o,w in enumerate(basis):
  for b in bits(w):output[:,:,o]^=((flat>>b)&1).astype(np.uint8)
 coeff=mobius(np.stack([mobius(row) for row in output]))
 columns=[[0]+[packed(coeff[h,:,o])&~1 for h in range(1,77)] for o in range(32)]
 terms=[];full=[o for o,c in enumerate(columns) if len(factor_columns(c))==15]
 for a,b in zip(full[::2],full[1::2]):
  ha=sum(((columns[a][h]>>1)&1)<<h for h in range(77));hb=sum(((columns[b][h]>>2)&1)<<h for h in range(77))
  for h in range(77):
   shared=(((ha>>h)&1)<<1)^(((hb>>h)&1)<<2)
   columns[a][h]^=shared;columns[b][h]^=shared
  assert len(factor_columns(columns[a]))==len(factor_columns(columns[b]))==14
  terms.append((1|((hb>>1)<<15),2|((ha>>1)<<15),(1<<a)|(1<<b)))
 for o,c in enumerate(columns):
  pairs=factor_columns(c)
  for i in range(0,len(pairs),2):
   a,h1=pairs[i]
   if i+1<len(pairs):b,h2=pairs[i+1];terms.append(((a>>1)|((h2>>1)<<15),(b>>1)|((h1>>1)<<15),1<<o))
   else:terms.append((a>>1,(h1>>1)<<15,1<<o))
 lines=[]
 for q in range(11):lines.append(f'APPEND_TO_REGISTER q{q} r0')
 lines.append('REGISTER r0 "selection"')
 for j in range(4):
  for b in range(8):lines.append(f'APPEND_TO_REGISTER q{11+8*j+b} r{j+1}')
  lines.append(f'REGISTER r{j+1} "word_{j}"');lines.append(f'CX q{17+8*j} q{18+8*j}')
 ops=basis_elimination(basis)
 for s,t in reversed(ops):lines.append(f'CX q{11+s} q{11+t}')
 cursor=43
 def bank(n,offset):
  nonlocal cursor
  wires={1<<b:offset+b for b in range((n-1).bit_length())};nodes=[]
  for mask in range(1,n):
   if mask in wires:continue
   unit=mask&-mask;a,b=wires[unit],wires[mask^unit]
   wires[mask]=cursor;nodes.append((a,b,cursor));lines.extend((f'R q{cursor}',f'CCX q{a} q{b} q{cursor}'));cursor+=1
  return wires,nodes
 hi,hn=bank(77,4)
 shift_ops=[]
 for b in range(4):
  sc=mobius(((np.asarray(shifts)>>b)&1).astype(np.uint8))
  if sc[0]:shift_ops.append(f'X q{b}')
  shift_ops.extend(f'CX q{hi[h]} q{b}' for h in range(1,77) if sc[h])
 lines.extend(shift_ops)
 lo,ln=bank(16,0);features=[lo[i] for i in range(1,16)]+[hi[i] for i in range(1,77)]
 c1,c2=cursor,cursor+1;lines.extend((f'R q{c1}',f'R q{c2}'))
 truth=np.array([((np.arange(16)[None,:]&m)==m).repeat(77,0) for m in range(1,16)]+[((np.arange(77)[:,None]&m)==m).repeat(16,1) for m in range(1,77)],dtype=np.uint8)
 residual=output.copy()
 def form(mask,q):return [f'CX q{features[i]} q{q}' for i in bits(mask)]
 for a,b,w in terms:
  aa,bb=form(a,c1),form(b,c2);out=list(bits(w));target=11+out[0]
  fan=[f'CX q{target} q{11+o}' for o in out[1:]]
  lines+=fan+aa+bb+[f'CCX q{c1} q{c2} q{target}']+list(reversed(bb))+list(reversed(aa))+list(reversed(fan))
  va=np.bitwise_xor.reduce(truth[list(bits(a))],axis=0);vb=np.bitwise_xor.reduce(truth[list(bits(b))],axis=0)
  for o in out:residual[:,:,o]^=va&vb
 assert np.array_equal(residual,residual[:,0:1]^residual[0:1,:]^residual[0,0])
 for o in range(32):
  lc=mobius(residual[0,:,o]^residual[0,0,o]);hc=mobius(residual[:,0,o]);target=11+o
  if lc[0]^hc[0]:lines.append(f'X q{target}')
  lines.extend(f'CX q{lo[i]} q{target}' for i in range(1,16) if lc[i])
  lines.extend(f'CX q{hi[i]} q{target}' for i in range(1,77) if hc[i])
 for a,b,t in reversed(ln):lines.extend((f'HMR q{t} b0',f'CZ q{a} q{b} if b0'))
 lines.extend(reversed(shift_ops))
 for a,b,t in reversed(hn):lines.extend((f'HMR q{t} b0',f'CZ q{a} q{b} if b0'))
 for s,t in ops:lines.append(f'CX q{11+s} q{11+t}')
 for j in range(4):lines.append(f'CX q{17+8*j} q{18+8*j}')
 circuit=km.Circuit('\n'.join(lines)+'\n')
 assert circuit.num_qubits==125 and circuit.operation_statistics().num_toffoli_like==80+len(terms)
 return circuit,dict(ccx=80+len(terms),bank_ccx=80,core_ccx=len(terms),qubits=125)

def main():
 p=argparse.ArgumentParser();p.add_argument('--search',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 data=json.loads(a.search.read_text());assert data['search']['status']=='sat';k=data['batch'];shifts=data['search']['shifts']
 words=np.pad(np.load(REPO/'score9_rebatch_synth_source_words_1232.npy').astype(np.uint64),((0,0),(0,1)));delta=words[:,4*k:4*k+4].copy()
 if k:delta^=words[:,4*k-4:4*k]
 initial,matrices=rank_cost(delta.reshape(77,16,4),shifts)
 basis,br=output_basis(matrices,a.out/'basis')
 circuit,row=build(delta,shifts,basis);row['proof']=prove(circuit,delta)
 dst=a.out/f'angle_k_{k}.kmb';circuit.to_file(dst,format='kmb')
 result=dict(status='TRANSLATED_ALL_OUTPUT_BASIS_EXACT_XOR_PASS',batch=k,source_search=str(a.search),source_search_sha256=hashlib.sha256(a.search.read_bytes()).hexdigest(),shifts=shifts,initial=initial,basis_search=br,basis=basis,circuit=row,path=str(dst),sha256=hashlib.sha256(dst.read_bytes()).hexdigest(),official_full_verifier_run=False)
 (a.out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
if __name__=='__main__':main()
