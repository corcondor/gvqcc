# J4 joint synthesis: new tensor search and copied coordinate prototype

## Result

This work produced **no accepted chemistry cost or portfolio score improvement**.
The accepted comparison remains score8, with loader cost4030 and portfolio
score27.32784222155277. The existing strict-XOR J4 joint family costs5197 per
pass; this work did not replace any member of that family. No full official
numeric verifier or competition submission was run.

It did implement two stronger search routes and a new exact circuit technique:

1. Rank-one tensor flip/plus moves can split the matrix blocks frozen by the
   earlier whole-output-matrix search. Representative bounded searches retained
   the previous best counts.
2. Arbitrary high-row-dependent translations can create rank deficiencies that
   do not exist under the old fixed partition. Concrete two-output and
   three-output deficiencies were found, but their full cost increases once the
   tag bits are correctly included.
3. Three copied low coordinates permit an arbitrary high-dependent invertible
   GL3 affine change while preserving the original selection bits. The emitted
   Q128 prototype uses **12 CCX for coordinate preparation and zero CCX for
   coordinate cleanup**. Exact HMR phase correction implements that cleanup.

## Actual saved circuits

All counts are the emitted KMB's `operation_statistics`, independently read
back by `score10_shared_audit.py`.

| Batch5 construction | Bank CCX | Coordinates | Data products | Tags | Total CCX | Q |
|---|---:|---:|---:|---:|---:|---:|
| Existing score9 J4 | 80 | 0 | 188 | Included | 268 | 125 |
| Two forced deficiencies, full32-output basis | 80 | 0 | 191 | Included | 271 | 125 |
| Three forced deficiencies, full32-output basis | 80 | 0 | 191 | Included | 271 | 125 |
| Copied GL3 prototype | 80 | 12 | 188 | 4 | 284 | 128 |

Each saved candidate has a deterministic proof over all1232 addresses in the
fixed native extension, including every required address0–1219, with32
arbitrary initial target bits. Selection is preserved, workspace is zero, and
every formal HMR phase coefficient cancels. The two translation circuits have
80 measurement variables; the GL3 circuit has83. This exact check is not
described as a full default-shot chemistry verifier run.

The source word-table file SHA256 is
`792e1b06ca6e4e7b5fa82c3cc96412b9e2d2d70a27edcd7ccb08eb242714bf68`.
The table is the actual circuit-recovered score8 table, not the differing
declared NPZ angle metadata. All candidates preserve its exact values.

## Tensor flip/plus search

`score10_shared_tensor_search.cpp` represents each cross tensor as rank-one
triples `(low, high, output)`. A flip acts on two terms sharing one factor.
A plus move splits two terms into three exact terms, enabling later flips and
merges. After each move, equal factor pairs are merged; the objective is the
sum of `ceil(rank(matrix)/2)` after grouping by output direction.

The two primary55-second runs proposed618,789 moves in total and retained
210 mixed products for batch0 and188 for batch5. The final cross tensors are
equal to their input tensors, checked both inside C++ and by a separate Python
construction in the audit. These runs do not establish a lower bound or an
optimality claim. The exported search result files retain all rank-one terms,
so reproducing the selected result does not require rerunning stochastic work.

The saved representatives also have zero high-rowspace intersection for all
378 pairs of substantive output matrices in each batch. This only excludes a
particular direct shared update inside those representatives. It does not
exclude a different factorization, nonlinear feature set, or circuit.

## High-dependent low translations

For each high row `h`, the solver chooses a four-bit translation `t[h]`, and
the prepared low coordinates become `y=x XOR t[h]`. The complete high bank
already spans every function of the77 high rows. Therefore these translations
and their inverses use only CNOT/X gates.

The SAT model finds nonzero low parity covectors whose output parity is
constant across every high row. Two and three independently selected full-rank
data coordinates were reduced from rank15 to14. However, the four top-bit tag
outputs cease to be pure low functions after the translation. Ignoring those
outputs would incorrectly report a saving.

`score10_shared_rank_basis.cpp` therefore enumerates all32,767 nonzero low
covectors and every resulting32-bit output kernel. The resulting complete
deficient-output sets have514 and516 members, including zero. Greedy linear
basis selection minimizes the sum of independent paired-rank costs over all
32 output combinations, including data/tag mixtures. This improves the initial
272-CCX estimates to271 but still loses to268.

The three four-constraint SAT probes timed out. Their result is UNKNOWN, not
UNSAT. All successful shift vectors, annihilators, output bases, compiler
inputs, and KMB hashes are retained.

## Copied-coordinate GL3 and phase-correct cleanup

The prototype preserves all original address bits and allocates three copied
coordinates. Its first low coordinate is `y0=x0`; the remaining three have

    yi = XOR_j Mij(h)*xj XOR ti(h),  i=1,2,3.

For each high row, the four coordinate functions form an invertible affine
map. This includes10,752 possible maps per row when the first coordinate is
fixed: GL3 on the other three coordinates, three shears from `x0`, and three
translation bits. The demonstration saves the complete77-row matrix and
translation plan.

Each nonconstant coefficient `Mij(h)` is a free linear combination of the
already prepared high bank. Its product with the original `xj` costs one CCX,
so preparing the three coordinates costs at most12 CCX. The complete low bank
is then prepared using these new coordinate wires. Three added coordinate
wires bring the actual circuit width from125 to128.

After the low bank is HMR-erased, measuring `yi` produces phase

    (-1)^(mi * yi).

The correction is the product of conditioned CZ operations for
`mi*Mij(h)*xj`, plus the high-only translation correction. The high functions
are formed by CNOTs, and all original `xj` wires are still available. Thus this
cleanup has **zero CCX**, and its complete phase cancellation is checked
symbolically for every address and measurement outcome. It is not an
unsupported assumption that the coordinate computation can be erased freely.

The original four low-only tag functions are handled exactly as quadratic
forms in the original address bits. Enumerating their output combinations
finds a basis implemented by four products of linear forms, plus free affine
corrections. These four CCX are included in the284 total.

The demonstration's random coordinate plan does not reduce the data product
count, so this is a reusable exact compiler technique, not a competitive
candidate or a score gain. Further coordinate search was stopped when the
user redirected the task toward the supplied literature.

## Reproduction and portability

The Python tools use NumPy and Kickmix; the SAT search additionally uses Z3.
Set `GVQCC_SOURCE_ROOT` to the repository directory containing
`score9_rebatch_synth_source_words_1232.npy`. The four exact Boolean helper
functions are copied unchanged into `score10_shared_boolean.py`, with their
source hash and attribution. If packages are not installed on
the normal Python path, `KICKMIX_SITE_PACKAGES` and `Z3_SITE_PACKAGES` may point
to their existing installations. No installation or network access is needed
for the saved-plan rebuilds.

Build `score10_shared_rank_basis.cpp` with `g++ -O3 -std=c++17`, naming the
executable `score10_shared_rank_basis` beside the Python sources. Then:

```bash
python3 score10_shared_translation_compile.py \
  --search score10_shared_translations_k5_r3.json --out rebuilt_translation
python3 score10_shared_copied_gl3.py \
  --plan gl3_full_k5/result.json --out rebuilt_gl3
python3 score10_shared_audit.py
```

The saved GL3 plan makes the rebuild deterministic. The tensor search uses
the copied `score10_shared_matrix_k0_input.txt` and `...k5_input.txt` fixtures.
The source word table and helper provenance are retained as
hash-bound repository dependencies in the manifest. No background search is
left running. No previous user or score9 file was modified.

Attribution: the exact matrix/basis infrastructure adapts the repository's
score9 and `outcome_chem_j4_synthesize.py` helpers, and the fixed word table
comes from the credited public maoxin123 chemistry loader family. New work in
this folder is the rank-one flip/plus search, translation SAT/compiler route,
all32-output extension, and copied-coordinate HMR implementation.
