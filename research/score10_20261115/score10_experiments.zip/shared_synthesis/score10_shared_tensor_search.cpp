// Rank-one tensor flip and plus search for mixed-product chemistry loaders.
// Cross-only quotient: pure partition terms are restored by exact compiler.
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <random>
#include <vector>
using U=unsigned __int128;
struct Term {U v[3];}; // low, high, output
using Matrix=std::array<U,15>;
int bit(U v){uint64_t h=v>>64;return h?127-__builtin_clzll(h):63-__builtin_clzll((uint64_t)v);}
int rank(Matrix a){std::array<U,128>b{};int n=0;for(U v:a)while(v){int p=bit(v);if(b[p])v^=b[p];else{b[p]=v;++n;break;}}return n;}
int packed(const std::vector<Term>& ts){std::map<uint64_t,Matrix> g;for(auto&t:ts){auto&m=g[(uint64_t)t.v[2]];for(int i=0;i<15;++i)if(t.v[0]>>i&1)m[i]^=t.v[1];}int c=0;for(auto&x:g)c+=(rank(x.second)+1)/2;return c;}
std::vector<uint64_t> tensor(const std::vector<Term>&ts){std::vector<uint64_t>x(15*76);for(auto&t:ts)for(int l=0;l<15;++l)if(t.v[0]>>l&1)for(int h=0;h<76;++h)if(t.v[1]>>h&1)x[76*l+h]^=(uint64_t)t.v[2];return x;}
void clean(std::vector<Term>&ts){bool changed=true;while(changed){changed=false;for(size_t i=0;i<ts.size();++i){if(!ts[i].v[0]||!ts[i].v[1]||!ts[i].v[2]){ts[i]=ts.back();ts.pop_back();changed=true;break;}for(size_t j=i+1;j<ts.size();++j){int same=0,diff=-1;for(int k=0;k<3;++k){if(ts[i].v[k]==ts[j].v[k])++same;else diff=k;}if(same>=2){if(diff<0)ts[i].v[0]=0;else ts[i].v[diff]^=ts[j].v[diff];ts[j]=ts.back();ts.pop_back();changed=true;break;}}if(changed)break;}}}
int main(int argc,char**argv){if(argc!=8){std::cerr<<"input output seconds growth seed restart_length plus_interval\n";return 2;}std::ifstream in(argv[1]);int h,l,o,n,c;in>>h>>l>>o>>n>>c;if(h!=76||l!=15||o!=28)return 3;std::vector<Term> initial;for(int i=0;i<n;++i){uint64_t lo,hi,lv,w;in>>lo>>hi>>lv>>w;initial.push_back({{lv,U(lo)|(U(hi)<<64),w}});}if(!in)return 4;clean(initial);if(packed(initial)!=c)return 5;const auto truth=tensor(initial);double seconds=std::stod(argv[3]);int growth=std::stoi(argv[4]);std::mt19937_64 rng(std::stoull(argv[5]));int restart=std::stoi(argv[6]),plus=std::stoi(argv[7]);auto start=std::chrono::steady_clock::now();auto elapsed=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};auto bests=initial;int best=c,best_raw=initial.size();uint64_t steps=0,accepted=0,pluses=0,flips=0,runs=0,merges=0;int raw_min=initial.size();
while(elapsed()<seconds){auto state=bests;int cur=best;++runs;for(int k=0;k<restart&&elapsed()<seconds;++k){++steps;size_t i=rng()%state.size(),j=0;int shared=rng()%3;std::vector<size_t> matches;for(size_t p=0;p<state.size();++p)if(p!=i&&state[p].v[shared]==state[i].v[shared])matches.push_back(p);bool do_plus=matches.empty()||(plus&&k%plus==0);auto trial=state;if(do_plus){++pluses;j=rng()%(state.size()-1);if(j>=i)++j;int a=shared,b=(a+1+rng()%2)%3,d=3-a-b;auto x=state[i],y=state[j];Term z=x;trial[i].v[a]^=y.v[a];z.v[a]=y.v[a];z.v[d]^=y.v[d];trial[j].v[b]^=x.v[b];trial.push_back(z);}else{++flips;j=matches[rng()%matches.size()];int a=(shared+1+rng()%2)%3,b=3-shared-a;trial[i].v[a]^=trial[j].v[a];trial[j].v[b]^=state[i].v[b];}
// Only new pair merges are possible because state is already normalized.
size_t prior=trial.size();clean(trial);merges+=prior-trial.size();if(trial.empty())return 6;
int next=packed(trial);bool keep=next<=best+growth&&trial.size()<=bests.size()+2*growth+6;
if(next>cur && rng()%8==0)keep=false;if(!keep)continue;state=std::move(trial);cur=next;++accepted;raw_min=std::min(raw_min,(int)state.size());
if(next<best||(next==best&&(int)state.size()<best_raw)){if(tensor(state)!=truth)return 10;best=next;best_raw=state.size();bests=state;std::cerr<<"best="<<best<<" raw="<<best_raw<<" step="<<steps<<" seconds="<<elapsed()<<"\n";}
}if(tensor(state)!=truth)return 11;}
if(tensor(bests)!=truth)return 12;std::ofstream out(argv[2]);out<<"{\"status\":\"RANK_ONE_FLIP_PLUS_COMPLETE\",\"initial_packed_cost\":"<<c<<",\"best_packed_cost\":"<<best<<",\"initial_raw_terms\":"<<initial.size()<<",\"best_raw_terms\":"<<bests.size()<<",\"raw_min_seen\":"<<raw_min<<",\"steps\":"<<steps<<",\"accepted\":"<<accepted<<",\"flips\":"<<flips<<",\"pluses\":"<<pluses<<",\"merges\":"<<merges<<",\"restarts\":"<<runs<<",\"growth\":"<<growth<<",\"seed\":"<<argv[5]<<",\"seconds\":"<<elapsed()<<",\"exact_cross_tensor_equal\":true,\"best_terms\":[";bool first=true;for(auto&t:bests){if(!first)out<<",";first=false;out<<"["<<(uint64_t)t.v[1]<<","<<(uint64_t)(t.v[1]>>64)<<","<<(uint64_t)t.v[0]<<","<<(uint64_t)t.v[2]<<"]";}out<<"]}\n";std::cout<<"best="<<best<<" raw="<<bests.size()<<" steps="<<steps<<" accepted="<<accepted<<" seconds="<<elapsed()<<"\n";
}
