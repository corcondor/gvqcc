#!/usr/bin/env python3
"""Exact Q128 copied-coordinate GL3 prototype with HMR phase cleanup.

Three new coordinate bits are arbitrary high-dependent affine combinations
of the four original low bits. The first low bit is retained. Preparation
costs at most12 CCX; HMR cleanup uses conditioned CZ only. All original
address bits survive unchanged. The original low-only tag functions are
synthesized independently as quadratic forms, with actual costs counted.
"""
from pathlib import Path
import argparse,hashlib,json,os,sys,time
import numpy as np
sys.path.append(os.environ.get('KICKMIX_SITE_PACKAGES','/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages'))
import kickmix as km
from score10_shared_translation_compile import bits,basis_elimination,output_basis,REPO
sys.path.insert(0,str(REPO))
from score10_shared_boolean import factor_columns,mobius,packed,prove

def parity(n):return int(n).bit_count()%2

def coordinate_plan(mode,seed):
 rng=np.random.default_rng(seed);matrices=[];shifts=[]
 for h in range(77):
  if mode=='shear':
   matrices.append([1,2^((h>>1&1)*1),4,8]);shifts.append(0)
  elif mode=='triangular':
   matrices.append([1,2^(int(rng.integers(2))*1),4^(int(rng.integers(4))),8^(int(rng.integers(8)))])
   shifts.append(int(rng.integers(8))<<1)
  else:
   while True:
    rows=list(map(int,rng.integers(1,8,size=3)))
    vals={0}
    for row in rows:vals|={x^row for x in list(vals)}
    if len(vals)==8:break
   matrices.append([1]+[(row<<1)|int(rng.integers(2)) for row in rows]);shifts.append(int(rng.integers(8))<<1)
 return matrices,shifts

def tag_product_program(tag):
 """Minimum-cost linear basis of four low-only quadratic output functions."""
 pair_masks=[(1<<i)|(1<<j) for j in range(4) for i in range(j)]
 products={}
 for a in range(1,16):
  for b in range(a+1,16):
   truth=np.array([parity(a&l)&parity(b&l) for l in range(16)],np.uint8)
   anf=mobius(truth);quad=sum(int(anf[m])<<i for i,m in enumerate(pair_masks))
   if quad:products.setdefault(quad,(a,b,truth))
 records=[]
 for mask in range(1,16):
  truth=np.zeros(16,np.uint8)
  for j in bits(mask):truth^=tag[:,j]
  anf=mobius(truth)
  assert all(not anf[m] for m in range(16) if m.bit_count()>2)
  quad=sum(int(anf[m])<<i for i,m in enumerate(pair_masks))
  if quad==0:terms=[]
  elif quad in products:terms=[products[quad]]
  else:
   u=next(u for u in products if u^quad in products);terms=[products[u],products[u^quad]]
  residual=truth.copy()
  for _,_,v in terms:residual^=v
  assert all(not mobius(residual)[m] for m in range(16) if m.bit_count()>1)
  records.append((len(terms),mask.bit_count(),mask,terms,mobius(residual)))
 basis=[];chosen=[];piv={}
 for cost,_,mask,terms,res in sorted(records,key=lambda r:r[:3]):
  v=mask
  while v and v.bit_length()-1 in piv:v^=piv[v.bit_length()-1]
  if v:piv[v.bit_length()-1]=v;basis.append(mask);chosen.append((terms,res))
  if len(basis)==4:break
 assert len(basis)==4
 return basis,chosen

def prepare(delta,matrices,shifts):
 inverses=[]
 for rows,t in zip(matrices,shifts):
  assert rows[0]==1 and not(t&1)
  perm=[sum(parity(row&x)<<i for i,row in enumerate(rows))^t for x in range(16)]
  assert sorted(perm)==list(range(16))
  inverses.append(np.argsort(perm))
 table=delta.reshape(77,16,4)
 coded=table.astype(np.uint32).copy();coded^=(coded&64)<<1
 tag=((coded>>7)&1).astype(np.uint8)
 assert np.array_equal(tag,tag[:1].repeat(77,axis=0))
 coded&=127
 translated=np.stack([coded[h,inverses[h]] for h in range(77)])
 flat=sum(translated[:,:,j]<<(8*j) for j in range(4))
 coeff=mobius(np.stack([mobius(row) for row in flat]))
 matrices_out=[[sum(((int(coeff[h,l])>>o)&1)<<(h-1) for h in range(1,77)) for l in range(1,16)] for o in range(32)]
 return flat,tag[0],matrices_out,inverses

def build(delta,matrices,shifts,basis):
 flat,tag,_,inverses=prepare(delta,matrices,shifts)
 output=np.zeros((77,16,32),np.uint8)
 for o,w in enumerate(basis):
  for b in bits(w):output[:,:,o]^=((flat>>b)&1).astype(np.uint8)
 coeff=mobius(np.stack([mobius(row) for row in output]))
 columns=[[0]+[packed(coeff[h,:,o])&~1 for h in range(1,77)] for o in range(32)]
 full=[o for o,c in enumerate(columns) if len(factor_columns(c))==15];terms=[]
 for a,b in zip(full[::2],full[1::2]):
  ha=sum(((columns[a][h]>>1)&1)<<h for h in range(77));hb=sum(((columns[b][h]>>2)&1)<<h for h in range(77))
  for h in range(77):
   share=(((ha>>h)&1)<<1)^(((hb>>h)&1)<<2);columns[a][h]^=share;columns[b][h]^=share
  assert len(factor_columns(columns[a]))==len(factor_columns(columns[b]))==14
  terms.append((1|((hb>>1)<<15),2|((ha>>1)<<15),(1<<a)|(1<<b)))
 for o,c in enumerate(columns):
  pairs=factor_columns(c)
  for i in range(0,len(pairs),2):
   a,h1=pairs[i]
   if i+1<len(pairs):b,h2=pairs[i+1];terms.append(((a>>1)|((h2>>1)<<15),(b>>1)|((h1>>1)<<15),1<<o))
   else:terms.append((a>>1,(h1>>1)<<15,1<<o))
 lines=[]
 for q in range(11):lines.append(f'APPEND_TO_REGISTER q{q} r0')
 lines.append('REGISTER r0 "selection"')
 for j in range(4):
  for b in range(8):lines.append(f'APPEND_TO_REGISTER q{11+8*j+b} r{j+1}')
  lines.append(f'REGISTER r{j+1} "word_{j}"');lines.append(f'CX q{17+8*j} q{18+8*j}')
 ops=basis_elimination(basis)
 for s,t in reversed(ops):lines.append(f'CX q{11+s} q{11+t}')
 cursor=43
 def bank(n,wires):
  nonlocal cursor
  wires=dict(wires);nodes=[]
  for mask in range(1,n):
   if mask in wires:continue
   unit=mask&-mask;a,b=wires[unit],wires[mask^unit]
   wires[mask]=cursor;nodes.append((a,b,cursor));lines.extend((f'R q{cursor}',f'CCX q{a} q{b} q{cursor}'));cursor+=1
  return wires,nodes
 hi,hn=bank(77,{1<<b:4+b for b in range(7)})
 coordinates=[0,cursor,cursor+1,cursor+2];cursor+=3
 c1,c2=126,127;lines.extend((f'R q{c1}',f'R q{c2}'))
 def high_form(values,target):
  anf=mobius(np.asarray(values,dtype=np.uint8));out=[]
  if anf[0]:out.append(f'X q{target}')
  out.extend(f'CX q{hi[h]} q{target}' for h in range(1,77) if anf[h])
  return out
 m=np.array(matrices,dtype=np.uint8);t=np.array(shifts,dtype=np.uint8);coordinate_ccx=0
 for i in range(1,4):
  target=coordinates[i];lines.append(f'R q{target}')
  lines+=high_form((t>>i)&1,target)
  for j in range(4):
   value=(m[:,i]>>j)&1
   if not np.any(value):continue
   if np.all(value):lines.append(f'CX q{j} q{target}')
   else:
    form=high_form(value,c1);lines+=form+[f'CCX q{c1} q{j} q{target}']+list(reversed(form));coordinate_ccx+=1
 lo,ln=bank(16,{1<<i:q for i,q in enumerate(coordinates)})
 assert cursor==126
 features=[lo[i] for i in range(1,16)]+[hi[i] for i in range(1,77)]
 truth=np.array([((np.arange(16)[None,:]&a)==a).repeat(77,0) for a in range(1,16)]+[((np.arange(77)[:,None]&a)==a).repeat(16,1) for a in range(1,77)],dtype=np.uint8)
 residual=output.copy()
 def form(mask,q):return [f'CX q{features[i]} q{q}' for i in bits(mask)]
 for a,b,w in terms:
  aa,bb=form(a,c1),form(b,c2);outs=list(bits(w));target=11+outs[0];fan=[f'CX q{target} q{11+o}' for o in outs[1:]]
  lines+=fan+aa+bb+[f'CCX q{c1} q{c2} q{target}']+list(reversed(bb))+list(reversed(aa))+list(reversed(fan))
  va=np.bitwise_xor.reduce(truth[list(bits(a))],axis=0);vb=np.bitwise_xor.reduce(truth[list(bits(b))],axis=0)
  for o in outs:residual[:,:,o]^=va&vb
 assert np.array_equal(residual,residual[:,0:1]^residual[0:1,:]^residual[0,0])
 for o in range(32):
  lc,hc=mobius(residual[0,:,o]^residual[0,0,o]),mobius(residual[:,0,o]);target=11+o
  if lc[0]^hc[0]:lines.append(f'X q{target}')
  lines.extend(f'CX q{lo[i]} q{target}' for i in range(1,16) if lc[i]);lines.extend(f'CX q{hi[i]} q{target}' for i in range(1,77) if hc[i])
 for a,b,out in reversed(ln):lines.extend((f'HMR q{out} b0',f'CZ q{a} q{b} if b0'))
 # Measured coordinate = Σ original_x_j*M_ij(high) + t_i(high).
 # Every correction is diagonal Clifford once its high-only form is copied.
 for i in range(1,4):
  lines.append(f'HMR q{coordinates[i]} b0')
  for j in range(4):
   value=(m[:,i]>>j)&1
   if np.any(value):
    ff=high_form(value,c1);lines+=ff+[f'CZ q{c1} q{j} if b0']+list(reversed(ff))
  value=(t>>i)&1
  if np.any(value):
   ff=high_form(value,c1);lines+=[f'X q{c2}']+ff+[f'CZ q{c1} q{c2} if b0']+list(reversed(ff))+[f'X q{c2}']
 for a,b,out in reversed(hn):lines.extend((f'HMR q{out} b0',f'CZ q{a} q{b} if b0'))
 for s,targ in ops:lines.append(f'CX q{11+s} q{11+targ}')
 tag_basis,tag_terms=tag_product_program(tag);tag_ops=basis_elimination(tag_basis);tag_wires=[18+8*j for j in range(4)]
 for s,targ in reversed(tag_ops):lines.append(f'CX q{tag_wires[s]} q{tag_wires[targ]}')
 tag_ccx=0
 for i,(tt,linear) in enumerate(tag_terms):
  target=tag_wires[i]
  for a,b,_ in tt:
   aa=[f'CX q{q} q{c1}' for q in bits(a)];bb=[f'CX q{q} q{c2}' for q in bits(b)]
   lines+=aa+bb+[f'CCX q{c1} q{c2} q{target}']+list(reversed(bb))+list(reversed(aa));tag_ccx+=1
  if linear[0]:lines.append(f'X q{target}')
  lines.extend(f'CX q{q} q{target}' for q in range(4) if linear[1<<q])
 for s,targ in tag_ops:lines.append(f'CX q{tag_wires[s]} q{tag_wires[targ]}')
 for j in range(4):lines.append(f'CX q{17+8*j} q{18+8*j}')
 circuit=km.Circuit('\n'.join(lines)+'\n');actual=int(circuit.operation_statistics().num_toffoli_like)
 assert circuit.num_qubits==128 and actual==80+coordinate_ccx+len(terms)+tag_ccx
 return circuit,dict(ccx=actual,bank_ccx=80,coordinate_prepare_ccx=coordinate_ccx,coordinate_cleanup_ccx=0,tag_ccx=tag_ccx,core_ccx=len(terms),qubits=128,measurement_count=83)

def main():
 p=argparse.ArgumentParser();p.add_argument('--batch',type=int,default=5);p.add_argument('--mode',choices=['shear','triangular','full'],default='full');p.add_argument('--seed',type=int,default=15120);p.add_argument('--plan',type=Path);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
 path=REPO/'score9_rebatch_synth_source_words_1232.npy';words=np.pad(np.load(path).astype(np.uint64),((0,0),(0,1)));k=a.batch;delta=words[:,4*k:4*k+4].copy()
 if k:delta^=words[:,4*k-4:4*k]
 if a.plan:
  saved=json.loads(a.plan.read_text());matrices,shifts=saved['matrices'],saved['shifts']
 else:matrices,shifts=coordinate_plan(a.mode,a.seed)
 _,_,cross,_=prepare(delta,matrices,shifts);basis,br=output_basis(cross,a.out/'basis')
 circuit,row=build(delta,matrices,shifts,basis);row['proof']=prove(circuit,delta)
 target=a.out/f'angle_k_{k}.kmb';circuit.to_file(target,format='kmb')
 result=dict(status='COPIED_GL3_ARBITRARY_TARGET_ALL_PHASES_PASS',batch=k,mode=a.mode,seed=a.seed,source_words_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),matrices=matrices,shifts=shifts,basis=basis,basis_search=br,circuit=row,path=str(target),sha256=hashlib.sha256(target.read_bytes()).hexdigest(),default_official_verifier_run=False,claim='Concrete exact technique; no accepted score gain.')
 (a.out/'result.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({key:value for key,value in result.items() if key not in ['matrices','shifts','basis']}),flush=True)
if __name__=='__main__':main()
