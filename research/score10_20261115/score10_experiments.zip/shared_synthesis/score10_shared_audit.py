#!/usr/bin/env python3
"""Read saved candidates and verify their full exact value/phase contracts."""
from pathlib import Path
import hashlib,json,os,sys
import numpy as np
sys.path.append(os.environ.get('KICKMIX_SITE_PACKAGES','/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages'))
import kickmix as km
from score10_shared_translations import REPO,rank
from score10_shared_translation_compile import bits
from score10_shared_boolean import prove

HERE=Path(__file__).resolve().parent

def cross(terms):
 table=[0]*(15*76)
 for lo,hi,low,output in terms:
  high=lo|(hi<<64)
  for l in bits(low):
   for h in bits(high):table[76*l+h]^=output
 return table

def main():
 words_path=REPO/'score9_rebatch_synth_source_words_1232.npy'
 words=np.pad(np.load(words_path).astype(np.uint64),((0,0),(0,1)))
 assert hashlib.sha256(words_path.read_bytes()).hexdigest()=='792e1b06ca6e4e7b5fa82c3cc96412b9e2d2d70a27edcd7ccb08eb242714bf68'
 rows=[]
 for folder in ['translation_k5_r2','translation_k5_r3','gl3_full_k5']:
  record=json.loads((HERE/folder/'result.json').read_text());k=record['batch'];path=HERE/folder/f'angle_k_{k}.kmb'
  assert hashlib.sha256(path.read_bytes()).hexdigest()==record['sha256']
  circuit=km.Circuit.from_file(path)
  delta=words[:,4*k:4*k+4].copy()
  if k:delta^=words[:,4*k-4:4*k]
  proof=prove(circuit,delta)
  assert circuit.num_qubits==record['circuit']['qubits']
  assert circuit.operation_statistics().num_toffoli_like==record['circuit']['ccx']
  rows.append(dict(folder=folder,ccx=int(circuit.operation_statistics().num_toffoli_like),qubits=circuit.num_qubits,sha256=record['sha256'],proof=proof))
 flips=[]
 for k in [0,5]:
  inp=HERE/f'score10_shared_matrix_k{k}_input.txt';lines=inp.read_text().splitlines();original=[list(map(int,line.split())) for line in lines[1:]]
  result_path=HERE/f'score10_shared_k{k}_long.json';result=json.loads(result_path.read_text());best=result['best_terms']
  assert cross(original)==cross(best)
  matrices={}
  for lo,hi,low,output in best:
   matrix=matrices.setdefault(output,[0]*15)
   for l in bits(low):matrix[l]^=lo|(hi<<64)
  cost=sum((rank(m)+1)//2 for m in matrices.values())
  assert cost==result['best_packed_cost']
  substantive=[m for m in matrices.values() if rank(m)>2];intersection_hist={}
  for i,a in enumerate(substantive):
   for b in substantive[i+1:]:
    dim=rank(a)+rank(b)-rank(a+b);intersection_hist[str(dim)]=intersection_hist.get(str(dim),0)+1
  flips.append(dict(batch=k,input_sha256=hashlib.sha256(inp.read_bytes()).hexdigest(),result_sha256=hashlib.sha256(result_path.read_bytes()).hexdigest(),exact_cross_equal=True,best_packed_cost=cost,steps=result['steps'],accepted=result['accepted'],pair_rowspace_intersection_dimensions=intersection_hist))
 report=dict(status='SAVED_KMB_EXACT_AUDIT_PASS',source_words_sha256=hashlib.sha256(words_path.read_bytes()).hexdigest(),circuits=rows,tensor_searches=flips,full_official_verifier_run=False,accepted_score_improvement=False)
 (HERE/'score10_shared_audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
if __name__=='__main__':main()
