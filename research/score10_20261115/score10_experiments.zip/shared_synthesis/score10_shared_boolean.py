#!/usr/bin/env python3
"""Unmodified exact Boolean helpers extracted for portable saved-plan rebuilds.

Attribution: outcome_chem_j4_synthesize.py, corcondor/gvqcc.
Source SHA256: a4e532abfd320abcd7c18e2c5a5eacf3383d441fffe8f6cebcd3ac25299dcbca
"""
import numpy as np

def mobius(a):
    a=np.array(a,copy=True)
    for bit in range((len(a)-1).bit_length()):
        for h in range(len(a)):
            if h>>bit&1:a[h]^=a[h^(1<<bit)]
    return a

def packed(a):
    return sum(int(v)<<i for i,v in enumerate(a))

def factor_columns(columns):
    """Exact GF(2) rank factorization: cross(h,l)=sum A_i(l) B_i(h)."""
    basis={};low=[];high=[]
    for h,v in enumerate(columns):
        expr=0
        while v:
            pivot=v.bit_length()-1
            if pivot in basis:
                val,index=basis[pivot];v^=val;expr^=1<<index
            else:
                index=len(low);low.append(v);high.append(0)
                basis[pivot]=(v,index);expr^=1<<index;break
        for index in range(len(low)):
            if expr>>index&1:high[index]^=1<<h
    for h,wanted in enumerate(columns):
        got=0
        for a,b in zip(low,high):
            if b>>h&1:got^=a
        assert got==wanted
    return list(zip(low,high))

def prove(circuit,delta):
    """All1232addresses, arbitrary32targetbits, everyHMR branch exactly."""
    n=len(delta);one=(1<<n)-1
    state=[0]*circuit.num_qubits
    for q in range(11):state[q]=packed(((np.arange(n)>>q)&1))
    initial_address=state[:11].copy()
    for out in range(32):state[11+out]=one<<(n*(out+1))
    initial_output=state[11:43].copy();phase=0;measurements=0
    for line in str(circuit).splitlines():
        p=line.split();gate=p[0]
        if gate in ('REGISTER','APPEND_TO_REGISTER'):continue
        q=[int(s[1:]) for s in p[1:] if s.startswith('q')]
        if gate=='X':state[q[0]]^=one
        elif gate=='CX':state[q[1]]^=state[q[0]]
        elif gate=='CCX':
            assert state[q[0]]>>n==state[q[1]]>>n==0,'output-dependent control'
            state[q[2]]^=state[q[0]]&state[q[1]]
        elif gate=='R':assert state[q[0]]==0
        elif gate=='HMR':
            assert phase==0
            phase=state[q[0]];state[q[0]]=0;measurements+=1
        elif gate=='CZ':
            assert p[-2:] == ['if','b0']
            phase^=state[q[0]]&state[q[1]]
        else:raise ValueError(gate)
    assert state[:11]==initial_address and not any(state[43:]) and phase==0
    for j in range(4):
        for bit in range(8):assert state[11+8*j+bit]==initial_output[8*j+bit]^packed((delta[:,j]>>bit)&1)
    return dict(status='EXACT_ARBITRARY_TARGET_XOR_AND_PHASE_PASS',addresses=n,output_bits=32,formal_measurement_variables_cancelled=measurements)
