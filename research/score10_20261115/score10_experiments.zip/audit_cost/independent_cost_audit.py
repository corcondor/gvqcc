#!/usr/bin/env python3
"""Read-only scalar re-evaluation using pinned official chemistry helpers."""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path
import sys

VERIFIERS = Path('/workspace/scratch/7f542e06b7cf/official_sources/Inzainos/verifiers')
REPO = Path('/workspace/scratch/7f542e06b7cf/gvqcc_repo')
FACTOR = Path('/workspace/scratch/3815fb5fae06/score8_chem_v27_schur_full/submission.npz')

def pin(path):
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(), bytes=path.stat().st_size)

def main():
    sys.path.insert(0, str(VERIFIERS))
    sys.path.append('/opt/codex/runtimes/codex-primary-runtime/dependencies/python/lib/python3.12/site-packages')
    import numpy as np
    import dfthcsos.verify as official
    data = np.load(FACTOR, allow_pickle=False)
    rank, basis, ensemble = data['W'].shape
    orbitals = data['U'].shape[-1]
    old = json.loads((REPO / 'score8_scorecard.json').read_text())
    heuristic = official.heuristic_costs(orbitals, rank, basis, ensemble, 8)
    assert (orbitals, rank, basis, ensemble) == (76, 8, 143, 44)
    assert (heuristic['toffoli'], heuristic['persistent_qubits'], heuristic['temporary_qubits']) == (6662, 84, 303)
    lam = old['chemistry_metrics']['lambda_eff']
    accepted_cost = old['candidate_costs']['dfthcsos']
    current = math.prod(old['reference_costs'][name] / value for name, value in old['candidate_costs'].items()) ** (1/3)
    assert abs(current - 27.32784222155277) < 1e-13
    assert official.score_from_metrics(old['chemistry_metrics'], old['chemistry_resources']) == accepted_cost
    ratio28 = (current / 28)**3
    baseline_tq = 14722*427
    rows = []
    for j in range(1, 15):
        public = 11 + 8*j
        max_temp = official.QUBIT_CAP - public
        assert max_temp >= 0 and max_temp < heuristic['temporary_qubits']
        q = heuristic['persistent_qubits'] + 8*j + max(heuristic['temporary_qubits'], max_temp)
        threshold = (baseline_tq/q - heuristic['toffoli'])/2
        target28 = (baseline_tq*ratio28/q - heuristic['toffoli'])/2
        rows.append(dict(J=j, circuits=math.ceil(75/j), public_angle_qubits=public,
                         max_angle_workspace=max_temp, total_qubits=q,
                         improve_strict_upper=threshold, improve_integer_max=math.ceil(threshold)-1,
                         reach28_inclusive_upper=target28, reach28_integer_max=math.floor(target28)))
    cases = []
    for loader in (5434,5197,4171,4170,4030,4000,3800,3644,3643):
        resources = dict(angles_qubits=125, toffoli=6662+2*loader, qubits=419)
        cost = official.score_from_metrics(old['chemistry_metrics'], resources)
        score = current*(accepted_cost/cost)**(1/3)
        cases.append(dict(J=4, loader_toffolis_per_pass=loader, chemistry_cost=cost,
                          conditional_combined_score=score, improves=cost<accepted_cost, reaches28=score>=28))
    result = dict(status='INDEPENDENT_OFFICIAL_SCALAR_AUDIT_PASS',
                  baseline_score=current, baseline_chemistry_cost=accepted_cost, lambda_eff=lam,
                  official_heuristic=heuristic, chemistry_target_cost_for28=accepted_cost*ratio28,
                  cost_product_reduction_to28_percent=100*(1-ratio28), rows=rows, j4_cases=cases,
                  assumptions=['Accepted score8 physical coefficients, actual angle words and brot8 unchanged.',
                               'DQI and invsqrt costs fixed to the accepted score8 receipts.',
                               'L is half the actual aggregate forward-and-reverse executed Toffoli count.',
                               'Integer thresholds apply only to unconditional integer-cost loaders.',
                               'Rows J9..14 are width feasibility only; no circuit construction is claimed.',
                               'No full official numeric verifier or competition submission was performed.'],
                  sources=[pin(VERIFIERS/'dfthcsos'/x) for x in ('verify.py','scoreinfra/costs_prepare.py','scoreinfra/circuits.py')]
                          + [pin(REPO/'score8_scorecard.json'),pin(FACTOR),pin(Path(__file__))])
    output = Path(__file__).with_suffix('.json')
    output.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(dict(status=result['status'], baseline=current, j4=rows[3], j4_cases=cases),indent=2))

if __name__ == '__main__':
    main()
