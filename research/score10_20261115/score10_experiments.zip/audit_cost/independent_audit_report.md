# Independent chemistry J4 review

## Accepted comparison and exact cost gate

The accepted score8 portfolio is `27.32784222155277`, chemistry cost
`294887961.3668603`, with `lambda_eff=46.909667503120325`, loader cost4030
per pass, total Toffoli14722 and total Q427. These values were read from the
hash-pinned scorecard and reevaluated with the unchanged official scalar
functions.

The actual factorization has `(N,R,B,C)=(76,8,143,44)` and brot8. Official
`heuristic_costs` returns6662 Toffolis,84 persistent preparation qubits and303
shared temporary qubits. Consequently, for any legal ANGLE family at that
shape and precision,

\[
T=6662+2L,\qquad Q=84+8J+\max(303,Q_{\rm angle}-11-8J)=387+8J.
\]

The second equality follows from the separate ANGLE width cap128. Reducing
ANGLE workspace alone cannot reduce the303-term in this model. The code
records all width-feasible J values1 through14; these are cost targets and
are not claims of existing circuits.

For J4, the exact strict improvement inequality is

\[
L<\frac{14722\cdot427/419-6662}{2}=4170.54415274463.
\]

Thus an unconditional integer-cost family needs **L≤4170**. Chemistry alone
reaches portfolio28 at **L≤3643**, holding the other two task costs and the
physical metrics fixed. The modeled score at4170 is27.32850302947949; at4171
it is27.327288699194423. At4030 it is27.500671113890828. At3643 it is
28.000229039501296.

L means half the actual aggregate forward-plus-reverse executed count.
Conditional Toffolis can produce noninteger means, so the strict real-valued
threshold remains the general criterion.

## Independent proof of the existing19 emitted circuits

The review read the actual KMB files in
`/workspace/scratch/3815fb5fae06/score9_rebatch_synth/joint`, rather than
trusting the generator's tensors or its own proof function. An independently
implemented simulator kept separate representations for the exact address
truth table and each affine coefficient of32 arbitrary word-input bits.
Each HMR created a fresh formal measurement variable, and its phase
coefficient was tracked to the end of the circuit, even after its classical
destination was overwritten.

All19 circuits pass on all1232 represented addresses:1220 required addresses
and12 fixed extension addresses. They preserve selection, return every
workspace qubit to zero, cancel every phase coefficient, and implement the
correct arbitrary-target XOR map. There are1520 independent HMR symbols in
the family. The actual counts are **5197 CCX per pass** and **125 maximum
ANGLE qubits**.

The input table's required uint8 portion has SHA256
`8caf7416de79102103757e3ab7ab4b6bbebfad9b1bf1ecd564c20eb948dbfcea`.
The evidence records every KMB hash. Omitting one conditional CZ correction
and inserting one erroneous output X were separately tested; both corrupted
circuits were rejected by this independent checker.

The existing5197 family therefore has correct exact circuit semantics in
this scope, but its unchanged-physics cost is335238250.0630193 and its
conditional portfolio score26.1842316386983. It cannot replace accepted
score8. This review performs no full numerical verifier run and no
competition submission.

## Contract restrictions relevant to further synthesis

All files must use the same selection and J word registers. J4 requires
exactly19 files, with three real words and one zero-padded word in the last
batch. The last slot still costs eight persistent qubits and must clear its
old contents. Quantum and classical scratch cannot persist across file
boundaries because the official recovery function resets the simulator and
restores only selection and word values after each circuit.

The official README includes both an XOR-oracle description and the explicit
allowance for any construction that loads the submitted words in the
simulated sequence. Those statements must be read together. A construction
proved exact on the coherent reachable forward/reverse subspaces must not
be called disallowed merely because its arbitrary-target extension differs.
The inherited public tag-based family uses precisely such reachable input
relations. The new19-file family happens to satisfy the stronger
arbitrary-target property as well. The independent checker here proves that
stronger property for its supported instruction class; rejecting a
data-dependent nonlinear control means this checker cannot certify it, not
that the competition necessarily forbids it.

Exact Givens reordering can be certified by preserving the relative order
of every pair of edges sharing a vertex. A permutation satisfying those
constraints can be realized through adjacent swaps of disjoint rotations,
which commute. Table columns and tree rows must receive the same permutation.
Parent-before-child validity and numerical vector/metric agreement should
still be independently checked on the resulting artifact.

## Independent review of the new commuting reorder

The alternative architecture agent emitted a complete reordered family at
`/workspace/scratch/fd9d1fc36baf/alternative_arch/score10_alt_reordered_family`.
The independent review validates all770 supplied adjacent swaps, checks that
each pair is disjoint at the point of exchange, and verifies all164
shared-vertex order constraints. The reordered tree remains valid. The
resulting1220×76 decoded floating-point vector array is **bitwise identical**
to the accepted actual-word vectors.

Every KMB in this family passes the same independent all-address,
arbitrary-target, all-HMR proof. The actual cost is **5182 CCX per pass**,
15 fewer than the previous5197 candidate, with125 maximum circuit qubits.
The five physical parameter arrays are byte-for-byte unchanged. Only the
tree rows and angle-word declaration change; the latter deliberately uses
the actual recovered words instead of the stale473-entry-different baseline
declaration. Cost remains above accepted score8, so no new scoring verifier
run or submission is warranted for this candidate.

## Evidence

- `independent_cost_audit.py` and `.json`: official scalar calculation,
  source hashes, all J bounds and representative J4 costs.
- `independent_family_audit.py` and `.json`: independent exact KMB proof,
  every file hash, all operation counts and measurement counts.
- `independent_family_fault_controls.json`: explicit corrupted-circuit
  negative controls.
- `independent_reorder_audit.py` and `.json`: checked swap witness, actual NPZ
  mapping, unchanged coefficients, native vector equality and all19 KMB
  proofs for the5182 candidate.

Primary official source: `Inzainos/quantum-circuit-compilation`, commit
`4277c767440df9efb8a90860ae2ce47028e46ba9`,
`verifiers/dfthcsos/verify.py`, `scoreinfra/costs_prepare.py`, and
`scoreinfra/circuits.py`. Accepted portfolio source: `corcondor/gvqcc`, commit
`d48d84beaf9286c560d0fd12ba97f72ad137bf69`, `score8_scorecard.json`.
Contract interpretation additionally uses the complete pinned
`official_sources/current_pinned_dfthcsos/SCORING_README.md`, especially
the XOR description and the construction allowance in the following
verification section, plus `chemistry_loader_contract_and_resynthesis.md`.
