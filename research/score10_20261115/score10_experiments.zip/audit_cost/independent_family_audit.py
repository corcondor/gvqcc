#!/usr/bin/env python3
"""Independent exact affine-data/all-measurement proof for J4 KMB loaders.

This reads emitted KMB files, not the generator's tensor factors or proof.
Each qubit is an affine expression in 32 arbitrary word-input bits, with an
exact address truth table as constant. Every HMR creates a fresh formal
measurement variable. Its phase coefficient is retained across the entire
circuit, including overwrites of the classical destination. This verifier
rejects data-dependent nonlinear controls instead of assuming they are safe.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys
import time

sys.path.append('/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages')
import kickmix as km
import numpy as np


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def truth(bits):
    return int.from_bytes(np.packbits(np.asarray(bits, dtype=np.uint8), bitorder='little').tobytes(), 'little')


def verify_one(path: Path, delta: np.ndarray) -> dict:
    circuit = km.Circuit.from_file(path)
    registers = circuit.register_data
    selection = [q.id for q in registers['selection']]
    outputs = [q.id for j in range(4) for q in registers[f'word_{j}']]
    assert len(selection) == 11 and len(outputs) == 32
    assert len(set(selection + outputs)) == 43
    assert circuit.num_qubits <= 128
    n = len(delta)
    ones = (1 << n) - 1
    addresses = np.arange(n, dtype=np.uint64)
    # Constants are exact truth tables over addresses. Linear coefficients
    # use an unrelated 32-bit space and can never collide with constants.
    const = [0] * circuit.num_qubits
    linear = [0] * circuit.num_qubits
    for i, q in enumerate(selection):
        const[q] = truth((addresses >> i) & 1)
    expected_address = [const[q] for q in selection]
    for i, q in enumerate(outputs):
        linear[q] = 1 << i
    measurements: dict[int, int] = {}
    phase_coefficients: dict[int, tuple[int, int]] = {}
    count = Counter()
    measurement_count = 0
    for line_number, line in enumerate(str(circuit).splitlines(), 1):
        parts = line.split()
        if not parts:
            continue
        op = parts[0]
        if op in ('REGISTER', 'APPEND_TO_REGISTER'):
            continue
        qids = [int(x[1:]) for x in parts[1:] if re.fullmatch(r'q\d+', x)]
        condition = int(parts[-1][1:]) if 'if' in parts else None
        count[op] += 1
        if op == 'X' and condition is None:
            const[qids[0]] ^= ones
        elif op == 'CX' and condition is None:
            a, b = qids
            const[b] ^= const[a]
            linear[b] ^= linear[a]
        elif op == 'CCX' and condition is None:
            a, b, c = qids
            assert linear[a] == linear[b] == 0, (path.name, line_number, 'data-dependent nonlinear control')
            const[c] ^= const[a] & const[b]
        elif op == 'R' and condition is None:
            a, = qids
            assert const[a] == linear[a] == 0, (path.name, line_number, 'reset of nonzero symbolic state')
        elif op == 'HMR' and condition is None:
            a, = qids
            bit = int(parts[-1][1:])
            measurement_count += 1
            measurements[bit] = measurement_count
            phase_coefficients[measurement_count] = (const[a], linear[a])
            const[a] = linear[a] = 0
        elif op == 'CZ' and condition is not None:
            a, b = qids
            assert linear[a] == linear[b] == 0, (path.name, line_number, 'data-dependent phase product')
            assert condition in measurements, (path.name, line_number, 'uninitialized classical condition')
            symbol = measurements[condition]
            value, lin = phase_coefficients[symbol]
            phase_coefficients[symbol] = (value ^ (const[a] & const[b]), lin)
        else:
            raise AssertionError((path.name, line_number, 'unsupported instruction', line))
    assert [const[q] for q in selection] == expected_address
    assert all(linear[q] == 0 for q in selection)
    public = set(selection + outputs)
    assert all(const[q] == linear[q] == 0 for q in range(circuit.num_qubits) if q not in public)
    assert all(value == lin == 0 for value, lin in phase_coefficients.values()), 'formal phase did not cancel'
    for i, q in enumerate(outputs):
        word, bit = divmod(i, 8)
        assert const[q] == truth((delta[:, word].astype(np.uint64) >> bit) & 1)
        assert linear[q] == 1 << i, (path.name, i, 'arbitrary input word not preserved')
    official_count = int(circuit.operation_statistics().num_toffoli_like)
    assert official_count == count['CCX']
    return dict(name=path.name, sha256=sha(path), addresses=n,
                arbitrary_target_bits=32, independent_measurement_variables=measurement_count,
                all_measurement_coefficients_zero=True, all_workspace_zero=True,
                selection_preserved=True, exact_target_xor=True,
                static_and_executed_toffolis=official_count,
                circuit_qubits=int(circuit.num_qubits), operation_counts=dict(count))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--family', type=Path, default=Path('/workspace/scratch/3815fb5fae06/score9_rebatch_synth/joint'))
    parser.add_argument('--words', type=Path, default=Path('/workspace/scratch/7f542e06b7cf/gvqcc_repo/score9_rebatch_synth_source_words_1232.npy'))
    parser.add_argument('--out', type=Path, default=Path(__file__).with_suffix('.json'))
    args = parser.parse_args()
    start = time.monotonic()
    words = np.load(args.words, allow_pickle=False)
    assert words.ndim == 2 and words.shape[1] == 75
    assert words.shape[0] >= 1220
    padded = np.pad(words, ((0, 0), (0, 1)))
    rows = []
    for k in range(19):
        delta = padded[:, 4*k:4*k+4].copy()
        if k:
            delta ^= padded[:, 4*k-4:4*k]
        row = verify_one(args.family / f'angle_k_{k}.kmb', delta)
        row['batch'] = k
        rows.append(row)
    result = dict(status='INDEPENDENT_EXACT_KMB_XOR_PHASE_PROOF_PASS',
                  source_code_sha256=sha(__file__), words_file_sha256=sha(args.words),
                  words_raw_required_addresses_sha256=hashlib.sha256(words[:1220].astype(np.uint8).tobytes()).hexdigest(),
                  family=str(args.family), required_addresses=1220,
                  extension_addresses=words.shape[0]-1220,
                  circuit_count=len(rows), loader_toffolis_per_pass=sum(row['static_and_executed_toffolis'] for row in rows),
                  max_circuit_qubits=max(row['circuit_qubits'] for row in rows),
                  total_independent_measurement_symbols=sum(row['independent_measurement_variables'] for row in rows),
                  full_official_numeric_verifier=False, rows=rows, seconds=time.monotonic()-start)
    args.out.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k != 'rows'}, indent=2))


if __name__ == '__main__':
    main()
