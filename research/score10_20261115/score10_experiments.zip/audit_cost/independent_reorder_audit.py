#!/usr/bin/env python3
"""Independent operator, NPZ, vector and emitted-KMB review of the reorder."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import sys
import time
import numpy as np
from independent_family_audit import verify_one, sha

ROOT = Path('/workspace/scratch/fd9d1fc36baf/alternative_arch')
REPO = Path('/workspace/scratch/7f542e06b7cf/gvqcc_repo')
BASELINE = Path('/workspace/scratch/3815fb5fae06/score8_chem_v27_schur_full/submission.npz')
VERIFIERS = Path('/workspace/scratch/7f542e06b7cf/official_sources/Inzainos/verifiers')

def main():
    start = time.monotonic()
    evidence_path = ROOT / 'score10_alt_reorder_result.json'
    evidence = json.loads(evidence_path.read_text())
    family = ROOT / 'score10_alt_reordered_family'
    original = dict(np.load(BASELINE, allow_pickle=False))
    candidate = dict(np.load(family / 'submission.npz', allow_pickle=False))
    source_words = np.load(REPO / 'score9_rebatch_synth_source_words_1232.npy', allow_pickle=False)
    permutation = evidence['permutation']
    assert sorted(permutation) == list(range(75))
    edges = original['tree_edges']
    assert np.array_equal(candidate['tree_edges'], edges[permutation])
    words = source_words[:, permutation]
    assert np.array_equal(candidate['angle_words'], words[:1220])
    unchanged = []
    for key in original:
        if key in ('tree_edges','angle_words'):
            continue
        assert candidate[key].dtype == original[key].dtype
        assert candidate[key].shape == original[key].shape
        assert candidate[key].tobytes() == original[key].tobytes(), key
        unchanged.append(key)
    assert set(original) == set(candidate)
    position = {old:new for new,old in enumerate(permutation)}
    overlaps = []
    for i in range(75):
        for j in range(i+1,75):
            if set(map(int, edges[i])).intersection(map(int, edges[j])):
                assert position[i] < position[j]
                overlaps.append((i,j))
    # Validate the actual supplied witness, including adjacency in its current
    # state, instead of generating a new witness and trusting the old one.
    order = list(range(75))
    for left, right in evidence['commuting_adjacent_swaps']:
        at = order.index(left)
        assert order[at+1] == right
        assert set(map(int, edges[left])).isdisjoint(map(int, edges[right]))
        order[at], order[at+1] = order[at+1], order[at]
    assert order == permutation
    visited = {0}
    for parent, child in candidate['tree_edges']:
        assert int(parent) in visited and int(child) not in visited
        visited.add(int(child))
    assert visited == set(range(76))
    sys.path.insert(0, str(VERIFIERS))
    from dfthcsos.scoreinfra.dfthc_math import reconstruct_u_vectors
    old_u = reconstruct_u_vectors(source_words[:1220].astype(float)/128, edges)
    new_u = reconstruct_u_vectors(words[:1220].astype(float)/128, candidate['tree_edges'])
    assert np.isfinite(new_u).all()
    assert old_u.tobytes() == new_u.tobytes(), float(np.max(np.abs(old_u-new_u)))
    # The exact operator argument above applies to every angle. This native
    # vector equality additionally checks the concrete accepted word table.
    padded = np.pad(words, ((0,0),(0,1)))
    rows=[]
    for k in range(19):
        delta=padded[:,4*k:4*k+4].copy()
        if k:
            delta ^= padded[:,4*k-4:4*k]
        row = verify_one(family/f'angle_k_{k}.kmb', delta)
        row['batch'] = k
        assert row['sha256'] == evidence['rows'][k]['sha256']
        rows.append(row)
    loader=sum(row['static_and_executed_toffolis'] for row in rows)
    assert loader == 5182 == evidence['loader_ccx']
    result=dict(status='INDEPENDENT_REORDER_KMB_AND_PHYSICS_PROOF_PASS',
                source_code_sha256=sha(__file__), family_checker_sha256=sha(Path(__file__).with_name('independent_family_audit.py')),
                reviewed_builder_receipt_sha256=sha(evidence_path), source_factorization_sha256=sha(BASELINE),
                candidate_factorization_sha256=sha(family/'submission.npz'),
                unchanged_factorization_arrays=unchanged, permuted_arrays=['tree_edges','angle_words'],
                actual_words_used_instead_of_stale_declared_words=True,
                preserved_shared_vertex_pair_count=len(overlaps),
                validated_adjacent_disjoint_swap_count=len(evidence['commuting_adjacent_swaps']),
                parent_before_child_tree_valid=True,
                operator_equivalence='All witness swaps exchange disjoint Givens rotations; exact for arbitrary angles.',
                native_decoded_vectors_bitwise_identical=True,
                decoded_vector_shape=list(new_u.shape),decoded_vectors_sha256=hashlib.sha256(new_u.tobytes()).hexdigest(),
                arbitrary_target_bits=32, required_addresses=1220, extension_addresses=12,
                independent_measurement_symbols=sum(row['independent_measurement_variables'] for row in rows),
                loader_toffolis_per_pass=loader, max_angle_qubits=max(row['circuit_qubits'] for row in rows),
                full_official_numeric_verifier=False, rows=rows, seconds=time.monotonic()-start)
    Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k!='rows'},indent=2))

if __name__=='__main__':
    main()
