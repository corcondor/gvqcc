#!/usr/bin/env python3
"""Prepare source-bound pair-rank/scheduling and GL4 screen inputs."""
from pathlib import Path
import argparse,hashlib,json
import numpy as np

def mobius(a):
  a=np.array(a,copy=True)
  for bit in range((len(a)-1).bit_length()):
    for i in range(len(a)):
      if (i>>bit)&1:a[i]^=a[i^(1<<bit)]
  return a
def packed(a):return sum(int(v)<<i for i,v in enumerate(a))
def rank(rows):
  piv={}
  for v in rows:
    while v and v.bit_length()-1 in piv:v^=piv[v.bit_length()-1]
    if v:piv[v.bit_length()-1]=v
  return len(piv)
def main():
  p=argparse.ArgumentParser(description=__doc__)
  p.add_argument('--source-words',type=Path,required=True)
  p.add_argument('--source-npz',type=Path,required=True)
  p.add_argument('--out',type=Path,default=Path(__file__).resolve().parent)
  a=p.parse_args();out=a.out;out.mkdir(parents=True,exist_ok=True)
  words=np.load(a.source_words,allow_pickle=False).astype(np.uint8)
  assert words.shape==(1232,75)
  digest=hashlib.sha256(words[:1220].tobytes()).hexdigest()
  assert digest=='8caf7416de79102103757e3ab7ab4b6bbebfad9b1bf1ecd564c20eb948dbfcea'
  assert hashlib.sha256(a.source_npz.read_bytes()).hexdigest()=='da30619d4a668d663adc9f7f0462cfd52ba8684cc5523980f5119dc3ef90302e','Expected the accepted score8 factorization'
  edges=np.load(a.source_npz,allow_pickle=False)['tree_edges']
  coded=words.copy();coded^=(coded&64)<<1;coeff=coded.reshape(77,16,75)
  for h in range(77):coeff[h]=mobius(coeff[h])
  coeff=mobius(coeff)
  matrices=[[[packed((coeff[1:,l,j]>>b)&1) for l in range(1,16)] for b in range(7)] for j in range(75)]
  matrices.append([[0]*15 for _ in range(7)])
  ranks=[[[rank([x^y for x,y in zip(matrices[i][b],matrices[j][b])]) for b in range(7)] for j in range(76)] for i in range(76)]
  previous=[-1]*76;pred=[0]*75
  for i,(v,w) in enumerate(edges):
    for x in (v,w):
      if previous[x]>=0:pred[i]|=1<<previous[x]
      previous[x]=i
  cost=[[sum((r+1)//2 for r in rs) for rs in row] for row in ranks]
  full=[[sum(r==15 for r in rs) for rs in row] for row in ranks]
  data=dict(actual_words_sha256=digest,source_words_file_sha256=hashlib.sha256(a.source_words.read_bytes()).hexdigest(),
    source_npz_sha256=hashlib.sha256(a.source_npz.read_bytes()).hexdigest(),edges=edges.tolist(),ranks=ranks,cost=cost,full=full,predecessors=[str(v) for v in pred])
  (out/'score10_alt_schedule_input.json').write_text(json.dumps(data)+'\n')
  with (out/'score10_alt_schedule_input.txt').open('w') as f:
    f.write('75\n')
    for v in pred:f.write(str(v&((1<<64)-1))+' '+str(v>>64)+'\n')
    for row in cost:f.write(' '.join(map(str,row))+'\n')
    for row in full:f.write(' '.join(map(str,row))+'\n')
  extended=np.pad(words.astype(np.uint32),((0,0),(0,1)));tables=[]
  for k in range(19):
    delta=extended[:,4*k:4*k+4].copy()
    if k:delta^=extended[:,4*k-4:4*k]
    delta^=(delta&64)<<1
    tables.append(sum(delta[:,j]<<(8*j) for j in range(4)).reshape(77,16))
  np.asarray(tables,dtype='<u4').tofile(out/'score10_alt_gl4_input.u32')
  high=np.arange(77,dtype=np.uint32)[:,None]
  low=np.arange(16,dtype=np.uint32)[None,:]
  positive=(low&1)^(((low>>1)&1)&(high&1))
  positive.astype('<u4').tofile(out/'score10_alt_gl4_positive.u32')
  print(json.dumps({k:data[k] for k in ('actual_words_sha256','source_words_file_sha256','source_npz_sha256')}))
if __name__=='__main__':main()
