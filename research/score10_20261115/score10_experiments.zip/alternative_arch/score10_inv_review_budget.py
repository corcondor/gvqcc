#!/usr/bin/env python3
"""Exact algebraic Q46-to-Q45 budget from the retained official invsqrt cost."""
from pathlib import Path
from decimal import Decimal,getcontext
import argparse,hashlib,json
getcontext().prec=50
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--scorecard',type=Path,required=True)
p.add_argument('--official-source',type=Path,required=True)
p.add_argument('--native-receipt',type=Path,required=True)
p.add_argument('--out',type=Path,required=True)
a=p.parse_args();card=json.loads(a.scorecard.read_text(),parse_float=Decimal)
cost=Decimal(card['candidate_costs']['invsqrt']);base=cost/46;budget=base/45
native=json.loads(a.native_receipt.read_text());rows=native['rows']
before={r['seed']:r for r in rows if r['file']=='accepted.kmb'}
after={r['seed']:r for r in rows if r['file']=='phase_retired_candidate.kmb'}
assert before.keys()==after.keys()
for seed,x in before.items():
 y=after[seed]
 assert y['inputs']==x['inputs']==3105
 assert all(x[k]==y[k]==0 for k in ('input_errors','scratch_errors','phase_mismatches'))
 assert y['total_toffolis']-x['total_toffolis']==9*x['inputs']
source=a.official_source.read_text()
assert "'score': circuit.num_qubits * toffolis" in source
r=dict(status='OFFICIAL_COST_BUDGET_AND_NATIVE_RECEIPT_ARITHMETIC_PASS',
  official_source_sha256=hashlib.sha256(a.official_source.read_bytes()).hexdigest(),
  scorecard_sha256=hashlib.sha256(a.scorecard.read_bytes()).hexdigest(),
  native_receipt_sha256=hashlib.sha256(a.native_receipt.read_bytes()).hexdigest(),
  current_invsqrt_cost=str(cost),inherited_mean_toffoli_equivalent=str(base),
  strict_total_extra_toffoli_budget_for_Q45=str(budget),strict_remaining_after_9=str(budget-9),strict_remaining_after_5=str(budget-5),
  formula='45*(T_old+delta)<46*T_old iff delta<T_old/45; same phase rotations and all other costs fixed.',
  current_Q46_plus9_cost=str(cost+46*9),conditional_Q45_plus9_cost=str(45*(base+9)),conditional_Q45_plus5_cost=str(45*(base+5)),
  native_comparison_inputs_per_seed=3105,native_seeds=list(before),native_extra_toffolis_each_input=9,
  limitation='Audits recorded native receipt arithmetic and input bindings; does not rerun it or claim whole-circuit Q45. Budget inherits the finite default mean from score8; exact extra unconditioned gates hold for every input.')
a.out.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
