#!/usr/bin/env python3
"""Exact bound for the fixed-coordinate rank-pairing reorder objective only."""
from pathlib import Path
import argparse,json,math
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--input',type=Path,default=ROOT/'score10_alt_schedule_input.json')
p.add_argument('--out',type=Path,default=ROOT/'score10_alt_schedule_bound.json')
args=p.parse_args()
d=json.loads(args.input.read_text())
R=d['ranks'];rare=[];bad=set(range(15));adj={}
for i in range(76):
  for j in range(i):
    expected=[15]*7 if i in bad or j in bad else [4]+[15]*6
    rs=R[i][j]
    if rs!=expected:
      assert not(i in bad or j in bad)
      assert rs==[4,10,15,15,15,15,15]
      rare.append([i,j]);adj.setdefault(i,set()).add(j);adj.setdefault(j,set()).add(i)
remaining=set(adj);components=[]
while remaining:
  todo=[remaining.pop()];seen=set(todo)
  while todo:
    for v in adj[todo.pop()]:
      if v not in seen:seen.add(v);remaining.remove(v);todo.append(v)
  components.append(sorted(seen))
rare_path_bound=sum(len(c)-1 for c in components)
assert rare_path_bound==6
# Every real bad word has a distinct incoming transition, so B>=15.
# Rare transitions form a subgraph of four ordered slot paths, hence a forest.
# Their count is at most the sum(|component|-1)=6.
# In76 transitions with no exceptional bits, per-output cost=76*50=3800,
# number of rank15 slices=76*6=456, so sharing saves at most228.
# Each bad transition raises cost6 and rank15 count1; each rare transition
# lowers cost3 and rank15 count1. Sum floor(full_k/2)<=floor(sum full_k/2).
minimum_bad_transitions=15
bound=19*80+76*50-228+math.ceil((11*minimum_bad_transitions-5*rare_path_bound)/2)
result=dict(status='EXACT_SCOPED_REORDER_LOWER_BOUND',legal_words=75,padding_words=1,transitions=76,
  low_lsb_word_indices=list(range(15,75)),random_lsb_word_indices=list(range(15)),
  minimum_random_lsb_incident_transitions=minimum_bad_transitions,rare_pairs=rare,
  rare_graph_components=components,maximum_rare_transitions_in_any_four_slot_paths=rare_path_bound,
  lower_bound_ccx=bound,known_candidate_ccx=5182,
  scope='Fixed4/7 complete banks, fixed physical output bit coordinates, independent ceil(rank/2) products with one shared rank2 correction per pair of full rank15 slices. Applies to every angle permutation even before commuting/DAG constraints.',
  excluded='Does not bound arbitrary output bases, larger shared product systems, alternative bank bases, nonlinear staged circuits, or global reversible circuit complexity.')
args.out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
