#!/usr/bin/env python3
"""Independent symbolic instrument audit of invsqrt phase-cache retirement.

Does not import or invoke the candidate builder. Reads the actual two KMBs,
verifies unchanged prefix/suffix, and evaluates GF2 polynomials including
measurement symbols in the phase polynomial itself.
"""
from pathlib import Path
import argparse,collections,hashlib,json,re,time
import kickmix as km

CLEAN={7,8,19,20,21,44};START=7604;END=8400
ONE=frozenset([0]);ZERO=frozenset()
def mul(a,b):
  out=set()
  for x in a:
    for y in b:
      term=x|y
      if term in out:out.remove(term)
      else:out.add(term)
  return frozenset(out)
def wires(line):return tuple(int(v) for v in re.findall(r'\bq(\d+)\b',line))
def classical(line):return tuple(int(v) for v in re.findall(r'\bb(\d+)\b',line))
def digest(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def evaluate(lines):
  state=[ZERO if q in CLEAN else frozenset([1<<q]) for q in range(46)]
  bvals={};stack=[];phase=ZERO;rotations=[];measurement_events=[];width=[]
  for index,line in enumerate(lines):
    op=line.split()[0];q=wires(line);b=classical(line)
    if op=='PUSH_CONDITION':stack.append(bvals[b[-1]]);continue
    if op=='POP_CONDITION':stack.pop();continue
    cond=ONE
    for predicate in stack:cond=mul(cond,predicate)
    if ' if ' in line:cond=mul(cond,bvals[b[-1]])
    if op in ('Z','CZ','CCZ','NEG'):
      p=cond
      for wire in q:p=mul(p,state[wire])
      phase=phase^p
    elif op=='Z_POW':
      assert cond==ONE
      rotations.append((line.split()[2],state[q[0]]))
    else:
      assert cond==ONE,('unexpected conditional data gate',line)
      if op=='X':state[q[0]]=state[q[0]]^ONE
      elif op=='CX':state[q[1]]=state[q[1]]^state[q[0]]
      elif op=='CCX':state[q[2]]=state[q[2]]^mul(state[q[0]],state[q[1]])
      elif op=='CSWAP':
        c,x,y=q;product=mul(state[c],state[x]^state[y]);state[x]^=product;state[y]^=product
      elif op=='SWAP':state[q[0]],state[q[1]]=state[q[1]],state[q[0]]
      elif op=='R':assert not state[q[0]],('reset nonzero',line)
      elif op=='HMR':
        symbol=46+len(measurement_events);m=frozenset([1<<symbol])
        measurement_events.append(dict(local_line=index+1,qubit=q[0],bit=b[0],was_zero=not state[q[0]],symbol=symbol))
        phase=phase^mul(m,state[q[0]]);state[q[0]]=ZERO;bvals[b[0]]=m
      else:raise ValueError(line)
    width.append(sum(bool(p) for p in state))
  assert not stack
  measure_mask=((1<<(46+len(measurement_events)))-1)^((1<<46)-1)
  measurement_phase=[m for m in phase if m&measure_mask]
  return dict(state=state,phase=phase,rotations=rotations,events=measurement_events,bvals=bvals,
              live_nonzero_peak=max(width),measurement_phase=measurement_phase,width=width)
def main():
  p=argparse.ArgumentParser(description=__doc__)
  p.add_argument('--baseline',type=Path,required=True)
  p.add_argument('--candidate',type=Path,required=True)
  p.add_argument('--builder-receipt',type=Path,required=True)
  p.add_argument('--out',type=Path,required=True)
  args=p.parse_args();start=time.monotonic()
  old=km.Circuit.from_file(args.baseline);new=km.Circuit.from_file(args.candidate)
  a=str(old).splitlines();b=str(new).splitlines()
  assert a[:START]==b[:START]
  suffix=a[END:];assert b[-len(suffix):]==suffix
  sa=a[START:END];sb=b[START:len(b)-len(suffix)]
  # Exact bound of the assumed zero entry wires to the untouched prefix.
  last={};stack=[]
  for i,line in enumerate(a[:START]):
    op=line.split()[0];q=wires(line)
    if op=='PUSH_CONDITION':stack.append(line)
    elif op=='POP_CONDITION':stack.pop()
    targets=q[-1:] if op in ('X','CX','CCX','HMR','R') else q if op=='SWAP' else q[1:] if op=='CSWAP' else ()
    for t in set(targets)&CLEAN:last[t]=(i+1,line,len(stack))
  assert set(last)==CLEAN
  assert all(v[1].startswith('HMR ') and v[2]==0 and ' if ' not in v[1] for v in last.values())
  x=evaluate(sa);y=evaluate(sb)
  assert x['state']==y['state']
  assert x['rotations']==y['rotations']
  # Corrected measurement branches must not remain in the phase polynomial.
  assert not x['measurement_phase'] and not y['measurement_phase']
  assert x['phase']==y['phase']
  assert [l for l in a if l.startswith('Z_POW ')]==[l for l in b if l.startswith('Z_POW ')]
  counts_a=collections.Counter(l.split()[0] for l in a);counts_b=collections.Counter(l.split()[0] for l in b)
  delta=int(new.operation_statistics().num_toffoli_like-old.operation_statistics().num_toffoli_like)
  # HMR on zero is observable as a classical random outcome unless unused.
  zero_events=[]
  for e in y['events']:
    if not e['was_zero']:continue
    pos=START+e['local_line']-1;bit=e['bit'];reads=[];overwritten=None
    for i in range(pos+1,len(b)):
      if bit not in classical(b[i]):continue
      op=b[i].split()[0]
      if op in ('HMR','R') and classical(b[i])[0]==bit:overwritten=i+1;break
      reads.append((i+1,b[i]))
    zero_events.append(dict(**e,full_candidate_line=pos+1,reads_before_next_write=reads,next_write_line=overwritten))
  result=dict(status='INDEPENDENT_PHASE_INSTRUMENT_EQUIVALENCE_PASS',review_script_sha256=digest(__file__),
    source_sha256=digest(args.baseline),candidate_sha256=digest(args.candidate),builder_receipt_sha256=digest(args.builder_receipt),
    unchanged_prefix_lines=START,unchanged_suffix_lines=len(suffix),clean_entry_evidence=last,
    input_scope='All40 arbitrary nonclean phase-entry qubits; six clean qubits bound to preceding unconditional HMR.',
    final_wire_anf_identical=True,generic_rotation_predicates_identical=True,generic_angle_sequence_identical=True,
    full_GF2_phase_anf_identical=True,all_measurement_variables_cancel_from_phase=True,
    original_measurements=len(x['events']),candidate_measurements=len(y['events']),
    original_live_nonzero_peak=x['live_nonzero_peak'],candidate_live_nonzero_peak=y['live_nonzero_peak'],
    actual_whole_circuit_qubits=int(new.num_qubits),compiled_Q45=int(new.num_qubits)==45,
    live_peak_is_not_physical_allocation='A zero wire used by a retained HMR can require an extra physical wire even when only45 wire polynomials are nonzero.',
    original_static_toffoli=int(old.operation_statistics().num_toffoli_like),candidate_static_toffoli=int(new.operation_statistics().num_toffoli_like),
    static_toffoli_difference=delta,operation_count_changes={k:counts_b[k]-counts_a[k] for k in sorted(counts_a.keys()|counts_b.keys()) if counts_a[k]!=counts_b[k]},
    zero_measurements_in_candidate=zero_events,full_official_verifier_run=False,seconds=time.monotonic()-start)
  args.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('zero_measurements_in_candidate','clean_entry_evidence')},indent=2))
if __name__=='__main__':main()
