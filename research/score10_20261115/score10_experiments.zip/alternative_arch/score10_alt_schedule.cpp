#include <array>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <random>
#include <vector>
#include <algorithm>
using namespace std;
int main(int argc,char**argv){
  if(argc<4)return 2;
  ifstream f(argv[1]);int n;f>>n;
  vector<array<uint64_t,2>> pred(n);
  for(auto &p:pred)f>>p[0]>>p[1];
  int c[76][76],r[76][76];
  for(auto &row:c)for(auto &v:row)f>>v;
  for(auto &row:r)for(auto &v:row)f>>v;
  array<array<bool,75>,75> before{};
  for(int i=0;i<n;i++)for(int j=0;j<i;j++)if((pred[i][j/64]>>(j%64))&1){before[j][i]=true;for(int k=0;k<j;k++)if(before[k][j])before[k][i]=true;}
  auto score=[&](const vector<int>&p){int cost=80*19;for(int k=0;k<19;k++){int full=0;for(int s=0;s<4;s++){int at=4*k+s;int a=at<75?p[at]:75,b=at>=4?p[at-4]:75;cost+=c[a][b];full+=r[a][b];}cost-=full/2;}return cost;};
  vector<int> best(n);for(int i=0;i<n;i++)best[i]=i;int bestCost=score(best);uint64_t steps=0,accepts=0;
  mt19937_64 gen(stoull(argv[3]));double seconds=stod(argv[2]);auto start=chrono::steady_clock::now();
  auto elapsed=[&](){return chrono::duration<double>(chrono::steady_clock::now()-start).count();};
  int restart=0;
  while(elapsed()<seconds){
    vector<int> p=best;int curr=bestCost;
    double t0=elapsed(),period=2.0;
    while(elapsed()-t0<period && elapsed()<seconds){
      int i=gen()%n,j=gen()%n;if(i==j)continue;
      bool valid=true;int a=p[i];
      if(i<j){for(int k=i+1;k<=j;k++)if(before[a][p[k]]){valid=false;break;}}
      else {for(int k=j;k<i;k++)if(before[p[k]][a]){valid=false;break;}}
      if(!valid)continue;
      auto q=p;q.erase(q.begin()+i);q.insert(q.begin()+j,a);
      int next=score(q);steps++;
      double t=0.08+3.0*pow(1.0-(elapsed()-t0)/period,2);
      if(next<=curr || generate_canonical<double,53>(gen)<exp((curr-next)/t)){
        p=move(q);curr=next;accepts++;
        if(curr<bestCost){bestCost=curr;best=p;cerr<<"best "<<bestCost<<" at "<<elapsed()<<"\n";}
      }
    }
    restart++;
  }
  cout<<"{\"best_ccx\":"<<bestCost<<",\"steps\":"<<steps<<",\"accepts\":"<<accepts<<",\"seconds\":"<<elapsed()<<",\"restarts\":"<<restart<<",\"permutation\":[";
  for(int i=0;i<n;i++){if(i)cout<<",";cout<<best[i];}cout<<"]}\n";
}
