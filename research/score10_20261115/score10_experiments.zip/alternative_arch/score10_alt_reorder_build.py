#!/usr/bin/env python3
"""Compile disjoint-Givens reordered J4 loaders, with exact XOR/phase proof."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys,time
import numpy as np

ROOT=Path(__file__).resolve().parent
def main():
  parser=argparse.ArgumentParser(description=__doc__)
  parser.add_argument('--repo-root',type=Path,default=ROOT)
  parser.add_argument('--source-words',type=Path)
  parser.add_argument('--source-npz',type=Path,required=True)
  parser.add_argument('--verifier-root',type=Path,required=True,help='directory containing the unmodified dfthcsos package')
  parser.add_argument('--schedule',type=Path,default=ROOT/'score10_alt_schedule_result.json')
  parser.add_argument('--out',type=Path,default=ROOT/'score10_alt_reordered_family')
  parser.add_argument('--result',type=Path,default=ROOT/'score10_alt_reorder_result.json')
  args=parser.parse_args()
  repo=args.repo_root.resolve();source_words=args.source_words or repo/'score9_rebatch_synth_source_words_1232.npy'
  sys.path.insert(0,str(repo))
  sys.path.insert(0,str(args.verifier_root.resolve()))
  import kickmix as km
  from score9_rebatch_synth import coefficients,output_basis,transform_delta,initial_terms,synthesize,prove
  start=time.monotonic()
  schedule=json.loads(args.schedule.read_text())
  permutation=schedule['permutation'];assert sorted(permutation)==list(range(75))
  factor=args.source_npz
  assert hashlib.sha256(factor.read_bytes()).hexdigest()=='da30619d4a668d663adc9f7f0462cfd52ba8684cc5523980f5119dc3ef90302e','Expected the accepted score8 factorization'
  params=dict(np.load(factor,allow_pickle=False));edges=params['tree_edges']
  position={v:i for i,v in enumerate(permutation)}
  conflicts=0
  for i in range(75):
    for j in range(i+1,75):
      if set(edges[i])&set(edges[j]):
        conflicts+=1;assert position[i]<position[j]
  # Independently construct an adjacent-swap witness: every crossed pair
  # must have disjoint supports, proving commutation at operator level.
  current=list(range(75));swaps=[]
  for target,value in enumerate(permutation):
    at=current.index(value)
    while at>target:
      left,right=current[at-1],current[at]
      assert not set(edges[left])&set(edges[right])
      swaps.append([left,right]);current[at-1:at+1]=[right,left];at-=1
  assert current==permutation
  original=np.load(source_words,allow_pickle=False)
  assert original.shape==(1232,75)
  assert hashlib.sha256(original[:1220].astype(np.uint8).tobytes()).hexdigest()=='8caf7416de79102103757e3ab7ab4b6bbebfad9b1bf1ecd564c20eb948dbfcea'
  words=np.pad(original[:,permutation].astype(np.uint64),((0,0),(0,1)))
  out=args.out;out.mkdir(parents=True,exist_ok=True)
  subprocess.run(['g++','-O3','-std=c++17',str(repo/'score9_rebatch_synth_rank_basis.cpp'),'-o',str(out/'rank_basis')],check=True)
  rows=[]
  for k in range(19):
    delta=words[:,4*k:4*k+4].copy()
    if k:delta^=words[:,4*k-4:4*k]
    basis,row=output_basis(coefficients(delta),out,k)
    _,wanted=transform_delta(delta,basis);terms=initial_terms(wanted,True)
    circuit=synthesize(delta,basis,terms)
    row.update(batch=k,ccx=int(circuit.operation_statistics().num_toffoli_like),qubits=circuit.num_qubits,proof=prove(circuit,delta))
    path=out/f'angle_k_{k}.kmb';circuit.to_file(path,format='kmb')
    row['sha256']=hashlib.sha256(path.read_bytes()).hexdigest();rows.append(row)
    print(json.dumps({key:row[key] for key in ('batch','ccx','qubits','rank_deficient_outputs')}),flush=True)
  params['tree_edges']=edges[permutation]
  params['angle_words']=original[:1220,permutation].astype(params['angle_words'].dtype)
  np.savez(out/'submission.npz',**params)
  from dfthcsos.scoreinfra.circuits import recover_words_from_circuits
  circuits=[km.Circuit.from_file(out/f'angle_k_{k}.kmb') for k in range(19)]
  recovered,layout,t=recover_words_from_circuits(circuits,num_vectors=1220,num_angles=75,shots_per_address=1,seed=20261115019)
  assert np.array_equal(recovered,words[:1220,:75]) and layout.batch_size==4
  L=sum(r['ccx'] for r in rows);assert t==2*L
  ratio=419*(6662+2*L)/(427*14722)
  result=dict(status='EXACT_REORDERED_FAMILY_BUILT',permutation=permutation,preserved_overlap_pairs=conflicts,
    commuting_adjacent_swaps=swaps,rows=rows,loader_ccx=L,total_toffoli=6662+2*L,total_qubits=419,max_circuit_qubits=max(r['qubits'] for r in rows),
    source_factorization_sha256=hashlib.sha256(factor.read_bytes()).hexdigest(),output_factorization_sha256=hashlib.sha256((out/'submission.npz').read_bytes()).hexdigest(),
    native_recovery={'status':'PASS','legal_addresses':1220,'forward_reverse':True,'shots_per_address':1,'seed':20261115019,'word_errors':0},
    physics_proof='Permutation realized by adjacent swaps of disjoint Givens rotations; exact same ordered operator.',
    QT_ratio_to_score8=ratio,chemistry_cost_from_identical_physics=294887961.3668603*ratio,portfolio_score_from_identical_physics=27.32784222155277/ratio**(1/3),
    full_official_verifier_run=False,improves_score8=ratio<1,seconds=time.monotonic()-start)
  args.result.parent.mkdir(parents=True,exist_ok=True)
  args.result.write_text(json.dumps(result,indent=2)+'\n')
  print(json.dumps({k:v for k,v in result.items() if k not in ('rows','commuting_adjacent_swaps')}),flush=True)
if __name__=='__main__':main()
