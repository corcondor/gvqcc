#!/usr/bin/env python3
"""Independently verify the actual Q45 phase fragment and dead HMR erasure."""
from pathlib import Path
import argparse,json,re,time
import kickmix as km
from score10_inv_review import CLEAN,START,END,wires,classical,digest,evaluate
def main():
  p=argparse.ArgumentParser(description=__doc__)
  p.add_argument('--baseline',type=Path,required=True)
  p.add_argument('--whole-candidate',type=Path,required=True)
  p.add_argument('--source-fragment',type=Path,required=True)
  p.add_argument('--fragment',type=Path,required=True)
  p.add_argument('--builder-receipt',type=Path,required=True)
  p.add_argument('--out',type=Path,required=True)
  a=p.parse_args();start=time.monotonic()
  old=km.Circuit.from_file(a.baseline);whole=km.Circuit.from_file(a.whole_candidate)
  source=km.Circuit.from_file(a.source_fragment);fragment=km.Circuit.from_file(a.fragment)
  oldlines=str(old).splitlines();newlines=str(whole).splitlines()
  src=str(source).splitlines();frag=str(fragment).splitlines()
  data=[q for q in range(46) if q not in CLEAN]
  expected_header=[f'APPEND_TO_REGISTER q{q} r0' for q in data]+['REGISTER r0 "phase_data"']
  assert src[:41]==expected_header
  def lift(line):
    return re.sub(r'\bq(\d+)\b',lambda m:f'q{int(m[1]) if int(m[1])<19 else int(m[1])+1}',line)
  lifted=[lift(line) for line in frag]
  assert lifted[:41]==expected_header
  assert src[41:]==oldlines[START:END]
  suffix=oldlines[END:];assert newlines[:START]==oldlines[:START] and newlines[-len(suffix):]==suffix
  patched=newlines[START:len(newlines)-len(suffix)]
  removed=[(i,l) for i,l in enumerate(patched) if 19 in wires(l)]
  assert len(removed)==5 and all(l.startswith('HMR q19 ') for _,l in removed)
  keep=[l for l in patched if 19 not in wires(l)]
  assert lifted[41:]==keep
  dead=[]
  for i,line in removed:
    bit=classical(line)[0];nextwrite=None
    for j in range(i+1,len(patched)):
      if bit not in classical(patched[j]):continue
      assert patched[j].startswith('HMR ') and classical(patched[j])==(bit,),('live removed outcome',j,patched[j])
      nextwrite=j+1;break
    assert nextwrite is not None
    dead.append(dict(patched_phase_line=i+1,bit=bit,overwritten_before_any_read_at_phase_line=nextwrite))
  x=evaluate(src[41:]);y=evaluate(lifted[41:]);z=evaluate(patched)
  assert x['state']==y['state']==z['state']
  assert x['phase']==y['phase']==z['phase']
  assert x['rotations']==y['rotations']==z['rotations']
  assert not x['measurement_phase'] and not y['measurement_phase'] and not z['measurement_phase']
  assert len(x['events'])==41 and len(y['events'])==36
  assert source.num_qubits==46 and fragment.num_qubits==45 and whole.num_qubits==46
  old_t=int(source.operation_statistics().num_toffoli_like);new_t=int(fragment.operation_statistics().num_toffoli_like)
  assert old_t==105 and new_t==110
  result=dict(status='INDEPENDENT_ACTUAL_Q45_FRAGMENT_AND_DEAD_OUTCOME_PROOF_PASS',
    review_script_sha256=digest(__file__),review_algebra_sha256=digest(Path(__file__).with_name('score10_inv_review.py')),
    source_kmb_sha256=digest(a.baseline),whole_candidate_sha256=digest(a.whole_candidate),
    source_fragment_sha256=digest(a.source_fragment),fragment_sha256=digest(a.fragment),builder_receipt_sha256=digest(a.builder_receipt),
    actual_fragment_qubits=int(fragment.num_qubits),actual_whole_candidate_qubits=int(whole.num_qubits),whole_circuit_Q45=False,
    arbitrary_data_inputs_preserved=40,parked_q42_q45_explicitly_retained=True,removed_logical_wire=19,
    exact_static_relabeling=True,removed_wire_has_no_other_phase_references=True,dead_outcome_checks=dead,
    original_measurements=41,fragment_measurements=36,all_measurement_phase_variables_cancel=True,
    arbitrary_input_final_state_and_generic_rotation_predicates_identical=True,
    original_fragment_toffolis=old_t,candidate_fragment_toffolis=new_t,additional_unconditional_toffoli=5,
    coupling_note='Five independent uniform HMR outcomes on zero are discarded before any read. Fixed RNG seeds need not couple later draws; the corrected quantum instrument is exactly equal after marginalizing these dead outcomes.',
    no_whole_score_improvement_claimed=True,full_official_verifier_run=False,seconds=time.monotonic()-start)
  a.out.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
