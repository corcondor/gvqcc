#include <algorithm>
#include <array>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <set>
#include <utility>
#include <vector>
using namespace std;
using u128=__uint128_t;
static constexpr int OUT=28,H=77,L=16;
static int careH=H;
static int dataBit(int o){return (o/7)*8+o%7;}
int rankcols(const array<uint16_t,H>&c){array<uint16_t,15>p{};int r=0;for(int h=1;h<careH;h++){auto v=uint16_t(c[h]^c[0]);while(v){int b=31-__builtin_clz(v);if(p[b])v^=p[b];else{p[b]=v;r++;break;}}if(r==15)return r;}return r;}
int main(int argc,char**argv){if(argc<3)return 2;ifstream f(argv[1],ios::binary);int num=stoi(argv[2]);if(argc>=4)careH=stoi(argv[3]);if(careH<1||careH>H)return 3;vector<array<array<uint32_t,L>,H>> table(num);f.read(reinterpret_cast<char*>(table.data()),num*H*L*4);if(!f)return 4;u128 mask=(u128(1)<<careH)-1;cout<<"{\"status\":\"EXACT_SINGLE_TRANSVECTION_KERNEL_SCREEN\",\"care_high_rows\":"<<careH<<",\"low_covectors_per_slice\":32767,\"rows\":[";bool firstrow=true;
  for(int k=0;k<num;k++)for(int i=0;i<4;i++)for(int j=0;j<4;j++)if(i!=j){
    array<array<array<uint16_t,H>,OUT>,2> columns{};
    array<array<array<u128,15>,OUT>,2> bitrows{};
    for(int t=0;t<2;t++)for(int h=0;h<careH;h++){
      array<uint32_t,16>a{};for(int l=0;l<16;l++)a[l]=table[k][h][l^((t&&((l>>j)&1))?(1<<i):0)];
      for(int b=0;b<4;b++)for(int l=0;l<16;l++)if((l>>b)&1)a[l]^=a[l^(1<<b)];
      for(int o=0;o<OUT;o++)for(int l=1;l<16;l++)if((a[l]>>dataBit(o))&1){columns[t][o][h]|=1<<(l-1);bitrows[t][o][l-1]|=u128(1)<<h;}
    }
    vector<int> original;int orig=0,full=0;for(int o=0;o<OUT;o++){int r=rankcols(columns[0][o]);original.push_back(r);orig+=(r+1)/2;full+=r==15;}orig-=full/2;
    set<pair<uint64_t,uint64_t>> candidates;int fullSlices=0,noKernel=0;
    for(int o=0;o<OUT;o++){
      u128 v0=0,v1=0;int witnesses=0;
      for(int s=1;s<(1<<15);s++){
        int b=__builtin_ctz(s);v0^=bitrows[0][o][b];v1^=bitrows[1][o][b];
        if(v0==0 || v0==mask)continue;
        if((v0&v1)==0){candidates.emplace(uint64_t(v0),uint64_t(v0>>64));witnesses++;}
        if(((v0|v1)&mask)==mask){auto h=(~v0)&mask;candidates.emplace(uint64_t(h),uint64_t(h>>64));witnesses++;}
      }
      if(original[o]==15){fullSlices++;noKernel+=witnesses==0;}
    }
    int best=orig;pair<uint64_t,uint64_t>besth{};vector<int> bestranks=original;
    for(auto pair:candidates){u128 choose=u128(pair.first)|(u128(pair.second)<<64);int cost=0,full=0;vector<int> ranks;
      for(int o=0;o<OUT;o++){array<uint16_t,H>c{};for(int h=0;h<H;h++)c[h]=columns[(choose>>h)&1][o][h];int r=rankcols(c);ranks.push_back(r);cost+=(r+1)/2;full+=r==15;}
      cost-=full/2;
      if(cost<best){best=cost;besth=pair;bestranks=ranks;}
    }
    if(!firstrow)cout<<",";firstrow=false;
    cout<<"{\"batch\":"<<k<<",\"target_low_bit\":"<<i<<",\"control_low_bit\":"<<j<<",\"original_core\":"<<orig<<",\"best_core\":"<<best<<",\"full_rank_slices\":"<<fullSlices<<",\"full_rank_slices_without_any_possible_null_vector\":"<<noKernel<<",\"candidate_high_functions\":"<<candidates.size()<<",\"high_truth_lo\":"<<besth.first<<",\"high_truth_hi\":"<<besth.second<<",\"best_ranks\":[";
    for(int o=0;o<OUT;o++){if(o)cout<<",";cout<<bestranks[o];}cout<<"]}";
  }
  cout<<"]}\n";
}
