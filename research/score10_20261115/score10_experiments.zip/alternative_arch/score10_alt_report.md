# J4 exact commuting reorder and conditional GL4 audit

## Concrete result

All nineteen new loaders were built. Their actual KMB Toffoli-like counts sum
to **5,182 per pass**, compared with 5,197 for the previous fixed-order joint
family. Maximum circuit width is **125 qubits**. This is a further experimental
reduction of **15 CCX per pass**, not an improvement over the accepted J5
4,030-loader portfolio.

The new family has total modeled T=17,026 and Q=419. Keeping the exact physics,
its chemistry cost is 334,648,595.5425051, a factor 1.1348330192638143 of the
accepted score8 cost. Its conditional portfolio score is 26.199601583316532.
It therefore fails the improvement gate of L<=4,170. No full numeric verifier
or competition submission was run for this more expensive candidate.

The change reorders angle columns and their tree edges together. The saved
permutation preserves all 164 ordered pairs of edges sharing a vertex. A
770-step witness realizes it using adjacent swaps of disjoint Givens rotations.
These rotations commute as full operators; no approximate physical equivalence
is used. The independent cost-audit reviewer also found the 1,220 by 76 decoded
floating-point vectors bitwise identical.

Each of the nineteen emitted circuits passed the exact symbolic proof over
1,232 address values, arbitrary 32-bit target inputs, and every HMR outcome.
The official native recovery routine additionally passed both directions over
all 1,220 legal addresses, one shot per address, seed 20261115019, with no word
differences. These checks are not called a full default-shot verifier PASS.

See `score10_alt_reorder_result.json`, the actual family under
`score10_alt_reordered_family/`, and the independently produced
`independent_reorder_audit.json` in the parent task's audit directory.

## Why changing only the order has limited scope

The rank matrices were computed for all pairs among the 75 real columns and a
zero word, using the pinned actual 1,232-address extension. In the existing
4/7 split, the seven non-tag output-bit ranks have only three forms:

| Pair type | Ranks | Independent paired core cost |
|---|---|---:|
| At least one of columns0--14 | 15,15,15,15,15,15,15 | 56 |
| Ordinary remaining pair | 4,15,15,15,15,15,15 | 50 |
| Nine special pairs | 4,10,15,15,15,15,15 | 47 |

The special-pair graph consists of three isolated edges and a four-vertex
clique. Four ordered slot paths can use at most six of these edges. Every
permutation has at least fifteen transitions touching the first class. With
80 bank-preparation CCX for each of nineteen files and the existing one-product
sharing between two full-rank slices, this gives the exact scoped bound

    L >= 19*80 + 76*50 - 228 + ceil((11*15 - 5*6)/2) = 5160.

This bound concerns **fixed physical output coordinates and the present
independent paired-rank construction plus full-rank pair sharing**. It does
not bound arbitrary output bases, larger shared products, different features,
other address partitions, or general reversible circuits. The 30-second
schedule search made 60,269,939 legal proposals and found 5,182; it is not
claimed globally optimal, even in its own scheduling class. The compiled
candidate also receives the existing exhaustive output-basis check, which did
not further reduce its count.

See `score10_alt_schedule_bound.py` and its JSON certificate.

## Exact screen of one conditional low-address transvection

The next experiment allows

    y_i = x_i XOR (x_j AND h(high)),  i != j,

with **any** Boolean function h of the high address. Because the full high
feature bank is present, h can be formed with CNOTs. Applying this change and
its inverse adds two CCX to a physical circuit.

For each of 19 batches, each of the 12 ordered pairs i,j, and each of the 28
non-tag output slices, the screen enumerates all 32,767 nonzero low covectors.
For one covector let v0 and v1 be its evaluations over the high rows under
identity and transvection. A selectable high-dependent warp makes this
covector constant iff

    v0 AND v1 = 0,  or  v0 OR v1 = all_ones.

This exactly tests existence of a high predicate, without enumerating its
2^76 possibilities. Covectors already constant before the warp are excluded
when looking for a newly available kernel vector.

The stronger run uses only the first **76 complete high rows**, namely the
first **1,216 legal addresses**. Thus its negative conclusion does not rely on
the twelve unrequired extension values or even the final partial high row.
Across all 228 cases and 6,384 output slices, **no new null vector is possible**.
All 5,700 full-rank slices retain rank15. In this fixed-output synthesis class,
one conditional transvection cannot lower the core count and would add two CCX.

This excludes only one such transvection. It does not exclude compositions,
output-basis changes, general high-dependent affine permutations, or nonlinear
address encodings. A broader warp must also synthesize the four tag outputs:
after a high-dependent coordinate change they need not remain pure-low.

A synthetic positive control, f=x0 XOR (x1 AND h0), is reduced from core rank1
to rank0 by the screen. Its physical coordinate changes still cost two CCX;
it is a search sanity check, not a benchmark gain. The JSON records this
qualification explicitly.

## Reproduction

Dependencies: Python with NumPy and Kickmix; C++17; the unchanged official
`dfthcsos` verifier package. Supply paths to the pinned original word table and
accepted score8 NPZ. The new scripts do not require this session's paths.

Prepare the inputs:

```bash
python score10_alt_prepare.py --source-words /path/to/score9_rebatch_synth_source_words_1232.npy --source-npz /path/to/accepted/submission.npz --out /path/to/work
```

The saved `score10_alt_schedule_result.json` contains the full permutation.
Rebuild it deterministically without rerunning the stochastic search:

```bash
python score10_alt_reorder_build.py --repo-root /path/to/gvqcc --source-words /path/to/score9_rebatch_synth_source_words_1232.npy --source-npz /path/to/accepted/submission.npz --verifier-root /path/to/official/verifiers --schedule /path/to/score10_alt_schedule_result.json --out /path/to/rebuilt --result /path/to/rebuild_result.json
```

The supplied repo root must contain the prior `score9_rebatch_synth.py`,
`score9_rebatch_synth_rank_basis.cpp` and `outcome_chem_j4_synthesize.py` helpers.
The builder compiles the rank enumerator locally and emits all nineteen KMB
files, the reordered NPZ, exact proofs, and native family recovery. A clean
second build reproduced all nineteen KMB files and the NPZ **byte for byte**;
see `score10_alt_portability.json`.

Run the scoped GL4 screen:

```bash
g++ -O3 -std=c++17 score10_alt_gl4_screen.cpp -o gl4_screen
./gl4_screen /path/to/work/score10_alt_gl4_input.u32 19 76 > gl4_care.json
./gl4_screen /path/to/work/score10_alt_gl4_positive.u32 1 76 > gl4_positive.json
python score10_alt_schedule_bound.py --input /path/to/work/score10_alt_schedule_input.json --out /path/to/bound.json
```

The C++ inputs are little-endian uint32 arrays. The 77-row run is retained as
`score10_alt_gl4_screen.json`; the stronger legal-subset run is
`score10_alt_gl4_care_screen.json`.

The original maoxin123 loader family and prior score9 synthesis helpers retain
their original attribution. The commuting-schedule search, scoped schedule
bound and conditional-transvection kernel screen are new in this continuation.
