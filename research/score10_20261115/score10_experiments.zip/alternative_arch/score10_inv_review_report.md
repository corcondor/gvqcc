# Independent review of inverse-square-root phase-cache retirement

## Finding

The latest five-cache construction is an exact implementation of the accepted
phase region with **45 actual circuit qubits and 110 Toffoli-like gates**,
versus 46 qubits and105 gates for the source fragment. It preserves all forty
arbitrary nonclean inputs, including the two parked data coordinates.

The **whole benchmark candidate still declares46 qubits** and its static
Toffoli count is1,555, versus1,550 for the accepted circuit. Consequently this
is a verified regional primitive, not an accepted portfolio improvement.
The remaining nonphase peak must be redesigned and a complete45-qubit program
emitted before the qubit reduction can lower the official cost.

## Independent proof

The reviewer reads the actual KMB files and does not import or invoke either
candidate builder. It checks that the first7,604 source lines and final15,504
source lines are unchanged, isolating the transformed source interval7605--8400.

At that boundary, wires7,8,19,20,21,44 are zero. Each assumption is independently
bound to the last unconditional HMR write to that wire in the unchanged prefix.
The other forty input wires are independent formal Boolean variables.

The reviewer evaluates sparse GF(2) polynomials, representing measurement
outcomes as additional variables in the phase polynomial itself. It checks:

- Identical final polynomials on all46 logical wires.
- Identical Boolean predicates and angle strings for every generic Z_POW.
- Identical full binary phase polynomial, with all measurement variables
  cancelling from it.
- Actual static Toffoli counts and actual `Circuit.num_qubits`.

For the physical45-qubit fragment, the reviewer lifts every wire number back
to its original logical coordinate and independently matches the emitted body
to the whole candidate. The only omitted logical wire is q19, which is zero
throughout the transformed region. All forty data coordinates remain explicitly
listed in the fragment's input register.

The five remaining q19 references are HMRs of zero. Every discarded outcome
is overwritten before any subsequent read. Deleting these measurements and
relabeling the other wires therefore preserves the corrected quantum channel.
The reviewer reruns the full symbolic comparison after deletion: the source
has41 measurements, the physical45-qubit fragment has36, and all phase and
data identities still hold.

Deleting independent unused outcomes changes a fixed-seed random-number
stream. Quantum-instrument equality follows after marginalizing these dead
outcomes; a same-integer-seed comparison must not be used to claim every later
measurement draw is coupled. The whole candidate currently retains the zero
HMRs, so its same-seed comparisons do preserve that coupling.

## Earlier nine-cache candidate

The earlier candidate also passes the independent arbitrary-input and phase
proof. Its static count is1,559, adding9 gates. Its maximum number of nonzero
symbolic wire values decreases46→45, but its actual circuit width remains46.

The distinction matters: an HMR of zero can still need a physical zero qubit
while45 other values are live. The five-cache construction resolves that
specific issue by identifying one wire that remains zero throughout the whole
phase region and removing its dead HMRs in the standalone fragment.

## Official cost budget

The official inverse-square-root source computes cost as

    circuit.num_qubits * toffoli_equivalent.

Using the retained score8 cost78,673.55534364567 gives

    T_old = 78,673.55534364567 /46 = 1,710.2946813836015...

A complete45-qubit circuit improves this cost, with identical rotations and
the same other behavior, precisely when

    delta < T_old /45 = 38.006548475191145...

The five-cache primitive consumes5 of that allowance, leaving a **strict
remaining allowance of33.006548475191145**. The nine-cache primitive leaves
29.006548475191145. This calculation inherits the accepted finite-default mean;
it is not a new official score.

If the whole circuit were reduced to45 with only5 extra gates, its conditional
cost would be77,188.26066226207. With actual width still46, five extra gates
instead increase its modeled cost to78,903.55534364567. The regional artifact
has not yet realized the former case.

The recorded earlier native comparisons contain3,105 inputs at each of two
seeds. Their value/scratch/phase errors are zero and the count differences
equal exactly9 times3,105. The budget script independently verifies this receipt
arithmetic, but does not represent it as an independently rerun native check.

The latest persistent native check also passed3,129 whole-circuit inputs and
4,178 arbitrary40-bit fragment assignments, each at two seeds. It compares all
quantum output wires and exact phase units, and records the expected5-gate
increase. The independent reviewer inspected the check's source, verified all
four artifact hashes and source/receipt bindings, and checked every count
difference. This is source/receipt review, not a second native execution; the
separate symbolic proof above covers all input assignments and all branches.

## Artifacts and bindings

- `score10_inv_review.py`: independent arbitrary-input instrument checker.
- `score10_inv_review9.json`: earlier nine-cache whole-candidate review.
- `score10_inv_review5.json`: five-cache whole-candidate review.
- `score10_inv_review5_fragment.py` and `.json`: actual45-qubit fragment,
  static relabeling, and dead-measurement proof.
- `score10_inv_review_budget.py` and `.json`: official-source cost calculation
  and recorded native comparison arithmetic.
- `score10_inv_review_native5.json`: latest native source/receipt and artifact
  hash review.

Accepted circuit SHA-256:
`684106f101730ca193627229920a0501bef9ea10ccfb34aa453fcf63edadb50a`.

Five-cache whole candidate SHA-256:
`489c74015e0fda32b0e2f1e8bf67857898066f9079b7577b4121f0bc3e8468aa`.

Actual45-qubit phase fragment SHA-256:
`75cd25308c5dcd23e9d95e2d0150bf2af88bbe49efc00739f7bd86754d53f1e7`.

The review JSON files additionally bind the builder receipts and checker
source hashes. No full official verifier or competition submission was run
by this independent review.
