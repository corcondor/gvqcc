#!/usr/bin/env python3
"""Exact eight-input check and actual Kickmix resource count of the CCZ identity.

Uses Selinger Eq.(5)-(6), also displayed in Zhang-Zhang Figure3. This is a
standalone resource audit, not a GVQCC submission or an improvement claim.
"""
import hashlib,json,sys
from fractions import Fraction
from pathlib import Path
import numpy as np
sys.path.append('/workspace/scratch/7f542e06b7cf/kickmix_venv/lib/python3.12/site-packages')
import kickmix as km
ROOT=Path(__file__).resolve().parent
header=[f'APPEND_TO_REGISTER q{i} r0' for i in range(3)]+['REGISTER r0 "data"']
compute=['CX q0 q3','CX q1 q3','CX q2 q3',
         'CX q0 q4','CX q1 q4','CX q0 q5','CX q2 q5','CX q1 q6','CX q2 q6']
rot=[f'Z_POW q{i} 0.25' for i in range(4)]+[f'Z_POW q{i} -0.25' for i in range(4,7)]
variants={'native_ccz':header+['CCZ q0 q1 q2'],
          'seven_t_depth_one':header+compute+rot+compute[::-1]}
rows=[]
for name,lines in variants.items():
 c=km.Circuit('\n'.join(lines)+'\n');dest=ROOT/f'{name}.kmb';c.to_file(dest,format='kmb')
 st=c.operation_statistics();sim=km.Simulator(batch_size=8,seed=20261115,counting_operations=True)
 sim.use_same_registers_as(c);reg=km.array(list(c.register_data['data']))
 vals=np.arange(8,dtype=np.uint64);bits=(vals[None,:]>>np.arange(3,dtype=np.uint64)[:,None])&1==1
 sim.write_across_shots(reg,bits);sim.do(c)
 assert np.array_equal(sim.read_across_shots(reg),bits)
 if c.num_qubits>3:assert not sim.read_across_shots(km.array([km.q(i) for i in range(3,c.num_qubits)])).any()
 phases=[str(Fraction(sim.read_shot_phase(i))%2) for i in range(8)]
 assert phases==['0']*7+['1']
 t=int(st.num_t_like);tof=int(st.num_toffoli_like)
 rows.append(dict(name=name,num_qubits=int(c.num_qubits),toffoli_like=tof,t_like=t,
                  invsqrt_effective_toffoli=tof+t/4,phase_half_turns=phases,
                  all8_inputs_exact=True,workspace_clean=True,
                  kmb_sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
identity=[]
for a in (0,1):
 for b in (0,1):
  for c in (0,1):
   rhs=a+b+c-(a^b)-(a^c)-(b^c)+(a^b^c)
   assert rhs==4*a*b*c;identity.append([a,b,c,rhs])
grammar=[]
for instr in ('H q0','X_SQRT q0','T q0'):
 try:km.Circuit(instr);grammar.append(dict(instruction=instr,parsed=True))
 except ValueError as e:grammar.append(dict(instruction=instr,parsed=False,error=str(e)))
result=dict(status='EXACT_CCZ_IDENTITY_AND_RESOURCE_AUDIT_PASS',variants=rows,
            identity_cases=identity,t_depth_one_uses_clean_ancillas=4,
            chemistry_and_DQI_admissible=False,reason='Both official contracts prohibit Z_POW.',
            invsqrt_single_native_CCZ_replacement_improves=False,
            extra_effective_toffoli_per_CCZ=0.75,depth_is_not_scored=True,
            parser_probes=grammar,full_official_verifier_run=False,
            sources=['https://arxiv.org/html/2409.13809v2#S2.F3',
                     'https://www.mathstat.dal.ca/~selinger/papers/toffoli.pdf'])
(ROOT/'ccz_figure3_resource_check.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
