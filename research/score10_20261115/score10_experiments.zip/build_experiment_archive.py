"""Package the completed code/proofs; never include third-party paper bodies."""
from pathlib import Path
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'deliverables'

def main():
    OUT.mkdir(exist_ok=True)
    paths=[]
    for folder in ['alternative_arch','shared_synthesis','invsqrt_arch','audit_cost']:
        for p in (ROOT/folder).rglob('*'):
            if not p.is_file(): continue
            rel=p.relative_to(ROOT)
            if set(rel.parts)&{'__pycache__','portable_rebuild','gl3_rebuild_check'}: continue
            if p.suffix not in {'.py','.cpp','.md','.json','.txt','.log','.kmb','.kmx','.npz','.u32'}: continue
            paths.append(p)
    paths += [ROOT/'IMPLEMENTATION_REVIEW_JA.md', ROOT/'score10_official_gate.py',
              ROOT/'score10_official_gate.json', Path(__file__),
              ROOT/'literature/ccz_figure3_resource_check.py', ROOT/'literature/ccz_figure3_resource_check.json',
              ROOT/'literature/native_ccz.kmb', ROOT/'literature/seven_t_depth_one.kmb']
    paths=sorted(set(paths))
    records=[dict(path=p.relative_to(ROOT).as_posix(),bytes=p.stat().st_size,
                  sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in paths]
    manifest=dict(date='2026-11-15',accepted_score=27.32784222155277,
                  status='NO_IMPROVING_WHOLE_CANDIDATE',full_official_verifier_run=False,
                  archive_scope='New code, actual circuits, data, original receipts, independent proofs, and own report. No third-party paper texts.',
                  external_dependencies='Existing gvqcc score9 helpers, accepted score8 archive, unmodified official verifier, Kickmix, NumPy, C++17; Z3 for SAT experiments.',
                  files=records)
    payload=(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n').encode()
    (OUT/'experiment_manifest.json').write_bytes(payload)
    archive=OUT/'score10_experiments.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in paths:
            info=zipfile.ZipInfo(p.relative_to(ROOT).as_posix(),date_time=(2026,11,15,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
            z.writestr(info,p.read_bytes())
        info=zipfile.ZipInfo('experiment_manifest.json',date_time=(2026,11,15,0,0,0))
        info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o644<<16
        z.writestr(info,payload)
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None
        for r in records:
            b=z.read(r['path']);assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
    b=archive.read_bytes()
    receipt=dict(archive=archive.name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest(),
                 git_blob_sha1=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),
                 file_count=len(records),manifest_sha256=hashlib.sha256(payload).hexdigest(),
                 all_archive_entries_verified=True)
    (OUT/'experiment_archive_receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt))

if __name__=='__main__':main()
