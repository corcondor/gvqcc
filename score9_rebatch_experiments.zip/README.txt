RESEARCH FIXTURES; NOT A SUBMISSION

The J=4 family is exactly correct under the recorded checks, but costs
5197 loader Toffoli per pass and is worse than the accepted score8.
It was not adopted or submitted. The retained local score is
27.32784222155277; the requested target28 was not reached.

Source, mathematical scope, and independent reviews:
https://github.com/corcondor/gvqcc/pull/6
Entry point: score9_rebatch_results.md
